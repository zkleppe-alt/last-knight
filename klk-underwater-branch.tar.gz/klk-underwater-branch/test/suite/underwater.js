// suite/underwater.js — THE DEEP: the underwater branch.
//
// Measured, not eyeballed. Every check drives the REAL game: real key events,
// the real loop() pumped frame by frame, the real save/load path. A new
// place.kind has bitten nine systems before, so the core of this suite enters
// 'underwater' and runs loop() through every system that branches on kind.
const K = require('../boot.js');
const { ok, check, done, fmt } = require('./lib.js');
const fs = require('fs'), path = require('path'), cp = require('child_process');
console.log('underwater');
// While apply_kit.py is part-way through the kit, the hooks are not all in yet and
// this suite would fail by design. It stands down then — and ONLY then — and runs
// in full after the last edit and in every ordinary ./gate.sh.
if (process.env.UW_KIT_PARTIAL === '1') { console.log('  (kit partly applied — the underwater suite runs after the last edit)'); console.log('  ── underwater: 0 passed, 0 failed'); process.exit(0); }
const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');
const live = fs.readFileSync(__dirname + '/../game.stripped.js', 'utf8');   // comments and strings blanked

// ── helpers ────────────────────────────────────────────────────────────────
const run = (n = 1) => K.frames(n);
const at = () => K.$('[Math.floor((player.x+TILE/2)/TILE), Math.floor((player.y+TILE/2)/TILE)]');
const settle = () => { for (let i = 0; i < 90 && K.$('cross.t>0'); i++) run(1); run(2); };
const closeTalk = () => { for (let i = 0; i < 40 && K.$('dialogue.open'); i++) K.$('closeDialogue()'); };
const A = () => { K.key.tap('j'); settle(); };                   // the A key: aPress() -> doAction(true)
const face = d => K.$(`player.dir='${d}'`);
const standAt = (x, y, d) => K.$(`player.x=${x}*TILE; player.y=${y}*TILE; player.dir='${d || 'down'}';`);
// 60 frames through the real rAF queue. (_legacy: called loop() directly 60 times —
// but every call schedules its own next frame, so each check left 60 more loop
// chains running and later frames ran hundreds of game loops: a knight shot 730px
// in 20 frames and the suite crawled. One chain, the game's own, is the truth.)
const errs = () => { try { run(60); return null; } catch (e) { return String(e.stack || e).slice(0, 300); } };
const chains = () => K.$('globalThis.__rafPending.size');
const fresh = () => K.$(`applySaveData(JSON.parse(FRESH_STATE)); boot.done=true; dialogue.open=false; menu.open=false; intro.open=false;
  document.getElementById('gamemenu').classList.remove('open');`);
const seaDragon = () => K.$(`player.pet={id:'steadfast',form:2}; player.mounted=true; player.boating=false; player.level=20;`);

// ═══ 1. the switch, the block, the hooks ═══════════════════════════════════
ok('one on/off switch, on', /\nconst UW_ON = true;\n/.test(raw));
ok('one self-contained block, clearly marked', raw.includes('🌊 THE DEEP — a secret underwater world') && raw.includes('// ═══ end of THE DEEP ═══'));
const hooks = {
  save: /underwater: \(typeof uwSave==='function' \? uwSave\(\) : undefined\)/,
  load: /uwLoad\(s\.underwater\)/,
  where: /if\(w\.kind==='underwater'\)\{ if\(typeof uwRestore==='function' && uwRestore\(\)\) return true; bail\(\); return false; \}/,
  loop: /if\(place\.kind==='underwater'\)\{ uwFrame\(dt\); requestAnimationFrame\(loop\); return; \}/,
  draw: /if\(place\.kind==='underwater'\)\{ uwDraw\(\); return; \}/,
  action: /if\(typeof uwAction==='function' && uwAction\(\)\) return true;/,
  attack: /if\(place\.kind==='underwater'\) return;/,
  marker: /uwMarkerAt\(tx,ty\)\) uwDrawDiveMarker\(x,y\)/,
  music: /if\(place\.kind==='underwater'\) return uwMusic\(\);/,
  livery: /if\(L\.flag==='deepwater'\) return/,
  decor: /default: if\(typeof uwDrawDecor==='function'\) uwDrawDecor\(d,x,y\); break;/,
  steed: /uwCoralSteed\(ox,oy,id,view,frame,rider,mirror\)\) return;/,
  pettab: /html \+= uwBardingRows\(\);/,
  quests: /uwQuestRows\(active, done\);/,
  eldan1: /quests\.goldenFish='done'; inventory\.goldenFish=0; if\(typeof uwEldanGift==='function'\) uwEldanGift\(1\);/,
  eldan2: /quests\.kindness='done'; if\(typeof uwEldanGift==='function'\) uwEldanGift\(2\);/,
};
const missing = Object.keys(hooks).filter(k => !hooks[k].test(raw));
check('all 16 hooks are in place', missing, []);
// live, not a _legacy comment: the stripped source still has the call
ok('and they are live code, not comments', ['uwSave(', 'uwLoad(', 'uwRestore(', 'uwFrame(', 'uwDraw(', 'uwAction(', 'uwMarkerAt(', 'uwMusic(', 'uwDrawDecor(', 'uwCoralSteed(', 'uwBardingRows(', 'uwQuestRows('].every(n => live.split(n).length > 2), 'each called outside its own definition');

// ═══ 2. the map: two rooms ═══════════════════════════════════════════════
fresh(); K.$("uwBuildGrid('courts')");
check('the courts are 52 wide, 48 tall (the Reef Garden, expanded)', K.$('[uw.W, uw.H]'), [52, 48]);
K.$("uwBuildGrid('temple')");
check('the house within is 30 wide, 42 tall', K.$('[uw.W, uw.H]'), [30, 42]);
check('every row the same width, in both rooms', K.$('["courts","temple"].every(r=>UW_ROOMS[r].rows.every(x=>x.length===UW_ROOMS[r].rows[0].length))'), true);
check('no randomness: two builds are identical', K.$("(()=>{ uwBuildGrid('temple'); const a=JSON.stringify(uw.grid); uwBuildGrid('temple'); return a===JSON.stringify(uw.grid); })()"), true);
check('the house keeps the true 1:2:1 proportions (tiles = 2 cubits): most holy 10x10, holy 10x20, porch 10x5',
  K.$(`(()=>{ uwBuildGrid('temple'); const g=uw.grid, rows=(y0,y1)=>{ let n=0; for(let y=y0;y<=y1;y++) for(let x=10;x<=19;x++) if(g[y][x]!==UW_T.CEDAR) n++; return n; };
    return [rows(2,11), rows(13,32), rows(34,38)]; })()`), [100, 200, 50]);
// flood fill with the game's own uwWalkable, room by room
const flood = (room, start, open) => K.$(`(()=>{ const keep=uwSaved.opened; uwSaved.opened=${open}; uwBuildGrid('${room}');
  const W=uw.W,H=uw.H, seen=new Set(), st=[${JSON.stringify(start)}]; seen.add(st[0].join(','));
  while(st.length){ const [x,y]=st.pop(); for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny;
    if(nx<0||ny<0||nx>=W||ny>=H||seen.has(k)||!uwWalkable(nx,ny)) continue; seen.add(k); st.push([nx,ny]); } }
  const near=(p)=>[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>seen.has((p[0]+dx)+','+(p[1]+dy)));
  const R=UW_ROOMS['${room}'], out={};
  for(const k in R.chests) out['chest '+k]=near(R.chests[k]);
  for(const k in R.tablets) out['tablet '+k]=near(R.tablets[k]);
  for(const k in R.npc) out['npc '+k]=near(R.npc[k]);
  if('${room}'==='courts'){ for(const k in UW_ENTRY) out['entry '+k]=seen.has(UW_ENTRY[k].join(',')); out['the doorway']=UW_DOOR.every(d=>seen.has(d.join(','))); }
  else { for(const k in UW_PRAYER) out['lamp '+k]=near(UW_PRAYER[k]); out['humble chest']=near([14,5])||near([15,5]); out['the way out']=UW_EXIT.every(d=>seen.has(d.join(','))); }
  uwSaved.opened=keep; uwBuildGrid('courts'); return out; })()`);
for (const e of ['A', 'B', 'C', 'D', 'E']) { const c = flood('courts', K.$(`UW_ENTRY.${e}`), false);
  check(`courts from entry ${e}: every entry, the doorway, every chest, tablet and person`, Object.keys(c).filter(k => !c[k]), []); }
const shut = flood('temple', K.$('UW_ARRIVE'), false), open = flood('temple', K.$('UW_ARRIVE'), true);
check('the house, doors shut: everything reachable except what lies beyond the inner doors',
  Object.keys(shut).filter(k => !shut[k]).sort(), ['humble chest', 'tablet micah', 'tablet rec3']);
check('doors open: everything in the house reachable, and the way out', Object.keys(open).filter(k => !open[k]), []);

// ═══ 3. the world fingerprint: markers are drawn, never stamped ════════════
check('every dive spot is real deep water (tile 3) on the untouched WORLD', K.$('UW_SPOTS.map(s=>WORLD[s.y][s.x])'), [3, 3, 3, 3, 3]);
check('and so is its whole 3x3 dive zone', K.$('UW_SPOTS.every(s=>[-1,0,1].every(dy=>[-1,0,1].every(dx=>WORLD[s.y+dy][s.x+dx]===3)))'), true);
ok('nothing in the block writes WORLD', !/WORLD\[[^\]]+\]\[[^\]]+\]\s*=[^=]/.test(raw.slice(raw.indexOf('🌊 THE DEEP — a secret'), raw.indexOf('// ═══ end of THE DEEP ═══'))));
{ // the marker really draws: pixels at a spot differ from a plain deep-water tile
  // the SAME tile at the SAME moment, with and without its spot registered — so tile detail can't fake a difference
  const shot = (mark) => K.$(`(()=>{ ctx.setTransform(1,0,0,1,0,0); ctx.canvas.width=32; ctx.canvas.height=32; place={kind:'overworld'}; Date.now=()=>5000;
    const keep=UW_SPOTS[0].x; if(!${mark}) UW_SPOTS[0].x=-99;
    drawTile(3,0,0,170,40); UW_SPOTS[0].x=keep; const d=ctx.getImageData(0,0,16,16).data; let s=0; for(let i=0;i<d.length;i+=4) s+=d[i]*3+d[i+1]*5+d[i+2]*7; return s; })()`);
  const on = shot(true), off = shot(false);
  ok('the dive marker is drawn at a spot (same tile, same instant, measured)', on !== off && shot(false) === off, `${off} -> ${on}`);
}

// ═══ 4. diving: only the Sea Dragon ════════════════════════════════════════
fresh(); K.$(`place={kind:'overworld'}; demons=[]; spawnDemons();`);
K.$(`player.pet={id:'faithful',form:2}; player.mounted=true;`); standAt(170, 40, 'down');
A();
check('the Lion at a dive spot: still on the overworld', K.$('place.kind'), 'overworld');
ok('and told why (the hint)', /Only a creature of the sea could carry you down/.test(K.$('banner.innerHTML')), K.$('banner.innerHTML').slice(0, 80));
K.$(`player.pet={id:'unicorn',form:2}; player.mounted=true;`); K.$('banner.innerHTML=""'); A();
check('the Unicorn (flying over it): no dive either', K.$('place.kind'), 'overworld');
ok('and the same hint', /Only a creature of the sea/.test(K.$('banner.innerHTML')));
K.$(`player.pet={id:'steadfast',form:1}; player.mounted=false; player.boating=true;`); K.$('banner.innerHTML=""'); A();
check('the boat: no dive', K.$('place.kind'), 'overworld');
ok('but a hint', /Only a creature of the sea/.test(K.$('banner.innerHTML')));
K.$(`player.boating=false;`);
// the Sea Dragon, one tile off centre (still in the 3x3 zone)
seaDragon(); standAt(171, 39, 'down'); K.$('demons=[]; spawnDemons();'); const demonsBefore = K.$('demons.length');
A();
check('the Sea Dragon dives', K.$('place.kind'), 'underwater');
check('and arrives in the courts, just off entry current A', [K.$('uw.room'), ...at()], ['courts', K.$('UW_ENTRY.A[0]'), K.$('UW_ENTRY.A[1]') - 1]);
check('still riding', K.$('player.mounted'), true);
check('the overworld demons are left above', [demonsBefore > 0, K.$('demons.length')], [true, 0]);
check('the way home is remembered: the dive spot', K.$('[lastOverworld.x/TILE, lastOverworld.y/TILE, uwSaved.from]'), [170, 40, 'A']);
ok('the first dive is marked visited', K.$('uwSaved.visited.A') === true);
check('a dive from outside the zone does nothing', (() => { K.$(`place={kind:'overworld'};`); seaDragon(); standAt(173, 40, 'down'); K.$('banner.innerHTML=""'); A(); const k = K.$('place.kind'); return k; })(), 'overworld');

// ═══ 5. the new place.kind through the REAL loop() ═════════════════════════
fresh(); seaDragon(); K.$(`place={kind:'overworld'};`); standAt(230, 200); A(); closeTalk();
check('dove at D', [K.$('place.kind'), K.$('uwSaved.from')], ['underwater', 'D']);
check('60 frames of the real loop(), no errors', errs(), null);
check('and the game runs exactly one frame chain (the underwater hook reschedules once)', chains(), 1);
check('minimap: hidden underwater', K.$(`document.getElementById('minimap').style.display`), 'none');
check('mount button: hidden (you cannot dismount below)', K.$(`document.getElementById('mountBtn').style.display`), 'none');
check('the surface button: shown', K.$(`document.getElementById('uwSurfaceBtn').style.display`), 'flex');
K.$('RTRACKS.underwater.dead=false; RTRACKS.chapel.dead=false;');   // the harness has no audio: every recording reads dead unless told
check('music: underwater.mp3, until it proves missing', K.$('musicFor()'), 'rt:underwater');
K.$('RTRACKS.underwater.dead=true;');
check('then the chapel recording', K.$('musicFor()'), 'rt:chapel');
K.$('RTRACKS.underwater.dead=false;');
{ K.$(`document.getElementById('loc').textContent='The Open Road'`); run(2);
  check('the HUD says where you are below', K.$(`document.getElementById('loc').textContent`), 'The Drowned Courts');
  K.$("uwBuildGrid('temple')");
  standAt(14, 20, 'up'); run(2); check('and names the Holy Place', K.$(`document.getElementById('loc').textContent`), 'The Holy Place');
  standAt(14, 8, 'up'); run(2); check('and the Most Holy Place', K.$(`document.getElementById('loc').textContent`), 'The Most Holy Place');
  standAt(4, 30, 'up'); run(2); check('and the side chambers', K.$(`document.getElementById('loc').textContent`), 'The Side Chambers');
  K.$("uwBuildGrid('courts')"); const [ex, ey] = K.$('UW_ENTRY.D'); standAt(ex, ey - 1, 'up'); run(2); }
{ const t0 = K.$('dayClock.t'); run(30); ok('the day clock still turns below', K.$('dayClock.t') > t0, `${t0} -> ${K.$('dayClock.t')}`); }
{ const lo = K.$('[lastOverworld.x,lastOverworld.y]'); K.key.down('d'); run(40); K.key.up('d'); run(1);
  check('moving below never overwrites the way home', K.$('[lastOverworld.x,lastOverworld.y]'), lo); }
{ const p0 = K.$('[player.x,player.y]'); K.key.down('a'); run(20); K.key.up('a'); run(1);   // away from the wall the last check left him against
  const p1 = K.$('[player.x,player.y]'); ok('the real keys swim the knight (measured)', p1[0] !== p0[0] || p1[1] !== p0[1], `${p0} -> ${p1}`); }
{ // swim hard into the kelp wall: the tile under him must stay swimmable
  standAt(44, 25, 'right'); K.key.down('d'); run(120); K.key.up('d'); run(1);
  const [x, y] = at(); ok('the kelp wall stops him', K.$(`uwWalkable(${x},${y})`) && x <= 48, `stopped at ${x},${y}`); }
{ // the house is a building: its walls stop him; only the doorway lets him in
  standAt(21, 15, 'up'); K.key.down('w'); run(120); K.key.up('w'); run(1);
  check('swimming into the front wall: still in the courts, stopped below it', [K.$('uw.room'), at()[1] >= 14], ['courts', true]); }
{ // combat, arrows, dodge, mounting: all deliberately inert
  { const keep = K.$('place.kind'); K.$(`place={kind:'overworld'}; player.swing=0; player.combo=0; player.dashing=0;`); K.$('doAttack()');
    ok('control: on the overworld the same call swings', K.$('player.swing>0 || player.combo>0')); K.$(`place={kind:'${'underwater'}'}; player.swing=0;`); }
  K.$('player.swing=0; player.combo=0;'); K.$('doAttack()');
  check('no sword swings below (doAttack)', K.$('[player.swing, player.combo]'), [0, 0]);
  K.key.down('j', { repeat: true }); K.key.up('j'); run(2);
  check('a held attack key does nothing either', K.$('player.swing'), 0);
  const d0 = K.$('player.dashing'); K.$('doDodge()'); check('no dodge below', K.$('player.dashing'), d0);
  K.$('toggleMount()'); check('cannot dismount below', K.$('player.mounted'), true);
  check('no arrows in flight', K.$('(typeof arrows==="undefined"||!arrows.length)'), true); }
{ // menus: the menu freezes the world and draws it through the draw() hook
  K.$('toggleMenu()'); check('the menu opens underwater', K.$('menu.open'), true);
  check('and the frame behind it draws, no errors', errs(), null);
  check('still underwater behind it', K.$('place.kind'), 'underwater');
  K.$('toggleMenu()'); }
{ // dialogue freezes the swim
  K.$(`say(['a line'])`); const p0 = K.$('[player.x,player.y]'); K.key.down('a'); run(20); K.key.up('a');
  check('dialogue holds the knight still', K.$('[player.x,player.y]'), p0); closeTalk(); }
{ // the pixels: underwater draws its own world, not the overworld at these coordinates
  K.$(`ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0); draw();`);
  const d = K.$(`(()=>{ const c=ctx.canvas, g=c.getContext('2d').getImageData(0,0,c.width,c.height).data; let b=0,n=0; for(let i=0;i<g.length;i+=16){ n++; if(g[i+2]>g[i]+10) b++; } return b/n; })()`);
  ok('the view is sea-coloured (blue channel dominant over most of it)', d > 0.5, `blue-dominant ${(d * 100).toFixed(0)}%`); }

// ═══ 6. surfacing ══════════════════════════════════════════════════════════
{ // Ⓐ on a current: up at THAT current's spot (current C, though we dove at D)
  const [cx, cy] = K.$('UW_ENTRY.C'); standAt(cx, cy - 1, 'down'); A();
  check('Ⓐ at current C surfaces at spot C', [K.$('place.kind'), ...at()], ['overworld', 40, 170]);
  check('riding, with the demons back', [K.$('player.mounted'), K.$('demons.length') > 0], [true, true]);
  check('the mount button is back', K.$(`document.getElementById('mountBtn').style.display`), 'flex');
  run(2); check('the surface button hides', K.$(`document.getElementById('uwSurfaceBtn').style.display`), 'none'); }
{ // the U key: up where you went in
  seaDragon(); standAt(190, 234); A(); check('dove at E', K.$('uwSaved.from'), 'E');
  standAt(20, 55); K.key.tap('u'); settle();
  check('U surfaces at the spot you went in (E)', [K.$('place.kind'), ...at()], ['overworld', 190, 234]); }
{ // the ⬆ button, through its real listener
  seaDragon(); standAt(70, 120); A(); check('dove at B', K.$('uwSaved.from'), 'B');
  K.$(`document.getElementById('uwSurfaceBtn').dispatchEvent({type:'touchstart', preventDefault(){}})`); settle();
  check('the ⬆ button surfaces at B', [K.$('place.kind'), ...at()], ['overworld', 70, 120]); }

// ═══ 7. the Holy Place: Jonah's prayer ═════════════════════════════════════
fresh(); seaDragon(); K.$(`place={kind:'overworld'};`); standAt(170, 40); A(); closeTalk();
// ── into the house: through the doorway between the pillars, by the real keys ──
standAt(25, 15, 'up'); K.key.down('w'); for (let i = 0; i < 200 && K.$('uw.room') === 'courts'; i++) run(1); K.key.up('w'); settle(); closeTalk();
check('swim up through the doorway: into the house', [K.$('uw.room'), ...at()], ['temple', ...K.$('UW_ARRIVE')]);
ok('the first time, 1 Kings 6:7 greets you', K.$('uwSaved.met.house') === true);
check('and it plays inside', errs(), null);
{ standAt(14, 38, 'down'); K.key.down('s'); for (let i = 0; i < 200 && K.$('uw.room') === 'temple'; i++) run(1); K.key.up('s'); settle();
  check('swim down over the threshold: back out before the door', [K.$('uw.room'), ...at()], ['courts', ...K.$('UW_DOOR_IN')]);
  run(30); check('and not straight back in', K.$('uw.room'), 'courts');
  standAt(25, 15, 'up'); K.key.down('w'); for (let i = 0; i < 200 && K.$('uw.room') === 'courts'; i++) run(1); K.key.up('w'); settle(); }
{ // the side chambers open off the Holy Place, through the real walls
  standAt(11, 23, 'left'); K.key.down('a'); run(60); K.key.up('a'); run(1);
  ok('the west doorway leads into the chambers', at()[0] <= 8, `at ${at()}`);
  standAt(18, 24, 'right'); K.key.down('d'); run(60); K.key.up('d'); run(1);
  ok('and the east doorway too', at()[0] >= 21, `at ${at()}`);
  standAt(11, 16, 'left'); K.key.down('a'); run(60); K.key.up('a'); run(1);
  ok('but the cedar wall elsewhere holds', at()[0] >= 10, `at ${at()}`); }
const lamp = (id) => { const [x, y] = K.$(`UW_PRAYER.${id}`); standAt(x === 10 ? 11 : 18, y, x === 10 ? 'left' : 'right'); A(); closeTalk(); };
K.$('uwSaved.lamps=[]');
lamp('L2'); lamp('L5');
check('out of order: every flame gutters out', K.$('uwSaved.lamps'), []);
check('the doors stay shut', K.$('uwTile(14,12)'), K.$('UW_T.INNERDOOR'));
{ standAt(11, 18, 'left'); K.$('banner.innerHTML=""'); A(); check('a lampstand without words will not light', K.$('uwSaved.lamps'), []);
  ok('and says so (Ⓐ really reached it)', /bears no words/.test(K.$('banner.innerHTML'))); }
lamp('L2'); lamp('L4'); lamp('L5');
check('in order, they stay lit', K.$('uwSaved.lamps'), ['L2', 'L4', 'L5']);
check('lit lamps measured lit, the rest dark', K.$('UW_LAMPSTANDS.filter(([x,y])=>uwLampLit(x,y)).length'), 3);
check('the livery is not given yet', K.$('liveryUnlocked("deepwater")'), false);
lamp('L9');
check('the prayer whole: all ten blaze', K.$('UW_LAMPSTANDS.filter(([x,y])=>uwLampLit(x,y)).length'), 10);
check('the inner doors open', [K.$('uwTile(14,12)'), K.$('uwTile(15,12)')], [K.$('UW_T.GOLDFLOOR'), K.$('UW_T.GOLDFLOOR')]);
check('the Deepwater Pearl is given', K.$('liveryUnlocked("deepwater")'), true);
{ K.$('player.livery="deepwater"'); check('and can be worn', K.$('currentLivery()'), 'deepwater'); K.$('player.livery="azure"'); }
{ // walk through: the Most Holy Place, the humble chest and the Wooden Cross
  standAt(14, 6, 'up'); run(2); closeTalk();
  const inv0 = K.$('homesteadDecor.inv.uw_woodenCross|0'); A(); closeTalk();
  check('the humble chest holds the Wooden Cross', K.$('homesteadDecor.inv.uw_woodenCross|0') - inv0, 1);
  A(); closeTalk(); check('once only', K.$('homesteadDecor.inv.uw_woodenCross|0') - inv0, 1);
  standAt(17, 9, 'up'); A(); closeTalk();
  ok('the Micah stone enters the codex', K.$('codex.seen.some(e=>e.ref==="Micah 7:19")')); }

// ═══ 8. tablets, Tirzah's questions, the coral barding ═════════════════════
{ const take = (room, id) => { K.$(`uwBuildGrid('${room}')`); const [x, y] = K.$(`UW_ROOMS.${room}.tablets.${id}`);
    const d = K.$(`[[0,1,'up'],[1,0,'left'],[-1,0,'right'],[0,-1,'down']].find(([dx,dy])=>uwWalkable(${x}+dx,${y}+dy))`);
    standAt(x + d[0], y + d[1], d[2]); A(); closeTalk(); };
  take('courts', 'rec1'); take('temple', 'rec2'); take('temple', 'rec3');
  check('three record tablets taken', K.$('["rec1","rec2","rec3"].map(k=>!!uwSaved.tablets[k])'), [true, true, true]);
  check('and gone from their stands', K.$(`[["courts","rec1"],["temple","rec2"],["temple","rec3"]].map(([r,k])=>{ uwBuildGrid(r); return uwTile(...UW_ROOMS[r].tablets[k])===UW_T.TABLET; })`), [false, false, false]);
  K.$("uwBuildGrid('temple')"); const [tx, ty] = K.$('UW_ROOMS.temple.npc.tirzah');
  standAt(tx - 1, ty, 'right'); A(); closeTalk();                     // first meeting
  standAt(tx - 1, ty, 'right'); A(); closeTalk();                     // the quiz opens after her lines
  check("Tirzah's questions open", K.$('!!uw.quiz'), true);
  run(5); check('the world holds while she asks', K.$('uw.quiz.i'), 0);
  // a wrong answer, through the real ▼ key and Ⓐ
  K.key.down('s'); run(1); K.key.up('s'); run(1);   // held for a frame (the quiz reads key edges): ▼ once = A, and the answer is B
  A();
  check('a wrong answer is marked', [K.$('uw.quiz.answered'), K.$('uw.quiz.pick===UW_QUIZ[0].a')], [true, false]);
  A(); check('and asks again', K.$('uw.quiz.answered'), false);
  for (let q = 0; q < 3; q++) { K.$(`uw.quiz.pick=UW_QUIZ[uw.quiz.i].a`); A(); A(); }
  check('all three right: the questions close', K.$('uw.quiz'), null);
  closeTalk();
  check('the Coral Barding is owned', K.$('!!player.mountSkinOwned.uwcoral'), true);
  K.$(`toggleMountSkin('uwcoral')`); check('and worn', K.$('player.mountSkin'), 'uwcoral');
  ok('the Pet tab offers it', /Coral Barding/.test(K.$('uwBardingRows()')));
  const shot = (skin) => K.$(`(()=>{ player.mountSkin=${skin}; ctx.setTransform(1,0,0,1,0,0); ctx.canvas.width=48; ctx.canvas.height=48; ctx.clearRect(0,0,48,48);
      drawSteedSprite(8,8,'steadfast','back',0,true,false); const d=ctx.getImageData(0,0,48,48).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0xd8&&d[i+1]===0x58&&d[i+2]===0x6a) n++; return n; })()`);
  const pal0 = K.$('JSON.stringify(STEED2.PAL.steadfast)');
  const plain = shot('null'), coral = shot("'uwcoral'");
  ok('the barding paints the shell coral (measured pixels)', plain === 0 && coral > 20, `coral pixels ${plain} -> ${coral}`);
  check('and the steed palette is restored after every draw', K.$('JSON.stringify(STEED2.PAL.steadfast)'), pal0);
  const lion = K.$(`(()=>{ player.mountSkin='uwcoral'; const P=JSON.stringify(STEED2.PAL.faithful); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,48,48);
      drawSteedSprite(8,8,'faithful','back',0,true,false); const d=ctx.getImageData(0,0,48,48).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0xd8&&d[i+1]===0x58&&d[i+2]===0x6a) n++; return [n, P===JSON.stringify(STEED2.PAL.faithful)]; })()`);
  check('it never touches another steed (the Lion under the same skin setting)', lion, [0, true]);
  K.$(`player.pet={id:'steadfast',form:2};`); }

// ═══ 9. chests, pearls, Zebulun ════════════════════════════════════════════
{ K.$("uwBuildGrid('courts')"); const g0 = K.$('gold');
  for (const k of ['pearl_g1', 'pearl_g2', 'pearl_g3']) { const [x, y] = K.$(`UW_ROOMS.courts.chests.${k}`);
    const d = K.$(`[[0,1,'up'],[0,-1,'down'],[1,0,'left'],[-1,0,'right']].find(([dx,dy])=>uwWalkable(${x}+dx,${y}+dy))`);
    standAt(x + d[0], y + d[1], d[2]); A(); closeTalk(); }
  check('three courts pearl chests: five pearls', K.$('uwSaved.pearls'), 5);
  const [zx, zy] = K.$('UW_ROOMS.courts.npc.zebulun');
  standAt(zx - 1, zy, 'right'); A(); closeTalk();                    // he introduces himself first
  standAt(zx - 1, zy, 'right'); A(); closeTalk();
  check('Zebulun pays 120 a pearl', [K.$('gold') - g0, K.$('uwSaved.pearls'), K.$('uwSaved.sold')], [600, 0, 5]); }
{ const inv0 = K.$('homesteadDecor.inv.uw_coralPlanter|0'); const [x, y] = K.$('UW_ROOMS.courts.chests.dec_planter');
  standAt(x, y + 1, 'up'); A(); closeTalk();
  check('a decoration chest: into the Home inventory', K.$('homesteadDecor.inv.uw_coralPlanter|0') - inv0, 1);
  ok('placeable like any other decoration', K.$(`DECOR_ITEMS.uw_coralPlanter && DECOR_ITEMS.uw_coralPlanter.kind==='uwCoralPlanter'`));
  const px = (kind, w) => K.$(`(()=>{ ctx.setTransform(1,0,0,1,0,0); ctx.canvas.width=40; ctx.canvas.height=40; ctx.clearRect(0,0,40,40); drawDecor({kind:'${kind}',w:${w}},2,6);
      const d=ctx.getImageData(0,0,40,40).data; let n=0; for(let i=3;i<d.length;i+=4) if(d[i]>0) n++; return n; })()`);
  const drawn = ['uwCoralPlanter:1', 'uwPearlFountain:2', 'uwBellArbor:2', 'uwWheelSign:1', 'uwWoodenCross:1'].map(s => { const [k, w] = s.split(':'); return [k, px(k, +w)]; });
  ok('all five decorations draw through drawDecor (measured pixels)', drawn.every(([, n]) => n > 30), drawn.map(([k, n]) => k + '=' + n).join(' ')); }
check('the Quests tab lists the deep once you have been down', K.$(`(()=>{ const a=[],d=[]; uwQuestRows(a,d); return [...a,...d].map(r=>r[0]).sort(); })()`),
  ['The Drowned House', 'The Keeper\u2019s Records', 'Treasures of the Deep'].sort());

// ═══ 10. saves: its own key; underwater reloads underwater ═════════════════
{ K.$("uwBuildGrid('courts')"); const [x, y] = [30, 30]; standAt(x, y, 'left');
  const s = K.$('JSON.parse(JSON.stringify(buildSaveData()))');
  check('the save says where: underwater', s.where.kind, 'underwater');
  check('the deep lives under its own key', ['v', 'from', 'at', 'opened', 'livery', 'barding', 'pearls'].every(k => k in s.underwater), true);
  check('with the exact spot and room', s.underwater.at, { x: x * 16, y: y * 16, room: 'courts' });
  check('and the surface as the fallback home', [s.where.home.x / 16, s.where.home.y / 16], [170, 40]);
  globalThis.__raw = JSON.stringify(s);
  K.$(`applySaveData(JSON.parse(FRESH_STATE)); place={kind:'overworld'};`);
  check('loading a slot while below hides the surface button', K.$(`document.getElementById('uwSurfaceBtn').style.display`), 'none');
  check('a fresh knight has never been down', K.$('[Object.keys(uwSaved.visited).length, uwSaved.opened, liveryUnlocked("deepwater")]'), [0, false, false]);
  K.$(`localStorage.setItem(slotKey(3), globalThis.__raw); loadGame(3);`);
  check('reloaded: underwater, exactly where he saved', [K.$('place.kind'), ...K.$('[player.x/TILE, player.y/TILE]')], ['underwater', x, y]);
  check('riding, the livery still his', K.$('[uw.room, player.mounted, uwSaved.opened, liveryUnlocked("deepwater")]'), ['courts', true, true, true]);
  check('and it plays', errs(), null);
  // saved inside the house: reloads inside the house, the inner doors still open
  K.$("uwBuildGrid('temple')"); standAt(14, 9, 'up'); const sIn = K.$('JSON.parse(JSON.stringify(buildSaveData()))');
  check('a save inside the house records the room', sIn.underwater.at, { x: 14 * 16, y: 9 * 16, room: 'temple' });
  globalThis.__raw = JSON.stringify(sIn); K.$(`applySaveData(JSON.parse(FRESH_STATE)); localStorage.setItem(slotKey(3), globalThis.__raw); loadGame(3);`);
  check('and reloads there, the inner doors open', [K.$('place.kind'), K.$('uw.room'), ...at(), K.$('uwTile(14,12)===UW_T.GOLDFLOOR')], ['underwater', 'temple', 14, 9, true]);
  globalThis.__raw = JSON.stringify(s);
  // a save made underwater, loaded where the Sea Dragon is gone (or by a build that does not know the deep): the surface
  const s2 = JSON.parse(globalThis.__raw); s2.player.pet = { id: 'faithful', form: 2 };
  globalThis.__raw = JSON.stringify(s2); K.$(`localStorage.setItem(slotKey(3), globalThis.__raw); loadGame(3);`);
  check('if it cannot go back down, it falls back to the surface at the dive spot', [K.$('place.kind'), ...at()], ['overworld', 170, 40]);
  // a corrupt/foreign underwater key cannot break a load
  const s3 = JSON.parse(globalThis.__raw); s3.underwater = { lamps: ['L2', 'bogus', 7], pearls: -4, visited: 'x', eldan: null };
  globalThis.__raw = JSON.stringify(s3);
  check('a garbled underwater key still loads', K.$(`(()=>{ localStorage.setItem(slotKey(3), globalThis.__raw); return loadGame(3).ok; })()`), true);
  check('and is cleaned', K.$('[uwSaved.lamps, uwSaved.pearls, typeof uwSaved.visited, typeof uwSaved.eldan]'), [['L2'], 0, 'object', 'object']); }

// ═══ 11. Eldan's trials give the missing starter lines ═════════════════════
{ fresh(); K.$(`player.pet={id:'grace',form:2}; player.barnPets=[]; quests.goldenFish='active'; inventory.goldenFish=1;`);
  K.$('sageTalk()'); closeTalk();
  check('the Golden Fish gives the first missing line, full-grown', K.$('player.barnPets'), [{ id: 'faithful', form: 2 }]);
  K.$(`quests.kindness='active'; inventory.sacredScroll=1; inventory.wheat=3;`); K.$('monkTalk()'); closeTalk();
  check('Kindness gives the second', K.$('player.barnPets'), [{ id: 'faithful', form: 2 }, { id: 'steadfast', form: 2 }]);
  K.$('uwEldanGift(1); uwEldanGift(2);');
  check('never twice', K.$('player.barnPets.length'), 2);
  K.$(`player.pet={id:'steadfast',form:2}; player.barnPets=[{id:'grace',form:2},{id:'faithful',form:2}]; uwSaved.eldan={fish:false,kind:false}; quests.goldenFish='done'; quests.kindness='done';`);
  K.$('uwEldanCheck(true)');
  check('a Steadfast knight who owns every line gets nothing extra', K.$('player.barnPets.length'), 2);
  const s = K.$(`(()=>{ applySaveData(JSON.parse(FRESH_STATE)); player.pet={id:'faithful',form:2}; quests.goldenFish='done'; quests.kindness='done';
      const d=JSON.parse(JSON.stringify(buildSaveData())); delete d.underwater; return d; })()`);
  globalThis.__raw = JSON.stringify(s); K.$(`localStorage.setItem(slotKey(3), globalThis.__raw); loadGame(3);`);
  check('retroactive: an old save with both trials done finds them waiting', K.$('player.barnPets.map(p=>p.id)'), ['grace', 'steadfast']);
  // and the path to the deep: swap to the Sea Dragon at the barn, then dive
  K.$(`openBarn(); barnSwap(player.barnPets.findIndex(p=>p.id==='steadfast')); closeBarn();`);
  check('a Lion knight can now bring out the Sea Dragon', K.$('player.pet'), { id: 'steadfast', form: 2 }); }

// ═══ 12. UW_ON = false: the whole branch goes quiet ════════════════════════
{ const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'uwoff-'));
  for (const f of ['boot.js', 'harness_env.js']) fs.copyFileSync(path.join(__dirname, '..', f), path.join(tmp, f));
  fs.writeFileSync(path.join(tmp, 'game.js'), raw.replace('\nconst UW_ON = true;\n', '\nconst UW_ON = false;\n'));
  fs.writeFileSync(path.join(tmp, 'game.stripped.js'), live.replace(/const UW_ON = true;/, 'const UW_ON = false;'));
  fs.symlinkSync(path.join(__dirname, '..', 'node_modules'), path.join(tmp, 'node_modules'));
  fs.writeFileSync(path.join(tmp, 'off.js'), `const K=require('./boot.js');
    K.$("applySaveData(JSON.parse(FRESH_STATE)); boot.done=true; place={kind:'overworld'}; player.pet={id:'steadfast',form:2}; player.mounted=true; player.x=170*TILE; player.y=40*TILE;");
    const r={}; r.dive=K.$("uwAction()"); K.$("doAction(true)"); r.kind=K.$("place.kind"); r.save=K.$("'underwater' in JSON.parse(JSON.stringify(buildSaveData()))");
    r.livery=K.$("'deepwater' in LIVERIES"); r.decor=K.$("Object.keys(DECOR_ITEMS).some(k=>k.startsWith('uw_'))"); r.track=K.$("'underwater' in RTRACKS");
    r.marker=K.$("uwMarkerAt(170,40)"); r.gift=K.$("uwEldanGift(1)");
    r.loop=K.$("(()=>{ try{ for(let i=0;i<30;i++) loop(performance.now()+i*16); return null; }catch(e){ return String(e).slice(0,120); } })()");
    process.stdout.write(JSON.stringify(r));`);
  let out; try { out = JSON.parse(cp.execFileSync('node', [path.join(tmp, 'off.js')], { cwd: tmp, encoding: 'utf8' })); } catch (e) { out = { error: String(e.stdout || e).slice(0, 300) }; }
  check('UW_ON=false: no dive, no save key, no livery, decor, track, marker or gift; plays',
    out, { dive: false, kind: 'overworld', save: false, livery: false, decor: false, track: false, marker: false, gift: null, loop: null });
  fs.rmSync(tmp, { recursive: true, force: true }); }

done('underwater');

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — ART (mockup stage; becomes the ART section of the
//  underwater block once approved). Same idiom as drawTile: px() on
//  a 16-px tile, hash-varied detail, Date.now() for slow animation.
// ════════════════════════════════════════════════════════════════
// Tile codes are LOCAL to the underwater grid (their own namespace:
// the overworld's WORLD never holds them, and the grid is rebuilt
// from code, never saved), so they cannot collide with retired codes.
const UW_T = { SAND:0, GRASS:1, CORAL:2, ROCK:3, KELP:4, FLAG:5, WALL:6, COLUMN:7,
               CURRENT:8, LAMP:9, CHEST:10, DOOR:11, TRENCH:12, DOME:13, TABLET:14 };
const _uwH = (x,y)=>((x*374761393+y*668265263)>>>0);

// ── the DIVE MARKER on the overworld: a dark, slow-turning eddy in deep
//    water with a thread of bubbles. Everyone can see it (Zak: "hint +
//    visible marker"); only the Sea Dragon can go down.
function uwDrawDiveMarker(x,y){
  const t=Date.now()/600;
  // the deep hole: two darker rings, reading as depth under the swells
  px(x+3,y+3,10,10,'#2c5a8e'); px(x+2,y+5,12,6,'#2c5a8e'); px(x+5,y+2,6,12,'#2c5a8e');
  px(x+5,y+5,6,6,'#1f4677'); px(x+4,y+6,8,4,'#1f4677'); px(x+6,y+4,4,8,'#1f4677');
  px(x+7,y+7,2,2,'#163a66');
  // the eddy: a dashed foam ring that slowly turns, so the spot catches the eye
  const ph=Math.floor(t*2)%4;
  for(let k=0;k<16;k++){ const an=k/16*Math.PI*2, rx=Math.round(7.5+Math.cos(an)*7), ry=Math.round(7.5+Math.sin(an)*7);
    if((k+ph)%4===0) px(x+rx,y+ry,2,1,'#e0f2fa'); else if((k+ph)%4===1) px(x+rx,y+ry,1,1,'#9fd0e8'); }
  const a=t%(Math.PI*2), bx=Math.round(7.5+Math.cos(a)*3.5), by=Math.round(7.5+Math.sin(a)*3.5);
  px(x+bx,y+by,1,1,'#7fb0d8');
  // a rising thread of bubbles
  const bp=Math.floor(Date.now()/180)%8;
  px(x+8,y+9-bp,1,1,'#e0f2fa');
  px(x+7,y+13-((bp+4)%8),1,1,'#cfe6f2');
}

// ── floor tiles ──
function uwFloor(x,y,tx,ty){
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#a2a88c');                                   // pale sea-sand
  px(x+(h%9),y+3+(h>>4)%3,6,1,'#b4ba9c');                       // ripples
  px(x+((h>>8)%8),y+10+(h>>12)%3,7,1,'#b4ba9c');
  px(x+((h>>6)%12),y+7,4,1,'#8c927a');
  if((h&31)===5){ px(x+4,y+12,2,1,'#e8e0d0'); px(x+5,y+11,1,1,'#f4ece0'); }   // a shell
  if((h&63)===9){ px(x+10,y+5,2,2,'#c8687a'); px(x+10,y+5,1,1,'#e8909e'); } // a starfish
}
function uwFlag(x,y,tx,ty){                                     // drowned flagstones
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#7e8a86');
  px(x,y+7,TILE,1,'#5e6a68'); px(x+(ty&1?4:10),y,1,7,'#5e6a68'); px(x+(ty&1?11:3),y+8,1,8,'#5e6a68');
  px(x+1,y+1,6,1,'#95a19c'); px(x+1,y+9,8,1,'#95a19c');
  if(h%5===0){ px(x+2+(h>>5)%9,y+3,3,2,'#5f8a5a'); px(x+3+(h>>5)%9,y+2,1,1,'#78a870'); } // algae
  if(h%11===0){ px(x+9,y+11,4,1,'#6a7672'); px(x+10,y+12,2,1,'#6a7672'); }      // crack
}

// ── the tile switch for the underwater grid ──
function uwDrawTile(t,x,y,tx,ty){
  const h=_uwH(tx,ty), now=Date.now();
  switch(t){
    case UW_T.SAND: uwFloor(x,y,tx,ty); break;
    case UW_T.GRASS: {                                          // seagrass: sways, walkable
      uwFloor(x,y,tx,ty);
      const s=Math.round(Math.sin(now/700+tx*0.9+ty*0.4));
      for(let i=0;i<4;i++){ const bx=x+2+i*4+((h>>i)&1), ht=6+((h>>(i*3))%5);
        px(bx,y+15-ht,1,ht,'#3f8a5a'); px(bx+s,y+15-ht-2,1,3,'#5cae70'); }
      break; }
    case UW_T.CORAL: {                                          // coral head: solid, colour by hash
      uwFloor(x,y,tx,ty);
      const C=[['#d8586a','#f08a96','#9a3446'],['#e8905a','#f8b888','#a85a2e'],
               ['#9a6ac8','#c49ae8','#5e3a88'],['#e8c85a','#f8e498','#a8882e']][h%4];
      if((h>>3)&1){ // branching
        px(x+4,y+13,8,2,C[2]); px(x+7,y+4,2,10,C[2]);
        px(x+2,y+3,3,9,C[0]); px(x+11,y+2,3,10,C[0]); px(x+6,y+2,4,3,C[0]);
        px(x+4,y+8,3,2,C[0]); px(x+9,y+7,2,2,C[0]);
        px(x+2,y+2,3,1,C[1]); px(x+11,y+1,3,1,C[1]); px(x+6,y+1,4,1,C[1]);
        px(x+3,y+5,1,3,C[1]); px(x+12,y+4,1,3,C[1]);
      } else {      // brain / mound
        px(x+1,y+5,14,10,C[2]); px(x+2,y+3,12,11,C[0]); px(x+4,y+2,8,2,C[0]);
        px(x+3,y+6,10,1,C[1]); px(x+4,y+9,8,1,C[1]); px(x+5,y+4,6,1,C[1]); px(x+4,y+12,8,1,C[1]);
        px(x+3,y+14,10,1,'#6a6450');
      }
      break; }
    case UW_T.ROCK: {
      uwFloor(x,y,tx,ty);
      px(x+1,y+4,14,11,'#4e5a60'); px(x+2,y+3,12,2,'#5e6a70'); px(x+2,y+4,6,2,'#74828a');
      px(x+1,y+14,14,1,'#343e44'); if(h&1) px(x+9,y+8,3,2,'#3e8a5a');
      break; }
    case UW_T.KELP: {                                           // tall kelp: a soft wall
      px(x,y,TILE,TILE,'#2e5a52');
      const s=Math.round(Math.sin(now/900+tx)*1.5);
      for(let i=0;i<3;i++){ const bx=x+2+i*5+((h>>i)&1);
        px(bx+s,y,2,TILE,'#3e7a4a'); px(bx+s+1,y+(i*5+h)%12,3,3,'#5a9a52'); px(bx+s-2,y+(i*7+h*3)%12,3,2,'#4e8a4a'); }
      break; }
    case UW_T.FLAG: uwFlag(x,y,tx,ty); break;
    case UW_T.WALL: {                                           // drowned masonry
      px(x,y,TILE,TILE,'#5a6664');
      for(let r=0;r<4;r++){ const o=(r&1)?4:0; px(x,y+r*4,TILE,1,'#434e4c');
        px(x+o,y+r*4,1,4,'#434e4c'); px(x+o+8,y+r*4,1,4,'#434e4c'); px(x+o+1,y+r*4+1,6,1,'#6e7a78'); }
      if(h%3===0){ px(x+2,y+12,5,4,'#4e7a52'); px(x+3,y+11,2,1,'#6a9a62'); }
      break; }
    case UW_T.COLUMN: {                                         // a standing column, one tile
      uwFlag(x,y,tx,ty);
      px(x+3,y+13,10,2,'#5e6a68'); px(x+5,y+1,6,13,'#9aa6a2'); px(x+5,y+1,2,13,'#b8c4c0');
      px(x+10,y+1,1,13,'#6e7a78'); px(x+4,y,8,2,'#aab6b2'); px(x+8,y+4,1,8,'#8a9692');
      if(h&1){ px(x+5,y+9,6,3,'#4e7a52'); px(x+6,y+8,2,1,'#6a9a62'); }
      break; }
    case UW_T.CURRENT: {                                        // rising current: the way up
      uwFloor(x,y,tx,ty);
      px(x+2,y+2,12,12,'rgba(200,236,248,0.22)'); px(x+4,y+1,8,14,'rgba(200,236,248,0.18)');
      for(let i=0;i<5;i++){ const yy=(15-((Math.floor(now/90)+i*5+(h&7))%16));
        px(x+3+((i*5+h)%10),y+yy,(i&1)?2:1,(i&1)?2:1,'#eef8fc'); }
      px(x+1,y+1,14,1,'rgba(238,248,252,0.5)'); px(x+1,y+14,14,1,'rgba(238,248,252,0.5)'); px(x+1,y+1,1,14,'rgba(238,248,252,0.5)'); px(x+14,y+1,1,14,'rgba(238,248,252,0.5)');
      px(x+7,y+6,2,4,'rgba(255,255,255,0.35)');
      break; }
    case UW_T.LAMP: {                                           // sea-lamp on a post: lit via uwLampLit
      uwFlag(x,y,tx,ty);
      const lit = typeof uwLampLit==='function' && uwLampLit(tx,ty);
      px(x+7,y+6,2,9,'#5e6a68'); px(x+5,y+14,6,1,'#434e4c');
      px(x+4,y+1,8,6,'#434e4c'); px(x+5,y+2,6,4, lit?'#fff2a8':'#2e3a3e');
      if(lit) px(x+6,y+3,4,2,'#fffbe0');
      px(x+4,y+1,8,1,'#6e7a78');
      break; }
    case UW_T.CHEST: {
      uwFloor(x,y,tx,ty);
      px(x+2,y+6,12,8,'#5a3e26'); px(x+2,y+6,12,3,'#7a5a36'); px(x+2,y+9,12,1,'#3a2816');
      px(x+7,y+8,2,3,'#c9a94a'); px(x+2,y+6,1,8,'#8a6a3a'); px(x+13,y+6,1,8,'#8a6a3a');
      px(x+3,y+13,4,2,'#3e7a5a'); px(x+10,y+5,2,1,'#e8e0d0');                 // weed + a pearl
      break; }
    case UW_T.DOOR: {                                           // temple doors: sealed bronze
      px(x,y,TILE,TILE,'#5a6664');
      px(x+2,y+1,12,15,'#6a5a2e'); px(x+3,y+2,5,14,'#8a7438'); px(x+8,y+2,5,14,'#7e6a32');
      px(x+7,y+2,1,14,'#4a3e1e'); px(x+5,y+8,1,2,'#c9a94a'); px(x+10,y+8,1,2,'#c9a94a');
      px(x+3,y+2,10,1,'#a8904a'); px(x+4,y+11,8,1,'#3e7a5a');
      break; }
    case UW_T.TRENCH: {                                         // the deep: frames the map, solid
      px(x,y,TILE,TILE,'#0e2230');
      if((h&15)===2) px(x+(h>>4)%14,y+(h>>8)%14,1,1,'#2a5a70');           // drifting motes
      break; }
    case UW_T.DOME: {                                           // an air dome's glass wall
      uwFloor(x,y,tx,ty);
      px(x,y,TILE,TILE,'rgba(210,240,250,0.30)');
      px(x+2,y+2,3,1,'rgba(255,255,255,0.7)'); px(x+2,y+3,1,2,'rgba(255,255,255,0.6)');
      break; }
    case UW_T.TABLET: {                                         // carved verse stone
      uwFlag(x,y,tx,ty);
      px(x+3,y+2,10,12,'#8a9692'); px(x+3,y+2,10,1,'#aab6b2'); px(x+4,y+1,8,1,'#aab6b2');
      for(let r=0;r<4;r++) px(x+5,y+4+r*2,6-(r&1)*2,1,'#5e6a68');
      px(x+2,y+14,12,1,'#434e4c');
      break; }
    default: if(!uwDrawTempleTile(t,x,y,tx,ty)) uwFloor(x,y,tx,ty);
  }
}

// ── the WATER ITSELF: drawn over the whole view after tiles and sprites.
//    A blue-green tint, sun-shafts from the surface, drifting caustics.
function uwDrawWaterOverlay(vw,vh,camX,camY,zone,lights){
  const now=Date.now();
  ctx.fillStyle = zone==='ruins' ? 'rgba(16,44,92,0.42)' : zone==='temple' ? 'rgba(24,64,96,0.20)' : 'rgba(22,112,146,0.32)';
  ctx.fillRect(0,0,vw,vh);
  const dg=ctx.createLinearGradient(0,0,0,vh);            // lighter toward the surface
  dg.addColorStop(0,'rgba(190,245,255,0.10)'); dg.addColorStop(1,'rgba(0,18,48,0.22)');
  ctx.fillStyle=dg; ctx.fillRect(0,0,vw,vh);
  // sun-shafts: slow, leaning, garden brighter than ruins
  const a = zone==='ruins' ? 0.05 : zone==='temple' ? 0.06 : 0.09;
  for(let i=0;i<4;i++){
    const sx=((i*97 - camX*0.3 + Math.sin(now/4000+i)*12) % (vw+60)+vw+60)%(vw+60)-30;
    ctx.fillStyle='rgba(220,250,255,'+a+')';
    ctx.beginPath(); ctx.moveTo(sx,0); ctx.lineTo(sx+14,0); ctx.lineTo(sx+44,vh); ctx.lineTo(sx+24,vh); ctx.closePath(); ctx.fill();
  }
  // caustic flecks, anchored to the world so they don't swim with the camera
  ctx.fillStyle='rgba(230,252,255,0.16)';
  const ox=Math.floor(camX/TILE), oy=Math.floor(camY/TILE);
  for(let ty=oy;ty<oy+vh/TILE+2;ty++) for(let tx=ox;tx<ox+vw/TILE+2;tx++){
    const h=_uwH(tx,ty); if(h%3) continue;
    const ph=Math.sin(now/800+(h&63));
    ctx.fillRect(tx*TILE-camX+(h>>6)%12, ty*TILE-camY+(h>>10)%12, 3+Math.round(ph), 1);
  }
  // lit sea-lamps shine THROUGH the water: drawn after the tint so it can't bury them
  for(const [lx,ly] of (lights||[])){
    const pulse=0.55+0.1*Math.sin(now/300+lx);
    const rg=ctx.createRadialGradient(lx,ly,1,lx,ly,26);
    rg.addColorStop(0,'rgba(255,240,160,'+pulse.toFixed(3)+')'); rg.addColorStop(1,'rgba(255,240,160,0)');
    ctx.fillStyle=rg; ctx.fillRect(lx-26,ly-26,52,52);
    ctx.fillStyle='#fffbe0'; ctx.fillRect(lx-2,ly-1,4,2);
  }
  // drifting motes
  ctx.fillStyle='rgba(240,255,255,0.35)';
  for(let i=0;i<14;i++){ const mx=((i*53+now/60*((i%3)+1))%(vw+20))-10, my=((i*71 - now/90*((i%2)+1))%vh+vh)%vh;
    ctx.fillRect(mx|0,my|0,1,1); }
}

// ── bubbles off the rider: a short trail rising from the knight's helm ──
function uwDrawRiderBubbles(sx,sy){
  const now=Date.now();
  for(let i=0;i<3;i++){ const ph=((now/140)+i*5)%15;
    const bx=sx+7+Math.round(Math.sin(now/200+i*2)*1.5), by=sy-10-ph;
    px(bx,by,(i===1)?2:1,(i===1)?2:1,'rgba(238,248,252,'+(0.9-ph/18).toFixed(2)+')'); }
}

// ── the FISH: little peaceful schools (ambient, not creatures you fight) ──
function uwDrawFish(x,y,kind,dir,f){
  const P=[['#f0a040','#fff0c8','#a86020'],['#58a8e8','#d8f0ff','#2a6aa8'],['#e8e070','#ffffff','#a89a30']][kind%3];
  const m=dir<0;
  const q=(xx,yy,w,h,c)=>px(m? x+7-xx-w : x+xx, y+yy, w, h, c);
  q(1,1,4,3,P[0]); q(2,1,2,1,P[1]); q(5,1+(f&1),2,2,P[2]); q(0,2,1,1,P[2]); q(1,2,1,1,'#1a1a1a');
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — PEOPLE (mockup stage)
//  Zebulun the pearl-diver (Gen 49:13 — "Zebulun shall dwell at the
//  haven of the sea") lives in an air dome in the Reef Garden.
//  Tirzah keeps the drowned temple's records in a dome by the ruins.
// ════════════════════════════════════════════════════════════════
function uwDrawZebulun(sx,sy){
  const t=Date.now(), bob=Math.sin(t/800)>0.5?1:0, oy=sy+bob;
  const SK='#c8925f', SK_D='#9a6b42', BEARD='#e8e4d8', BEARD_D='#b8b4a8';
  const TUN='#3a7a8a', TUN_L='#58a0ae', TUN_D='#285a66', ROPE='#c8b078', NET='#8a7a50';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(sx+8,sy+15,5,2,0,0,7); ctx.fill();
  // legs, bare feet
  px(sx+5,oy+12,2,3,SK_D); px(sx+9,oy+12,2,3,SK_D);
  // short sea-tunic, rope belt with a pearl pouch
  px(sx+4,oy+7,8,6,TUN); px(sx+4,oy+7,2,6,TUN_L); px(sx+11,oy+7,1,6,TUN_D);
  px(sx+4,oy+10,8,1,ROPE); px(sx+10,oy+10,3,3,'#8a6a3a'); px(sx+11,oy+11,1,1,'#f4f0e8');
  // bare arms; one holds a net over the shoulder
  px(sx+3,oy+7,1,4,SK); px(sx+12,oy+7,1,4,SK_D);
  px(sx+12,oy+3,2,5,NET); px(sx+13,oy+4,1,1,ROPE); px(sx+12,oy+6,1,1,ROPE);
  // head: weathered, bald crown, white beard
  px(sx+5,oy+1,6,6,SK); px(sx+5,oy+1,2,6,'#e0b184'); px(sx+10,oy+2,1,5,SK_D);
  px(sx+6,oy+3,1,1,'#2a2036'); px(sx+9,oy+3,1,1,'#2a2036');
  px(sx+5,oy+5,6,3,BEARD); px(sx+5,oy+5,1,3,BEARD_D); px(sx+7,oy+8,2,1,BEARD);
  px(sx+4,oy+2,1,2,BEARD); px(sx+11,oy+2,1,2,BEARD);          // white tufts at the ears
}
function uwDrawTirzah(sx,sy){
  const t=Date.now(), bob=Math.sin(t/950)>0.6?1:0, oy=sy+bob;
  const ROBE='#3a5a7a', ROBE_L='#5a7ea0', ROBE_D='#26405a', VEIL='#c8d4dc', VEIL_D='#98a8b4';
  const SK='#e0b080', SCROLL='#e8dcb8', CASE='#8a6a3a';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(sx+8,sy+15,5,2,0,0,7); ctx.fill();
  // long robe to the floor
  px(sx+4,oy+11,8,4,ROBE_D); px(sx+5,oy+6,6,6,ROBE); px(sx+5,oy+6,2,6,ROBE_L); px(sx+10,oy+6,1,6,ROBE_D);
  px(sx+4,oy+13,1,2,ROBE_L);
  // a scroll held open before her
  px(sx+4,oy+8,8,3,SCROLL); px(sx+4,oy+8,1,3,CASE); px(sx+11,oy+8,1,3,CASE);
  px(sx+6,oy+9,4,1,'#8a7a5a');
  // the veil, pale as sea-foam, and her face
  px(sx+5,oy+1,6,6,VEIL); px(sx+4,oy+2,1,6,VEIL_D); px(sx+11,oy+2,1,6,VEIL_D); px(sx+5,oy+1,6,1,'#e8f0f4');
  px(sx+6,oy+3,4,3,SK); px(sx+6,oy+4,1,1,'#2a2036'); px(sx+9,oy+4,1,1,'#2a2036');
  // a small gold clasp: the temple's sign
  px(sx+7,oy+7,2,1,'#c9a94a');
}
// ── portraits (64×76, drawn through q like RG_ART) ──
function uwPortraitBackdrop(q, a, b, c){
  q(0,0,64,76,a); q(0,0,64,30,b);
  for(let i=0;i<5;i++) q(4+i*13, 6+(i%2)*8, 2, 2, '#9fd0e8');     // bubbles drifting up
  for(let i=0;i<4;i++) q(10+i*15, 16+(i%2)*6, 1, 1, '#e0f2fa');
  q(0,72,64,4,c); q(0,0,2,76,c); q(62,0,2,76,c);
}
function uwPortraitZebulun(q){
  uwPortraitBackdrop(q, '#16384a', '#1f4a5e', '#0a1c26');
  // shoulders: sea-tunic, rope over one shoulder, net slung behind
  q(0,56,64,20,'#3a7a8a'); q(0,56,64,3,'#58a0ae'); q(0,56,14,20,'#58a0ae'); q(50,56,14,20,'#285a66');
  for(let i=0;i<5;i++) q(46+((i*3)%10), 50+i*4, 10, 1, '#8a7a50');           // the net
  for(let i=0;i<3;i++) q(48+i*4, 48, 1, 20, '#8a7a50');
  q(8,58,40,3,'#c8b078'); q(8,58,40,1,'#e0cc98');                             // rope across the chest
  q(22,64,8,8,'#8a6a3a'); q(24,66,4,4,'#f4f0e8'); q(25,66,2,1,'#ffffff');     // pouch and a pearl
  q(22,48,20,10,'#9a6b42');                                                  // neck, sun-dark
  // head: weathered tan, bald crown
  q(14,10,36,40,'#c8925f'); q(14,10,9,40,'#e0b184'); q(43,10,7,40,'#9a6b42');
  q(18,8,28,4,'#d8a26e'); q(20,9,10,1,'#f0c8a0');                            // the shine on his crown
  q(10,24,4,10,'#9a6b42'); q(50,24,4,10,'#9a6b42');                          // ears
  q(8,18,6,10,'#e8e4d8'); q(50,18,6,10,'#b8b4a8');                           // white tufts
  // eyes: crinkled, kind, the sea's colour
  q(18,24,10,2,'#e8e4d8'); q(36,24,10,2,'#e8e4d8');                          // white brows
  q(19,27,8,4,'#fbf6ea'); q(37,27,8,4,'#fbf6ea');
  q(22,27,4,4,'#2a6a7a'); q(40,27,4,4,'#2a6a7a'); q(23,28,1,1,'#b8f0f0'); q(41,28,1,1,'#b8f0f0');
  q(16,31,5,1,'#9a6b42'); q(43,31,5,1,'#9a6b42');                            // crow's feet
  q(30,30,5,9,'#b07e56'); q(30,30,2,9,'#e0b184');                            // nose
  // the white beard, short and full
  q(15,38,34,4,'#e8e4d8'); q(13,42,38,14,'#e8e4d8'); q(13,42,9,14,'#f4f2ea'); q(42,42,9,14,'#b8b4a8');
  for(let i=0;i<6;i++) q(17+i*5,46,1,9,'#b8b4a8');
  q(18,55,28,4,'#e8e4d8'); q(24,58,16,3,'#b8b4a8');
  q(20,38,24,4,'#f4f2ea'); q(20,41,24,1,'#b8b4a8');                          // moustache
  q(27,43,10,2,'#8a4a3a'); q(26,42,2,1,'#8a4a3a'); q(36,42,2,1,'#8a4a3a');   // a small upturned smile
}
function uwPortraitTirzah(q){
  uwPortraitBackdrop(q, '#1a2a44', '#243a5a', '#0c1424');
  // robe and the temple clasp
  q(0,58,64,18,'#3a5a7a'); q(0,58,64,3,'#5a7ea0'); q(0,58,14,18,'#5a7ea0'); q(50,58,14,18,'#26405a');
  q(28,60,8,5,'#c9a94a'); q(28,60,8,2,'#f0d98a'); q(31,62,2,3,'#8a6a20');
  // the scroll she keeps, lifted at the bottom edge
  q(6,66,24,10,'#e8dcb8'); q(6,66,3,10,'#8a6a3a'); q(27,66,3,10,'#8a6a3a');
  for(let i=0;i<3;i++) q(11,68+i*2,14,1,'#8a7a5a');
  // the veil: pale sea-foam, framing the face
  q(8,4,48,18,'#c8d4dc'); q(8,4,48,3,'#e8f0f4'); q(8,4,12,18,'#e8f0f4'); q(44,4,12,18,'#98a8b4');
  q(6,18,8,42,'#c8d4dc'); q(50,18,8,42,'#98a8b4'); q(6,18,3,42,'#e8f0f4');
  q(14,56,36,4,'#98a8b4');
  // face: mid skin, grave and calm
  q(16,16,32,40,'#e0b080'); q(16,16,8,40,'#f2c99b'); q(42,16,6,40,'#b8875c');
  q(16,16,32,4,'#c8a07c');                                                   // the veil's shadow
  q(20,26,9,2,'#6b5340'); q(35,26,9,2,'#6b5340');                            // brows
  q(20,29,9,5,'#fbf6ea'); q(35,29,9,5,'#fbf6ea');
  q(23,29,4,5,'#3a4a6a'); q(38,29,4,5,'#3a4a6a'); q(24,30,1,1,'#c8d8f0'); q(39,30,1,1,'#c8d8f0');
  q(20,29,9,1,'#b8875c'); q(35,29,9,1,'#b8875c');                            // lids
  q(30,33,4,9,'#c8966a'); q(30,33,2,9,'#f2c99b'); q(28,41,8,2,'#b8875c');   // nose
  q(25,46,14,3,'#a86a5a'); q(27,46,10,1,'#c88878');                          // a closed, patient mouth
  q(20,52,24,4,'#c8966a');                                                   // chin shadow
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — REWARDS (mockup stage)
// ════════════════════════════════════════════════════════════════
// ── CORAL BARDING: a Sea Dragon skin. The shell goes coral, the saddle-rim
//    and horns go pearl. Applied by swapping STEED2.PAL.steadfast for the
//    length of one draw and putting it straight back.
const UW_CORAL_PAL = { S:'#d8586a', s:'#9a3446', H:'#f5a0a8', g:'#f4f0e8', G:'#c8c0b0', h:'#f4f0e8' };
function uwWithCoralBarding(fn){
  const P=STEED2.PAL.steadfast, keep={};
  for(const k in UW_CORAL_PAL){ keep[k]=P[k]; P[k]=UW_CORAL_PAL[k]; }
  try{ fn(); } finally { for(const k in keep) P[k]=keep[k]; }
}
// ── THE DEEPWATER PEARL livery (flag-unlocked, like the Stormward Plate):
//    sea-teal over pearl, with a coral plume.
const UW_LIVERY = { name:'Deepwater Pearl', req:0, flag:'deepwater', note:'the drowned temple, opened',
  TUNIC:'#2a8a8a', TUNIC_L:'#4ab0aa', TUNIC_D:'#1c6464', TUNIC_RIM:'#f4f0e8', TUNIC_SH:'#123e42',
  LEG:'#1c5a5e', LEG_D:'#12403f', PLUME:'#e8707a', PLUME_HI:'#f8a0a8', PLUME_D:'#a8404c',
  HELM:'#e8e6e0', HELM_HI:'#ffffff', HELM_L:'#f4f2ec', HELM_D:'#b8b2a4' };
// ── HOMESTEAD DECORATIONS (drawDecor kinds). All solid, like the others.
const UW_DECOR_ITEMS = {
  coralPlanter: { name:'Coral Planter',     emoji:'🪸', kind:'uwCoralPlanter', w:1 },
  pearlFountain:{ name:'Pearl Fountain',    emoji:'⛲', kind:'uwPearlFountain', w:2 },
  bellArbor:    { name:'Sunken-Bell Arbor', emoji:'🔔', kind:'uwBellArbor',    w:2 },
  wheelSign:    { name:"Ship's-Wheel Sign", emoji:'☸️', kind:'uwWheelSign',    w:1 },
};
function uwDrawDecor(d,x,y){
  const now=Date.now();
  switch(d.kind){
    case 'uwCoralPlanter': {                                    // a shell-rimmed box of coral
      ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,6,2,0,0,7); ctx.fill();
      px(x+2,y+8,12,7,'#7a4f2a'); px(x+2,y+8,12,2,'#946232'); px(x+2,y+14,12,1,'#5a3a1e');
      for(let i=0;i<4;i++) px(x+3+i*3,y+11,2,2,'#f4f0e8');                     // a row of shells
      px(x+3,y+2,2,6,'#d8586a'); px(x+2,y+1,2,2,'#f08a96'); px(x+5,y+4,2,2,'#d8586a');   // red branch
      px(x+8,y+3,4,5,'#e8905a'); px(x+8,y+3,4,1,'#f8b888'); px(x+9,y+5,2,1,'#f8b888');   // orange mound
      px(x+12,y+1,2,7,'#9a6ac8'); px(x+11,y+3,1,2,'#9a6ac8'); px(x+12,y+1,2,1,'#c49ae8');// purple fan
      return; }
    case 'uwPearlFountain': { const W=d.w*TILE;                 // a giant shell holding a pearl
      ctx.fillStyle='rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(x+W/2,y+W-2,W/2-1,4,0,0,7); ctx.fill();
      px(x+3,y+14,W-6,14,'#8a9692'); px(x+3,y+14,W-6,2,'#aab6b2'); px(x+3,y+27,W-6,1,'#5e6a68');  // stone basin
      px(x+6,y+17,W-12,8,'#3f7ec0'); px(x+7,y+18,W-14,2,'#6aa6e0');                          // water
      // the scallop shell standing up behind, ribs fanning out
      px(x+7,y+2,W-14,12,'#f0c8b0'); px(x+9,y,W-18,3,'#f0c8b0');
      for(let i=0;i<5;i++) px(x+9+i*3,y+1,1,12,'#d8a088');
      px(x+7,y+12,W-14,2,'#c8907a');
      // the pearl, and water spilling
      px(x+W/2-3,y+9,6,6,'#f4f0e8'); px(x+W/2-2,y+10,2,2,'#ffffff'); px(x+W/2+1,y+13,2,1,'#c8c0b0');
      const s=Math.floor(now/200)%3;
      px(x+W/2-5,y+15+s,1,2,'#bfe0ff'); px(x+W/2+4,y+15+((s+1)%3),1,2,'#bfe0ff');
      return; }
    case 'uwBellArbor': { const W=d.w*TILE;                     // a timber arbor hung with a sunken bell
      ctx.fillStyle='rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(x+W/2,y+TILE+14,W/2-2,3,0,0,7); ctx.fill();
      px(x+2,y+2,3,28,'#6f5128'); px(x+2,y+2,1,28,'#8a6a3a'); px(x+W-5,y+2,3,28,'#6f5128'); px(x+W-5,y+2,1,28,'#8a6a3a');
      px(x,y,W,4,'#8a6a3a'); px(x,y,W,1,'#a8844e'); px(x,y+3,W,1,'#5a3f22');                // crossbeam
      for(let i=0;i<6;i++) px(x+2+i*5,y+4+(i%2),3,3,'#3e8a5a');                              // sea-vine
      px(x+4,y+5,1,8,'#3e8a5a'); px(x+W-4,y+6,1,10,'#3e8a5a');
      // the bell, green with age, swinging a little
      const sw=Math.round(Math.sin(now/700));
      px(x+W/2,y+4,1,4,'#4a3e1e');
      px(x+W/2-5+sw,y+8,10,10,'#5a8a6a'); px(x+W/2-4+sw,y+7,8,2,'#6a9a7a'); px(x+W/2-6+sw,y+17,12,2,'#4a7a5a');
      px(x+W/2-4+sw,y+9,2,7,'#8abaa0'); px(x+W/2+sw,y+18,2,2,'#3a4a3a');                      // shine + clapper
      px(x+W/2-3+sw,y+12,6,1,'#c9a94a');                                                       // a gold band
      return; }
    case 'uwWoodenCross': uwDrawWoodenCross(x,y); return;
    case 'uwWheelSign': {                                       // a ship's wheel on a post
      ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,5,2,0,0,7); ctx.fill();
      px(x+7,y+10,2,5,'#5b3a1f'); px(x+7,y+10,1,5,'#7a5230');
      const cx=x+8, cy=y+6;
      for(let k=0;k<8;k++){ const a=k/8*Math.PI*2;                  // eight spokes, each ending in a handle
        for(let r=1;r<=5;r++) px(Math.round(cx+Math.cos(a)*r-0.5),Math.round(cy+Math.sin(a)*r-0.5),1,1,'#6f5128');
        px(Math.round(cx+Math.cos(a)*7-1),Math.round(cy+Math.sin(a)*7-1),2,2,'#8a6a3a'); }
      for(let k=0;k<28;k++){ const a=k/28*Math.PI*2;                // a solid rim
        px(Math.round(cx+Math.cos(a)*4.6-0.5),Math.round(cy+Math.sin(a)*4.6-0.5),1,1,'#a8844e'); }
      for(let k=0;k<28;k++){ const a=k/28*Math.PI*2;
        if(Math.sin(a)<0) px(Math.round(cx+Math.cos(a)*4.6-0.5),Math.round(cy+Math.sin(a)*4.6-0.5),1,1,'#c8a468'); }  // lit top
      px(cx-2,cy-2,3,3,'#c9a94a'); px(cx-1,cy-1,1,1,'#f0d98a');         // brass hub
      return; }
  }
  return false;
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — THE TEMPLE PIECES (1 Kings 6–7), mockup stage
//  Tiles 15..21 extend UW_T; the three large pieces (the Molten Sea, the
//  bronze altar, the cherubim) are OBJECTS drawn in the sorted object pass,
//  never from inside a tile, so the tiles after them can't paint over them.
// ════════════════════════════════════════════════════════════════
Object.assign(UW_T, { PILLAR_TOP:15, PILLAR:16, LAVER:17, CEDAR:18, GOLDFLOOR:19, LAMPSTAND:20, INNERDOOR:21 });
const UW_BRONZE={ B:'#a8743a', L:'#d0a060', D:'#6e4620', V:'#5a9a80', VL:'#7ab8a0' };
const UW_GOLD  ={ G:'#c8a448', L:'#f0d890', D:'#8a6a24', T:'#9a8a50' };   // T = tarnish
function uwGoldFloor(x,y,tx,ty){                       // "the floor of the house he overlaid with gold" (6:30)
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#a8904c'); px(x,y,TILE,1,'#c0a860'); px(x,y+8,TILE,1,'#8a7438');
  px(x+(ty&1?5:11),y,1,8,'#8a7438'); px(x+(ty&1?12:3),y+9,1,7,'#8a7438');
  if(h%4===0) px(x+2+(h>>4)%9,y+11,4,2,'#b8a878');     // a drift of sand
  if(h%7===0) px(x+3+(h>>6)%8,y+3,2,2,'#6a8a5a');      // weed in a seam
}
function uwDrawTempleTile(t,x,y,tx,ty){
  const h=_uwH(tx,ty), now=Date.now(), B=UW_BRONZE, Gd=UW_GOLD;
  switch(t){
    case UW_T.GOLDFLOOR: uwGoldFloor(x,y,tx,ty); return true;
    case UW_T.CEDAR: {                                  // cedar, overlaid with gold, carved with palms and open flowers (6:29)
      px(x,y,TILE,TILE,'#8a7440'); px(x,y,TILE,2,'#a8904c'); px(x,y+14,TILE,2,'#5e4e2a');
      px(x,y+2,1,12,'#6e5c30'); px(x+15,y+2,1,12,'#6e5c30');
      if(tx%2===0){                                    // a palm: trunk and fronds
        px(x+7,y+6,2,8,Gd.D); px(x+4,y+4,8,1,Gd.L); px(x+3,y+5,3,1,Gd.L); px(x+10,y+5,3,1,Gd.L); px(x+6,y+3,4,1,Gd.L);
      } else {                                         // an open flower
        px(x+6,y+5,4,4,Gd.L); px(x+5,y+6,6,2,Gd.L); px(x+7,y+4,2,6,Gd.L); px(x+7,y+6,2,2,Gd.D);
      }
      if(h%5===0) px(x+1+(h>>4)%10,y+11,4,3,'#4e7a52');  // the sea has had it for a long time
      return true; }
    case UW_T.PILLAR_TOP: {                             // the chapiter: lily-work, network, pomegranates (7:16-22)
      uwFlag(x,y,tx,ty);
      px(x+2,y+9,12,7,B.B); px(x+2,y+9,3,7,B.L); px(x+12,y+9,2,7,B.D);          // the bowl
      for(let i=0;i<4;i++) for(let j=0;j<2;j++) px(x+3+i*3,y+10+j*3,1,1,B.D);     // network
      for(let i=0;i<5;i++) px(x+2+i*2.5|0,y+15,2,2,'#a84a3a');                     // a row of pomegranates
      px(x+1,y+4,14,5,B.B); px(x+2,y+2,3,3,B.L); px(x+7,y+1,2,4,B.L); px(x+11,y+2,3,3,B.L); // lily petals
      px(x+1,y+8,14,1,B.D); if(h&1) px(x+3,y+5,3,2,B.V);
      return true; }
    case UW_T.PILLAR: {                                 // the shaft of Jachin / Boaz: bronze, green with age
      uwFlag(x,y,tx,ty);
      px(x+4,y,8,15,B.B); px(x+4,y,2,15,B.L); px(x+10,y,2,15,B.D);
      px(x+3,y+14,10,2,B.D);
      px(x+6,y+3+(h%6),2,3,B.V); px(x+9,y+9-(h%4),1,2,B.VL);
      return true; }
    case UW_T.LAVER: {                                  // a laver on its wheeled base (7:27-38)
      uwFloor(x,y,tx,ty);
      px(x+2,y+13,3,3,B.D); px(x+11,y+13,3,3,B.D); px(x+3,y+14,1,1,B.L); px(x+12,y+14,1,1,B.L);   // wheels
      px(x+3,y+7,10,6,B.B); px(x+3,y+7,10,1,B.L); px(x+3,y+12,10,1,B.D);                         // the base
      px(x+5,y+9,2,2,B.D); px(x+9,y+9,2,2,B.D);                                                  // lions and oxen, worn smooth
      px(x+2,y+3,12,4,B.B); px(x+3,y+2,10,2,B.L); px(x+4,y+3,8,2,'#3f7ec0');                     // the basin, brimming
      if(h&1) px(x+11,y+5,2,2,B.V);
      return true; }
    case UW_T.LAMPSTAND: {                              // a golden lampstand (7:49): lit via uwLampLit
      uwGoldFloor(x,y,tx,ty);
      const lit = typeof uwLampLit==='function' && uwLampLit(tx,ty);
      const OL='#3e2e0c';
      px(x+3,y+13,10,3,OL); px(x+6,y+4,4,10,OL); px(x+2,y+1,12,5,OL);                          // outline first
      px(x+4,y+14,8,1,Gd.D); px(x+5,y+13,6,1,Gd.G); px(x+7,y+5,2,8,Gd.G); px(x+7,y+5,1,8,Gd.L);
      px(x+6,y+8,4,1,Gd.L); px(x+6,y+11,4,1,Gd.L);                                             // knops
      px(x+4,y+3,8,2,Gd.G); px(x+4,y+3,8,1,Gd.L); px(x+3,y+2,2,2,Gd.G); px(x+11,y+2,2,2,Gd.G); // the cup and its flowers
      if(lit){ px(x+7,y,2,3,'#fff2a8'); px(x+7,y+1,2,1,'#ffffff'); }
      else px(x+7,y+2,2,1,'#3a3a2a');
      return true; }
    case UW_T.INNERDOOR: {                              // olive-wood doors, gold over cherubim, palms, flowers (6:31-32)
      px(x,y,TILE,TILE,'#8a7440');
      px(x+1,y+1,14,15,Gd.G); px(x+1,y+1,14,1,Gd.L); px(x+7,y+1,2,15,Gd.D);
      px(x+3,y+4,3,5,Gd.L); px(x+2,y+5,1,3,Gd.L);                                              // a cherub's wing, left leaf
      px(x+10,y+4,3,5,Gd.L); px(x+13,y+5,1,3,Gd.L);                                            // and right
      px(x+3,y+11,3,3,Gd.D); px(x+10,y+11,3,3,Gd.D);                                           // flowers
      return true; }
  }
  return false;
}
// ── the large pieces, drawn as objects (x,y = top-left of their footprint) ──
function uwDrawMoltenSea(x,y){                          // 3×3 tiles: the Sea on twelve oxen (7:23-26)
  const B=UW_BRONZE, OX='#8a5a2e', OXL='#b07a44', HORN='#e0d0a0';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+24,y+45,22,3,0,0,7); ctx.fill();
  // the oxen: three look out toward you, one of each side-group shows its flank
  const ox=(ax,ay)=>{ px(ax,ay+3,8,8,OX); px(ax,ay+3,2,8,OXL); px(ax+1,ay,6,5,OX); px(ax+1,ay,6,1,OXL);
    px(ax,ay,1,2,HORN); px(ax+7,ay,1,2,HORN); px(ax+2,ay+2,1,1,'#1a1208'); px(ax+5,ay+2,1,1,'#1a1208');
    px(ax+1,ay+11,2,3,OX); px(ax+5,ay+11,2,3,OX); };
  ox(x+2,y+32); ox(x+14,y+33); ox(x+26,y+33); ox(x+38,y+32);
  // the bowl, tapering to the oxen's backs, with two rows of knops beneath the brim (7:24)
  for(let r=0;r<18;r++){ const w=Math.round(44-r*0.7), lx=x+24-(w>>1);
    px(lx,y+14+r,w,1, r<3?B.L:B.B); px(lx,y+14+r,3,1,B.L); px(lx+w-3,y+14+r,3,1,B.D); }
  for(let i=0;i<10;i++){ px(x+5+i*4,y+18,2,2,B.D); px(x+7+i*4,y+21,2,2,B.D); }
  px(x+9,y+24,5,3,B.V); px(x+30,y+26,4,2,B.V);
  // the brim, "wrought like the brim of a cup, with flowers of lilies"
  for(let r=0;r<12;r++){ const a=Math.sqrt(1-Math.pow((r-6)/6,2)), w=Math.round(46*a), lx=x+24-(w>>1);
    px(lx,y+4+r,w,1,B.B); }
  for(let r=0;r<8;r++){ const a=Math.sqrt(1-Math.pow((r-4)/4,2)), w=Math.round(38*a), lx=x+24-(w>>1);
    px(lx,y+6+r,w,1,'#2f6aa8'); }
  px(x+14,y+7,12,1,'#6aa6e0'); px(x+26,y+9,6,1,'#6aa6e0');
  for(let i=0;i<9;i++) px(x+3+i*5,y+15-(i%2),3,2,B.L);                                     // the lily scallops
}
function uwDrawAltar(x,y){                              // 2×2 tiles: the altar of brass (2 Chr 4:1)
  const B=UW_BRONZE;
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+16,y+30,15,3,0,0,7); ctx.fill();
  px(x+2,y+10,28,20,B.B); px(x+2,y+10,4,20,B.L); px(x+26,y+10,4,20,B.D); px(x+2,y+28,28,2,B.D);
  px(x+2,y+4,28,8,B.D); px(x+4,y+5,24,6,'#3a2a1a');                                       // the hearth, long cold
  for(let i=0;i<6;i++) px(x+5+i*4,y+5,1,6,B.B);                                             // the grate
  px(x+1,y+2,4,4,B.L); px(x+27,y+2,4,4,B.L); px(x+1,y+10,3,3,B.L); px(x+28,y+10,3,3,B.L); // horns
  px(x+8,y+16,16,1,B.D); px(x+8,y+22,16,1,B.D); px(x+11,y+18,4,3,B.V); px(x+20,y+24,5,2,B.V);
}
function uwDrawCherub(x,y){                             // 3×5 tiles: one cherub, wings spanning north–south (6:23-28)
  const G=UW_GOLD, OL='#4a3810';
  // two great wings: one sweeps to the north end of the span, one to the south,
  // broad at the shoulder and tapering to the tip that touches wall or partner
  const wing=(y0,y1,up)=>{ const n=y1-y0;
    for(let i=0;i<n;i++){ const t=up? (n-1-i)/n : i/n;                 // 0 at the shoulder, 1 at the tip
      const w=Math.round(26-18*t), lx=x+4;
      px(lx-1,y0+i,w+2,1,OL); px(lx,y0+i,w,1, (i%4===0)?G.D:G.G); px(lx,y0+i,Math.max(2,w>>2),1,G.L); } };
  wing(y+1,y+34,true); wing(y+46,y+79,false);
  // the body, in profile facing the room (east), robed and bowed
  px(x+17,y+24,17,40,OL);
  px(x+18,y+34,15,29,G.G); px(x+18,y+34,4,29,G.L); px(x+30,y+34,3,29,G.D);          // robe
  for(let i=0;i<3;i++) px(x+22+i*4,y+40,1,20,G.D);                                  // folds
  px(x+19,y+25,11,10,G.G); px(x+19,y+25,4,10,G.L); px(x+28,y+28,2,5,G.D);         // head, bowed
  px(x+26,y+29,2,1,OL);
  px(x+24,y+37,10,4,G.L); px(x+32,y+39,2,3,G.G);                                   // arms folded forward
  px(x+17,y+62,17,2,OL);
}
// ── the cherubim seen FRONT-ON (the house turned north, per Zak): 5×3 tiles
//    each, standing against the north wall and facing you, wings stretched
//    straight out; one wing touches the wall, the other touches the other
//    cherub's wing in the middle of the house (6:27).
function uwDrawCherubFront(x,y){
  const G=UW_GOLD, OL='#4a3810', cx=x+40;
  ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(cx,y+46,12,2.5,0,0,7); ctx.fill();
  // the wings: broad at the shoulder, tapering to the tips at either edge of the span
  const wing=(dir)=>{ for(let i=0;i<38;i++){ const t=i/38, h=Math.round(16-11*t), top=y+9+Math.round(t*4);
      const wx = dir<0 ? cx-7-i : cx+6+i;
      px(wx,top-1,1,h+2,OL); px(wx,top,1,h, (i%5===0)?G.D:G.G); px(wx,top,1,Math.max(2,h>>2),G.L); } };
  wing(-1); wing(1);
  px(x,y+13,1,6,OL); px(x+79,y+13,1,6,OL);                                    // the tips, touching
  // the body: robed, standing, arms folded; a plain gold head, bowed toward the room
  px(cx-9,y+8,18,39,OL);
  px(cx-8,y+19,16,27,G.G); px(cx-8,y+19,4,27,G.L); px(cx+5,y+19,3,27,G.D);
  for(let i=0;i<3;i++) px(cx-4+i*4,y+30,1,15,G.D);                             // folds
  px(cx-6,y+22,12,4,G.L); px(cx-6,y+25,12,1,G.D);                              // arms folded
  px(cx-5,y+9,10,10,G.G); px(cx-5,y+9,3,10,G.L); px(cx+3,y+11,2,6,G.D);         // head
  px(cx-4,y+17,8,2,G.D);                                                        // bowed
}
// ── THE HUMBLE CHEST (Zak): a plain wooden box between the cherubim, tied
//    with cord, no gold on it at all. Drawn as an object centred on the
//    room's middle line (the seam between two tiles); its footprint is the
//    two tiles it straddles. Holds the Wooden Cross.
function uwDrawHumbleChest(x,y,open){               // x,y = top-left of the 2×1 footprint
  const cx=x+16, W='#7a5a3a', WL='#9a7650', WD='#4e3822', CORD='#c8b890';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(cx,y+15,8,2,0,0,7); ctx.fill();
  px(cx-7,y+6,14,9,W); px(cx-7,y+6,14,1,WL); px(cx-7,y+14,14,1,WD);
  px(cx-7,y+6,1,9,WD); px(cx+6,y+6,1,9,WD); px(cx-3,y+7,1,7,WD); px(cx+2,y+7,1,7,WD);   // plank seams
  if(open){ px(cx-7,y+2,14,4,WD); px(cx-6,y+3,12,2,'#2a1c10'); }
  else { px(cx-7,y+4,14,3,WL); px(cx-7,y+4,14,1,'#b08a60');                            // the lid
         px(cx-1,y+4,2,11,CORD); px(cx-7,y+10,14,1,CORD); px(cx,y+9,1,2,'#e8dcb8'); }    // cord and knot
}
// ── THE WOODEN CROSS: a homestead decoration (1 tile), plain timber on a
//    cairn of stones. Deliberately humbler than the Champion's Cross.
UW_DECOR_ITEMS.woodenCross = { name:'Wooden Cross', emoji:'✝️', kind:'uwWoodenCross', w:1 };
function uwDrawWoodenCross(x,y){
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,5,2,0,0,7); ctx.fill();
  px(x+4,y+12,8,3,'#8a8478'); px(x+5,y+11,6,2,'#a6a094'); px(x+4,y+14,8,1,'#6a6458');   // stones
  px(x+7,y,2,13,'#7a5230'); px(x+7,y,1,13,'#9a6e44');                                  // upright
  px(x+3,y+3,10,2,'#7a5230'); px(x+3,y+3,10,1,'#9a6e44');                              // crossbeam
  px(x+8,y+5,1,1,'#4e3420'); px(x+7,y+8,1,2,'#5e4028');                                // grain
}

// ════════════════════════════════════════════════════════════════
//  THE HOUSE, SEEN FROM THE COURTS (Zak: a building you walk into)
//  Compact like the game's chapels: 14×10 tiles outside, bigger within.
//  Hewn stone (6:7), a tall porch front, the side chambers as lower wings
//  with narrow windows (6:4), cedar beams under a flat roof. Standing, but
//  drowned: coral and weed creep over the ledges. The doorway is the two
//  tiles at the bottom-centre of the footprint.
// ════════════════════════════════════════════════════════════════
function uwDrawTempleExterior(ox,oy){
  const W=14*TILE, H=10*TILE, OL='#1a141c';
  const ST='#c8bea0', STL='#ddd4b8', STD='#9a9078', STS='#7e7662';   // limestone: face, lit, shade, side
  const CED='#6e4a2c', CEDD='#4e3420', GOLD='#c8a448', GOLDL='#f0d890';
  const WEED='#4e7a52', WEEDL='#6a9a62', COR='#d8586a', CORL='#f08a96';
  const h=(a,b)=>((a*374761393+b*668265263)>>>0);
  // the shadow it casts on the sea floor
  ctx.fillStyle='rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.ellipse(ox+W/2+6, oy+H-2, W/2, TILE*0.55, 0,0,7); ctx.fill();
  const ashlar=(x,y,w,hh)=>{ for(let r=0;r*6<hh;r++){ const yy=y+r*6; if(yy>=y+hh) break; px(x,yy,w,1,STD);
      for(let c=((r&1)?4:0);c<w;c+=12) px(x+c,yy+1,1,Math.min(5,y+hh-yy-1),STD); } };
  const block=(x,y,w,hh,roofH)=>{                       // one massing: flat cedar-edged roof over a stone face
    px(x-1,y-1,w+2,hh+2,OL);
    px(x,y,w,roofH,'#8a8070'); px(x,y,w,2,'#a89e88');           // the flat roof (stone over cedar)
    px(x,y+roofH-3,w,3,CED); px(x,y+roofH-3,w,1,CEDD);           // the cedar beam-ends under its lip
    for(let i=4;i<w-2;i+=6) px(x+i,y+roofH-2,2,2,CEDD);
    px(x,y+roofH,w,hh-roofH,ST); px(x,y+roofH,2,hh-roofH,STL); px(x+w-2,y+roofH,2,hh-roofH,STD);
    ashlar(x+2,y+roofH+2,w-4,hh-roofH-2);
    px(x+w+1,y+roofH+2,3,hh-roofH-1,STS);                        // the side in shadow (the game's faked depth)
  };
  // the two side wings: the storied chambers, lower, with narrow windows
  const wingY=oy+Math.round(H*0.38), wingH=H-Math.round(H*0.38);
  block(ox,wingY,4*TILE,wingH,10); block(ox+10*TILE,wingY,4*TILE,wingH,10);
  for(const wx of [ox, ox+10*TILE]) for(let s=0;s<3;s++) for(let k=0;k<3;k++){       // three storeys of narrow lights
    const x=wx+8+k*18, y=wingY+16+s*24; px(x,y,3,9,'#2a2a34'); px(x,y,3,1,STD); px(x-1,y+9,5,1,STL); }
  // the house itself, taller, behind the porch
  const houseY=oy+Math.round(H*0.16);
  block(ox+4*TILE,houseY,6*TILE,H-Math.round(H*0.16),12);
  for(let k=0;k<5;k++){ const x=ox+4*TILE+8+k*18; px(x,houseY+18,3,12,'#2a2a34'); px(x-1,houseY+30,5,1,STL); }   // high windows
  // the porch: the tallest front, centred, with the doorway
  const pX=ox+5*TILE, pW=4*TILE, pY=oy;
  block(pX,pY,pW,H,14);
  px(pX+4,pY+16,pW-8,2,GOLD); px(pX+4,pY+16,pW-8,1,GOLDL);                          // a band of gold, faded
  for(let i=0;i<6;i++){ const fx=pX+8+i*9; px(fx,pY+22,4,4,GOLD); px(fx+1,pY+23,2,2,GOLDL); }   // open flowers carved in the band
  // the doorway: two tiles wide at the foot of the porch, an open dark mouth under a lintel
  const dX=ox+6*TILE, dW=2*TILE, dY=oy+H-Math.round(TILE*2.2);
  px(dX-3,dY-5,dW+6,5,STD); px(dX-3,dY-5,dW+6,1,STL);                              // the lintel
  px(dX,dY,dW,oy+H-dY,'#0e1a22'); px(dX+2,dY+2,dW-4,oy+H-dY-2,'#142a36');
  px(dX+dW/2-1,dY,2,oy+H-dY,'#0a141a');                                              // the doors stand open
  px(dX-2,dY,2,oy+H-dY,'#5e4a30'); px(dX+dW,dY,2,oy+H-dY,'#5e4a30');                 // door leaves folded back
  // the sea has had it a long time: weed on the ledges, coral at the footings, a few cracks
  for(let i=0;i<W;i+=3){ const k=h(ox+i,oy)%7;
    if(k<3){ px(ox+i,wingY+10,2,2+k,WEED); px(ox+i,wingY+10,1,1,WEEDL); }
    if(k===4 && (ox+i<pX-4 || ox+i>pX+pW+4)) { px(ox+i,oy+H-5,3,4,COR); px(ox+i,oy+H-5,3,1,CORL); } }
  for(let i=0;i<pW;i+=4){ const k=h(pX+i,1)%5; if(k<2) px(pX+i,pY+14,2,3+k,WEED); }
  px(ox+4*TILE+30,houseY+40,1,9,STS); px(ox+4*TILE+31,houseY+48,1,6,STS);           // cracks
  px(ox+11*TILE+12,wingY+40,1,8,STS); px(ox+11*TILE+13,wingY+47,1,5,STS);
}

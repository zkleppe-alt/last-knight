import uw_map as M
WALK=set('.gfu_')
def solid_objs(objs):
    s=set()
    for (_,x,y,w,h) in objs.values():
        for yy in range(y,y+h):
            for xx in range(x,x+w): s.add((xx,yy))
    return s
def flood(rows, objs, npcs, start, door_open=False, passable=()):
    H=len(rows); W=len(rows[0]); so=solid_objs(objs)-set(passable); npc=set(npcs.values())
    def ok(x,y):
        if not (0<=x<W and 0<=y<H) or (x,y) in npc: return False
        if (x,y) in passable: return True
        if (x,y) in so: return False
        c=rows[y][x]; return c in WALK or (door_open and c=='I')
    seen={start}; st=[start]
    while st:
        x,y=st.pop()
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            n=(x+dx,y+dy)
            if n not in seen and ok(*n): seen.add(n); st.append(n)
    return seen
adj=lambda s,p: any((p[0]+dx,p[1]+dy) in s for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
bad=False
# ── COURTS ──
door=set(M.DOOR)
things={('chest',k):v for k,v in M.CH.items()}
things.update({('tablet',k):v for k,v in M.COURTS_TABLETS.items()})
things.update({('npc',k):v for k,v in M.COURTS_NPC.items()})
for e,p in M.ENTRY.items():
    s=flood(M.COURTS, M.COURTS_OBJ, M.COURTS_NPC, p, passable=door)
    miss=[k for k,v in things.items() if not adj(s,v)]
    reach_door=all(d in s for d in door); reach_entries=all(q in s for q in M.ENTRY.values())
    print('courts', e, len(s), 'missing:', miss, 'door:', reach_door, 'entries:', reach_entries)
    bad |= bool(miss) or not reach_door or not reach_entries
print('door in front is open floor:', M.COURTS[M.DOOR_IN[1]][M.DOOR_IN[0]] in WALK)
bad |= M.COURTS[M.DOOR_IN[1]][M.DOOR_IN[0]] not in WALK
# ── TEMPLE ──
tt={('chest',k):v for k,v in M.TCH.items()}
tt.update({('tablet',k):v for k,v in M.TEMPLE_TABLETS.items()})
tt.update({('prayer',k):v for k,v in M.PRAYER.items()})
tt.update({('npc',k):v for k,v in M.TEMPLE_NPC.items()})
tt[('chest','humble')]=(14,5)
tt[('door','inner')]=M.INNER_DOOR[0]
for opened in (False, True):
    s=flood(M.TEMPLE, M.TEMPLE_OBJ, M.TEMPLE_NPC, M.ARRIVE, door_open=opened)
    miss=sorted(k for k,v in tt.items() if not adj(s,v))
    print('temple', 'open' if opened else 'shut', len(s), 'missing:', miss, 'exit:', all(e in s for e in M.EXIT))
    want=[] if opened else [('chest','humble'),('tablet','micah'),('tablet','rec3')]
    bad |= miss!=sorted(want) or not all(e in s for e in M.EXIT)
# placement asserts
for k,(x,y) in M.CH.items(): assert M.COURTS[y][x]=='$',k
for k,(x,y) in M.TCH.items(): assert M.TEMPLE[y][x]=='$',k
for k,(x,y) in M.COURTS_TABLETS.items(): assert M.COURTS[y][x]=='t',k
for k,(x,y) in M.TEMPLE_TABLETS.items(): assert M.TEMPLE[y][x]=='t',k
for (x,y) in M.LAMPSTANDS: assert M.TEMPLE[y][x]=='L'
for rows,objs in ((M.COURTS,M.COURTS_OBJ),(M.TEMPLE,M.TEMPLE_OBJ)):
    for (_,x,y,w,h) in objs.values():
        for yy in range(y,y+h):
            for xx in range(x,x+w): assert rows[yy][xx] in '._f', (x,y,xx,yy,rows[yy][xx])
print('RESULT', 'FAIL' if bad else 'PASS')

#!/usr/bin/env python3
"""make_testbuild.py — turn a kit-applied index.html into underwater.html, the
PLAYTEST build. NOT part of the merge kit: these edits exist only in the test
build, so it can sit next to index.html on the same site without ever touching
the real saves (both pages share one browser storage).

  python3 make_testbuild.py <kit-applied index.html> <out underwater.html>

Every storage key is renamed klk_ -> klkuw_ (exact counts asserted), and the
title-screen build tag says TEST so the two can never be confused.
"""
import re, sys, pathlib
src = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')
out = pathlib.Path(sys.argv[2])
EXPECT = {"'klk_active_slot'": 2, "'klk_audio'": 2, "'__klk_probe'": 3, "'klk_save_slot'": 1, "'klk_save_v1'": 1}
for lit, n in EXPECT.items():
    got = src.count(lit)
    assert got == n, f'{lit}: expected {n}, found {got} — the storage keys changed in main; update this list, do not force it'
    src = src.replace(lit, lit.replace('klk_', 'klkuw_'))
# nothing that looks like a storage key may still carry the real prefix
left = re.findall(r"['\"](?:__)?klk_[a-z0-9_]*['\"]", src)
assert not left, f'real-prefix keys left: {left}'
# Save CODES get their own marker too: a code made in the test build is refused by
# the real game (whose import would otherwise overwrite the active real slot).
CODE = [("return 'KLK1:'+btoa(", "return 'KLKUW1:'+btoa("),
        ("const m=code.search(/klk1/i);", "const m=code.search(/klkuw1/i);"),
        ("if(m>=0) code=code.slice(m+4);", "if(m>=0) code=code.slice(m+6);"),
        ("!/klk1/i.test(raw)", "!/klkuw1/i.test(raw)"),
        ("starting with KLK1:", "starting with KLKUW1:")]
for a_, b_ in CODE:
    assert src.count(a_) == 1, f'save-code marker changed in main: {a_!r}'
    src = src.replace(a_, b_)
tag = re.search(r"const BUILD_TAG='([^']*)';", src); assert tag
src = src.replace(tag.group(0), f"const BUILD_TAG='UW-TEST {tag.group(1)}';", 1)
out.write_text(src, encoding='utf-8')
print(f'{out.name}: {sum(EXPECT.values())} storage keys renamed klk_ -> klkuw_, build tag {tag.group(1)!r} -> UW-TEST')

#!/usr/bin/env bash
# check_testbuild.sh <underwater.html> — boots the PLAYTEST build in its own temp
# harness and proves (1) it never reads or writes a real save key, and (2) the
# start save code lands at dive spot A with the Sea Dragon, one mount + Ⓐ from
# the deep. Writes the code to start_code.txt beside this script.
set -eu
HERE="$(cd "$(dirname "$0")" && pwd)"
T="$(mktemp -d)"; mkdir -p "$T/test"
cp "$1" "$T/index.html"
cp /home/claude/klk/harness/test/{boot.js,harness_env.js,extract_js.py} "$T/test/"
cp -r /home/claude/klk/harness/test/fixtures "$T/test/"
ln -s /home/claude/klk/harness/test/node_modules "$T/test/node_modules"
( cd "$T/test" && python3 extract_js.py >/dev/null )
cat > "$T/test/tb.js" <<'EOF'
const K = require('./boot.js');
const fs = require('fs');
const out = {};
// what localStorage keys does this build touch, from boot to a save?
const keys = () => { const L = globalThis.localStorage, o = []; for (let i = 0; i < L.length; i++) o.push(L.key(i)); return o; };
// seed a REAL save under the real key first: the test build must not see it or touch it
globalThis.localStorage.setItem('klk_save_slot1', '{"real":"save"}');
globalThis.localStorage.setItem('klk_active_slot', '1');
const before = globalThis.localStorage.getItem('klk_save_slot1');
// the start-here knight: the hand-built mid-game save, given the Sea Dragon, at spot A
const MID = JSON.parse(fs.readFileSync(__dirname + '/fixtures/old_saves_2026-09-22.json', 'utf8')).mid;
globalThis.__raw = JSON.stringify(MID);
K.$(`(()=>{ applySaveData(JSON.parse(globalThis.__raw)); boot.done=true; dialogue.open=false; menu.open=false;
  tutorial.done=true; tutorial.step=99;
  while(player.level<18) gainXp(Math.max(1,player.xpNext-player.xp));
  player.pet={id:'steadfast',form:2}; player.hp=player.maxHp;
  place={kind:'overworld'}; player.x=169*TILE; player.y=37*TILE; player.dir='down';   // lake A's north beach: 2 tiles from the marker
  lastOverworld.x=player.x; lastOverworld.y=player.y; dialogue.open=false; })()`);
K.$('saveGame(1)');
out.keysAfterSave = keys().sort();
out.realUntouched = globalThis.localStorage.getItem('klk_save_slot1') === before;
out.code = K.$('(lastSaveJSON=null, encodeSaveCode())');
// now load the code the way a player would, into a fresh session state, and dive
K.$(`applySaveData(JSON.parse(FRESH_STATE));`);
out.loaded = K.$(`(()=>{ const s=decodeSaveCode(${JSON.stringify(out.code)}); return applySaveData(s); })()`);
K.$('boot.done=true; dialogue.open=false; menu.open=false;');
out.spot = K.$('[place.kind, Math.floor((player.x+8)/16), Math.floor((player.y+8)/16), player.pet.id, player.pet.form, player.level]');
K.$('toggleMount()'); K.$('dialogue.open=false;');
out.mounted = K.$('player.mounted');
K.key.down('s'); for (let i = 0; i < 400 && K.$('Math.floor((player.y+8)/16)')<40; i++) K.frames(1); K.key.up('s'); K.key.down('d'); for (let i = 0; i < 200 && K.$('Math.floor((player.x+8)/16)')<170; i++) K.frames(1); K.key.up('d'); K.frames(1);
out.swamTo = K.$('[Math.floor((player.x+8)/16), Math.floor((player.y+8)/16)]');
K.key.tap('j'); for (let i = 0; i < 60; i++) K.frames(1);
out.after = K.$('place.kind');
out.frames = K.$(`(()=>{ try{ for(let i=0;i<60;i++) loop(performance.now()+i*16); return 'ok'; }catch(e){ return String(e).slice(0,100); } })()`);
out.tag = K.$('BUILD_TAG');
process.stdout.write(JSON.stringify(out));
EOF
( cd "$T/test" && node tb.js ) > "$T/out.json"
python3 - "$T/out.json" "$HERE/start_code.txt" <<'EOF'
import json, sys
o = json.load(open(sys.argv[1]))
open(sys.argv[2], 'w').write(o['code'] + '\n')
checks = [
  ('every key it wrote is klkuw_ (or the seeded real ones)', all(k.startswith('klkuw_') or k in ('klk_save_slot1','klk_active_slot') for k in o['keysAfterSave'])),
  ('it saved to its own slot key', 'klkuw_save_slot1' in o['keysAfterSave']),
  ('the real save is byte-for-byte untouched', o['realUntouched']),
  ('the code loads', o['loaded'] is True),
  ('it starts on lake A\'s beach, Sea Dragon, level 18+', o['spot'][:5] == ['overworld', 169, 37, 'steadfast', 2] and o['spot'][5] >= 18),
  ('a short swim puts him on the marker', o['swamTo'] == [170, 40]),
  ('one tap of the mount button mounts him', o['mounted'] is True),
  ('and Ⓐ (the real key) takes him down', o['after'] == 'underwater'),
  ('and it plays', o['frames'] == 'ok'),
  ('the title says TEST', o['tag'].startswith('UW-TEST')),
]
for name, ok in checks: print(('  ok   ' if ok else '  FAIL ') + name)
print('  keys:', o['keysAfterSave'], '| start:', o['spot'])
sys.exit(0 if all(ok for _, ok in checks) else 1)
EOF
rc=$?; rm -rf "$T"; exit $rc

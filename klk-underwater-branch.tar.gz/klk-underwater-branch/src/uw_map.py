# Builds the underwater maps as fixed ASCII rows. TWO ROOMS (Zak, v4):
#   COURTS  — the Reef Garden, expanded. The house stands at its north end as a
#             BUILDING (a compact exterior, like the game's chapels); you walk in
#             through its doorway.
#   TEMPLE  — the house within, after Solomon's (1 Kings 6-7), facing south:
#             porch -> Holy Place -> Most Holy Place, one tile = two cubits
#             (porch 5x10, Holy Place 20x10, Most Holy Place 10x10). The side
#             chambers (6:5-10) open off both side walls of the Holy Place.
# Facing out of the house (south): Jachin on the right (west), Boaz on the left
# (east), freestanding before the door (7:21). The Sea sits at the front-right
# corner (7:39). No randomness anywhere: the same rows every boot.

def grid(W,H,fill='x'): return [[fill]*W for _ in range(H)]
def mk(G):
    def rect(x0,y0,x1,y1,c):
        for y in range(y0,y1+1):
            for x in range(x0,x1+1): G[y][x]=c
    def put(x,y,c): G[y][x]=c
    def ring(x0,y0,x1,y1,c):
        for x in range(x0,x1+1): G[y0][x]=c; G[y1][x]=c
        for y in range(y0,y1+1): G[y][x0]=c; G[y][x1]=c
    return rect,put,ring

# ══ COURTS (52 x 48) ═══════════════════════════════════════════════════════
CW, CH_ = 52, 48
C = grid(CW, CH_); rect,put,ring = mk(C)
rect(0,0,CW-1,CH_-1,'k'); rect(3,3,CW-4,CH_-4,'.')
for (x,y) in [(3,3),(4,3),(3,4),(48,3),(47,3),(48,4),(3,44),(4,44),(3,43),(48,44),(47,44),(48,43),(16,44),(17,44),(34,44),(35,44),(3,20),(3,21),(48,30),(48,31)]:
    C[y][x]='k'
# the house as a building: footprint x 19..32, y 4..17 is drawn as an object; floor beneath
TEMPLE_EXT = (19,4,14,10)                     # x, y, w, h (tiles)
DOOR = [(25,13),(26,13)]                      # its doorway: walk north into it to go in
# a paved forecourt before the porch
rect(19,14,32,22,'f')
# Jachin (west) and Boaz (east), freestanding before the door: capital + two shaft tiles
for x in (23,28): put(x,14,'J'); put(x,15,'j'); put(x,16,'j')
# seagrass, coral, rock: the garden has grown into the courts
for (x0,y0,x1,y1) in [(5,6,10,10),(39,6,45,9),(5,24,9,28),(41,26,46,29),(8,36,14,40),(37,37,44,41),(22,30,27,33),(15,23,17,26)]:
    rect(x0,y0,x1,y1,'g')
for (x,y) in [(12,5),(13,5),(35,7),(46,13),(45,14),(6,18),(7,18),(30,27),(33,40),(20,40),(11,31),(44,33),(16,9),(36,15)]:
    C[y][x]='c'
for (x,y) in [(15,11),(34,12),(9,21),(42,22),(28,38),(6,33)]:
    C[y][x]='r'
for (x,y) in [(17,6),(17,7),(34,5),(35,10),(18,20)]:          # fallen masonry from the house
    C[y][x]='w'
# ten lavers, five on each side (7:39)
for y in (20,23,26,29,32): put(13,y,'v'); put(38,y,'v')
# ZEBULUN'S AIR DOME, east of the court; the way in faces west
ring(40,16,46,21,'d'); rect(41,17,45,20,'.'); put(40,19,'.')
put(39,23,'t')                                  # the Psalm 104 stone, by his door
# record tablet 1, in a kelp nook on the court's west edge
rect(3,29,5,34,'k'); put(5,31,'.'); put(5,32,'.'); put(4,32,'t')
# the five ENTRY currents, roughly where each dive spot lies on the map above
ENTRY = {'A':(46,6), 'B':(6,5), 'C':(6,42), 'D':(45,42), 'E':(26,43)}
for k,(x,y) in ENTRY.items(): put(x,y,'u')
CH = {'dec_planter':(8,14), 'dec_wheel':(42,38), 'pearl_g1':(47,27), 'pearl_g2':(30,35), 'pearl_g3':(12,39)}
for k,(x,y) in CH.items(): put(x,y,'$')
COURTS = [''.join(r) for r in C]
COURTS_OBJ = {'temple':('uwDrawTempleExterior',)+TEMPLE_EXT, 'altar':('uwDrawAltar',25,18,2,2), 'sea':('uwDrawMoltenSea',15,15,3,3)}
COURTS_NPC = {'zebulun':(43,18)}
COURTS_TABLETS = {'rec1':(4,32), 'ps104':(39,23)}
DOOR_IN = (25,14)                               # where you stand when you come back out

# ══ TEMPLE (30 x 42) ═══════════════════════════════════════════════════════
TW, TH = 30, 42
T = grid(TW, TH); rect,put,ring = mk(T)
# the side chambers: stone, x 1..28, y 1..40; the house sits in the middle
rect(1,1,28,40,'w'); rect(2,2,27,39,'.')
# the house: cedar walls x=9 and x=20, rows 1..39; gold floor within
rect(9,1,20,39,'C'); rect(10,2,19,38,'_')
for x in range(10,20): put(x,12,'C'); put(x,33,'C')
put(14,12,'I'); put(15,12,'I')                 # the olive-wood doors of the Most Holy Place
put(14,33,'_'); put(15,33,'_')                 # the doors of the Holy Place stand open
put(14,39,'_'); put(15,39,'_')                 # the porch doorway: out to the courts
for x in range(10,20): put(x,40,'x')
put(14,40,'_'); put(15,40,'_')                 # (the threshold: stepping here takes you out)
# doorways off the Holy Place into the chambers, one each side
put(9,22,'_'); put(9,23,'_'); put(20,24,'_'); put(20,25,'_')
# the chambers' old room divisions, some fallen
for y in (10,19,29):
    for x in range(2,9): put(x,y,'w')
    for x in range(21,28): put(x,y,'w')
for (x,y) in [(4,10),(5,10),(7,19),(3,29),(4,29),(23,10),(26,19),(25,29),(26,29)]: put(x,y,'.')
for (x,y) in [(3,5),(6,14),(2,25),(7,36),(22,13),(26,22),(23,34)]: put(x,y,'r')
for (x,y) in [(5,7),(24,26)]: put(x,y,'o')
# ten golden lampstands, five on each side of the Holy Place (7:49)
LAMPSTANDS = [(10,y) for y in (14,18,22,26,30)] + [(19,y) for y in (14,18,22,26,30)]
# the doorway west is at row 22-23: lampstand (10,22) sits beside it, fine; keep the walls' doors clear
for (x,y) in LAMPSTANDS: put(x,y,'L')
PRAYER = {'L2':(10,22), 'L4':(19,30), 'L5':(10,14), 'L9':(19,18)}   # Jonah 2:2, 2:4, 2:5, 2:9
# the Most Holy Place: cherubim (objects), the humble chest, tablet 3, the Micah stone
put(12,8,'t'); put(17,8,'t')
put(17,35,'t')                                 # the porch stone: "Pray as the prophet prayed"
# TIRZAH, in an east chamber, in her air dome; the way in faces west
ring(22,4,26,8,'d'); rect(23,5,25,7,'.'); put(22,6,'.')
put(4,24,'t')                                  # record tablet 2, in a west chamber
TCH = {'dec_bell':(3,3), 'dec_fountain':(26,37), 'pearl_r1':(6,12), 'pearl_r2':(3,37), 'pearl_r3':(26,16)}
for k,(x,y) in TCH.items(): put(x,y,'$')
TEMPLE = [''.join(r) for r in T]
TEMPLE_OBJ = {'cherubW':('uwDrawCherubFront',10,2,5,3), 'cherubE':('uwDrawCherubFront',15,2,5,3),
              'humble':('uwDrawHumbleChest',14,5,2,1)}
TEMPLE_NPC = {'tirzah':(24,6)}
TEMPLE_TABLETS = {'rec2':(4,24), 'rec3':(12,8), 'micah':(17,8), 'porch':(17,35)}
INNER_DOOR = [(14,12),(15,12)]
EXIT = [(14,40),(15,40)]                        # stepping here takes you out to DOOR_IN
ARRIVE = (14,37)                                # where you stand when you come in

if __name__=='__main__':
    print('COURTS'); [print(f'{i:2d} {r}') for i,r in enumerate(COURTS)]
    print('TEMPLE'); [print(f'{i:2d} {r}') for i,r in enumerate(TEMPLE)]

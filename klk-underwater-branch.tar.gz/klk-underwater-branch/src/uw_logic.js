
// ════════════════════════════════════════════════════════════════
//  UNDERWATER — STATE
//  Everything that persists lives in `uwSaved` and goes out under its OWN save
//  key, `underwater` (buildSaveData hook). A save from before this block has no
//  such key, and uwLoad() turns that into "never been underwater".
//  Everything in `uw` is transient and rebuilt on demand.
// ════════════════════════════════════════════════════════════════
function uwFresh(){ return { v:1, from:null, at:null, visited:{}, chests:{}, tablets:{}, read:{},
  lamps:[], opened:false, livery:false, barding:false, quiz:false, pearls:0, sold:0,
  met:{}, eldan:{ fish:false, kind:false } }; }
let uwSaved = uwFresh();
const uw = { room:'courts', grid:null, W:0, H:0, solid:null, quiz:null, btn:null, lastKey:{}, t:0, hint:0 };
// the live room's tables (rows, objects, people, tablets, chests)
function uwR(){ return UW_ROOMS[uw.room] || UW_ROOMS.courts; }

// ── the five dive spots (Zak circled them; coordinates measured, not guessed) ──
const UW_SPOTS = [
  { id:'A', x:170, y:40,  name:'the lake by Crystalpeak'   },
  { id:'B', x:70,  y:120, name:'the river pond'            },
  { id:'C', x:40,  y:170, name:'the west pond'             },
  { id:'D', x:230, y:200, name:'the pond by the Shadowmere road' },
  { id:'E', x:190, y:234, name:"Stormgate's east harbour" },
];
const UW_PRAYER_ORDER = ['L2','L4','L5','L9'];
const UW_PRAYER_TEXT = {
  L2:['Jonah 2:2','I cried by reason of mine affliction unto the LORD, and he heard me; out of the belly of hell cried I, and thou heardest my voice.'],
  L4:['Jonah 2:4','Then I said, I am cast out of thy sight; yet I will look again toward thy holy temple.'],
  L5:['Jonah 2:5','The waters compassed me about, even to the soul: the depth closed me round about, the weeds were wrapped about my head.'],
  L9:['Jonah 2:9','But I will sacrifice unto thee with the voice of thanksgiving; I will pay that that I have vowed. Salvation is of the LORD.'],
};
const UW_CHEST_LOOT = {
  dec_planter:{ decor:'uw_coralPlanter' }, dec_wheel:{ decor:'uw_wheelSign' },
  dec_bell:{ decor:'uw_bellArbor' },       dec_fountain:{ decor:'uw_pearlFountain' },
  humble:{ decor:'uw_woodenCross' },
  pearl_g1:{ pearls:2 }, pearl_g2:{ pearls:1 }, pearl_g3:{ pearls:2 },
  pearl_r1:{ pearls:3 }, pearl_r2:{ pearls:2 }, pearl_r3:{ pearls:3 },
};
const UW_PEARL_PRICE = 120;
const UW_QUIZ = [
  { q:'From where did Jonah cry unto the LORD?', a:1,
    o:['From the deck of the ship, before the storm','Out of the belly of the fish — “out of the belly of hell cried I”','From the city of Nineveh','From the shore where he was cast up'] },
  { q:'Cast out of God’s sight, where did Jonah say he would look?', a:2,
    o:['Back toward the land of his fathers','Up toward the sky, for rescue','Again toward thy holy temple','Down into the deep, in despair'] },
  { q:'How does Jonah’s prayer end?', a:0,
    o:['“Salvation is of the LORD”','“Let the sea take me”','“I have done no wrong”','“Send another in my stead”'] },
];

// ── the grid: the live room's rows -> tile codes; opened doors and taken tablets applied ──
function uwBuildGrid(room){
  if(room) uw.room=room;
  const R=uwR(), g=R.rows.map(r=>[...r].map(ch=>UW_CHAR[ch]));
  if(uw.room==='temple' && uwSaved.opened) for(const [x,y] of UW_INNER_DOOR) g[y][x]=UW_T.GOLDFLOOR;
  for(const id in R.tablets) if(/^rec/.test(id) && uwSaved.tablets[id]){ const [x,y]=R.tablets[id]; g[y][x]=(UW_ZONE(x,y)==='temple')?UW_T.GOLDFLOOR:UW_T.SAND; }
  uw.grid=g; uw.H=g.length; uw.W=g[0].length;
  uw.solid=new Set();
  for(const k in R.obj){ const [,x,y,w,h]=R.obj[k]; for(let yy=y;yy<y+h;yy++) for(let xx=x;xx<x+w;xx++) uw.solid.add(xx+','+yy); }
  if(uw.room==='courts') for(const [x,y] of UW_DOOR) uw.solid.delete(x+','+y);   // the house's doorway is open
  for(const k in R.npc){ const [x,y]=R.npc[k]; uw.solid.add(x+','+y); }
}
function uwRegionName(){
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE), z=UW_ZONE(tx,ty);
  if(z==='garden') return 'The Drowned Courts';
  if(z==='ruins') return 'The Side Chambers';
  return ty<=11 ? 'The Most Holy Place' : ty<=32 ? 'The Holy Place' : 'The Porch';
}
// courts: all garden. temple: the house within (x 10..19, y 2..39) is gold; the chambers are ruins
function UW_ZONE(tx,ty){ if(uw.room!=='temple') return 'garden'; return (tx>=10&&tx<=19&&ty>=2&&ty<=39) ? 'temple' : 'ruins'; }
const UW_WALK = new Set([0,1,5,8,19]);           // sand, seagrass, flagstone, current, gold floor
function uwTile(tx,ty){ return (uw.grid && uw.grid[ty] && uw.grid[ty][tx]!==undefined) ? uw.grid[ty][tx] : UW_T.TRENCH; }
function uwWalkable(tx,ty){ return UW_WALK.has(uwTile(tx,ty)) && !uw.solid.has(tx+','+ty); }
function uwLampLit(tx,ty){
  if(uw.room!=='temple') return false;
  if(uwSaved.opened) return true;
  for(const id of uwSaved.lamps){ const p=UW_PRAYER[id]; if(p && p[0]===tx && p[1]===ty) return true; }
  return false;
}

// ── SAVE / LOAD (hooks in buildSaveData and applySaveData) ──
function uwSave(){
  if(!UW_ON) return undefined;
  const s=JSON.parse(JSON.stringify(uwSaved));
  s.at = (place.kind==='underwater') ? { x:Math.round(player.x), y:Math.round(player.y), room:uw.room } : null;
  return s;
}
function uwLoad(s){
  uwSaved=uwFresh(); uw.grid=null; uw.room='courts'; uwQuizClose(true); uwHideButton();   // any load leaves the deep (uwRestore may re-enter)
  if(!UW_ON) return;
  if(s && typeof s==='object'){
    const F=uwFresh();
    for(const k in F){ if(s[k]===undefined) continue;
      if(F[k]!==null && typeof F[k]==='object' && !Array.isArray(F[k])) uwSaved[k]=Object.assign({},F[k],(s[k]&&typeof s[k]==='object')?s[k]:{});
      else if(Array.isArray(F[k])) uwSaved[k]=Array.isArray(s[k])?s[k].filter(id=>UW_PRAYER_ORDER.includes(id)):[];
      else uwSaved[k]=s[k]; }
    uwSaved.pearls=Math.max(0,uwSaved.pearls|0); uwSaved.sold=Math.max(0,uwSaved.sold|0);
  }
  uwEldanCheck(true);                            // trials finished before this update still pay out
}
// restoreWhere hook: a save made underwater comes back underwater, where it was made
function uwRestore(){
  if(!UW_ON || !uwCanDive()) return false;
  const at=uwSaved.at;
  uwBuildGrid(at && UW_ROOMS[at.room] ? at.room : 'courts');
  place={kind:'underwater'};
  player.mounted=true; player.boating=false; demons=[];
  const ok=at && uwWalkable(Math.floor((at.x+TILE/2)/TILE), Math.floor((at.y+TILE/2)/TILE));
  if(!ok) uwBuildGrid('courts');
  const e=UW_ENTRY[uwSaved.from||'A'];
  player.x = ok ? at.x : e[0]*TILE; player.y = ok ? at.y : (e[1]-1)*TILE;
  uwSaved.at=null;
  if(typeof updateMountBtn==='function') updateMountBtn();
  return true;
}

// ── who may dive ──
function uwCanDive(){ return !!(player.pet && player.pet.id==='steadfast' && player.pet.form===2); }
function uwSpotHere(){
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE);
  return UW_SPOTS.find(s=>Math.abs(s.x-tx)<=1 && Math.abs(s.y-ty)<=1) || null;
}

// ── Ⓐ: the doAction hook. true = handled (and no sword is swung) ──
function uwAction(){
  if(!UW_ON) return false;
  if(place.kind==='underwater'){ uwUnderAction(); return true; }
  if(place.kind!=='overworld') return false;
  const s=uwSpotHere(); if(!s) return false;
  if(player.mounted && !player.boating && uwCanDive()){ uwDive(s); return true; }
  if(player.mounted || player.boating){
    showBanner('🌊 <b style="color:#9fd0e8">The water turns dark and deep here.</b><br><span style="font-size:7px">Something far below catches the light. Only a creature of the sea could carry you down.</span>', 2600);
    return true;
  }
  return false;
}
function uwDive(s){
  beginCross('stair', ()=>{
    lastOverworld.x=s.x*TILE; lastOverworld.y=s.y*TILE;
    uwSaved.from=s.id; const first=!Object.keys(uwSaved.visited).length; uwSaved.visited[s.id]=true;
    uwBuildGrid('courts');
    fishing=null; player.boating=false; player.mounted=true; demons=[];
    place={kind:'underwater'};
    const e=UW_ENTRY[s.id]; player.x=e[0]*TILE; player.y=(e[1]-1)*TILE; player.dir='up';
    if(typeof updateMountBtn==='function') updateMountBtn();
    saveGame();
    showBanner(first
      ? '🌊 <b style="color:#9ff0ff">Down, down into the deep…</b><br><span style="font-size:7px">A drowned court opens around you, and beyond it the pillars of a house of gold. “So is this great and wide sea” — Psalm 104:25</span>'
      : '🌊 <b style="color:#9ff0ff">You dive from '+s.name+'.</b>', first?4200:1600);
  });
}
function uwSurface(spotId){
  const s=UW_SPOTS.find(q=>q.id===spotId) || UW_SPOTS[0];
  beginCross('stair', ()=>{
    uwQuizClose(true); uwHideButton();
    place={kind:'overworld'};
    player.x=s.x*TILE; player.y=s.y*TILE; player.mounted=true; player.boating=false; player.dir='down';
    lastOverworld.x=player.x; lastOverworld.y=player.y;
    uwSaved.at=null;
    demons=[]; spawnDemons();
    if(typeof updateMountBtn==='function') updateMountBtn();
    saveGame();
    showBanner('🌅 You break the surface at '+s.name+'.', 1600);
  });
}

// ── the frame: the loop() hook hands the whole frame to this ──
function uwFrame(dt){
  uw.t+=dt;
  if(bannerT>0 && !dialogue.open){ bannerT-=dt; if(bannerT<=0) banner.style.display='none'; }
  uwSyncButton();
  if(!uw.grid) uwBuildGrid();
  // the HUD the overworld branch would have kept current: where you are, the hour, your health
  { const el=document.getElementById('loc'), nm=uwRegionName(); if(el && el.textContent!==nm) el.textContent=nm; }
  setHudHint(`${phaseIcon()} ${clockHHMM()}`, 0);
  { const hb=document.getElementById('hpbar'); if(hb) hb.style.width=(player.hp/player.maxHp*100)+'%'; }
  const frozen = dialogue.open || cross.t>0 || !!uw.quiz;
  if(uw.quiz) uwQuizInput();
  let dx=0, dy=0;
  if(!frozen){
    if(held.up) dy=-1; else if(held.down) dy=1;
    if(held.left) dx=-1; else if(held.right) dx=1;
    if(dx&&dy){ const k=0.70710678; dx*=k; dy*=k; }
    if(dy<0) player.dir='up'; else if(dy>0) player.dir='down'; else if(dx<0) player.dir='left'; else if(dx>0) player.dir='right';
  }
  player.moving=!!(dx||dy);
  if(player.moving){
    const spd=SPEED*1.4*(dt/16);                 // the Sea Dragon's swim: its overworld mounted pace
    const cx=Math.floor((player.x+TILE/2)/TILE), cy=Math.floor((player.y+TILE/2)/TILE);
    const nx=player.x+dx*spd, ny=player.y+dy*spd;
    if(uwWalkable(Math.floor((nx+TILE/2)/TILE), cy)) player.x=nx;
    if(uwWalkable(Math.floor((player.x+TILE/2)/TILE), Math.floor((ny+TILE/2)/TILE))) player.y=ny;
    player.ftick=(player.ftick||0)+1; if(player.ftick%8===0) player.frame=((player.frame||0)+1)%4;
    uwThresholds();
  }
  draw();                                        // the draw() hook routes to uwDraw()
}
// ── walking in and out of the house: the doorway in the courts, the threshold inside ──
function uwThresholds(){
  if(cross.t>0) return;
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE);
  const on=(L)=>L.some(([x,y])=>x===tx&&y===ty);
  if(uw.room==='courts' && player.dir==='up' && on(UW_DOOR)) beginCross('door', ()=>{
    uwBuildGrid('temple'); player.x=UW_ARRIVE[0]*TILE; player.y=UW_ARRIVE[1]*TILE; player.dir='up';
    if(!uwSaved.met.house){ uwSaved.met.house=true;
      showBanner('🕯 <b style="color:#f0d890">The house within.</b><br><span style="font-size:7px">“And the house, when it was in building, was built of stone made ready before it was brought thither: so that there was neither hammer nor axe nor any tool of iron heard in the house.” — 1 Kings 6:7</span>', 4200); }
    saveGame(); });
  else if(uw.room==='temple' && player.dir==='down' && on(UW_EXIT)) beginCross('door', ()=>{
    uwBuildGrid('courts'); player.x=UW_DOOR_IN[0]*TILE; player.y=UW_DOOR_IN[1]*TILE; player.dir='down'; saveGame(); });
}
// the surface button (⬆) and the U key: block-owned, no hook needed
function uwSyncButton(){
  if(!uw.btn){
    const mb=document.getElementById('mountBtn');
    const host=(mb && mb.parentNode) || document.getElementById('stage');   // a sibling of the mount button, on the stage
    if(host && document.createElement){
      const b=document.createElement('div'); b.setAttribute('id','uwSurfaceBtn'); b.textContent='⬆';
      b.style.cssText='position:absolute;top:7px;right:110px;z-index:11;background:rgba(20,60,80,.88);border:1px solid #7fd0e8;color:#fff;font-size:13px;width:30px;height:26px;border-radius:5px;display:none;align-items:center;justify-content:center;';
      const go=e=>{ if(e&&e.preventDefault) e.preventDefault(); uwSurfaceAsked(); };
      if(b.addEventListener){ b.addEventListener('touchstart',go,{passive:false}); b.addEventListener('mousedown',go); }
      host.appendChild(b); uw.btn=b;
    }
  }
  if(uw.btn){ const want=(place.kind==='underwater' && boot.done)?'flex':'none'; if(uw.btn.style.display!==want) uw.btn.style.display=want; }
}
function uwHideButton(){ if(uw.btn && uw.btn.style.display!=='none') uw.btn.style.display='none'; }
function uwSurfaceAsked(){
  if(place.kind!=='underwater' || dialogue.open || uw.quiz || cross.t>0) return;
  uwSurface(uwSaved.from||'A');
}
if(UW_ON && typeof addEventListener==='function') addEventListener('keydown', e=>{
  if(e && e.key && e.key.toLowerCase()==='u' && !e.repeat && place.kind==='underwater') uwSurfaceAsked(); });

// ── Ⓐ underwater ──
function uwFacing(){
  const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[player.dir]||[0,1];
  const cx=Math.floor((player.x+TILE/2)/TILE), cy=Math.floor((player.y+TILE/2)/TILE);
  return [cx,cy,cx+d[0],cy+d[1]];
}
function uwUnderAction(){
  if(uw.quiz){ uwQuizSelect(); return; }
  if(cross.t>0) return;
  const [cx,cy,fx,fy]=uwFacing();
  // a rising current, under you or before you, takes you up at its own spot
  for(const [x,y] of [[cx,cy],[fx,fy]]) if(uwTile(x,y)===UW_T.CURRENT){
    const id=Object.keys(UW_ENTRY).find(k=>UW_ENTRY[k][0]===x&&UW_ENTRY[k][1]===y); uwSurface(id||uwSaved.from||'A'); return; }
  // people
  const R=uwR();
  for(const k in R.npc){ const [x,y]=R.npc[k]; if(x===fx&&y===fy){ k==='zebulun'?uwTalkZebulun():uwTalkTirzah(); return; } }
  // the large pieces
  for(const k in R.obj){ const [,x,y,w,h]=R.obj[k]; if(fx>=x&&fx<x+w&&fy>=y&&fy<y+h && !(uw.room==='courts' && UW_DOOR.some(([dx,dy])=>dx===fx&&dy===fy))){ uwObjAction(k); return; } }
  const t=uwTile(fx,fy), key=fx+','+fy;
  const chest=Object.keys(R.chests).find(k=>R.chests[k][0]===fx&&R.chests[k][1]===fy);
  if(chest && t===UW_T.CHEST){ uwOpenChest(chest); return; }
  const tab=Object.keys(R.tablets).find(k=>R.tablets[k][0]===fx&&R.tablets[k][1]===fy);
  if(tab && t===UW_T.TABLET){ uwReadTablet(tab); return; }
  if(t===UW_T.LAMPSTAND){ uwLamp(fx,fy); return; }
  if(t===UW_T.PILLAR || t===UW_T.PILLAR_TOP){ uwPillar(fx); return; }
  if(t===UW_T.INNERDOOR){ say(['The olive-wood doors are shut fast, gold over carved cherubim, palms, and open flowers. No handle, no lock. Only the house itself can open them.']); return; }
  if(t===UW_T.LAVER){ say(['A laver on its wheeled base: lions, oxen, and cherubim cast in its panels (1 Kings 7:29). It still holds water — the sea’s own.']); return; }
  if(t===UW_T.CHEST){ showBanner('The chest hangs open. Nothing more here.', 1100); return; }
}
function uwObjAction(k){
  if(k==='sea') say(['The Molten Sea: ten cubits brim to brim, standing upon twelve oxen, three looking to each quarter (1 Kings 7:23-25).','It was made for the priests to wash in. Now the whole sea washes over it.']);
  else if(k==='altar') say(['The altar of brass, long cold (2 Chronicles 4:1). No fire has burned here in an age.','Its horns still point to the four winds.']);
  else if(k==='humble') uwOpenChest('humble');
  else if(k==='temple') say(['The house of the LORD, standing in the deep. Hewn stone, every block made ready before it was brought (1 Kings 6:7).','The way in is the doorway between the pillars.']);
  else say(['Two cherubim of olive wood overlaid with gold, ten cubits high. The wing of the one touches the one wall, the wing of the other the other wall, and their wings touch one another in the midst of the house (1 Kings 6:23-27).']);
}
function uwPillar(fx){
  if(fx<26) say(['Jachin — “he shall establish.” The right pillar of the porch, brass, with lily-work and rows of pomegranates (1 Kings 7:21).']);
  else say(['Boaz — “in it is strength.” The left pillar of the porch, brass, with lily-work and rows of pomegranates (1 Kings 7:21).']);
}
function uwOpenChest(k){
  if(uwSaved.chests[k]){ showBanner('The chest hangs open. Nothing more here.', 1100); return; }
  if(k==='humble' && !uwSaved.opened) return;
  const L=UW_CHEST_LOOT[k]; if(!L) return;
  uwSaved.chests[k]=true;
  if(L.decor){ const it=DECOR_ITEMS[L.decor];
    homesteadDecor.inv[L.decor]=(homesteadDecor.inv[L.decor]||0)+1;
    if(k==='humble') say(['A small chest of plain wood, tied with cord. Nothing on it is gold.','Inside, wrapped in linen: a cross of rough timber.','“But God forbid that I should glory, save in the cross of our Lord Jesus Christ” — Galatians 6:14',
      '✝️ The <b>Wooden Cross</b> is yours, to raise at your Homestead (☰ Home).']);
    else showBanner('📦 <b style="color:#ffd27a">'+it.emoji+' '+it.name+'!</b><br><span style="font-size:7px">A Homestead decoration — place it from your ☰ Home tab.</span>', 3000);
  } else if(L.pearls){ uwSaved.pearls+=L.pearls;
    showBanner('🦪 <b style="color:#f4f0e8">'+L.pearls+' pearl'+(L.pearls>1?'s':'')+'!</b><br><span style="font-size:7px">You carry '+uwSaved.pearls+'. Zebulun the pearl-diver pays well for them.</span>', 2400); }
  saveGame();
}
function uwReadTablet(k){
  if(k==='rec1'||k==='rec2'||k==='rec3'){
    if(!uwSaved.tablets[k]){ uwSaved.tablets[k]=true; uwBuildGrid(); saveGame();
      const n=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
      showBanner('📜 <b style="color:#c8f0a0">A record tablet ('+n+' of 3).</b><br><span style="font-size:7px">Its letters are worn but whole. Tirzah, keeper of the records, will want it.</span>', 2600); }
    return; }
  if(k==='porch'){ say(['Letters cut deep into the porch stone:','“PRAY AS THE PROPHET PRAYED, FROM THE DEEP TO THE DELIVERANCE, AND THE HOUSE WILL BE FILLED WITH LIGHT.”']); return; }
  if(k==='ps104'){ codexAdd('The drowned courts','Psalm 104:24-26','O LORD, how manifold are thy works! in wisdom hast thou made them all: the earth is full of thy riches. So is this great and wide sea, wherein are things creeping innumerable, both small and great beasts. There go the ships: there is that leviathan, whom thou hast made to play therein.');
    say(['“O LORD, how manifold are thy works! in wisdom hast thou made them all: the earth is full of thy riches.”','“So is this great and wide sea, wherein are things creeping innumerable, both small and great beasts.” — Psalm 104:24-25']); return; }
  if(k==='micah'){ codexAdd('The Most Holy Place, drowned','Micah 7:19','He will turn again, he will have compassion upon us; he will subdue our iniquities; and thou wilt cast all their sins into the depths of the sea.');
    say(['“He will turn again, he will have compassion upon us; he will subdue our iniquities; and thou wilt cast all their sins into the depths of the sea.” — Micah 7:19','Here, in the depths of the sea, the words read differently.']); return; }
}
function uwLamp(tx,ty){
  if(uwSaved.opened){ showBanner('The lampstand burns steady. The house is full of light.', 1300); return; }
  const id=Object.keys(UW_PRAYER).find(k=>UW_PRAYER[k][0]===tx&&UW_PRAYER[k][1]===ty);
  if(!id){ showBanner('This lampstand bears no words. It will not take the flame.', 1500); return; }
  if(uwSaved.lamps.includes(id)){ const T=UW_PRAYER_TEXT[id]; showBanner('🕯 <i>'+T[1]+'</i> — '+T[0], 2600); return; }
  const want=UW_PRAYER_ORDER[uwSaved.lamps.length], T=UW_PRAYER_TEXT[id];
  if(id!==want){
    uwSaved.lamps=[]; saveGame();
    showBanner('💨 <b>The flames gutter out.</b><br><span style="font-size:7px">“'+T[1]+'” — not yet. Pray as the prophet prayed.</span>', 3000);
    return; }
  uwSaved.lamps.push(id);
  if(uwSaved.lamps.length<UW_PRAYER_ORDER.length){ saveGame();
    showBanner('🕯 <b style="color:#fff2a8">The lamp takes the flame.</b><br><span style="font-size:7px">“'+T[1]+'” — '+T[0]+'</span>', 3200); return; }
  // the prayer is whole: all ten blaze, the inner doors open, the livery is given
  uwSaved.opened=true; uwSaved.livery=true; uwBuildGrid(); saveGame();
  say(['“Salvation is of the LORD.”',
       'One by one, all ten lampstands take the flame, and the house is filled with light.',
       'The olive-wood doors of the inner house swing open.',
       '🧥 A livery is laid by the doors: <b>Deepwater Pearl</b>. Wear it from the wardrobe in your house.']);
}

// ── ZEBULUN: Psalm 104, and he buys pearls ──
function uwTalkZebulun(){
  const N='Zebulun the Pearl-Diver';
  if(!uwSaved.met.zebulun){ uwSaved.met.zebulun=true; saveGame();
    sayAs(N,['Ho! A knight, riding a dragon of the deep! Come in out of the water — well, out of MOST of it.',
      'I am Zebulun. My fathers’ blessing was that we would “dwell at the haven of the sea” (Genesis 49:13). I took it further than they meant.',
      'These are the courts of a house built long ago for the LORD’s name. The sea took the city; it never took the house.',
      'I dive for pearls in the old chests. Bring me any you find — '+UW_PEARL_PRICE+' gold apiece, and a blessing thrown in free.']); return; }
  if(uwSaved.pearls>0){ const n=uwSaved.pearls, g=n*UW_PEARL_PRICE;
    uwSaved.pearls=0; uwSaved.sold+=n; gold+=g; saveGame();
    sayAs(N,['He weighs each pearl in his palm and holds it up to the lamplight.',
      '“The kingdom of heaven is like unto a merchant man, seeking goodly pearls” (Matthew 13:45). Well, here I am!',
      '💰 +'+g+' gold for '+n+' pearl'+(n>1?'s':'')+'.']); return; }
  sayAs(N,[['“O LORD, how manifold are thy works!” I say it every morning, and every morning I mean it more.','Mind the Sea by the porch — the great bronze basin. Twelve oxen, and not one has blinked in a thousand years.','The pillars at the porch have names. Read them. Names are how the LORD’s people remembered.'][uwSaved.sold%3]]);
}
// ── TIRZAH: the records, then her questions ──
function uwTalkTirzah(){
  const N='Tirzah, Keeper of the Records';
  const have=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
  if(uwSaved.quiz){ sayAs(N,['The records are whole, and you have understood them. That is rarer than finding them.','“Salvation is of the LORD.” Remember where Jonah was when he learned it.']); return; }
  if(!uwSaved.met.tirzah){ uwSaved.met.tirzah=true; saveGame();
    sayAs(N,['You came down on purpose. Few do.','I keep the records of this house. Three tablets were scattered when the waters came: one in the courts, one in the fallen chambers, and one in the inner house, which no one has entered since.','Bring them to me, and then tell me what they say. A record no one understands is only a stone.']); return; }
  if(have<3){ sayAs(N,['You have found '+have+' of the three.'+(uwSaved.opened?'':' The last lies beyond the inner doors — and those open only to prayer.')]); return; }
  sayAs(N,['All three. Let me read them to you — they are the prayer of Jonah, from the belly of the fish.','Now: what did you hear?'], ()=>uwQuizOpen());
}
// ── the questions: a block-owned overlay in #gamemenu; Ⓐ comes in through doAction ──
function uwQuizOpen(){ uw.quiz={ i:0, pick:-1, answered:false }; uwQuizRender(); }
function uwQuizClose(silent){
  if(!uw.quiz) return; uw.quiz=null;
  const el=document.getElementById('gamemenu'); if(el){ el.classList.remove('open'); if(!silent) el.innerHTML=''; }
}
function uwQuizRender(){
  const el=document.getElementById('gamemenu'); if(!el||!uw.quiz) return;
  const Q=UW_QUIZ[uw.quiz.i];
  let h='<div class="gm-tabs"><div class="gm-tab sel">📜 Tirzah’s Questions — '+(uw.quiz.i+1)+' of '+UW_QUIZ.length+'</div></div><div class="gm-body">';
  h+='<div style="font-size:8px;color:#fff;line-height:1.8;margin:6px 4px 8px">'+Q.q+'</div>';
  if(!uw.quiz.answered){
    Q.o.forEach((o,i)=>{ h+='<div class="gm-node '+(uw.quiz.pick===i?'cur':'')+'" data-uwq="'+i+'" style="line-height:1.7"><span class="nm" style="pointer-events:none">'+String.fromCharCode(65+i)+'. '+o+'</span></div>'; });
    h+='<div class="gm-node" data-uwq="x"><span class="nm" style="pointer-events:none">↩ Leave for now</span></div>';
    h+='<div class="gm-hint">Tap an answer, or ▲▼ then Ⓐ</div>';
  } else {
    const ok=uw.quiz.pick===Q.a;
    h+='<div style="font-size:9px;color:'+(ok?'#6fdf8a':'#ff8a8a')+';margin:6px 4px;font-weight:bold">'+(ok?'✓ Yes.':'✗ Not so. Read it again.')+'</div>';
    h+='<div class="gm-node cur" data-uwq="go"><span class="nm" style="pointer-events:none">'+(ok?(uw.quiz.i<UW_QUIZ.length-1?'Next ▶':'✓ Finish'):'↻ Try again')+'</span></div>';
  }
  h+='</div>';
  el.innerHTML=h; el.classList.add('open');
  if(!el._uwq && el.addEventListener){ el._uwq=true;
    el.addEventListener('click', e=>{ if(!uw.quiz) return; const n=e.target && e.target.closest ? e.target.closest('[data-uwq]') : null; if(!n) return;
      const v=n.getAttribute('data-uwq'); if(v==='x'){ uwQuizClose(); return; }
      if(v==='go'){ uwQuizSelect(); return; } uw.quiz.pick=+v; uwQuizSelect(); }); }
}
function uwQuizInput(){
  const edge=k=>{ const d=!!held[k], was=!!uw.lastKey[k]; uw.lastKey[k]=d; return d&&!was; };
  if(uw.quiz.answered) return;
  const n=UW_QUIZ[uw.quiz.i].o.length+1;
  if(edge('up')){ uw.quiz.pick=(uw.quiz.pick<=0?n-1:uw.quiz.pick-1); uwQuizRender(); }
  if(edge('down')){ uw.quiz.pick=(uw.quiz.pick+1)%n; uwQuizRender(); }
}
function uwQuizSelect(){
  const q=uw.quiz; if(!q) return;
  const Q=UW_QUIZ[q.i];
  if(!q.answered){ if(q.pick<0) return; if(q.pick===Q.o.length){ uwQuizClose(); return; } q.answered=true; uwQuizRender(); return; }
  if(q.pick!==Q.a){ q.answered=false; q.pick=-1; uwQuizRender(); return; }
  if(q.i<UW_QUIZ.length-1){ q.i++; q.answered=false; q.pick=-1; uwQuizRender(); return; }
  uwQuizClose();
  uwSaved.quiz=true; uwSaved.barding=true;
  if(!player.mountSkinOwned) player.mountSkinOwned={};
  player.mountSkinOwned.uwcoral=true;
  codexAdd('The keeper’s records','Jonah 2:9','But I will sacrifice unto thee with the voice of thanksgiving; I will pay that that I have vowed. Salvation is of the LORD.');
  saveGame();
  sayAs('Tirzah, Keeper of the Records',['You heard it. From the deep to the deliverance.','Take this. It was made for a steed of the sea long ago, and it has waited long enough.',
    '🪸 <b>Coral Barding</b> for your Sea Dragon! Put it on from the ☰ Pet tab.']);
}

// ── ELDAN'S TRIALS give the missing starter lines (two hooks + on load) ──
function uwMissingLines(){
  const own=new Set([player.pet&&player.pet.id, ...((player.barnPets||[]).map(p=>p&&p.id))]);
  return STARTER_PETS.filter(id=>!own.has(id));
}
function uwEldanGift(which, quiet){
  if(!UW_ON) return null;
  const flag = which===1 ? 'fish' : 'kind';
  if(uwSaved.eldan[flag]) return null;
  uwSaved.eldan[flag]=true;
  const id=uwMissingLines()[0]; if(!id) return null;
  if(!player.barnPets) player.barnPets=[];
  player.barnPets.push({ id, form:2 });
  if(!quiet){ const f=PETS[id].forms[2];
    setTimeout(()=>showBanner('🌿 <b style="color:#8fd4a8">Eldan’s gift: '+f.emoji+' '+f.name+'!</b><br><span style="font-size:7px">A companion of the '+PETS[id].name+' line, fully grown, waits for you at the Homestead Stables.</span>', 4200), 2600); }
  return id;
}
function uwEldanCheck(onLoad){
  if(!UW_ON) return;
  const got=[];
  if(quests.goldenFish==='done' && !uwSaved.eldan.fish){ const id=uwEldanGift(1,true); if(id) got.push(id); }
  if(quests.kindness==='done' && !uwSaved.eldan.kind){ const id=uwEldanGift(2,true); if(id) got.push(id); }
  if(got.length && onLoad) setTimeout(()=>showBanner('🌿 <b style="color:#8fd4a8">Eldan remembers your trials.</b><br><span style="font-size:7px">'+got.map(id=>PETS[id].forms[2].emoji+' '+PETS[id].forms[2].name).join(' and ')+' now wait'+(got.length>1?'':'s')+' at the Homestead Stables.</span>', 4600), 1200);
}

// ── drawing (the draw() hook) ──
function uwDraw(){
  if(!uw.grid) uwBuildGrid();
  const vw=VIEW_TW*TILE, vh=VIEW_TH*TILE;
  let camX=player.x-vw/2+TILE/2, camY=player.y-vh/2+TILE/2;
  const mx=uw.W*TILE-vw, my=uw.H*TILE-vh;
  camX = mx<0 ? mx/2 : Math.max(0,Math.min(camX,mx)); camY = my<0 ? my/2 : Math.max(0,Math.min(camY,my));
  camX=Math.round(camX); camY=Math.round(camY);
  ctx.fillStyle='#0e2230'; ctx.fillRect(0,0,VW,VH);
  const x0=Math.max(0,Math.floor(camX/TILE)), y0=Math.max(0,Math.floor(camY/TILE));
  const x1=Math.min(uw.W-1,Math.ceil((camX+vw)/TILE)), y1=Math.min(uw.H-1,Math.ceil((camY+vh)/TILE));
  for(let ty=y0;ty<=y1;ty++) for(let tx=x0;tx<=x1;tx++) uwDrawTile(uw.grid[ty][tx], tx*TILE-camX, ty*TILE-camY, tx, ty);
  // objects, people and the knight, sorted by their feet
  const objs=[];
  const R=uwR();
  for(const k in R.obj){ const [fn,x,y,w,h]=R.obj[k];
    if(x+w<x0-1||x>x1+1||y+h<y0-1||y>y1+1) continue;
    objs.push({ sy:y+h, f:()=> k==='humble' ? uwDrawHumbleChest(x*TILE-camX,y*TILE-camY,!!uwSaved.chests.humble) : UW_OBJFN[fn](x*TILE-camX,y*TILE-camY) }); }
  for(const k in R.npc){ const [x,y]=R.npc[k]; objs.push({ sy:y+1, f:()=> (k==='zebulun'?uwDrawZebulun:uwDrawTirzah)(x*TILE-camX,y*TILE-camY) }); }
  objs.push({ sy:(player.y+TILE)/TILE+0.01, f:()=>{ const sx=Math.round(player.x-camX), sy=Math.round(player.y-camY);
    drawSteedMounted(sx, sy, player.pet.id, player.dir||'down', player.moving ? ((Date.now()>>7)&1) : 1); /* the overworld's own frame rule */ uwDrawRiderBubbles(sx,sy); } });
  objs.sort((a,b)=>a.sy-b.sy).forEach(o=>o.f());
  // the water: tinted per zone (courts / the house within / the ruined chambers)
  const lights=[];
  if(uw.room==='temple') for(const [x,y] of UW_LAMPSTANDS) if(uwLampLit(x,y)) lights.push([x*TILE-camX+8, y*TILE-camY+1]);
  const zone=(x0p,y0p,x1p,y1p,z)=>{ const L=Math.max(0,x0p*TILE-camX), T=Math.max(0,y0p*TILE-camY), R=Math.min(vw,x1p*TILE-camX), B=Math.min(vh,y1p*TILE-camY);
    if(R<=L||B<=T) return; ctx.save(); ctx.beginPath(); ctx.rect(L,T,R-L,B-T); ctx.clip(); uwDrawWaterOverlay(vw,vh,camX,camY,z, z==='temple'?lights:[]); ctx.restore(); };
  if(uw.room==='courts') zone(0,0,uw.W,uw.H,'garden');
  else { zone(0,0,10,uw.H,'ruins'); zone(20,0,uw.W,uw.H,'ruins'); zone(10,0,20,2,'ruins'); zone(10,40,20,uw.H,'ruins'); zone(10,2,20,40,'temple'); }
  drawCross();
}
// the dive markers on the overworld: drawn over the deep-water tile, never stamped
// into WORLD, so the world fingerprint is untouched (drawTile hook)
function uwMarkerAt(tx,ty){ return UW_ON && place.kind==='overworld' && UW_SPOTS.some(s=>s.x===tx&&s.y===ty); }

// ── the music (musicFor hook): underwater.mp3, else the chapel recording ──
function uwMusic(){
  if(RTRACKS.underwater && !RTRACKS.underwater.dead) return 'rt:underwater';
  return (RTRACKS.chapel && !RTRACKS.chapel.dead) ? 'rt:chapel' : 'town';
}
// ── the coral barding (drawSteedSprite hook) ──
let _uwCoralBusy=false;
function uwCoralSteed(ox,oy,id,view,frame,rider,mirror){
  if(!UW_ON || _uwCoralBusy || id!=='steadfast' || player.mountSkin!=='uwcoral') return false;
  _uwCoralBusy=true;
  try{ uwWithCoralBarding(()=>drawSteedSprite(ox,oy,id,view,frame,rider,mirror)); } finally { _uwCoralBusy=false; }
  return true;
}
// ── the Pet tab (barding rows) and the Quests tab ──
function uwBardingRows(){
  if(!UW_ON || !(player.mountSkinOwned && player.mountSkinOwned.uwcoral)) return '';
  const on=player.mountSkin==='uwcoral', sea=player.pet && player.pet.id==='steadfast';
  let h='';
  if(!(player.mountSkinOwned.spectral)) h+='<div class="gm-sectitle" style="margin-top:6px">Pet Barding</div>';
  h+='<div class="gm-item '+(on?'equipped':'')+'" onclick="toggleMountSkin(\'uwcoral\')" style="cursor:pointer">🪸 <span style="flex:1">Coral Barding <span class="ds">'+(sea?'coral and pearl, from the deep':'for the Sea Dragon only')+'</span></span>'+(on?'<span style="color:#23517d">equipped</span>':'')+'</div>';
  if(!(player.mountSkinOwned.spectral)) h+='<div class="gm-item '+(!player.mountSkin?'equipped':'')+'" onclick="toggleMountSkin(null)" style="cursor:pointer"><span style="flex:1">Normal <span class="ds">your steed’s true coat</span></span>'+(!player.mountSkin?'<span style="color:#23517d">equipped</span>':'')+'</div>';
  return h;
}
function uwQuestRows(active, done){
  if(!UW_ON) return;
  if(!Object.keys(uwSaved.visited).length) return;       // a secret until you have been down
  const rec=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
  if(!uwSaved.opened) active.push(['The Drowned House','Four lampstands in the Holy Place bear Jonah’s prayer. Pray as the prophet prayed.','#2f5434']);
  else done.push(['The Drowned House','The house is filled with light. ✓','#2f5434']);
  if(!uwSaved.quiz) active.push(['The Keeper’s Records','Record tablets found: <b>'+rec+'</b> of 3'+(rec>=3?' — return to Tirzah. ✓':'.'),rec>=3?'#7a5c28':'#2f5434']);
  else done.push(['The Keeper’s Records','Tirzah’s questions answered. ✓','#2f5434']);
  const left=Object.keys(UW_CHEST_LOOT).filter(k=>!uwSaved.chests[k]).length;
  if(left) active.push(['Treasures of the Deep','Chests still unopened: <b>'+left+'</b>. Pearls carried: <b>'+uwSaved.pearls+'</b>.','#2f5434']);
  else done.push(['Treasures of the Deep','Every chest opened. ✓','#2f5434']);
}

// ── registrations: object mutation only, so no hook is needed for these ──
if(UW_ON){
  LIVERIES.deepwater = UW_LIVERY;
  for(const k in UW_DECOR_ITEMS) DECOR_ITEMS['uw_'+k]=UW_DECOR_ITEMS[k];
  RTRACKS.underwater = { src:'underwater.mp3', el:null, dead:false, want:false, vol:0.50 };
  PORTRAITS['zebulun the pearl-diver']=(q)=>uwPortraitZebulun(q);
  PORTRAITS['tirzah, keeper of the records']=(q)=>uwPortraitTirzah(q);
  PORTRAIT_ALIAS['zebulun']='zebulun the pearl-diver';
  PORTRAIT_ALIAS['tirzah']='tirzah, keeper of the records';
}

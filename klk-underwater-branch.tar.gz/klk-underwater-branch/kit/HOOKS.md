# Underwater merge kit — hook list

Apply IN ORDER with `apply_kit.py` (it calls test/edit.py once per pair and runs the gate after each).
Every anchor must match EXACTLY ONCE in the target index.html. If one no longer matches, fix that hook by hand against the new code — never force it.

| # | hook | what it does |
|---|---|---|
| 00 | `livery` | liveryUnlocked(): the Deepwater Pearl is earned, not traded for. FIRST, so the livery is never registered without its lock. |
| 01 | `block` | Inserts the whole block after every system it extends is declared and before FRESH_STATE is taken. |
| 02 | `save` | buildSaveData: the underwater state under its own key. |
| 03 | `load` | applySaveData: restore (or reset) the underwater state; runs before restoreWhere. |
| 04 | `where` | restoreWhere: a save made underwater reloads underwater; if it can't, the surface. |
| 05 | `grid` | activeGrid(): draw() and tileAt() call it first thing; without this an unknown kind fell into the interior branch and threw. |
| 06 | `loop` | loop(): the underwater world owns its frame, after the day clock. |
| 07 | `draw` | draw(): route to uwDraw() — also covers the frozen frame behind an open menu. |
| 08 | `action` | doAction(): dive at a marker; every Ⓐ underwater. Returns true so no sword is swung. |
| 09 | `attack` | doAttack(): a held attack key reaches doAttack directly; underwater it does nothing. |
| 10 | `marker` | drawTile case 3: the dive marker is DRAWN, never stamped into WORLD (fingerprint unchanged). |
| 11 | `music` | musicFor(): the underwater track. |
| 12 | `decor` | drawDecor(): the five new decoration kinds. |
| 13 | `steed` | drawSteedSprite(): the coral barding, on every view of the Sea Dragon. |
| 14 | `pettab` | Pet tab: the coral barding toggle. |
| 15 | `quests` | Quests tab: the deep's three lines, once you have been down. |
| 16 | `eldan1` | Eldan's Golden Fish: the first missing starter line. |
| 17 | `eldan2` | Eldan's Kindness trial: the second missing starter line. |

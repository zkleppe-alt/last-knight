
// ═════════════════════════════════════════════════════════════════
//  🌊 THE DEEP — a secret underwater world (the underwater branch)
//  Only the Sea Dragon (the Steadfast line's final form) can dive, at five
//  marked spots of deep water. Below: the drowned courts — the Reef Garden —
//  and, standing at their north end, a house built after Solomon's (1 Kings
//  6-7). Walk in through its doorway: the porch, the Holy Place (side chambers
//  off both walls) and the Most Holy Place.
//  Wholly peaceful. You ride the Sea Dragon the whole time; there is no air.
//    • Dive: Ⓐ within a tile of a dive marker, riding the Sea Dragon.
//      Any other steed, or the boat, gets a hint. Walkers see the marker.
//    • Surface: Ⓐ on any entry current (you come up at ITS spot), or the
//      ⬆ button / U key (you come up where you went in).
//    • The Holy Place: four of the ten lampstands bear Jonah's prayer. Light
//      them in the prayer's order; all ten blaze, the inner doors open, and
//      the Deepwater Pearl livery is given. Between the cherubim, a humble
//      chest holds the Wooden Cross.
//    • Tirzah wants her three record tablets back, then asks three questions
//      on Jonah 2: the Coral Barding. Zebulun buys pearls from the chests.
//    • Eldan's two trials now each give a missing starter line, fully grown
//      (retroactive for saves that already finished them).
//  UW_ON=false turns ALL of it off: no markers, no dives, no new save key,
//  no livery/decor/music registrations, and every hook falls through.
//  Persisted: `underwater` save key (uwSaved). Everything else is transient.
//  Hooks: see the kit's HOOKS.md — each is a one-line call into this block.
// ═════════════════════════════════════════════════════════════════
const UW_ON = true;
// ════════════════════════════════════════════════════════════════
//  UNDERWATER — ART (mockup stage; becomes the ART section of the
//  underwater block once approved). Same idiom as drawTile: px() on
//  a 16-px tile, hash-varied detail, Date.now() for slow animation.
// ════════════════════════════════════════════════════════════════
// Tile codes are LOCAL to the underwater grid (their own namespace:
// the overworld's WORLD never holds them, and the grid is rebuilt
// from code, never saved), so they cannot collide with retired codes.
const UW_T = { SAND:0, GRASS:1, CORAL:2, ROCK:3, KELP:4, FLAG:5, WALL:6, COLUMN:7,
               CURRENT:8, LAMP:9, CHEST:10, DOOR:11, TRENCH:12, DOME:13, TABLET:14 };
const _uwH = (x,y)=>((x*374761393+y*668265263)>>>0);

// ── the DIVE MARKER on the overworld: a dark, slow-turning eddy in deep
//    water with a thread of bubbles. Everyone can see it (Zak: "hint +
//    visible marker"); only the Sea Dragon can go down.
function uwDrawDiveMarker(x,y){
  const t=Date.now()/600;
  // the deep hole: two darker rings, reading as depth under the swells
  px(x+3,y+3,10,10,'#2c5a8e'); px(x+2,y+5,12,6,'#2c5a8e'); px(x+5,y+2,6,12,'#2c5a8e');
  px(x+5,y+5,6,6,'#1f4677'); px(x+4,y+6,8,4,'#1f4677'); px(x+6,y+4,4,8,'#1f4677');
  px(x+7,y+7,2,2,'#163a66');
  // the eddy: a dashed foam ring that slowly turns, so the spot catches the eye
  const ph=Math.floor(t*2)%4;
  for(let k=0;k<16;k++){ const an=k/16*Math.PI*2, rx=Math.round(7.5+Math.cos(an)*7), ry=Math.round(7.5+Math.sin(an)*7);
    if((k+ph)%4===0) px(x+rx,y+ry,2,1,'#e0f2fa'); else if((k+ph)%4===1) px(x+rx,y+ry,1,1,'#9fd0e8'); }
  const a=t%(Math.PI*2), bx=Math.round(7.5+Math.cos(a)*3.5), by=Math.round(7.5+Math.sin(a)*3.5);
  px(x+bx,y+by,1,1,'#7fb0d8');
  // a rising thread of bubbles
  const bp=Math.floor(Date.now()/180)%8;
  px(x+8,y+9-bp,1,1,'#e0f2fa');
  px(x+7,y+13-((bp+4)%8),1,1,'#cfe6f2');
}

// ── floor tiles ──
function uwFloor(x,y,tx,ty){
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#a2a88c');                                   // pale sea-sand
  px(x+(h%9),y+3+(h>>4)%3,6,1,'#b4ba9c');                       // ripples
  px(x+((h>>8)%8),y+10+(h>>12)%3,7,1,'#b4ba9c');
  px(x+((h>>6)%12),y+7,4,1,'#8c927a');
  if((h&31)===5){ px(x+4,y+12,2,1,'#e8e0d0'); px(x+5,y+11,1,1,'#f4ece0'); }   // a shell
  if((h&63)===9){ px(x+10,y+5,2,2,'#c8687a'); px(x+10,y+5,1,1,'#e8909e'); } // a starfish
}
function uwFlag(x,y,tx,ty){                                     // drowned flagstones
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#7e8a86');
  px(x,y+7,TILE,1,'#5e6a68'); px(x+(ty&1?4:10),y,1,7,'#5e6a68'); px(x+(ty&1?11:3),y+8,1,8,'#5e6a68');
  px(x+1,y+1,6,1,'#95a19c'); px(x+1,y+9,8,1,'#95a19c');
  if(h%5===0){ px(x+2+(h>>5)%9,y+3,3,2,'#5f8a5a'); px(x+3+(h>>5)%9,y+2,1,1,'#78a870'); } // algae
  if(h%11===0){ px(x+9,y+11,4,1,'#6a7672'); px(x+10,y+12,2,1,'#6a7672'); }      // crack
}

// ── the tile switch for the underwater grid ──
function uwDrawTile(t,x,y,tx,ty){
  const h=_uwH(tx,ty), now=Date.now();
  switch(t){
    case UW_T.SAND: uwFloor(x,y,tx,ty); break;
    case UW_T.GRASS: {                                          // seagrass: sways, walkable
      uwFloor(x,y,tx,ty);
      const s=Math.round(Math.sin(now/700+tx*0.9+ty*0.4));
      for(let i=0;i<4;i++){ const bx=x+2+i*4+((h>>i)&1), ht=6+((h>>(i*3))%5);
        px(bx,y+15-ht,1,ht,'#3f8a5a'); px(bx+s,y+15-ht-2,1,3,'#5cae70'); }
      break; }
    case UW_T.CORAL: {                                          // coral head: solid, colour by hash
      uwFloor(x,y,tx,ty);
      const C=[['#d8586a','#f08a96','#9a3446'],['#e8905a','#f8b888','#a85a2e'],
               ['#9a6ac8','#c49ae8','#5e3a88'],['#e8c85a','#f8e498','#a8882e']][h%4];
      if((h>>3)&1){ // branching
        px(x+4,y+13,8,2,C[2]); px(x+7,y+4,2,10,C[2]);
        px(x+2,y+3,3,9,C[0]); px(x+11,y+2,3,10,C[0]); px(x+6,y+2,4,3,C[0]);
        px(x+4,y+8,3,2,C[0]); px(x+9,y+7,2,2,C[0]);
        px(x+2,y+2,3,1,C[1]); px(x+11,y+1,3,1,C[1]); px(x+6,y+1,4,1,C[1]);
        px(x+3,y+5,1,3,C[1]); px(x+12,y+4,1,3,C[1]);
      } else {      // brain / mound
        px(x+1,y+5,14,10,C[2]); px(x+2,y+3,12,11,C[0]); px(x+4,y+2,8,2,C[0]);
        px(x+3,y+6,10,1,C[1]); px(x+4,y+9,8,1,C[1]); px(x+5,y+4,6,1,C[1]); px(x+4,y+12,8,1,C[1]);
        px(x+3,y+14,10,1,'#6a6450');
      }
      break; }
    case UW_T.ROCK: {
      uwFloor(x,y,tx,ty);
      px(x+1,y+4,14,11,'#4e5a60'); px(x+2,y+3,12,2,'#5e6a70'); px(x+2,y+4,6,2,'#74828a');
      px(x+1,y+14,14,1,'#343e44'); if(h&1) px(x+9,y+8,3,2,'#3e8a5a');
      break; }
    case UW_T.KELP: {                                           // tall kelp: a soft wall
      px(x,y,TILE,TILE,'#2e5a52');
      const s=Math.round(Math.sin(now/900+tx)*1.5);
      for(let i=0;i<3;i++){ const bx=x+2+i*5+((h>>i)&1);
        px(bx+s,y,2,TILE,'#3e7a4a'); px(bx+s+1,y+(i*5+h)%12,3,3,'#5a9a52'); px(bx+s-2,y+(i*7+h*3)%12,3,2,'#4e8a4a'); }
      break; }
    case UW_T.FLAG: uwFlag(x,y,tx,ty); break;
    case UW_T.WALL: {                                           // drowned masonry
      px(x,y,TILE,TILE,'#5a6664');
      for(let r=0;r<4;r++){ const o=(r&1)?4:0; px(x,y+r*4,TILE,1,'#434e4c');
        px(x+o,y+r*4,1,4,'#434e4c'); px(x+o+8,y+r*4,1,4,'#434e4c'); px(x+o+1,y+r*4+1,6,1,'#6e7a78'); }
      if(h%3===0){ px(x+2,y+12,5,4,'#4e7a52'); px(x+3,y+11,2,1,'#6a9a62'); }
      break; }
    case UW_T.COLUMN: {                                         // a standing column, one tile
      uwFlag(x,y,tx,ty);
      px(x+3,y+13,10,2,'#5e6a68'); px(x+5,y+1,6,13,'#9aa6a2'); px(x+5,y+1,2,13,'#b8c4c0');
      px(x+10,y+1,1,13,'#6e7a78'); px(x+4,y,8,2,'#aab6b2'); px(x+8,y+4,1,8,'#8a9692');
      if(h&1){ px(x+5,y+9,6,3,'#4e7a52'); px(x+6,y+8,2,1,'#6a9a62'); }
      break; }
    case UW_T.CURRENT: {                                        // rising current: the way up
      uwFloor(x,y,tx,ty);
      px(x+2,y+2,12,12,'rgba(200,236,248,0.22)'); px(x+4,y+1,8,14,'rgba(200,236,248,0.18)');
      for(let i=0;i<5;i++){ const yy=(15-((Math.floor(now/90)+i*5+(h&7))%16));
        px(x+3+((i*5+h)%10),y+yy,(i&1)?2:1,(i&1)?2:1,'#eef8fc'); }
      px(x+1,y+1,14,1,'rgba(238,248,252,0.5)'); px(x+1,y+14,14,1,'rgba(238,248,252,0.5)'); px(x+1,y+1,1,14,'rgba(238,248,252,0.5)'); px(x+14,y+1,1,14,'rgba(238,248,252,0.5)');
      px(x+7,y+6,2,4,'rgba(255,255,255,0.35)');
      break; }
    case UW_T.LAMP: {                                           // sea-lamp on a post: lit via uwLampLit
      uwFlag(x,y,tx,ty);
      const lit = typeof uwLampLit==='function' && uwLampLit(tx,ty);
      px(x+7,y+6,2,9,'#5e6a68'); px(x+5,y+14,6,1,'#434e4c');
      px(x+4,y+1,8,6,'#434e4c'); px(x+5,y+2,6,4, lit?'#fff2a8':'#2e3a3e');
      if(lit) px(x+6,y+3,4,2,'#fffbe0');
      px(x+4,y+1,8,1,'#6e7a78');
      break; }
    case UW_T.CHEST: {
      uwFloor(x,y,tx,ty);
      px(x+2,y+6,12,8,'#5a3e26'); px(x+2,y+6,12,3,'#7a5a36'); px(x+2,y+9,12,1,'#3a2816');
      px(x+7,y+8,2,3,'#c9a94a'); px(x+2,y+6,1,8,'#8a6a3a'); px(x+13,y+6,1,8,'#8a6a3a');
      px(x+3,y+13,4,2,'#3e7a5a'); px(x+10,y+5,2,1,'#e8e0d0');                 // weed + a pearl
      break; }
    case UW_T.DOOR: {                                           // temple doors: sealed bronze
      px(x,y,TILE,TILE,'#5a6664');
      px(x+2,y+1,12,15,'#6a5a2e'); px(x+3,y+2,5,14,'#8a7438'); px(x+8,y+2,5,14,'#7e6a32');
      px(x+7,y+2,1,14,'#4a3e1e'); px(x+5,y+8,1,2,'#c9a94a'); px(x+10,y+8,1,2,'#c9a94a');
      px(x+3,y+2,10,1,'#a8904a'); px(x+4,y+11,8,1,'#3e7a5a');
      break; }
    case UW_T.TRENCH: {                                         // the deep: frames the map, solid
      px(x,y,TILE,TILE,'#0e2230');
      if((h&15)===2) px(x+(h>>4)%14,y+(h>>8)%14,1,1,'#2a5a70');           // drifting motes
      break; }
    case UW_T.DOME: {                                           // an air dome's glass wall
      uwFloor(x,y,tx,ty);
      px(x,y,TILE,TILE,'rgba(210,240,250,0.30)');
      px(x+2,y+2,3,1,'rgba(255,255,255,0.7)'); px(x+2,y+3,1,2,'rgba(255,255,255,0.6)');
      break; }
    case UW_T.TABLET: {                                         // carved verse stone
      uwFlag(x,y,tx,ty);
      px(x+3,y+2,10,12,'#8a9692'); px(x+3,y+2,10,1,'#aab6b2'); px(x+4,y+1,8,1,'#aab6b2');
      for(let r=0;r<4;r++) px(x+5,y+4+r*2,6-(r&1)*2,1,'#5e6a68');
      px(x+2,y+14,12,1,'#434e4c');
      break; }
    default: if(!uwDrawTempleTile(t,x,y,tx,ty)) uwFloor(x,y,tx,ty);
  }
}

// ── the WATER ITSELF: drawn over the whole view after tiles and sprites.
//    A blue-green tint, sun-shafts from the surface, drifting caustics.
function uwDrawWaterOverlay(vw,vh,camX,camY,zone,lights){
  const now=Date.now();
  ctx.fillStyle = zone==='ruins' ? 'rgba(16,44,92,0.42)' : zone==='temple' ? 'rgba(24,64,96,0.20)' : 'rgba(22,112,146,0.32)';
  ctx.fillRect(0,0,vw,vh);
  const dg=ctx.createLinearGradient(0,0,0,vh);            // lighter toward the surface
  dg.addColorStop(0,'rgba(190,245,255,0.10)'); dg.addColorStop(1,'rgba(0,18,48,0.22)');
  ctx.fillStyle=dg; ctx.fillRect(0,0,vw,vh);
  // sun-shafts: slow, leaning, garden brighter than ruins
  const a = zone==='ruins' ? 0.05 : zone==='temple' ? 0.06 : 0.09;
  for(let i=0;i<4;i++){
    const sx=((i*97 - camX*0.3 + Math.sin(now/4000+i)*12) % (vw+60)+vw+60)%(vw+60)-30;
    ctx.fillStyle='rgba(220,250,255,'+a+')';
    ctx.beginPath(); ctx.moveTo(sx,0); ctx.lineTo(sx+14,0); ctx.lineTo(sx+44,vh); ctx.lineTo(sx+24,vh); ctx.closePath(); ctx.fill();
  }
  // caustic flecks, anchored to the world so they don't swim with the camera
  ctx.fillStyle='rgba(230,252,255,0.16)';
  const ox=Math.floor(camX/TILE), oy=Math.floor(camY/TILE);
  for(let ty=oy;ty<oy+vh/TILE+2;ty++) for(let tx=ox;tx<ox+vw/TILE+2;tx++){
    const h=_uwH(tx,ty); if(h%3) continue;
    const ph=Math.sin(now/800+(h&63));
    ctx.fillRect(tx*TILE-camX+(h>>6)%12, ty*TILE-camY+(h>>10)%12, 3+Math.round(ph), 1);
  }
  // lit sea-lamps shine THROUGH the water: drawn after the tint so it can't bury them
  for(const [lx,ly] of (lights||[])){
    const pulse=0.55+0.1*Math.sin(now/300+lx);
    const rg=ctx.createRadialGradient(lx,ly,1,lx,ly,26);
    rg.addColorStop(0,'rgba(255,240,160,'+pulse.toFixed(3)+')'); rg.addColorStop(1,'rgba(255,240,160,0)');
    ctx.fillStyle=rg; ctx.fillRect(lx-26,ly-26,52,52);
    ctx.fillStyle='#fffbe0'; ctx.fillRect(lx-2,ly-1,4,2);
  }
  // drifting motes
  ctx.fillStyle='rgba(240,255,255,0.35)';
  for(let i=0;i<14;i++){ const mx=((i*53+now/60*((i%3)+1))%(vw+20))-10, my=((i*71 - now/90*((i%2)+1))%vh+vh)%vh;
    ctx.fillRect(mx|0,my|0,1,1); }
}

// ── bubbles off the rider: a short trail rising from the knight's helm ──
function uwDrawRiderBubbles(sx,sy){
  const now=Date.now();
  for(let i=0;i<3;i++){ const ph=((now/140)+i*5)%15;
    const bx=sx+7+Math.round(Math.sin(now/200+i*2)*1.5), by=sy-10-ph;
    px(bx,by,(i===1)?2:1,(i===1)?2:1,'rgba(238,248,252,'+(0.9-ph/18).toFixed(2)+')'); }
}

// ── the FISH: little peaceful schools (ambient, not creatures you fight) ──
function uwDrawFish(x,y,kind,dir,f){
  const P=[['#f0a040','#fff0c8','#a86020'],['#58a8e8','#d8f0ff','#2a6aa8'],['#e8e070','#ffffff','#a89a30']][kind%3];
  const m=dir<0;
  const q=(xx,yy,w,h,c)=>px(m? x+7-xx-w : x+xx, y+yy, w, h, c);
  q(1,1,4,3,P[0]); q(2,1,2,1,P[1]); q(5,1+(f&1),2,2,P[2]); q(0,2,1,1,P[2]); q(1,2,1,1,'#1a1a1a');
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — PEOPLE (mockup stage)
//  Zebulun the pearl-diver (Gen 49:13 — "Zebulun shall dwell at the
//  haven of the sea") lives in an air dome in the Reef Garden.
//  Tirzah keeps the drowned temple's records in a dome by the ruins.
// ════════════════════════════════════════════════════════════════
function uwDrawZebulun(sx,sy){
  const t=Date.now(), bob=Math.sin(t/800)>0.5?1:0, oy=sy+bob;
  const SK='#c8925f', SK_D='#9a6b42', BEARD='#e8e4d8', BEARD_D='#b8b4a8';
  const TUN='#3a7a8a', TUN_L='#58a0ae', TUN_D='#285a66', ROPE='#c8b078', NET='#8a7a50';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(sx+8,sy+15,5,2,0,0,7); ctx.fill();
  // legs, bare feet
  px(sx+5,oy+12,2,3,SK_D); px(sx+9,oy+12,2,3,SK_D);
  // short sea-tunic, rope belt with a pearl pouch
  px(sx+4,oy+7,8,6,TUN); px(sx+4,oy+7,2,6,TUN_L); px(sx+11,oy+7,1,6,TUN_D);
  px(sx+4,oy+10,8,1,ROPE); px(sx+10,oy+10,3,3,'#8a6a3a'); px(sx+11,oy+11,1,1,'#f4f0e8');
  // bare arms; one holds a net over the shoulder
  px(sx+3,oy+7,1,4,SK); px(sx+12,oy+7,1,4,SK_D);
  px(sx+12,oy+3,2,5,NET); px(sx+13,oy+4,1,1,ROPE); px(sx+12,oy+6,1,1,ROPE);
  // head: weathered, bald crown, white beard
  px(sx+5,oy+1,6,6,SK); px(sx+5,oy+1,2,6,'#e0b184'); px(sx+10,oy+2,1,5,SK_D);
  px(sx+6,oy+3,1,1,'#2a2036'); px(sx+9,oy+3,1,1,'#2a2036');
  px(sx+5,oy+5,6,3,BEARD); px(sx+5,oy+5,1,3,BEARD_D); px(sx+7,oy+8,2,1,BEARD);
  px(sx+4,oy+2,1,2,BEARD); px(sx+11,oy+2,1,2,BEARD);          // white tufts at the ears
}
function uwDrawTirzah(sx,sy){
  const t=Date.now(), bob=Math.sin(t/950)>0.6?1:0, oy=sy+bob;
  const ROBE='#3a5a7a', ROBE_L='#5a7ea0', ROBE_D='#26405a', VEIL='#c8d4dc', VEIL_D='#98a8b4';
  const SK='#e0b080', SCROLL='#e8dcb8', CASE='#8a6a3a';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(sx+8,sy+15,5,2,0,0,7); ctx.fill();
  // long robe to the floor
  px(sx+4,oy+11,8,4,ROBE_D); px(sx+5,oy+6,6,6,ROBE); px(sx+5,oy+6,2,6,ROBE_L); px(sx+10,oy+6,1,6,ROBE_D);
  px(sx+4,oy+13,1,2,ROBE_L);
  // a scroll held open before her
  px(sx+4,oy+8,8,3,SCROLL); px(sx+4,oy+8,1,3,CASE); px(sx+11,oy+8,1,3,CASE);
  px(sx+6,oy+9,4,1,'#8a7a5a');
  // the veil, pale as sea-foam, and her face
  px(sx+5,oy+1,6,6,VEIL); px(sx+4,oy+2,1,6,VEIL_D); px(sx+11,oy+2,1,6,VEIL_D); px(sx+5,oy+1,6,1,'#e8f0f4');
  px(sx+6,oy+3,4,3,SK); px(sx+6,oy+4,1,1,'#2a2036'); px(sx+9,oy+4,1,1,'#2a2036');
  // a small gold clasp: the temple's sign
  px(sx+7,oy+7,2,1,'#c9a94a');
}
// ── portraits (64×76, drawn through q like RG_ART) ──
function uwPortraitBackdrop(q, a, b, c){
  q(0,0,64,76,a); q(0,0,64,30,b);
  for(let i=0;i<5;i++) q(4+i*13, 6+(i%2)*8, 2, 2, '#9fd0e8');     // bubbles drifting up
  for(let i=0;i<4;i++) q(10+i*15, 16+(i%2)*6, 1, 1, '#e0f2fa');
  q(0,72,64,4,c); q(0,0,2,76,c); q(62,0,2,76,c);
}
function uwPortraitZebulun(q){
  uwPortraitBackdrop(q, '#16384a', '#1f4a5e', '#0a1c26');
  // shoulders: sea-tunic, rope over one shoulder, net slung behind
  q(0,56,64,20,'#3a7a8a'); q(0,56,64,3,'#58a0ae'); q(0,56,14,20,'#58a0ae'); q(50,56,14,20,'#285a66');
  for(let i=0;i<5;i++) q(46+((i*3)%10), 50+i*4, 10, 1, '#8a7a50');           // the net
  for(let i=0;i<3;i++) q(48+i*4, 48, 1, 20, '#8a7a50');
  q(8,58,40,3,'#c8b078'); q(8,58,40,1,'#e0cc98');                             // rope across the chest
  q(22,64,8,8,'#8a6a3a'); q(24,66,4,4,'#f4f0e8'); q(25,66,2,1,'#ffffff');     // pouch and a pearl
  q(22,48,20,10,'#9a6b42');                                                  // neck, sun-dark
  // head: weathered tan, bald crown
  q(14,10,36,40,'#c8925f'); q(14,10,9,40,'#e0b184'); q(43,10,7,40,'#9a6b42');
  q(18,8,28,4,'#d8a26e'); q(20,9,10,1,'#f0c8a0');                            // the shine on his crown
  q(10,24,4,10,'#9a6b42'); q(50,24,4,10,'#9a6b42');                          // ears
  q(8,18,6,10,'#e8e4d8'); q(50,18,6,10,'#b8b4a8');                           // white tufts
  // eyes: crinkled, kind, the sea's colour
  q(18,24,10,2,'#e8e4d8'); q(36,24,10,2,'#e8e4d8');                          // white brows
  q(19,27,8,4,'#fbf6ea'); q(37,27,8,4,'#fbf6ea');
  q(22,27,4,4,'#2a6a7a'); q(40,27,4,4,'#2a6a7a'); q(23,28,1,1,'#b8f0f0'); q(41,28,1,1,'#b8f0f0');
  q(16,31,5,1,'#9a6b42'); q(43,31,5,1,'#9a6b42');                            // crow's feet
  q(30,30,5,9,'#b07e56'); q(30,30,2,9,'#e0b184');                            // nose
  // the white beard, short and full
  q(15,38,34,4,'#e8e4d8'); q(13,42,38,14,'#e8e4d8'); q(13,42,9,14,'#f4f2ea'); q(42,42,9,14,'#b8b4a8');
  for(let i=0;i<6;i++) q(17+i*5,46,1,9,'#b8b4a8');
  q(18,55,28,4,'#e8e4d8'); q(24,58,16,3,'#b8b4a8');
  q(20,38,24,4,'#f4f2ea'); q(20,41,24,1,'#b8b4a8');                          // moustache
  q(27,43,10,2,'#8a4a3a'); q(26,42,2,1,'#8a4a3a'); q(36,42,2,1,'#8a4a3a');   // a small upturned smile
}
function uwPortraitTirzah(q){
  uwPortraitBackdrop(q, '#1a2a44', '#243a5a', '#0c1424');
  // robe and the temple clasp
  q(0,58,64,18,'#3a5a7a'); q(0,58,64,3,'#5a7ea0'); q(0,58,14,18,'#5a7ea0'); q(50,58,14,18,'#26405a');
  q(28,60,8,5,'#c9a94a'); q(28,60,8,2,'#f0d98a'); q(31,62,2,3,'#8a6a20');
  // the scroll she keeps, lifted at the bottom edge
  q(6,66,24,10,'#e8dcb8'); q(6,66,3,10,'#8a6a3a'); q(27,66,3,10,'#8a6a3a');
  for(let i=0;i<3;i++) q(11,68+i*2,14,1,'#8a7a5a');
  // the veil: pale sea-foam, framing the face
  q(8,4,48,18,'#c8d4dc'); q(8,4,48,3,'#e8f0f4'); q(8,4,12,18,'#e8f0f4'); q(44,4,12,18,'#98a8b4');
  q(6,18,8,42,'#c8d4dc'); q(50,18,8,42,'#98a8b4'); q(6,18,3,42,'#e8f0f4');
  q(14,56,36,4,'#98a8b4');
  // face: mid skin, grave and calm
  q(16,16,32,40,'#e0b080'); q(16,16,8,40,'#f2c99b'); q(42,16,6,40,'#b8875c');
  q(16,16,32,4,'#c8a07c');                                                   // the veil's shadow
  q(20,26,9,2,'#6b5340'); q(35,26,9,2,'#6b5340');                            // brows
  q(20,29,9,5,'#fbf6ea'); q(35,29,9,5,'#fbf6ea');
  q(23,29,4,5,'#3a4a6a'); q(38,29,4,5,'#3a4a6a'); q(24,30,1,1,'#c8d8f0'); q(39,30,1,1,'#c8d8f0');
  q(20,29,9,1,'#b8875c'); q(35,29,9,1,'#b8875c');                            // lids
  q(30,33,4,9,'#c8966a'); q(30,33,2,9,'#f2c99b'); q(28,41,8,2,'#b8875c');   // nose
  q(25,46,14,3,'#a86a5a'); q(27,46,10,1,'#c88878');                          // a closed, patient mouth
  q(20,52,24,4,'#c8966a');                                                   // chin shadow
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — REWARDS (mockup stage)
// ════════════════════════════════════════════════════════════════
// ── CORAL BARDING: a Sea Dragon skin. The shell goes coral, the saddle-rim
//    and horns go pearl. Applied by swapping STEED2.PAL.steadfast for the
//    length of one draw and putting it straight back.
const UW_CORAL_PAL = { S:'#d8586a', s:'#9a3446', H:'#f5a0a8', g:'#f4f0e8', G:'#c8c0b0', h:'#f4f0e8' };
function uwWithCoralBarding(fn){
  const P=STEED2.PAL.steadfast, keep={};
  for(const k in UW_CORAL_PAL){ keep[k]=P[k]; P[k]=UW_CORAL_PAL[k]; }
  try{ fn(); } finally { for(const k in keep) P[k]=keep[k]; }
}
// ── THE DEEPWATER PEARL livery (flag-unlocked, like the Stormward Plate):
//    sea-teal over pearl, with a coral plume.
const UW_LIVERY = { name:'Deepwater Pearl', req:0, flag:'deepwater', note:'the drowned temple, opened',
  TUNIC:'#2a8a8a', TUNIC_L:'#4ab0aa', TUNIC_D:'#1c6464', TUNIC_RIM:'#f4f0e8', TUNIC_SH:'#123e42',
  LEG:'#1c5a5e', LEG_D:'#12403f', PLUME:'#e8707a', PLUME_HI:'#f8a0a8', PLUME_D:'#a8404c',
  HELM:'#e8e6e0', HELM_HI:'#ffffff', HELM_L:'#f4f2ec', HELM_D:'#b8b2a4' };
// ── HOMESTEAD DECORATIONS (drawDecor kinds). All solid, like the others.
const UW_DECOR_ITEMS = {
  coralPlanter: { name:'Coral Planter',     emoji:'🪸', kind:'uwCoralPlanter', w:1 },
  pearlFountain:{ name:'Pearl Fountain',    emoji:'⛲', kind:'uwPearlFountain', w:2 },
  bellArbor:    { name:'Sunken-Bell Arbor', emoji:'🔔', kind:'uwBellArbor',    w:2 },
  wheelSign:    { name:"Ship's-Wheel Sign", emoji:'☸️', kind:'uwWheelSign',    w:1 },
};
function uwDrawDecor(d,x,y){
  const now=Date.now();
  switch(d.kind){
    case 'uwCoralPlanter': {                                    // a shell-rimmed box of coral
      ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,6,2,0,0,7); ctx.fill();
      px(x+2,y+8,12,7,'#7a4f2a'); px(x+2,y+8,12,2,'#946232'); px(x+2,y+14,12,1,'#5a3a1e');
      for(let i=0;i<4;i++) px(x+3+i*3,y+11,2,2,'#f4f0e8');                     // a row of shells
      px(x+3,y+2,2,6,'#d8586a'); px(x+2,y+1,2,2,'#f08a96'); px(x+5,y+4,2,2,'#d8586a');   // red branch
      px(x+8,y+3,4,5,'#e8905a'); px(x+8,y+3,4,1,'#f8b888'); px(x+9,y+5,2,1,'#f8b888');   // orange mound
      px(x+12,y+1,2,7,'#9a6ac8'); px(x+11,y+3,1,2,'#9a6ac8'); px(x+12,y+1,2,1,'#c49ae8');// purple fan
      return; }
    case 'uwPearlFountain': { const W=d.w*TILE;                 // a giant shell holding a pearl
      ctx.fillStyle='rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(x+W/2,y+W-2,W/2-1,4,0,0,7); ctx.fill();
      px(x+3,y+14,W-6,14,'#8a9692'); px(x+3,y+14,W-6,2,'#aab6b2'); px(x+3,y+27,W-6,1,'#5e6a68');  // stone basin
      px(x+6,y+17,W-12,8,'#3f7ec0'); px(x+7,y+18,W-14,2,'#6aa6e0');                          // water
      // the scallop shell standing up behind, ribs fanning out
      px(x+7,y+2,W-14,12,'#f0c8b0'); px(x+9,y,W-18,3,'#f0c8b0');
      for(let i=0;i<5;i++) px(x+9+i*3,y+1,1,12,'#d8a088');
      px(x+7,y+12,W-14,2,'#c8907a');
      // the pearl, and water spilling
      px(x+W/2-3,y+9,6,6,'#f4f0e8'); px(x+W/2-2,y+10,2,2,'#ffffff'); px(x+W/2+1,y+13,2,1,'#c8c0b0');
      const s=Math.floor(now/200)%3;
      px(x+W/2-5,y+15+s,1,2,'#bfe0ff'); px(x+W/2+4,y+15+((s+1)%3),1,2,'#bfe0ff');
      return; }
    case 'uwBellArbor': { const W=d.w*TILE;                     // a timber arbor hung with a sunken bell
      ctx.fillStyle='rgba(0,0,0,.18)'; ctx.beginPath(); ctx.ellipse(x+W/2,y+TILE+14,W/2-2,3,0,0,7); ctx.fill();
      px(x+2,y+2,3,28,'#6f5128'); px(x+2,y+2,1,28,'#8a6a3a'); px(x+W-5,y+2,3,28,'#6f5128'); px(x+W-5,y+2,1,28,'#8a6a3a');
      px(x,y,W,4,'#8a6a3a'); px(x,y,W,1,'#a8844e'); px(x,y+3,W,1,'#5a3f22');                // crossbeam
      for(let i=0;i<6;i++) px(x+2+i*5,y+4+(i%2),3,3,'#3e8a5a');                              // sea-vine
      px(x+4,y+5,1,8,'#3e8a5a'); px(x+W-4,y+6,1,10,'#3e8a5a');
      // the bell, green with age, swinging a little
      const sw=Math.round(Math.sin(now/700));
      px(x+W/2,y+4,1,4,'#4a3e1e');
      px(x+W/2-5+sw,y+8,10,10,'#5a8a6a'); px(x+W/2-4+sw,y+7,8,2,'#6a9a7a'); px(x+W/2-6+sw,y+17,12,2,'#4a7a5a');
      px(x+W/2-4+sw,y+9,2,7,'#8abaa0'); px(x+W/2+sw,y+18,2,2,'#3a4a3a');                      // shine + clapper
      px(x+W/2-3+sw,y+12,6,1,'#c9a94a');                                                       // a gold band
      return; }
    case 'uwWoodenCross': uwDrawWoodenCross(x,y); return;
    case 'uwWheelSign': {                                       // a ship's wheel on a post
      ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,5,2,0,0,7); ctx.fill();
      px(x+7,y+10,2,5,'#5b3a1f'); px(x+7,y+10,1,5,'#7a5230');
      const cx=x+8, cy=y+6;
      for(let k=0;k<8;k++){ const a=k/8*Math.PI*2;                  // eight spokes, each ending in a handle
        for(let r=1;r<=5;r++) px(Math.round(cx+Math.cos(a)*r-0.5),Math.round(cy+Math.sin(a)*r-0.5),1,1,'#6f5128');
        px(Math.round(cx+Math.cos(a)*7-1),Math.round(cy+Math.sin(a)*7-1),2,2,'#8a6a3a'); }
      for(let k=0;k<28;k++){ const a=k/28*Math.PI*2;                // a solid rim
        px(Math.round(cx+Math.cos(a)*4.6-0.5),Math.round(cy+Math.sin(a)*4.6-0.5),1,1,'#a8844e'); }
      for(let k=0;k<28;k++){ const a=k/28*Math.PI*2;
        if(Math.sin(a)<0) px(Math.round(cx+Math.cos(a)*4.6-0.5),Math.round(cy+Math.sin(a)*4.6-0.5),1,1,'#c8a468'); }  // lit top
      px(cx-2,cy-2,3,3,'#c9a94a'); px(cx-1,cy-1,1,1,'#f0d98a');         // brass hub
      return; }
  }
  return false;
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — THE TEMPLE PIECES (1 Kings 6–7), mockup stage
//  Tiles 15..21 extend UW_T; the three large pieces (the Molten Sea, the
//  bronze altar, the cherubim) are OBJECTS drawn in the sorted object pass,
//  never from inside a tile, so the tiles after them can't paint over them.
// ════════════════════════════════════════════════════════════════
Object.assign(UW_T, { PILLAR_TOP:15, PILLAR:16, LAVER:17, CEDAR:18, GOLDFLOOR:19, LAMPSTAND:20, INNERDOOR:21 });
const UW_BRONZE={ B:'#a8743a', L:'#d0a060', D:'#6e4620', V:'#5a9a80', VL:'#7ab8a0' };
const UW_GOLD  ={ G:'#c8a448', L:'#f0d890', D:'#8a6a24', T:'#9a8a50' };   // T = tarnish
function uwGoldFloor(x,y,tx,ty){                       // "the floor of the house he overlaid with gold" (6:30)
  const h=_uwH(tx,ty);
  px(x,y,TILE,TILE,'#a8904c'); px(x,y,TILE,1,'#c0a860'); px(x,y+8,TILE,1,'#8a7438');
  px(x+(ty&1?5:11),y,1,8,'#8a7438'); px(x+(ty&1?12:3),y+9,1,7,'#8a7438');
  if(h%4===0) px(x+2+(h>>4)%9,y+11,4,2,'#b8a878');     // a drift of sand
  if(h%7===0) px(x+3+(h>>6)%8,y+3,2,2,'#6a8a5a');      // weed in a seam
}
function uwDrawTempleTile(t,x,y,tx,ty){
  const h=_uwH(tx,ty), now=Date.now(), B=UW_BRONZE, Gd=UW_GOLD;
  switch(t){
    case UW_T.GOLDFLOOR: uwGoldFloor(x,y,tx,ty); return true;
    case UW_T.CEDAR: {                                  // cedar, overlaid with gold, carved with palms and open flowers (6:29)
      px(x,y,TILE,TILE,'#8a7440'); px(x,y,TILE,2,'#a8904c'); px(x,y+14,TILE,2,'#5e4e2a');
      px(x,y+2,1,12,'#6e5c30'); px(x+15,y+2,1,12,'#6e5c30');
      if(tx%2===0){                                    // a palm: trunk and fronds
        px(x+7,y+6,2,8,Gd.D); px(x+4,y+4,8,1,Gd.L); px(x+3,y+5,3,1,Gd.L); px(x+10,y+5,3,1,Gd.L); px(x+6,y+3,4,1,Gd.L);
      } else {                                         // an open flower
        px(x+6,y+5,4,4,Gd.L); px(x+5,y+6,6,2,Gd.L); px(x+7,y+4,2,6,Gd.L); px(x+7,y+6,2,2,Gd.D);
      }
      if(h%5===0) px(x+1+(h>>4)%10,y+11,4,3,'#4e7a52');  // the sea has had it for a long time
      return true; }
    case UW_T.PILLAR_TOP: {                             // the chapiter: lily-work, network, pomegranates (7:16-22)
      uwFlag(x,y,tx,ty);
      px(x+2,y+9,12,7,B.B); px(x+2,y+9,3,7,B.L); px(x+12,y+9,2,7,B.D);          // the bowl
      for(let i=0;i<4;i++) for(let j=0;j<2;j++) px(x+3+i*3,y+10+j*3,1,1,B.D);     // network
      for(let i=0;i<5;i++) px(x+2+i*2.5|0,y+15,2,2,'#a84a3a');                     // a row of pomegranates
      px(x+1,y+4,14,5,B.B); px(x+2,y+2,3,3,B.L); px(x+7,y+1,2,4,B.L); px(x+11,y+2,3,3,B.L); // lily petals
      px(x+1,y+8,14,1,B.D); if(h&1) px(x+3,y+5,3,2,B.V);
      return true; }
    case UW_T.PILLAR: {                                 // the shaft of Jachin / Boaz: bronze, green with age
      uwFlag(x,y,tx,ty);
      px(x+4,y,8,15,B.B); px(x+4,y,2,15,B.L); px(x+10,y,2,15,B.D);
      px(x+3,y+14,10,2,B.D);
      px(x+6,y+3+(h%6),2,3,B.V); px(x+9,y+9-(h%4),1,2,B.VL);
      return true; }
    case UW_T.LAVER: {                                  // a laver on its wheeled base (7:27-38)
      uwFloor(x,y,tx,ty);
      px(x+2,y+13,3,3,B.D); px(x+11,y+13,3,3,B.D); px(x+3,y+14,1,1,B.L); px(x+12,y+14,1,1,B.L);   // wheels
      px(x+3,y+7,10,6,B.B); px(x+3,y+7,10,1,B.L); px(x+3,y+12,10,1,B.D);                         // the base
      px(x+5,y+9,2,2,B.D); px(x+9,y+9,2,2,B.D);                                                  // lions and oxen, worn smooth
      px(x+2,y+3,12,4,B.B); px(x+3,y+2,10,2,B.L); px(x+4,y+3,8,2,'#3f7ec0');                     // the basin, brimming
      if(h&1) px(x+11,y+5,2,2,B.V);
      return true; }
    case UW_T.LAMPSTAND: {                              // a golden lampstand (7:49): lit via uwLampLit
      uwGoldFloor(x,y,tx,ty);
      const lit = typeof uwLampLit==='function' && uwLampLit(tx,ty);
      const OL='#3e2e0c';
      px(x+3,y+13,10,3,OL); px(x+6,y+4,4,10,OL); px(x+2,y+1,12,5,OL);                          // outline first
      px(x+4,y+14,8,1,Gd.D); px(x+5,y+13,6,1,Gd.G); px(x+7,y+5,2,8,Gd.G); px(x+7,y+5,1,8,Gd.L);
      px(x+6,y+8,4,1,Gd.L); px(x+6,y+11,4,1,Gd.L);                                             // knops
      px(x+4,y+3,8,2,Gd.G); px(x+4,y+3,8,1,Gd.L); px(x+3,y+2,2,2,Gd.G); px(x+11,y+2,2,2,Gd.G); // the cup and its flowers
      if(lit){ px(x+7,y,2,3,'#fff2a8'); px(x+7,y+1,2,1,'#ffffff'); }
      else px(x+7,y+2,2,1,'#3a3a2a');
      return true; }
    case UW_T.INNERDOOR: {                              // olive-wood doors, gold over cherubim, palms, flowers (6:31-32)
      px(x,y,TILE,TILE,'#8a7440');
      px(x+1,y+1,14,15,Gd.G); px(x+1,y+1,14,1,Gd.L); px(x+7,y+1,2,15,Gd.D);
      px(x+3,y+4,3,5,Gd.L); px(x+2,y+5,1,3,Gd.L);                                              // a cherub's wing, left leaf
      px(x+10,y+4,3,5,Gd.L); px(x+13,y+5,1,3,Gd.L);                                            // and right
      px(x+3,y+11,3,3,Gd.D); px(x+10,y+11,3,3,Gd.D);                                           // flowers
      return true; }
  }
  return false;
}
// ── the large pieces, drawn as objects (x,y = top-left of their footprint) ──
function uwDrawMoltenSea(x,y){                          // 3×3 tiles: the Sea on twelve oxen (7:23-26)
  const B=UW_BRONZE, OX='#8a5a2e', OXL='#b07a44', HORN='#e0d0a0';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+24,y+45,22,3,0,0,7); ctx.fill();
  // the oxen: three look out toward you, one of each side-group shows its flank
  const ox=(ax,ay)=>{ px(ax,ay+3,8,8,OX); px(ax,ay+3,2,8,OXL); px(ax+1,ay,6,5,OX); px(ax+1,ay,6,1,OXL);
    px(ax,ay,1,2,HORN); px(ax+7,ay,1,2,HORN); px(ax+2,ay+2,1,1,'#1a1208'); px(ax+5,ay+2,1,1,'#1a1208');
    px(ax+1,ay+11,2,3,OX); px(ax+5,ay+11,2,3,OX); };
  ox(x+2,y+32); ox(x+14,y+33); ox(x+26,y+33); ox(x+38,y+32);
  // the bowl, tapering to the oxen's backs, with two rows of knops beneath the brim (7:24)
  for(let r=0;r<18;r++){ const w=Math.round(44-r*0.7), lx=x+24-(w>>1);
    px(lx,y+14+r,w,1, r<3?B.L:B.B); px(lx,y+14+r,3,1,B.L); px(lx+w-3,y+14+r,3,1,B.D); }
  for(let i=0;i<10;i++){ px(x+5+i*4,y+18,2,2,B.D); px(x+7+i*4,y+21,2,2,B.D); }
  px(x+9,y+24,5,3,B.V); px(x+30,y+26,4,2,B.V);
  // the brim, "wrought like the brim of a cup, with flowers of lilies"
  for(let r=0;r<12;r++){ const a=Math.sqrt(1-Math.pow((r-6)/6,2)), w=Math.round(46*a), lx=x+24-(w>>1);
    px(lx,y+4+r,w,1,B.B); }
  for(let r=0;r<8;r++){ const a=Math.sqrt(1-Math.pow((r-4)/4,2)), w=Math.round(38*a), lx=x+24-(w>>1);
    px(lx,y+6+r,w,1,'#2f6aa8'); }
  px(x+14,y+7,12,1,'#6aa6e0'); px(x+26,y+9,6,1,'#6aa6e0');
  for(let i=0;i<9;i++) px(x+3+i*5,y+15-(i%2),3,2,B.L);                                     // the lily scallops
}
function uwDrawAltar(x,y){                              // 2×2 tiles: the altar of brass (2 Chr 4:1)
  const B=UW_BRONZE;
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+16,y+30,15,3,0,0,7); ctx.fill();
  px(x+2,y+10,28,20,B.B); px(x+2,y+10,4,20,B.L); px(x+26,y+10,4,20,B.D); px(x+2,y+28,28,2,B.D);
  px(x+2,y+4,28,8,B.D); px(x+4,y+5,24,6,'#3a2a1a');                                       // the hearth, long cold
  for(let i=0;i<6;i++) px(x+5+i*4,y+5,1,6,B.B);                                             // the grate
  px(x+1,y+2,4,4,B.L); px(x+27,y+2,4,4,B.L); px(x+1,y+10,3,3,B.L); px(x+28,y+10,3,3,B.L); // horns
  px(x+8,y+16,16,1,B.D); px(x+8,y+22,16,1,B.D); px(x+11,y+18,4,3,B.V); px(x+20,y+24,5,2,B.V);
}
function uwDrawCherub(x,y){                             // 3×5 tiles: one cherub, wings spanning north–south (6:23-28)
  const G=UW_GOLD, OL='#4a3810';
  // two great wings: one sweeps to the north end of the span, one to the south,
  // broad at the shoulder and tapering to the tip that touches wall or partner
  const wing=(y0,y1,up)=>{ const n=y1-y0;
    for(let i=0;i<n;i++){ const t=up? (n-1-i)/n : i/n;                 // 0 at the shoulder, 1 at the tip
      const w=Math.round(26-18*t), lx=x+4;
      px(lx-1,y0+i,w+2,1,OL); px(lx,y0+i,w,1, (i%4===0)?G.D:G.G); px(lx,y0+i,Math.max(2,w>>2),1,G.L); } };
  wing(y+1,y+34,true); wing(y+46,y+79,false);
  // the body, in profile facing the room (east), robed and bowed
  px(x+17,y+24,17,40,OL);
  px(x+18,y+34,15,29,G.G); px(x+18,y+34,4,29,G.L); px(x+30,y+34,3,29,G.D);          // robe
  for(let i=0;i<3;i++) px(x+22+i*4,y+40,1,20,G.D);                                  // folds
  px(x+19,y+25,11,10,G.G); px(x+19,y+25,4,10,G.L); px(x+28,y+28,2,5,G.D);         // head, bowed
  px(x+26,y+29,2,1,OL);
  px(x+24,y+37,10,4,G.L); px(x+32,y+39,2,3,G.G);                                   // arms folded forward
  px(x+17,y+62,17,2,OL);
}
// ── the cherubim seen FRONT-ON (the house turned north, per Zak): 5×3 tiles
//    each, standing against the north wall and facing you, wings stretched
//    straight out; one wing touches the wall, the other touches the other
//    cherub's wing in the middle of the house (6:27).
function uwDrawCherubFront(x,y){
  const G=UW_GOLD, OL='#4a3810', cx=x+40;
  ctx.fillStyle='rgba(0,0,0,.20)'; ctx.beginPath(); ctx.ellipse(cx,y+46,12,2.5,0,0,7); ctx.fill();
  // the wings: broad at the shoulder, tapering to the tips at either edge of the span
  const wing=(dir)=>{ for(let i=0;i<38;i++){ const t=i/38, h=Math.round(16-11*t), top=y+9+Math.round(t*4);
      const wx = dir<0 ? cx-7-i : cx+6+i;
      px(wx,top-1,1,h+2,OL); px(wx,top,1,h, (i%5===0)?G.D:G.G); px(wx,top,1,Math.max(2,h>>2),G.L); } };
  wing(-1); wing(1);
  px(x,y+13,1,6,OL); px(x+79,y+13,1,6,OL);                                    // the tips, touching
  // the body: robed, standing, arms folded; a plain gold head, bowed toward the room
  px(cx-9,y+8,18,39,OL);
  px(cx-8,y+19,16,27,G.G); px(cx-8,y+19,4,27,G.L); px(cx+5,y+19,3,27,G.D);
  for(let i=0;i<3;i++) px(cx-4+i*4,y+30,1,15,G.D);                             // folds
  px(cx-6,y+22,12,4,G.L); px(cx-6,y+25,12,1,G.D);                              // arms folded
  px(cx-5,y+9,10,10,G.G); px(cx-5,y+9,3,10,G.L); px(cx+3,y+11,2,6,G.D);         // head
  px(cx-4,y+17,8,2,G.D);                                                        // bowed
}
// ── THE HUMBLE CHEST (Zak): a plain wooden box between the cherubim, tied
//    with cord, no gold on it at all. Drawn as an object centred on the
//    room's middle line (the seam between two tiles); its footprint is the
//    two tiles it straddles. Holds the Wooden Cross.
function uwDrawHumbleChest(x,y,open){               // x,y = top-left of the 2×1 footprint
  const cx=x+16, W='#7a5a3a', WL='#9a7650', WD='#4e3822', CORD='#c8b890';
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(cx,y+15,8,2,0,0,7); ctx.fill();
  px(cx-7,y+6,14,9,W); px(cx-7,y+6,14,1,WL); px(cx-7,y+14,14,1,WD);
  px(cx-7,y+6,1,9,WD); px(cx+6,y+6,1,9,WD); px(cx-3,y+7,1,7,WD); px(cx+2,y+7,1,7,WD);   // plank seams
  if(open){ px(cx-7,y+2,14,4,WD); px(cx-6,y+3,12,2,'#2a1c10'); }
  else { px(cx-7,y+4,14,3,WL); px(cx-7,y+4,14,1,'#b08a60');                            // the lid
         px(cx-1,y+4,2,11,CORD); px(cx-7,y+10,14,1,CORD); px(cx,y+9,1,2,'#e8dcb8'); }    // cord and knot
}
// ── THE WOODEN CROSS: a homestead decoration (1 tile), plain timber on a
//    cairn of stones. Deliberately humbler than the Champion's Cross.
UW_DECOR_ITEMS.woodenCross = { name:'Wooden Cross', emoji:'✝️', kind:'uwWoodenCross', w:1 };
function uwDrawWoodenCross(x,y){
  ctx.fillStyle='rgba(0,0,0,.22)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,5,2,0,0,7); ctx.fill();
  px(x+4,y+12,8,3,'#8a8478'); px(x+5,y+11,6,2,'#a6a094'); px(x+4,y+14,8,1,'#6a6458');   // stones
  px(x+7,y,2,13,'#7a5230'); px(x+7,y,1,13,'#9a6e44');                                  // upright
  px(x+3,y+3,10,2,'#7a5230'); px(x+3,y+3,10,1,'#9a6e44');                              // crossbeam
  px(x+8,y+5,1,1,'#4e3420'); px(x+7,y+8,1,2,'#5e4028');                                // grain
}

// ════════════════════════════════════════════════════════════════
//  THE HOUSE, SEEN FROM THE COURTS (Zak: a building you walk into)
//  Compact like the game's chapels: 14×10 tiles outside, bigger within.
//  Hewn stone (6:7), a tall porch front, the side chambers as lower wings
//  with narrow windows (6:4), cedar beams under a flat roof. Standing, but
//  drowned: coral and weed creep over the ledges. The doorway is the two
//  tiles at the bottom-centre of the footprint.
// ════════════════════════════════════════════════════════════════
function uwDrawTempleExterior(ox,oy){
  const W=14*TILE, H=10*TILE, OL='#1a141c';
  const ST='#c8bea0', STL='#ddd4b8', STD='#9a9078', STS='#7e7662';   // limestone: face, lit, shade, side
  const CED='#6e4a2c', CEDD='#4e3420', GOLD='#c8a448', GOLDL='#f0d890';
  const WEED='#4e7a52', WEEDL='#6a9a62', COR='#d8586a', CORL='#f08a96';
  const h=(a,b)=>((a*374761393+b*668265263)>>>0);
  // the shadow it casts on the sea floor
  ctx.fillStyle='rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.ellipse(ox+W/2+6, oy+H-2, W/2, TILE*0.55, 0,0,7); ctx.fill();
  const ashlar=(x,y,w,hh)=>{ for(let r=0;r*6<hh;r++){ const yy=y+r*6; if(yy>=y+hh) break; px(x,yy,w,1,STD);
      for(let c=((r&1)?4:0);c<w;c+=12) px(x+c,yy+1,1,Math.min(5,y+hh-yy-1),STD); } };
  const block=(x,y,w,hh,roofH)=>{                       // one massing: flat cedar-edged roof over a stone face
    px(x-1,y-1,w+2,hh+2,OL);
    px(x,y,w,roofH,'#8a8070'); px(x,y,w,2,'#a89e88');           // the flat roof (stone over cedar)
    px(x,y+roofH-3,w,3,CED); px(x,y+roofH-3,w,1,CEDD);           // the cedar beam-ends under its lip
    for(let i=4;i<w-2;i+=6) px(x+i,y+roofH-2,2,2,CEDD);
    px(x,y+roofH,w,hh-roofH,ST); px(x,y+roofH,2,hh-roofH,STL); px(x+w-2,y+roofH,2,hh-roofH,STD);
    ashlar(x+2,y+roofH+2,w-4,hh-roofH-2);
    px(x+w+1,y+roofH+2,3,hh-roofH-1,STS);                        // the side in shadow (the game's faked depth)
  };
  // the two side wings: the storied chambers, lower, with narrow windows
  const wingY=oy+Math.round(H*0.38), wingH=H-Math.round(H*0.38);
  block(ox,wingY,4*TILE,wingH,10); block(ox+10*TILE,wingY,4*TILE,wingH,10);
  for(const wx of [ox, ox+10*TILE]) for(let s=0;s<3;s++) for(let k=0;k<3;k++){       // three storeys of narrow lights
    const x=wx+8+k*18, y=wingY+16+s*24; px(x,y,3,9,'#2a2a34'); px(x,y,3,1,STD); px(x-1,y+9,5,1,STL); }
  // the house itself, taller, behind the porch
  const houseY=oy+Math.round(H*0.16);
  block(ox+4*TILE,houseY,6*TILE,H-Math.round(H*0.16),12);
  for(let k=0;k<5;k++){ const x=ox+4*TILE+8+k*18; px(x,houseY+18,3,12,'#2a2a34'); px(x-1,houseY+30,5,1,STL); }   // high windows
  // the porch: the tallest front, centred, with the doorway
  const pX=ox+5*TILE, pW=4*TILE, pY=oy;
  block(pX,pY,pW,H,14);
  px(pX+4,pY+16,pW-8,2,GOLD); px(pX+4,pY+16,pW-8,1,GOLDL);                          // a band of gold, faded
  for(let i=0;i<6;i++){ const fx=pX+8+i*9; px(fx,pY+22,4,4,GOLD); px(fx+1,pY+23,2,2,GOLDL); }   // open flowers carved in the band
  // the doorway: two tiles wide at the foot of the porch, an open dark mouth under a lintel
  const dX=ox+6*TILE, dW=2*TILE, dY=oy+H-Math.round(TILE*2.2);
  px(dX-3,dY-5,dW+6,5,STD); px(dX-3,dY-5,dW+6,1,STL);                              // the lintel
  px(dX,dY,dW,oy+H-dY,'#0e1a22'); px(dX+2,dY+2,dW-4,oy+H-dY-2,'#142a36');
  px(dX+dW/2-1,dY,2,oy+H-dY,'#0a141a');                                              // the doors stand open
  px(dX-2,dY,2,oy+H-dY,'#5e4a30'); px(dX+dW,dY,2,oy+H-dY,'#5e4a30');                 // door leaves folded back
  // the sea has had it a long time: weed on the ledges, coral at the footings, a few cracks
  for(let i=0;i<W;i+=3){ const k=h(ox+i,oy)%7;
    if(k<3){ px(ox+i,wingY+10,2,2+k,WEED); px(ox+i,wingY+10,1,1,WEEDL); }
    if(k===4 && (ox+i<pX-4 || ox+i>pX+pW+4)) { px(ox+i,oy+H-5,3,4,COR); px(ox+i,oy+H-5,3,1,CORL); } }
  for(let i=0;i<pW;i+=4){ const k=h(pX+i,1)%5; if(k<2) px(pX+i,pY+14,2,3+k,WEED); }
  px(ox+4*TILE+30,houseY+40,1,9,STS); px(ox+4*TILE+31,houseY+48,1,6,STS);           // cracks
  px(ox+11*TILE+12,wingY+40,1,8,STS); px(ox+11*TILE+13,wingY+47,1,5,STS);
}

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — THE MAP (generated by build_kit.py from uw_map.py)
//  Two rooms. COURTS: the Reef Garden, with the house standing at its north
//  end as a building you walk into. TEMPLE: the house within, after Solomon's
//  (1 Kings 6-7), facing south — porch, Holy Place, Most Holy Place, one tile
//  to two cubits — with the side chambers opening off the Holy Place.
//  Fixed rows, no randomness: the same every boot.
// ════════════════════════════════════════════════════════════════
const UW_CHAR = {".": 0, "g": 1, "c": 2, "r": 3, "k": 4, "f": 5, "w": 6, "o": 7, "u": 8, "$": 10, "x": 12, "d": 13, "t": 14, "J": 15, "j": 16, "v": 17, "C": 18, "_": 19, "L": 20, "I": 21};
const UW_ROOMS = {
  courts: { rows:["kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkk..........................................kkkkk", "kkkk............................................kkkk", "kkk...u.....cc....................w..............kkk", "kkk..gggggg......w.....................gggggggu..kkk", "kkk..gggggg......w.................c...ggggggg...kkk", "kkk..gggggg............................ggggggg...kkk", "kkk..gggggg.....c......................ggggggg...kkk", "kkk..gggggg........................w.............kkk", "kkk............r.................................kkk", "kkk...............................r..............kkk", "kkk...........................................c..kkk", "kkk.....$..........ffffJffffJffff............c...kkk", "kkk................ffffjffffjffff...c............kkk", "kkk................ffffjffffjffff.......ddddddd..kkk", "kkk................ffffffffffffff.......d.....d..kkk", "kkk...cc...........ffffffffffffff.......d.....d..kkk", "kkk................ffffffffffffff.............d..kkk", "kkkk.........v....wffffffffffffff.....v.d.....d..kkk", "kkkk.....r.........ffffffffffffff.......ddddddd..kkk", "kkk................ffffffffffffff.........r......kkk", "kkk..........v.ggg....................vt.........kkk", "kkk..ggggg.....ggg...............................kkk", "kkk..ggggg.....ggg...............................kkk", "kkk..ggggg...v.ggg....................v..gggggg..kkk", "kkk..ggggg....................c..........gggggg$.kkk", "kkk..ggggg...............................gggggg..kkk", "kkkkkk.......v........................v..gggggg..kkk", "kkkkkk................gggggg....................kkkk", "kkkkk......c..........gggggg....................kkkk", "kkkkt........v........gggggg..........v..........kkk", "kkkkkkr...............gggggg................c....kkk", "kkkkkk...........................................kkk", "kkk...........................$..................kkk", "kkk.....ggggggg..................................kkk", "kkk.....ggggggg......................gggggggg....kkk", "kkk.....ggggggg.............r........ggggg$gg....kkk", "kkk.....gggg$gg......................gggggggg....kkk", "kkk.....ggggggg.....c............c...gggggggg....kkk", "kkk..................................gggggggg....kkk", "kkk...u......................................u...kkk", "kkkk......................u.....................kkkk", "kkkkk...........kk................kk...........kkkkk", "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk", "kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk"], obj:{"temple": ["uwDrawTempleExterior", 19, 4, 14, 10], "altar": ["uwDrawAltar", 25, 18, 2, 2], "sea": ["uwDrawMoltenSea", 15, 15, 3, 3]}, npc:{"zebulun": [43, 18]}, tablets:{"rec1": [4, 32], "ps104": [39, 23]}, chests:{"dec_planter": [8, 14], "dec_wheel": [42, 38], "pearl_g1": [47, 27], "pearl_g2": [30, 35], "pearl_g3": [12, 39]} },
  temple: { rows:["xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", "xwwwwwwwwCCCCCCCCCCCCwwwwwwwwx", "xw.......C__________C.......wx", "xw.$.....C__________C.......wx", "xw.......C__________C.ddddd.wx", "xw.r.....C__________C.d...d.wx", "xw.......C__________C.....d.wx", "xw...o...C__________C.d...d.wx", "xw.......C__t____t__C.ddddd.wx", "xw.......C__________C.......wx", "xwww..wwwC__________Cww.wwwwwx", "xw.......C__________C.......wx", "xw....$..CCCCCIICCCCC.......wx", "xw.......C__________C.r.....wx", "xw....r..CL________LC.......wx", "xw.......C__________C.......wx", "xw.......C__________C.....$.wx", "xw.......C__________C.......wx", "xw.......CL________LC.......wx", "xwwwwww.wC__________Cwwwww.wwx", "xw.......C__________C.......wx", "xw.......C__________C.......wx", "xw......._L________LC.....r.wx", "xw.......___________C.......wx", "xw..t....C___________.......wx", "xwr......C___________.......wx", "xw.......CL________LC...o...wx", "xw.......C__________C.......wx", "xw.......C__________C.......wx", "xww..wwwwC__________Cwwww..wwx", "xw.......CL________LC.......wx", "xw.......C__________C.......wx", "xw.......C__________C.......wx", "xw.......CCCCC__CCCCC.......wx", "xw.......C__________C..r....wx", "xw.......C_______t__C.......wx", "xw.....r.C__________C.......wx", "xw.$.....C__________C.....$.wx", "xw.......C__________C.......wx", "xw.......CCCCC__CCCCC.......wx", "xwwwwwwwwwxxxx__xxxxwwwwwwwwwx", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"], obj:{"cherubW": ["uwDrawCherubFront", 10, 2, 5, 3], "cherubE": ["uwDrawCherubFront", 15, 2, 5, 3], "humble": ["uwDrawHumbleChest", 14, 5, 2, 1]}, npc:{"tirzah": [24, 6]}, tablets:{"rec2": [4, 24], "rec3": [12, 8], "micah": [17, 8], "porch": [17, 35]}, chests:{"dec_bell": [3, 3], "dec_fountain": [26, 37], "pearl_r1": [6, 12], "pearl_r2": [3, 37], "pearl_r3": [26, 16]} },
};
const UW_ENTRY = {"A": [46, 6], "B": [6, 5], "C": [6, 42], "D": [45, 42], "E": [26, 43]};                 // the five entry currents (courts)
const UW_DOOR = [[25, 13], [26, 13]];     // the house's doorway in the courts
const UW_DOOR_IN = [25, 14];            // where you stand when you come back out
const UW_EXIT = [[14, 40], [15, 40]];     // the threshold inside: step here to go out
const UW_ARRIVE = [14, 37];              // where you stand when you come in
const UW_PRAYER = {"L2": [10, 22], "L4": [19, 30], "L5": [10, 14], "L9": [19, 18]};
const UW_LAMPSTANDS = [[10, 14], [10, 18], [10, 22], [10, 26], [10, 30], [19, 14], [19, 18], [19, 22], [19, 26], [19, 30]];
const UW_INNER_DOOR = [[14, 12], [15, 12]];
const UW_OBJFN = { uwDrawAltar:(x,y)=>uwDrawAltar(x,y), uwDrawMoltenSea:(x,y)=>uwDrawMoltenSea(x,y), uwDrawCherubFront:(x,y)=>uwDrawCherubFront(x,y), uwDrawTempleExterior:(x,y)=>uwDrawTempleExterior(x,y) };

// ════════════════════════════════════════════════════════════════
//  UNDERWATER — STATE
//  Everything that persists lives in `uwSaved` and goes out under its OWN save
//  key, `underwater` (buildSaveData hook). A save from before this block has no
//  such key, and uwLoad() turns that into "never been underwater".
//  Everything in `uw` is transient and rebuilt on demand.
// ════════════════════════════════════════════════════════════════
function uwFresh(){ return { v:1, from:null, at:null, visited:{}, chests:{}, tablets:{}, read:{},
  lamps:[], opened:false, livery:false, barding:false, quiz:false, pearls:0, sold:0,
  met:{}, eldan:{ fish:false, kind:false } }; }
let uwSaved = uwFresh();
const uw = { room:'courts', grid:null, W:0, H:0, solid:null, quiz:null, btn:null, lastKey:{}, t:0, hint:0 };
// the live room's tables (rows, objects, people, tablets, chests)
function uwR(){ return UW_ROOMS[uw.room] || UW_ROOMS.courts; }

// ── the five dive spots (Zak circled them; coordinates measured, not guessed) ──
const UW_SPOTS = [
  { id:'A', x:170, y:40,  name:'the lake by Crystalpeak'   },
  { id:'B', x:70,  y:120, name:'the river pond'            },
  { id:'C', x:40,  y:170, name:'the west pond'             },
  { id:'D', x:230, y:200, name:'the pond by the Shadowmere road' },
  { id:'E', x:190, y:234, name:"Stormgate's east harbour" },
];
const UW_PRAYER_ORDER = ['L2','L4','L5','L9'];
const UW_PRAYER_TEXT = {
  L2:['Jonah 2:2','I cried by reason of mine affliction unto the LORD, and he heard me; out of the belly of hell cried I, and thou heardest my voice.'],
  L4:['Jonah 2:4','Then I said, I am cast out of thy sight; yet I will look again toward thy holy temple.'],
  L5:['Jonah 2:5','The waters compassed me about, even to the soul: the depth closed me round about, the weeds were wrapped about my head.'],
  L9:['Jonah 2:9','But I will sacrifice unto thee with the voice of thanksgiving; I will pay that that I have vowed. Salvation is of the LORD.'],
};
const UW_CHEST_LOOT = {
  dec_planter:{ decor:'uw_coralPlanter' }, dec_wheel:{ decor:'uw_wheelSign' },
  dec_bell:{ decor:'uw_bellArbor' },       dec_fountain:{ decor:'uw_pearlFountain' },
  humble:{ decor:'uw_woodenCross' },
  pearl_g1:{ pearls:2 }, pearl_g2:{ pearls:1 }, pearl_g3:{ pearls:2 },
  pearl_r1:{ pearls:3 }, pearl_r2:{ pearls:2 }, pearl_r3:{ pearls:3 },
};
const UW_PEARL_PRICE = 120;
const UW_QUIZ = [
  { q:'From where did Jonah cry unto the LORD?', a:1,
    o:['From the deck of the ship, before the storm','Out of the belly of the fish — “out of the belly of hell cried I”','From the city of Nineveh','From the shore where he was cast up'] },
  { q:'Cast out of God’s sight, where did Jonah say he would look?', a:2,
    o:['Back toward the land of his fathers','Up toward the sky, for rescue','Again toward thy holy temple','Down into the deep, in despair'] },
  { q:'How does Jonah’s prayer end?', a:0,
    o:['“Salvation is of the LORD”','“Let the sea take me”','“I have done no wrong”','“Send another in my stead”'] },
];

// ── the grid: the live room's rows -> tile codes; opened doors and taken tablets applied ──
function uwBuildGrid(room){
  if(room) uw.room=room;
  const R=uwR(), g=R.rows.map(r=>[...r].map(ch=>UW_CHAR[ch]));
  if(uw.room==='temple' && uwSaved.opened) for(const [x,y] of UW_INNER_DOOR) g[y][x]=UW_T.GOLDFLOOR;
  for(const id in R.tablets) if(/^rec/.test(id) && uwSaved.tablets[id]){ const [x,y]=R.tablets[id]; g[y][x]=(UW_ZONE(x,y)==='temple')?UW_T.GOLDFLOOR:UW_T.SAND; }
  uw.grid=g; uw.H=g.length; uw.W=g[0].length;
  uw.solid=new Set();
  for(const k in R.obj){ const [,x,y,w,h]=R.obj[k]; for(let yy=y;yy<y+h;yy++) for(let xx=x;xx<x+w;xx++) uw.solid.add(xx+','+yy); }
  if(uw.room==='courts') for(const [x,y] of UW_DOOR) uw.solid.delete(x+','+y);   // the house's doorway is open
  for(const k in R.npc){ const [x,y]=R.npc[k]; uw.solid.add(x+','+y); }
}
function uwRegionName(){
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE), z=UW_ZONE(tx,ty);
  if(z==='garden') return 'The Drowned Courts';
  if(z==='ruins') return 'The Side Chambers';
  return ty<=11 ? 'The Most Holy Place' : ty<=32 ? 'The Holy Place' : 'The Porch';
}
// courts: all garden. temple: the house within (x 10..19, y 2..39) is gold; the chambers are ruins
function UW_ZONE(tx,ty){ if(uw.room!=='temple') return 'garden'; return (tx>=10&&tx<=19&&ty>=2&&ty<=39) ? 'temple' : 'ruins'; }
const UW_WALK = new Set([0,1,5,8,19]);           // sand, seagrass, flagstone, current, gold floor
function uwTile(tx,ty){ return (uw.grid && uw.grid[ty] && uw.grid[ty][tx]!==undefined) ? uw.grid[ty][tx] : UW_T.TRENCH; }
function uwWalkable(tx,ty){ return UW_WALK.has(uwTile(tx,ty)) && !uw.solid.has(tx+','+ty); }
function uwLampLit(tx,ty){
  if(uw.room!=='temple') return false;
  if(uwSaved.opened) return true;
  for(const id of uwSaved.lamps){ const p=UW_PRAYER[id]; if(p && p[0]===tx && p[1]===ty) return true; }
  return false;
}

// ── SAVE / LOAD (hooks in buildSaveData and applySaveData) ──
function uwSave(){
  if(!UW_ON) return undefined;
  const s=JSON.parse(JSON.stringify(uwSaved));
  s.at = (place.kind==='underwater') ? { x:Math.round(player.x), y:Math.round(player.y), room:uw.room } : null;
  return s;
}
function uwLoad(s){
  uwSaved=uwFresh(); uw.grid=null; uw.room='courts'; uwQuizClose(true); uwHideButton();   // any load leaves the deep (uwRestore may re-enter)
  if(!UW_ON) return;
  if(s && typeof s==='object'){
    const F=uwFresh();
    for(const k in F){ if(s[k]===undefined) continue;
      if(F[k]!==null && typeof F[k]==='object' && !Array.isArray(F[k])) uwSaved[k]=Object.assign({},F[k],(s[k]&&typeof s[k]==='object')?s[k]:{});
      else if(Array.isArray(F[k])) uwSaved[k]=Array.isArray(s[k])?s[k].filter(id=>UW_PRAYER_ORDER.includes(id)):[];
      else uwSaved[k]=s[k]; }
    uwSaved.pearls=Math.max(0,uwSaved.pearls|0); uwSaved.sold=Math.max(0,uwSaved.sold|0);
  }
  uwEldanCheck(true);                            // trials finished before this update still pay out
}
// restoreWhere hook: a save made underwater comes back underwater, where it was made
function uwRestore(){
  if(!UW_ON || !uwCanDive()) return false;
  const at=uwSaved.at;
  uwBuildGrid(at && UW_ROOMS[at.room] ? at.room : 'courts');
  place={kind:'underwater'};
  player.mounted=true; player.boating=false; demons=[];
  const ok=at && uwWalkable(Math.floor((at.x+TILE/2)/TILE), Math.floor((at.y+TILE/2)/TILE));
  if(!ok) uwBuildGrid('courts');
  const e=UW_ENTRY[uwSaved.from||'A'];
  player.x = ok ? at.x : e[0]*TILE; player.y = ok ? at.y : (e[1]-1)*TILE;
  uwSaved.at=null;
  if(typeof updateMountBtn==='function') updateMountBtn();
  return true;
}

// ── who may dive ──
function uwCanDive(){ return !!(player.pet && player.pet.id==='steadfast' && player.pet.form===2); }
function uwSpotHere(){
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE);
  return UW_SPOTS.find(s=>Math.abs(s.x-tx)<=1 && Math.abs(s.y-ty)<=1) || null;
}

// ── Ⓐ: the doAction hook. true = handled (and no sword is swung) ──
function uwAction(){
  if(!UW_ON) return false;
  if(place.kind==='underwater'){ uwUnderAction(); return true; }
  if(place.kind!=='overworld') return false;
  const s=uwSpotHere(); if(!s) return false;
  if(player.mounted && !player.boating && uwCanDive()){ uwDive(s); return true; }
  if(player.mounted || player.boating){
    showBanner('🌊 <b style="color:#9fd0e8">The water turns dark and deep here.</b><br><span style="font-size:7px">Something far below catches the light. Only a creature of the sea could carry you down.</span>', 2600);
    return true;
  }
  return false;
}
function uwDive(s){
  beginCross('stair', ()=>{
    lastOverworld.x=s.x*TILE; lastOverworld.y=s.y*TILE;
    uwSaved.from=s.id; const first=!Object.keys(uwSaved.visited).length; uwSaved.visited[s.id]=true;
    uwBuildGrid('courts');
    fishing=null; player.boating=false; player.mounted=true; demons=[];
    place={kind:'underwater'};
    const e=UW_ENTRY[s.id]; player.x=e[0]*TILE; player.y=(e[1]-1)*TILE; player.dir='up';
    if(typeof updateMountBtn==='function') updateMountBtn();
    saveGame();
    showBanner(first
      ? '🌊 <b style="color:#9ff0ff">Down, down into the deep…</b><br><span style="font-size:7px">A drowned court opens around you, and beyond it the pillars of a house of gold. “So is this great and wide sea” — Psalm 104:25</span>'
      : '🌊 <b style="color:#9ff0ff">You dive from '+s.name+'.</b>', first?4200:1600);
  });
}
function uwSurface(spotId){
  const s=UW_SPOTS.find(q=>q.id===spotId) || UW_SPOTS[0];
  beginCross('stair', ()=>{
    uwQuizClose(true); uwHideButton();
    place={kind:'overworld'};
    player.x=s.x*TILE; player.y=s.y*TILE; player.mounted=true; player.boating=false; player.dir='down';
    lastOverworld.x=player.x; lastOverworld.y=player.y;
    uwSaved.at=null;
    demons=[]; spawnDemons();
    if(typeof updateMountBtn==='function') updateMountBtn();
    saveGame();
    showBanner('🌅 You break the surface at '+s.name+'.', 1600);
  });
}

// ── the frame: the loop() hook hands the whole frame to this ──
function uwFrame(dt){
  uw.t+=dt;
  if(bannerT>0 && !dialogue.open){ bannerT-=dt; if(bannerT<=0) banner.style.display='none'; }
  uwSyncButton();
  if(!uw.grid) uwBuildGrid();
  // the HUD the overworld branch would have kept current: where you are, the hour, your health
  { const el=document.getElementById('loc'), nm=uwRegionName(); if(el && el.textContent!==nm) el.textContent=nm; }
  setHudHint(`${phaseIcon()} ${clockHHMM()}`, 0);
  { const hb=document.getElementById('hpbar'); if(hb) hb.style.width=(player.hp/player.maxHp*100)+'%'; }
  const frozen = dialogue.open || cross.t>0 || !!uw.quiz;
  if(uw.quiz) uwQuizInput();
  let dx=0, dy=0;
  if(!frozen){
    if(held.up) dy=-1; else if(held.down) dy=1;
    if(held.left) dx=-1; else if(held.right) dx=1;
    if(dx&&dy){ const k=0.70710678; dx*=k; dy*=k; }
    if(dy<0) player.dir='up'; else if(dy>0) player.dir='down'; else if(dx<0) player.dir='left'; else if(dx>0) player.dir='right';
  }
  player.moving=!!(dx||dy);
  if(player.moving){
    const spd=SPEED*1.4*(dt/16);                 // the Sea Dragon's swim: its overworld mounted pace
    const cx=Math.floor((player.x+TILE/2)/TILE), cy=Math.floor((player.y+TILE/2)/TILE);
    const nx=player.x+dx*spd, ny=player.y+dy*spd;
    if(uwWalkable(Math.floor((nx+TILE/2)/TILE), cy)) player.x=nx;
    if(uwWalkable(Math.floor((player.x+TILE/2)/TILE), Math.floor((ny+TILE/2)/TILE))) player.y=ny;
    player.ftick=(player.ftick||0)+1; if(player.ftick%8===0) player.frame=((player.frame||0)+1)%4;
    uwThresholds();
  }
  draw();                                        // the draw() hook routes to uwDraw()
}
// ── walking in and out of the house: the doorway in the courts, the threshold inside ──
function uwThresholds(){
  if(cross.t>0) return;
  const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE);
  const on=(L)=>L.some(([x,y])=>x===tx&&y===ty);
  if(uw.room==='courts' && player.dir==='up' && on(UW_DOOR)) beginCross('door', ()=>{
    uwBuildGrid('temple'); player.x=UW_ARRIVE[0]*TILE; player.y=UW_ARRIVE[1]*TILE; player.dir='up';
    if(!uwSaved.met.house){ uwSaved.met.house=true;
      showBanner('🕯 <b style="color:#f0d890">The house within.</b><br><span style="font-size:7px">“And the house, when it was in building, was built of stone made ready before it was brought thither: so that there was neither hammer nor axe nor any tool of iron heard in the house.” — 1 Kings 6:7</span>', 4200); }
    saveGame(); });
  else if(uw.room==='temple' && player.dir==='down' && on(UW_EXIT)) beginCross('door', ()=>{
    uwBuildGrid('courts'); player.x=UW_DOOR_IN[0]*TILE; player.y=UW_DOOR_IN[1]*TILE; player.dir='down'; saveGame(); });
}
// the surface button (⬆) and the U key: block-owned, no hook needed
function uwSyncButton(){
  if(!uw.btn){
    const mb=document.getElementById('mountBtn');
    const host=(mb && mb.parentNode) || document.getElementById('stage');   // a sibling of the mount button, on the stage
    if(host && document.createElement){
      const b=document.createElement('div'); b.setAttribute('id','uwSurfaceBtn'); b.textContent='⬆';
      b.style.cssText='position:absolute;top:7px;right:110px;z-index:11;background:rgba(20,60,80,.88);border:1px solid #7fd0e8;color:#fff;font-size:13px;width:30px;height:26px;border-radius:5px;display:none;align-items:center;justify-content:center;';
      const go=e=>{ if(e&&e.preventDefault) e.preventDefault(); uwSurfaceAsked(); };
      if(b.addEventListener){ b.addEventListener('touchstart',go,{passive:false}); b.addEventListener('mousedown',go); }
      host.appendChild(b); uw.btn=b;
    }
  }
  if(uw.btn){ const want=(place.kind==='underwater' && boot.done)?'flex':'none'; if(uw.btn.style.display!==want) uw.btn.style.display=want; }
}
function uwHideButton(){ if(uw.btn && uw.btn.style.display!=='none') uw.btn.style.display='none'; }
function uwSurfaceAsked(){
  if(place.kind!=='underwater' || dialogue.open || uw.quiz || cross.t>0) return;
  uwSurface(uwSaved.from||'A');
}
if(UW_ON && typeof addEventListener==='function') addEventListener('keydown', e=>{
  if(e && e.key && e.key.toLowerCase()==='u' && !e.repeat && place.kind==='underwater') uwSurfaceAsked(); });

// ── Ⓐ underwater ──
function uwFacing(){
  const d={up:[0,-1],down:[0,1],left:[-1,0],right:[1,0]}[player.dir]||[0,1];
  const cx=Math.floor((player.x+TILE/2)/TILE), cy=Math.floor((player.y+TILE/2)/TILE);
  return [cx,cy,cx+d[0],cy+d[1]];
}
function uwUnderAction(){
  if(uw.quiz){ uwQuizSelect(); return; }
  if(cross.t>0) return;
  const [cx,cy,fx,fy]=uwFacing();
  // a rising current, under you or before you, takes you up at its own spot
  for(const [x,y] of [[cx,cy],[fx,fy]]) if(uwTile(x,y)===UW_T.CURRENT){
    const id=Object.keys(UW_ENTRY).find(k=>UW_ENTRY[k][0]===x&&UW_ENTRY[k][1]===y); uwSurface(id||uwSaved.from||'A'); return; }
  // people
  const R=uwR();
  for(const k in R.npc){ const [x,y]=R.npc[k]; if(x===fx&&y===fy){ k==='zebulun'?uwTalkZebulun():uwTalkTirzah(); return; } }
  // the large pieces
  for(const k in R.obj){ const [,x,y,w,h]=R.obj[k]; if(fx>=x&&fx<x+w&&fy>=y&&fy<y+h && !(uw.room==='courts' && UW_DOOR.some(([dx,dy])=>dx===fx&&dy===fy))){ uwObjAction(k); return; } }
  const t=uwTile(fx,fy), key=fx+','+fy;
  const chest=Object.keys(R.chests).find(k=>R.chests[k][0]===fx&&R.chests[k][1]===fy);
  if(chest && t===UW_T.CHEST){ uwOpenChest(chest); return; }
  const tab=Object.keys(R.tablets).find(k=>R.tablets[k][0]===fx&&R.tablets[k][1]===fy);
  if(tab && t===UW_T.TABLET){ uwReadTablet(tab); return; }
  if(t===UW_T.LAMPSTAND){ uwLamp(fx,fy); return; }
  if(t===UW_T.PILLAR || t===UW_T.PILLAR_TOP){ uwPillar(fx); return; }
  if(t===UW_T.INNERDOOR){ say(['The olive-wood doors are shut fast, gold over carved cherubim, palms, and open flowers. No handle, no lock. Only the house itself can open them.']); return; }
  if(t===UW_T.LAVER){ say(['A laver on its wheeled base: lions, oxen, and cherubim cast in its panels (1 Kings 7:29). It still holds water — the sea’s own.']); return; }
  if(t===UW_T.CHEST){ showBanner('The chest hangs open. Nothing more here.', 1100); return; }
}
function uwObjAction(k){
  if(k==='sea') say(['The Molten Sea: ten cubits brim to brim, standing upon twelve oxen, three looking to each quarter (1 Kings 7:23-25).','It was made for the priests to wash in. Now the whole sea washes over it.']);
  else if(k==='altar') say(['The altar of brass, long cold (2 Chronicles 4:1). No fire has burned here in an age.','Its horns still point to the four winds.']);
  else if(k==='humble') uwOpenChest('humble');
  else if(k==='temple') say(['The house of the LORD, standing in the deep. Hewn stone, every block made ready before it was brought (1 Kings 6:7).','The way in is the doorway between the pillars.']);
  else say(['Two cherubim of olive wood overlaid with gold, ten cubits high. The wing of the one touches the one wall, the wing of the other the other wall, and their wings touch one another in the midst of the house (1 Kings 6:23-27).']);
}
function uwPillar(fx){
  if(fx<26) say(['Jachin — “he shall establish.” The right pillar of the porch, brass, with lily-work and rows of pomegranates (1 Kings 7:21).']);
  else say(['Boaz — “in it is strength.” The left pillar of the porch, brass, with lily-work and rows of pomegranates (1 Kings 7:21).']);
}
function uwOpenChest(k){
  if(uwSaved.chests[k]){ showBanner('The chest hangs open. Nothing more here.', 1100); return; }
  if(k==='humble' && !uwSaved.opened) return;
  const L=UW_CHEST_LOOT[k]; if(!L) return;
  uwSaved.chests[k]=true;
  if(L.decor){ const it=DECOR_ITEMS[L.decor];
    homesteadDecor.inv[L.decor]=(homesteadDecor.inv[L.decor]||0)+1;
    if(k==='humble') say(['A small chest of plain wood, tied with cord. Nothing on it is gold.','Inside, wrapped in linen: a cross of rough timber.','“But God forbid that I should glory, save in the cross of our Lord Jesus Christ” — Galatians 6:14',
      '✝️ The <b>Wooden Cross</b> is yours, to raise at your Homestead (☰ Home).']);
    else showBanner('📦 <b style="color:#ffd27a">'+it.emoji+' '+it.name+'!</b><br><span style="font-size:7px">A Homestead decoration — place it from your ☰ Home tab.</span>', 3000);
  } else if(L.pearls){ uwSaved.pearls+=L.pearls;
    showBanner('🦪 <b style="color:#f4f0e8">'+L.pearls+' pearl'+(L.pearls>1?'s':'')+'!</b><br><span style="font-size:7px">You carry '+uwSaved.pearls+'. Zebulun the pearl-diver pays well for them.</span>', 2400); }
  saveGame();
}
function uwReadTablet(k){
  if(k==='rec1'||k==='rec2'||k==='rec3'){
    if(!uwSaved.tablets[k]){ uwSaved.tablets[k]=true; uwBuildGrid(); saveGame();
      const n=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
      showBanner('📜 <b style="color:#c8f0a0">A record tablet ('+n+' of 3).</b><br><span style="font-size:7px">Its letters are worn but whole. Tirzah, keeper of the records, will want it.</span>', 2600); }
    return; }
  if(k==='porch'){ say(['Letters cut deep into the porch stone:','“PRAY AS THE PROPHET PRAYED, FROM THE DEEP TO THE DELIVERANCE, AND THE HOUSE WILL BE FILLED WITH LIGHT.”']); return; }
  if(k==='ps104'){ codexAdd('The drowned courts','Psalm 104:24-26','O LORD, how manifold are thy works! in wisdom hast thou made them all: the earth is full of thy riches. So is this great and wide sea, wherein are things creeping innumerable, both small and great beasts. There go the ships: there is that leviathan, whom thou hast made to play therein.');
    say(['“O LORD, how manifold are thy works! in wisdom hast thou made them all: the earth is full of thy riches.”','“So is this great and wide sea, wherein are things creeping innumerable, both small and great beasts.” — Psalm 104:24-25']); return; }
  if(k==='micah'){ codexAdd('The Most Holy Place, drowned','Micah 7:19','He will turn again, he will have compassion upon us; he will subdue our iniquities; and thou wilt cast all their sins into the depths of the sea.');
    say(['“He will turn again, he will have compassion upon us; he will subdue our iniquities; and thou wilt cast all their sins into the depths of the sea.” — Micah 7:19','Here, in the depths of the sea, the words read differently.']); return; }
}
function uwLamp(tx,ty){
  if(uwSaved.opened){ showBanner('The lampstand burns steady. The house is full of light.', 1300); return; }
  const id=Object.keys(UW_PRAYER).find(k=>UW_PRAYER[k][0]===tx&&UW_PRAYER[k][1]===ty);
  if(!id){ showBanner('This lampstand bears no words. It will not take the flame.', 1500); return; }
  if(uwSaved.lamps.includes(id)){ const T=UW_PRAYER_TEXT[id]; showBanner('🕯 <i>'+T[1]+'</i> — '+T[0], 2600); return; }
  const want=UW_PRAYER_ORDER[uwSaved.lamps.length], T=UW_PRAYER_TEXT[id];
  if(id!==want){
    uwSaved.lamps=[]; saveGame();
    showBanner('💨 <b>The flames gutter out.</b><br><span style="font-size:7px">“'+T[1]+'” — not yet. Pray as the prophet prayed.</span>', 3000);
    return; }
  uwSaved.lamps.push(id);
  if(uwSaved.lamps.length<UW_PRAYER_ORDER.length){ saveGame();
    showBanner('🕯 <b style="color:#fff2a8">The lamp takes the flame.</b><br><span style="font-size:7px">“'+T[1]+'” — '+T[0]+'</span>', 3200); return; }
  // the prayer is whole: all ten blaze, the inner doors open, the livery is given
  uwSaved.opened=true; uwSaved.livery=true; uwBuildGrid(); saveGame();
  say(['“Salvation is of the LORD.”',
       'One by one, all ten lampstands take the flame, and the house is filled with light.',
       'The olive-wood doors of the inner house swing open.',
       '🧥 A livery is laid by the doors: <b>Deepwater Pearl</b>. Wear it from the wardrobe in your house.']);
}

// ── ZEBULUN: Psalm 104, and he buys pearls ──
function uwTalkZebulun(){
  const N='Zebulun the Pearl-Diver';
  if(!uwSaved.met.zebulun){ uwSaved.met.zebulun=true; saveGame();
    sayAs(N,['Ho! A knight, riding a dragon of the deep! Come in out of the water — well, out of MOST of it.',
      'I am Zebulun. My fathers’ blessing was that we would “dwell at the haven of the sea” (Genesis 49:13). I took it further than they meant.',
      'These are the courts of a house built long ago for the LORD’s name. The sea took the city; it never took the house.',
      'I dive for pearls in the old chests. Bring me any you find — '+UW_PEARL_PRICE+' gold apiece, and a blessing thrown in free.']); return; }
  if(uwSaved.pearls>0){ const n=uwSaved.pearls, g=n*UW_PEARL_PRICE;
    uwSaved.pearls=0; uwSaved.sold+=n; gold+=g; saveGame();
    sayAs(N,['He weighs each pearl in his palm and holds it up to the lamplight.',
      '“The kingdom of heaven is like unto a merchant man, seeking goodly pearls” (Matthew 13:45). Well, here I am!',
      '💰 +'+g+' gold for '+n+' pearl'+(n>1?'s':'')+'.']); return; }
  sayAs(N,[['“O LORD, how manifold are thy works!” I say it every morning, and every morning I mean it more.','Mind the Sea by the porch — the great bronze basin. Twelve oxen, and not one has blinked in a thousand years.','The pillars at the porch have names. Read them. Names are how the LORD’s people remembered.'][uwSaved.sold%3]]);
}
// ── TIRZAH: the records, then her questions ──
function uwTalkTirzah(){
  const N='Tirzah, Keeper of the Records';
  const have=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
  if(uwSaved.quiz){ sayAs(N,['The records are whole, and you have understood them. That is rarer than finding them.','“Salvation is of the LORD.” Remember where Jonah was when he learned it.']); return; }
  if(!uwSaved.met.tirzah){ uwSaved.met.tirzah=true; saveGame();
    sayAs(N,['You came down on purpose. Few do.','I keep the records of this house. Three tablets were scattered when the waters came: one in the courts, one in the fallen chambers, and one in the inner house, which no one has entered since.','Bring them to me, and then tell me what they say. A record no one understands is only a stone.']); return; }
  if(have<3){ sayAs(N,['You have found '+have+' of the three.'+(uwSaved.opened?'':' The last lies beyond the inner doors — and those open only to prayer.')]); return; }
  sayAs(N,['All three. Let me read them to you — they are the prayer of Jonah, from the belly of the fish.','Now: what did you hear?'], ()=>uwQuizOpen());
}
// ── the questions: a block-owned overlay in #gamemenu; Ⓐ comes in through doAction ──
function uwQuizOpen(){ uw.quiz={ i:0, pick:-1, answered:false }; uwQuizRender(); }
function uwQuizClose(silent){
  if(!uw.quiz) return; uw.quiz=null;
  const el=document.getElementById('gamemenu'); if(el){ el.classList.remove('open'); if(!silent) el.innerHTML=''; }
}
function uwQuizRender(){
  const el=document.getElementById('gamemenu'); if(!el||!uw.quiz) return;
  const Q=UW_QUIZ[uw.quiz.i];
  let h='<div class="gm-tabs"><div class="gm-tab sel">📜 Tirzah’s Questions — '+(uw.quiz.i+1)+' of '+UW_QUIZ.length+'</div></div><div class="gm-body">';
  h+='<div style="font-size:8px;color:#fff;line-height:1.8;margin:6px 4px 8px">'+Q.q+'</div>';
  if(!uw.quiz.answered){
    Q.o.forEach((o,i)=>{ h+='<div class="gm-node '+(uw.quiz.pick===i?'cur':'')+'" data-uwq="'+i+'" style="line-height:1.7"><span class="nm" style="pointer-events:none">'+String.fromCharCode(65+i)+'. '+o+'</span></div>'; });
    h+='<div class="gm-node" data-uwq="x"><span class="nm" style="pointer-events:none">↩ Leave for now</span></div>';
    h+='<div class="gm-hint">Tap an answer, or ▲▼ then Ⓐ</div>';
  } else {
    const ok=uw.quiz.pick===Q.a;
    h+='<div style="font-size:9px;color:'+(ok?'#6fdf8a':'#ff8a8a')+';margin:6px 4px;font-weight:bold">'+(ok?'✓ Yes.':'✗ Not so. Read it again.')+'</div>';
    h+='<div class="gm-node cur" data-uwq="go"><span class="nm" style="pointer-events:none">'+(ok?(uw.quiz.i<UW_QUIZ.length-1?'Next ▶':'✓ Finish'):'↻ Try again')+'</span></div>';
  }
  h+='</div>';
  el.innerHTML=h; el.classList.add('open');
  if(!el._uwq && el.addEventListener){ el._uwq=true;
    el.addEventListener('click', e=>{ if(!uw.quiz) return; const n=e.target && e.target.closest ? e.target.closest('[data-uwq]') : null; if(!n) return;
      const v=n.getAttribute('data-uwq'); if(v==='x'){ uwQuizClose(); return; }
      if(v==='go'){ uwQuizSelect(); return; } uw.quiz.pick=+v; uwQuizSelect(); }); }
}
function uwQuizInput(){
  const edge=k=>{ const d=!!held[k], was=!!uw.lastKey[k]; uw.lastKey[k]=d; return d&&!was; };
  if(uw.quiz.answered) return;
  const n=UW_QUIZ[uw.quiz.i].o.length+1;
  if(edge('up')){ uw.quiz.pick=(uw.quiz.pick<=0?n-1:uw.quiz.pick-1); uwQuizRender(); }
  if(edge('down')){ uw.quiz.pick=(uw.quiz.pick+1)%n; uwQuizRender(); }
}
function uwQuizSelect(){
  const q=uw.quiz; if(!q) return;
  const Q=UW_QUIZ[q.i];
  if(!q.answered){ if(q.pick<0) return; if(q.pick===Q.o.length){ uwQuizClose(); return; } q.answered=true; uwQuizRender(); return; }
  if(q.pick!==Q.a){ q.answered=false; q.pick=-1; uwQuizRender(); return; }
  if(q.i<UW_QUIZ.length-1){ q.i++; q.answered=false; q.pick=-1; uwQuizRender(); return; }
  uwQuizClose();
  uwSaved.quiz=true; uwSaved.barding=true;
  if(!player.mountSkinOwned) player.mountSkinOwned={};
  player.mountSkinOwned.uwcoral=true;
  codexAdd('The keeper’s records','Jonah 2:9','But I will sacrifice unto thee with the voice of thanksgiving; I will pay that that I have vowed. Salvation is of the LORD.');
  saveGame();
  sayAs('Tirzah, Keeper of the Records',['You heard it. From the deep to the deliverance.','Take this. It was made for a steed of the sea long ago, and it has waited long enough.',
    '🪸 <b>Coral Barding</b> for your Sea Dragon! Put it on from the ☰ Pet tab.']);
}

// ── ELDAN'S TRIALS give the missing starter lines (two hooks + on load) ──
function uwMissingLines(){
  const own=new Set([player.pet&&player.pet.id, ...((player.barnPets||[]).map(p=>p&&p.id))]);
  return STARTER_PETS.filter(id=>!own.has(id));
}
function uwEldanGift(which, quiet){
  if(!UW_ON) return null;
  const flag = which===1 ? 'fish' : 'kind';
  if(uwSaved.eldan[flag]) return null;
  uwSaved.eldan[flag]=true;
  const id=uwMissingLines()[0]; if(!id) return null;
  if(!player.barnPets) player.barnPets=[];
  player.barnPets.push({ id, form:2 });
  if(!quiet){ const f=PETS[id].forms[2];
    setTimeout(()=>showBanner('🌿 <b style="color:#8fd4a8">Eldan’s gift: '+f.emoji+' '+f.name+'!</b><br><span style="font-size:7px">A companion of the '+PETS[id].name+' line, fully grown, waits for you at the Homestead Stables.</span>', 4200), 2600); }
  return id;
}
function uwEldanCheck(onLoad){
  if(!UW_ON) return;
  const got=[];
  if(quests.goldenFish==='done' && !uwSaved.eldan.fish){ const id=uwEldanGift(1,true); if(id) got.push(id); }
  if(quests.kindness==='done' && !uwSaved.eldan.kind){ const id=uwEldanGift(2,true); if(id) got.push(id); }
  if(got.length && onLoad) setTimeout(()=>showBanner('🌿 <b style="color:#8fd4a8">Eldan remembers your trials.</b><br><span style="font-size:7px">'+got.map(id=>PETS[id].forms[2].emoji+' '+PETS[id].forms[2].name).join(' and ')+' now wait'+(got.length>1?'':'s')+' at the Homestead Stables.</span>', 4600), 1200);
}

// ── drawing (the draw() hook) ──
function uwDraw(){
  if(!uw.grid) uwBuildGrid();
  const vw=VIEW_TW*TILE, vh=VIEW_TH*TILE;
  let camX=player.x-vw/2+TILE/2, camY=player.y-vh/2+TILE/2;
  const mx=uw.W*TILE-vw, my=uw.H*TILE-vh;
  camX = mx<0 ? mx/2 : Math.max(0,Math.min(camX,mx)); camY = my<0 ? my/2 : Math.max(0,Math.min(camY,my));
  camX=Math.round(camX); camY=Math.round(camY);
  ctx.fillStyle='#0e2230'; ctx.fillRect(0,0,VW,VH);
  const x0=Math.max(0,Math.floor(camX/TILE)), y0=Math.max(0,Math.floor(camY/TILE));
  const x1=Math.min(uw.W-1,Math.ceil((camX+vw)/TILE)), y1=Math.min(uw.H-1,Math.ceil((camY+vh)/TILE));
  for(let ty=y0;ty<=y1;ty++) for(let tx=x0;tx<=x1;tx++) uwDrawTile(uw.grid[ty][tx], tx*TILE-camX, ty*TILE-camY, tx, ty);
  // objects, people and the knight, sorted by their feet
  const objs=[];
  const R=uwR();
  for(const k in R.obj){ const [fn,x,y,w,h]=R.obj[k];
    if(x+w<x0-1||x>x1+1||y+h<y0-1||y>y1+1) continue;
    objs.push({ sy:y+h, f:()=> k==='humble' ? uwDrawHumbleChest(x*TILE-camX,y*TILE-camY,!!uwSaved.chests.humble) : UW_OBJFN[fn](x*TILE-camX,y*TILE-camY) }); }
  for(const k in R.npc){ const [x,y]=R.npc[k]; objs.push({ sy:y+1, f:()=> (k==='zebulun'?uwDrawZebulun:uwDrawTirzah)(x*TILE-camX,y*TILE-camY) }); }
  objs.push({ sy:(player.y+TILE)/TILE+0.01, f:()=>{ const sx=Math.round(player.x-camX), sy=Math.round(player.y-camY);
    drawSteedMounted(sx, sy, player.pet.id, player.dir||'down', player.moving ? ((Date.now()>>7)&1) : 1); /* the overworld's own frame rule */ uwDrawRiderBubbles(sx,sy); } });
  objs.sort((a,b)=>a.sy-b.sy).forEach(o=>o.f());
  // the water: tinted per zone (courts / the house within / the ruined chambers)
  const lights=[];
  if(uw.room==='temple') for(const [x,y] of UW_LAMPSTANDS) if(uwLampLit(x,y)) lights.push([x*TILE-camX+8, y*TILE-camY+1]);
  const zone=(x0p,y0p,x1p,y1p,z)=>{ const L=Math.max(0,x0p*TILE-camX), T=Math.max(0,y0p*TILE-camY), R=Math.min(vw,x1p*TILE-camX), B=Math.min(vh,y1p*TILE-camY);
    if(R<=L||B<=T) return; ctx.save(); ctx.beginPath(); ctx.rect(L,T,R-L,B-T); ctx.clip(); uwDrawWaterOverlay(vw,vh,camX,camY,z, z==='temple'?lights:[]); ctx.restore(); };
  if(uw.room==='courts') zone(0,0,uw.W,uw.H,'garden');
  else { zone(0,0,10,uw.H,'ruins'); zone(20,0,uw.W,uw.H,'ruins'); zone(10,0,20,2,'ruins'); zone(10,40,20,uw.H,'ruins'); zone(10,2,20,40,'temple'); }
  drawCross();
}
// the dive markers on the overworld: drawn over the deep-water tile, never stamped
// into WORLD, so the world fingerprint is untouched (drawTile hook)
function uwMarkerAt(tx,ty){ return UW_ON && place.kind==='overworld' && UW_SPOTS.some(s=>s.x===tx&&s.y===ty); }

// ── the music (musicFor hook): underwater.mp3, else the chapel recording ──
function uwMusic(){
  if(RTRACKS.underwater && !RTRACKS.underwater.dead) return 'rt:underwater';
  return (RTRACKS.chapel && !RTRACKS.chapel.dead) ? 'rt:chapel' : 'town';
}
// ── the coral barding (drawSteedSprite hook) ──
let _uwCoralBusy=false;
function uwCoralSteed(ox,oy,id,view,frame,rider,mirror){
  if(!UW_ON || _uwCoralBusy || id!=='steadfast' || player.mountSkin!=='uwcoral') return false;
  _uwCoralBusy=true;
  try{ uwWithCoralBarding(()=>drawSteedSprite(ox,oy,id,view,frame,rider,mirror)); } finally { _uwCoralBusy=false; }
  return true;
}
// ── the Pet tab (barding rows) and the Quests tab ──
function uwBardingRows(){
  if(!UW_ON || !(player.mountSkinOwned && player.mountSkinOwned.uwcoral)) return '';
  const on=player.mountSkin==='uwcoral', sea=player.pet && player.pet.id==='steadfast';
  let h='';
  if(!(player.mountSkinOwned.spectral)) h+='<div class="gm-sectitle" style="margin-top:6px">Pet Barding</div>';
  h+='<div class="gm-item '+(on?'equipped':'')+'" onclick="toggleMountSkin(\'uwcoral\')" style="cursor:pointer">🪸 <span style="flex:1">Coral Barding <span class="ds">'+(sea?'coral and pearl, from the deep':'for the Sea Dragon only')+'</span></span>'+(on?'<span style="color:#23517d">equipped</span>':'')+'</div>';
  if(!(player.mountSkinOwned.spectral)) h+='<div class="gm-item '+(!player.mountSkin?'equipped':'')+'" onclick="toggleMountSkin(null)" style="cursor:pointer"><span style="flex:1">Normal <span class="ds">your steed’s true coat</span></span>'+(!player.mountSkin?'<span style="color:#23517d">equipped</span>':'')+'</div>';
  return h;
}
function uwQuestRows(active, done){
  if(!UW_ON) return;
  if(!Object.keys(uwSaved.visited).length) return;       // a secret until you have been down
  const rec=['rec1','rec2','rec3'].filter(id=>uwSaved.tablets[id]).length;
  if(!uwSaved.opened) active.push(['The Drowned House','Four lampstands in the Holy Place bear Jonah’s prayer. Pray as the prophet prayed.','#2f5434']);
  else done.push(['The Drowned House','The house is filled with light. ✓','#2f5434']);
  if(!uwSaved.quiz) active.push(['The Keeper’s Records','Record tablets found: <b>'+rec+'</b> of 3'+(rec>=3?' — return to Tirzah. ✓':'.'),rec>=3?'#7a5c28':'#2f5434']);
  else done.push(['The Keeper’s Records','Tirzah’s questions answered. ✓','#2f5434']);
  const left=Object.keys(UW_CHEST_LOOT).filter(k=>!uwSaved.chests[k]).length;
  if(left) active.push(['Treasures of the Deep','Chests still unopened: <b>'+left+'</b>. Pearls carried: <b>'+uwSaved.pearls+'</b>.','#2f5434']);
  else done.push(['Treasures of the Deep','Every chest opened. ✓','#2f5434']);
}

// ── registrations: object mutation only, so no hook is needed for these ──
if(UW_ON){
  LIVERIES.deepwater = UW_LIVERY;
  for(const k in UW_DECOR_ITEMS) DECOR_ITEMS['uw_'+k]=UW_DECOR_ITEMS[k];
  RTRACKS.underwater = { src:'underwater.mp3', el:null, dead:false, want:false, vol:0.50 };
  PORTRAITS['zebulun the pearl-diver']=(q)=>uwPortraitZebulun(q);
  PORTRAITS['tirzah, keeper of the records']=(q)=>uwPortraitTirzah(q);
  PORTRAIT_ALIAS['zebulun']='zebulun the pearl-diver';
  PORTRAIT_ALIAS['tirzah']='tirzah, keeper of the records';
}

// ═══ end of THE DEEP ═══

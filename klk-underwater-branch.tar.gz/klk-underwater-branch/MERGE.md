# The Deep: underwater branch, merge kit

Built against main `index.html` md5 `816d16bd70b8bf8ae1d8d6c3bff35811` (pulled 2026-09-30).

## What's in this bundle

| Folder | What |
|---|---|
| `kit/` | The merge kit: `uw_block.js` (the whole block), 18 numbered `NN_name.anchor.txt` / `.repl.txt` pairs, and `HOOKS.md` (what each hook does) |
| `apply_kit.py` | Applies the pairs in order through `test/edit.py` (anchor must match exactly once), running `./gate.sh` after each |
| `test/` | Harness changes: new `suite/underwater.js`, updated `suite/oldsaves.js`, and `gate.sh` (adds the new suite) |
| `playtest/` | `underwater.html` (the TEST build) and `start_code.txt` (a save code for it) |
| `src/` | The branch source, needed to keep building: `uw_art.js`, `uw_logic.js`, `uw_map.py`, `uw_mapcheck.py`, `build_kit.py`, `make_testbuild.py`, `check_testbuild.sh` |

## Merging into the latest main

1. Pull the latest `index.html` and the harness from GitHub, unpack the harness and run `npm install`. Run `./gate.sh` on the untouched file first: it must pass.
2. Copy `test/suite/underwater.js` into the harness. For `suite/oldsaves.js` and `gate.sh`: if main hasn't changed them, copy these over. If it has, carry across by hand:
   - in `oldsaves.js`, the `UW_LOAD` / `UW_SAVE` blocks marked "underwater branch";
   - in `gate.sh`, `suite/underwater.js` in the suite list, just before `suite/oldsaves.js`.
3. Put `kit/` and `apply_kit.py` side by side, then run `python3 apply_kit.py path/to/harness/test`. It applies one edit, runs the full gate, then goes on to the next.
4. **If an anchor no longer matches, the script stops and names the hook.** Main has moved that code. Open that pair, find the same spot in the new code, update the `.anchor.txt` (and the `.repl.txt` to match), then resume with `--from N`. Never force it, and never paste the block without its hooks.
5. The last edit's gate runs the underwater suite in full. It must end `GATE: PASS` with `fingerprint` and `seedpanel` unchanged (the dive markers are drawn, never written into `WORLD`).
6. Upload `index.html`. When you have the track, upload `underwater.mp3` beside it. Until then it plays the chapel recording.

## Playtesting (before the merge)

Upload `playtest/underwater.html` to the repo **next to** `index.html`, not over it. Every storage key in it is renamed `klk_` → `klkuw_`, and the title screen says `UW-TEST`. It can never read or write your real saves or audio settings; a check proves this on every build.

To start at the deep: ☰ System → load a save code → paste `start_code.txt`. You're on the beach of the lake by Crystalpeak with the Sea Dragon at level 18.
1. Tap 🐎 to mount.
2. Swim 2 tiles south onto the dark eddy.
3. Press Ⓐ.

## Switching it off

`const UW_ON = true;` at the top of the block. Set it to `false` and there are no markers or dives, no new save key, no livery, decorations or track, and every hook falls through. The suite proves this in a separate boot.

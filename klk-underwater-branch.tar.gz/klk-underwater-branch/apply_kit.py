#!/usr/bin/env python3
"""apply_kit.py — apply the underwater merge kit to test/../index.html, one edit
at a time, running the full gate after EACH edit. Stops at the first failure
and says which hook. Never forces an anchor: edit.py refuses unless it matches
exactly once.

  python3 apply_kit.py <harness/test dir> [--from N] [--no-gate]
"""
import pathlib, subprocess, sys
KIT = pathlib.Path(__file__).resolve().parent / 'kit'
test = pathlib.Path(sys.argv[1]).resolve()
start = int(sys.argv[sys.argv.index('--from')+1]) if '--from' in sys.argv else 0
gate = '--no-gate' not in sys.argv
pairs = sorted(KIT.glob('*.anchor.txt'))
for a in pairs:
    n = int(a.name[:2])
    if n < start: continue
    r = a.with_name(a.name.replace('.anchor.txt', '.repl.txt'))
    print(f'── {a.name[:-11]} ──', flush=True)
    e = subprocess.run([sys.executable, str(test/'edit.py'), str(a), str(r)], capture_output=True, text=True)
    print('  ' + (e.stdout.strip() or e.stderr.strip()))
    if e.returncode: sys.exit(f'STOPPED at {a.name[:-11]}: anchor did not apply. Fix this hook against the new code; do not force it.')
    if gate:
        import os
        env = dict(os.environ, UW_KIT_PARTIAL='0' if a == pairs[-1] else '1')
        g = subprocess.run(['bash', str(test/'gate.sh')], capture_output=True, text=True, cwd=test, env=env)
        tail = [l for l in g.stdout.splitlines() if '──' in l and 'passed' in l or l.startswith('GATE') or 'FAIL' in l]
        print('\n'.join('  '+l.strip() for l in tail if 'FAIL' in l or l.startswith('GATE')))
        if g.returncode: sys.exit(f'STOPPED after {a.name[:-11]}: the gate failed.')
print('kit applied, gate green after every edit' if gate else 'kit applied (gate not run)')

// scopecheck.js — prove a mangled script is the original with only its LOCAL names changed.
// Both programs are parsed and scope-analysed (eslint-scope); every variable in every non-global scope is renamed to a
// canonical name by its position (scope n, variable m), then the two trees must match exactly. Globals and property
// names are never renamed, so any other difference — a dropped statement, a changed constant, a global renamed —
// fails the comparison.
const espree=require('espree'), escope=require('eslint-scope');
function canon(code){ const ast=espree.parse(code,{ecmaVersion:'latest',sourceType:'script',range:true,loc:false});
  // a shorthand property's key is not a reference: give it its own node so renaming the value leaves the key alone
  (function w(n){ if(!n||typeof n!=='object') return; if(Array.isArray(n)){ n.forEach(w); return; } if(n.type==='Property'&&n.shorthand){ n.key={...n.key}; n.shorthand=false; } for(const k in n) if(k!=='parent') w(n[k]); })(ast);
  const sm=escope.analyze(ast,{ecmaVersion:2022,sourceType:'script'});
  sm.scopes.forEach((sc,si)=>{ if(sc.type==='global') return; sc.variables.forEach((v,vi)=>{ if(v.name==='arguments'&&!v.defs.length) return; const nn='$'+si+'_'+vi;
    v.identifiers.forEach(id=>{ id.name=nn; }); v.references.forEach(r=>{ r.identifier.name=nn; }); }); });
  // labels: renamed by order of appearance, and each break/continue to the label it names (innermost first)
  { let k=0; const stack=[]; (function w(n){ if(!n||typeof n!=='object') return; if(Array.isArray(n)){ n.forEach(w); return; }
      if(n.type==='LabeledStatement'){ const c='L'+(k++); stack.push([n.label.name,c]); n.label={type:'Identifier',name:c}; w(n.body); stack.pop(); return; }
      if((n.type==='BreakStatement'||n.type==='ContinueStatement')&&n.label){ for(let i=stack.length-1;i>=0;i--) if(stack[i][0]===n.label.name){ n.label={type:'Identifier',name:stack[i][1]}; break; } return; }
      for(const key in n) if(key!=='parent') w(n[key]); })(ast); }
  const strip=(n)=>{ if(Array.isArray(n)) return n.map(strip); if(n&&typeof n==='object'){ const o={}; for(const k in n){ if(k==='start'||k==='end'||k==='range'||k==='loc'||k==='parent'||k==='raw') continue; o[k]=strip(n[k]); }
      if((o.type==='Property'||o.type==='MethodDefinition'||o.type==='PropertyDefinition')&&!o.computed&&o.key){ o.key={type:'Key',name:o.key.type==='Identifier'?o.key.name:String(o.key.value)}; } return o; } return n; };
  return JSON.stringify(strip(ast)); }
module.exports={ sameUpToLocalNames:(a,b)=>canon(a)===canon(b), _canon:canon };

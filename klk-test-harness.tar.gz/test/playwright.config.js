// Standard Playwright config. `npx playwright install chromium` downloads the
// browser; no CDP workaround needed outside a locked-down container.
module.exports = {
  testDir: './suite',
  testMatch: '**/*.spec.js',
  timeout: 30000,
  reporter: [['list']],
};

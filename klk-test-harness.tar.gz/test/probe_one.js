const K = require(__dirname + '/boot.js');
const { flood } = require(__dirname + '/suite/lib.js');
const sx = Math.floor(K.player.x / K.TILE), sy = Math.floor(K.player.y / K.TILE);
const counts = new Map();
for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++) {
  const t = K.WORLD[y][x]; counts.set(t, (counts.get(t) || 0) + 1);
}
console.log([process.env.KLK_SEED, flood(K, sx, sy).n, counts.size, counts.get(31) || 0].join(' '));

const fs=require('fs'), path=require('path'), { minify }=require(require.resolve('terser',{paths:[__dirname]})), acorn=require(require.resolve('acorn',{paths:[__dirname]}));
const [src,out]=process.argv.slice(2); const html=fs.readFileSync(src,'utf8');
const re=/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g; const blocks=[]; let m; while((m=re.exec(html))) blocks.push(m);
if(!blocks.length) throw new Error('no inline script');
const strip=(n)=>{ if(Array.isArray(n)) return n.map(strip); if(n&&typeof n==='object'){ if((n.type==='Property'||n.type==='MethodDefinition'||n.type==='PropertyDefinition')&&!n.computed&&n.key){ const k=n.key; n=Object.assign({},n,{key:{type:'Key',name:String(k.type==='Identifier'?k.name:k.value)}}); } const o={}; for(const k in n){ if(k==='start'||k==='end'||k==='loc'||k==='range'||k==='raw'||k==='shorthand') continue; o[k]=strip(n[k]); } return o; } return n; };
(async()=>{
  let res=html, off=0;
  for(const b of blocks){ const code=b[1]; if(!code.trim()) continue;
    // 2026-10-07: local names are mangled too (top-level names, globals and property names never are). The proof is
    // scopecheck.js: rename every local, in both programs, to a name fixed by its scope and position — the trees must
    // then be identical. _legacy (pack_legacy.js): no mangle, a plain AST comparison.
    const r=await minify(code,{compress:false, mangle:{toplevel:false, keep_fnames:false}, format:{comments:false, beautify:false, semicolons:true, max_line_len:false}});
    if(!require('./scopecheck.js').sameUpToLocalNames(code, r.code)) throw new Error('AST DIFFERS beyond local names — refusing to ship');
    console.log(`  script block: ${code.length} → ${r.code.length} chars, same program up to local names`);
    const s=b.index+off+b[0].indexOf(code); res=res.slice(0,s)+r.code+res.slice(s+code.length); off+=r.code.length-code.length; }
  const bytes=Buffer.byteLength(res,'utf8'); if(bytes>1.9e6) throw new Error(`phone copy is ${bytes} bytes — over 1.9 MB, refusing`);
  fs.writeFileSync(out,res); console.log(`  ${path.basename(out)}: ${bytes} bytes`);
})().catch(e=>{ console.error('PACKAGE FAILED: '+e.message); process.exit(1); });

const fs=require('fs'), path=require('path'), { minify }=require(require.resolve('terser',{paths:[__dirname]})), acorn=require(require.resolve('acorn',{paths:[__dirname]}));
const [src,out]=process.argv.slice(2); const html=fs.readFileSync(src,'utf8');
const re=/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g; const blocks=[]; let m; while((m=re.exec(html))) blocks.push(m);
if(!blocks.length) throw new Error('no inline script');
const strip=(n)=>{ if(Array.isArray(n)) return n.map(strip); if(n&&typeof n==='object'){ if((n.type==='Property'||n.type==='MethodDefinition'||n.type==='PropertyDefinition')&&!n.computed&&n.key){ const k=n.key; n=Object.assign({},n,{key:{type:'Key',name:String(k.type==='Identifier'?k.name:k.value)}}); } const o={}; for(const k in n){ if(k==='start'||k==='end'||k==='loc'||k==='range'||k==='raw'||k==='shorthand') continue; o[k]=strip(n[k]); } return o; } return n; };
(async()=>{
  let res=html, off=0;
  for(const b of blocks){ const code=b[1]; if(!code.trim()) continue;
    const r=await minify(code,{compress:false, mangle:false, format:{comments:false, beautify:false, semicolons:true, max_line_len:false}});
    const A=JSON.stringify(strip(acorn.parse(code,{ecmaVersion:'latest',sourceType:'script'}))), B=JSON.stringify(strip(acorn.parse(r.code,{ecmaVersion:'latest',sourceType:'script'})));
    if(A!==B) throw new Error('AST DIFFERS — refusing to ship');
    console.log(`  script block: ${code.length} → ${r.code.length} chars, AST diff 0`);
    const s=b.index+off+b[0].indexOf(code); res=res.slice(0,s)+r.code+res.slice(s+code.length); off+=r.code.length-code.length; }
  const bytes=Buffer.byteLength(res,'utf8'); if(bytes>1.9e6) throw new Error(`phone copy is ${bytes} bytes — over 1.9 MB, refusing`);
  fs.writeFileSync(out,res); console.log(`  ${path.basename(out)}: ${bytes} bytes`);
})().catch(e=>{ console.error('PACKAGE FAILED: '+e.message); process.exit(1); });

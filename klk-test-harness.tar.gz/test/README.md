# Testing — Kingdom's Last Knight

The game is one self-contained file, `index.html` (~1.5 MB). Nothing here
changes what a player downloads: everything in `test/` is tooling.

## Running it

```bash
cd test
npm install          # node-canvas + playwright
./gate.sh            # the Node suites — no browser needed
npx playwright install chromium
npx playwright test  # the browser suite
```

`gate.sh` should be run **after every edit to index.html**, one change at a
time. On push, `.github/workflows/gate.yml` runs both.

## What's here

| File | Does |
|---|---|
| `extract_js.py` | Pulls the single `<script>` block out of `index.html` into `game.js`, and writes `game.stripped.js` |
| `edit.py` | Atomic anchor-replace against `index.html` — refuses unless the anchor matches exactly once, syntax-checks, rolls back on failure |
| `harness_env.js` | A headless browser: seeded PRNG, node-canvas, DOM/audio stubs |
| `boot.js` | Evaluates the game and exposes `globalThis.__K` |
| `gate.sh` | Runs every Node suite |
| `suite/*.js` | The suites |
| `suite/puzzle.spec.js` | The browser suite (Playwright) |

`game.js`, `game.stripped.js` and `game.js.offset` are generated. Add them to
`.gitignore`.

## Making an edit

```bash
cd test
printf '%s' 'the exact text to replace' > /tmp/a.txt
printf '%s' 'what it becomes'           > /tmp/b.txt
python3 edit.py /tmp/a.txt /tmp/b.txt
./gate.sh
```

`edit.py` aborts if the anchor matches zero or several times, and rolls back
`index.html` if the result doesn't parse. Every run leaves `index.html.bak`.

## Traps this codebase sets

Each of these has cost a real debugging session. They are why the suites are
shaped the way they are.

- **Dungeon walkability is a blacklist.** Every new tile code walks by default.
  Forget to add a solid tile and it becomes a doorway.
- **Tile codes are written into saves.** Never reuse a retired code — a stale
  grid holding that number silently becomes a different object.
  `suite/tiles.js` enforces this; 43 is retired.
- **`_legacy` comments fool source scans.** Scan `game.stripped.js`, which
  blanks comments *and string bodies*, to ask "is this code live?" Scan the raw
  `game.js` to ask "what does this text say?" Using the wrong one fails for the
  wrong reason.
- **`const` bindings can't be written through the bridge.** `__K` exposes live
  getters whose setters throw. To mutate, use `__K.$('name = ...')`.
- **Suites must be files, never `node -e`.** An `-e` script's top-level `const`
  shares the global lexical scope with the game, so `const TILE` collides and
  throws from `game.js:1` — which reads like a game bug and isn't.
- **`facingTile()` adds `TILE/2` itself.** `player.x` is the sprite's *left
  edge*. Add the half-tile again and the knight stands one tile over, facing
  empty floor.
- **`aPress()` short-circuits while `!boot.done`.** A harness at the title
  screen sends every Ⓐ into the boot menu and nothing reaches `doAction`.
- **`#stage.booting` hides the HUD and controls.** Setting `boot.done = true`
  in JS does *not* remove that class, so `boundingBox()` returns `null` and the
  buttons look missing.
- **`#dpad` is `display:none`.** Touch movement is the *joystick*. A dpad test
  drives a control the player never sees.
- **`reachable` is seed-dependent.** It ranges 4205–4221 across seeds; the
  baseline 4210 is pinned at seed 11. `distinct` (36) and `plots` (58) are
  stable. `suite/seedpanel.sh` pins the whole distribution, which is the
  stronger check.
- **World edits must be stamped last**, and `place.kind` has eleven kinds —
  branching on it has bitten nine systems.

## What the suites do and don't cover

The Node suites test generated state, source structure, and real input through
the game's own keydown listeners. They cannot see layout, touch, or pixels —
Node has no browser. That's what `puzzle.spec.js` is for.

Neither tells you whether the game is *good*. Every bug found by playing this
session — a doorway that led nowhere, chapels opening pre-solved, the HUD
covering the top path — passed every assertion that existed at the time. The
loop that works is: play, hit something, turn it into an assertion.

## Known failures in the browser suite

Two tests fail and have not been fixed:

- **`tapping Ⓐ at a lampstand lights it`** — facing is correct (`T_CANDLE`),
  dialogue closed, `boot.done` true, and the tap reaches the button (the same
  helper works in the tablet test), but the candle doesn't light. Cause unknown.
- **`the joystick moves the knight`** — the synthetic drag doesn't set the
  `held.*` flags. The anchor arithmetic (`AX=72`, `AYOFF=110` from the stage
  foot) is probably wrong.

Both are test bugs as far as anyone can tell — the behaviour works when played.
They are left failing rather than deleted, because a deleted test is a silent
gap and a red one is a visible question.

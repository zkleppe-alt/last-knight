// shot.js — render game frames to a PNG sheet (tooling, not a suite).
//   node shot.js out.png 'js setup for frame 1' 'js setup for frame 2' ...
// Each setup runs in game scope; then drawTourney() (or the expression after "||DRAW:") paints the frame.
const K = require('./boot.js');
const { createCanvas } = require('canvas');
const fs = require('fs');
const out = process.argv[2], setups = process.argv.slice(3);
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; hunt.done=true; player.equip.weapon=player.equip.weapon||'ironsword';
  VIEW_TW=15; VIEW_TH=24; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; cv.width=VW*RENDER_SCALE; cv.height=VH*RENDER_SCALE;`);
const frames = [];
for (const s of setups) {
  const [setup, draw] = s.split('||DRAW:');
  K.$(`(()=>{ ${setup}; })()`);
  K.$(`(()=>{ ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0); ctx.clearRect(0,0,VW,VH); ${draw || 'drawTourney()'}; })()`);
  const cv = K.$(`cv`); const c = createCanvas(cv.width, cv.height); c.getContext('2d').drawImage(cv, 0, 0); frames.push(c);
}
const W = frames[0].width, H = frames[0].height, sheet = createCanvas(frames.length * (W + 10) + 10, H + 10), g = sheet.getContext('2d');
g.fillStyle = '#111'; g.fillRect(0, 0, sheet.width, sheet.height);
frames.forEach((f, i) => g.drawImage(f, 10 + i * (W + 10), 5));
fs.writeFileSync(out, sheet.toBuffer('image/png')); console.log('ok', frames.length, W, H);

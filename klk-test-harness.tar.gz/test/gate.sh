#!/usr/bin/env bash
# gate.sh — run after EVERY edit to index.html. One change at a time.
#
#   cd test && npm install && ./gate.sh
#
# Extracts the game's single <script> block, syntax-checks it, then runs every
# Node suite. These need no browser. For the browser checks (layout, touch,
# rendered pixels) see puzzle.spec.js and `npx playwright test`.
set -u
cd "$(dirname "$0")"

fail=0
echo "── extract ──────────────────────────────────────────"
python3 extract_js.py || exit 1
node --check game.js || { echo "  PARSE FAILED"; exit 1; }
echo "  ok   game.js parses"

echo "── suites ───────────────────────────────────────────"
for s in suite/fingerprint.js suite/candles.js suite/playthrough.js \
         suite/intro.js suite/chapels.js suite/layout.js suite/tiles.js suite/saltmere.js suite/hearthvale.js suite/ironhold.js suite/thornwood.js suite/dusthaven.js suite/crystalpeak.js suite/ashfield.js suite/stormgate.js suite/shadowmere.js suite/hellgate.js suite/throne.js suite/robby.js suite/generals.js; do
  [ -f "$s" ] || continue
  node "$s" || fail=1
done
[ -f suite/seedpanel.sh ] && { bash suite/seedpanel.sh || fail=1; }

echo "─────────────────────────────────────────────────────"
if [ "$fail" = 0 ]; then echo "GATE: PASS"; else echo "GATE: FAIL"; fi
exit $fail

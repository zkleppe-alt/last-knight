#!/usr/bin/env bash
# parallel gate: same suites as gate.sh, 2 at a time
cd "$(dirname "$0")"
python3 extract_js.py >/dev/null || exit 1
node --check game.js || { echo PARSE FAILED; exit 1; }
suites=$(grep -o 'suite/[a-z0-9]*\.js' gate.sh)
mkdir -p /tmp/claude-0/pg; rm -f /tmp/claude-0/pg/*
for s in $suites $EXTRA; do echo $s; done | xargs -P2 -I{} sh -c 'n=$(basename {} .js); node {} > /tmp/claude-0/pg/$n.log 2>&1; echo $? > /tmp/claude-0/pg/$n.rc'
bash suite/seedpanel.sh > /tmp/claude-0/pg/seedpanel.log 2>&1; echo $? > /tmp/claude-0/pg/seedpanel.rc
cat /tmp/claude-0/pg/*.log | awk '/passed,/{split($0,a," ");p+=a[3]; f+=a[5]} END{print "TOTAL",p,"passed",f,"failed"}'
bad=$(grep -L '^0$' /tmp/claude-0/pg/*.rc); [ -z "$bad" ] && echo "GATE: PASS" || { echo "GATE: FAIL $bad"; exit 1; }

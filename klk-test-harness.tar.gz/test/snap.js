// node snap.js out.png 'js to run' [w h]
const { chromium } = require('playwright');
(async()=>{
  const [out, js, w, h] = process.argv.slice(2);
  const b = await chromium.launch({executablePath:'/opt/pw-browsers/chromium'}).catch(()=>chromium.launch());
  const p = await b.newPage({viewport:{width:+(w||390), height:+(h||760)}, deviceScaleFactor:2});
  const errs=[]; p.on('pageerror', e=>errs.push(String(e)));
  await p.goto('file://' + require('path').resolve(__dirname, '../index.html'));
  await p.waitForTimeout(1500);
  const r = await p.evaluate(js||'0');
  await p.waitForTimeout(500);
  await p.screenshot({path: out});
  console.log('ok', JSON.stringify(r)||'', errs.slice(0,3).join(' | '));
  await b.close();
})();

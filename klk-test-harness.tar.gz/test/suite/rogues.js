// suite/rogues.js — the Roadside Rogues: Dylan, Ethan, Ranger Cody, the floating cell.
//
// Played through the game's own functions: updateRogues() frame by frame,
// doAction() to talk, resolveSwing() to hit, closeDialogue() to read on. What
// has to hold: nothing before the first chapel; Dylan takes the bread and up to
// 50 gold; Ethan can never put you below 1 HP and runs after three hits; Cody
// rides up after every encounter and his portrait shows; seven of each jails
// them, lays the pier, and unlocks the Ranger's Watch; after that Cody patrols
// with scripture and nobody else turns up; and all of it survives a save.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('rogues');
const T = K.TILE;
const frames = (n, each) => { for (let i = 0; i < n; i++) { K.$(`updateRogues();`); if (each) each(i); } };
const talkOpen = () => K.$(`dialogue.open`);
const speaker = () => K.$(`dialogue.open && dialogue.lines[dialogue.idx] ? dialogue.lines[dialogue.idx].speaker : null`);
const allText = () => K.$(`dialogue.lines.map(l=>l.text).join(' | ')`);
const close = () => { let n = 0; while (K.$(`dialogue.open`) && n++ < 20) K.$(`closeDialogue();`); };
const faceTo = (ex, ey) => { // stand the knight on the tile west of (ex,ey), facing east — or north, if west is blocked
  for (const [dx, dy, dir] of [[-1, 0, 'right'], [1, 0, 'left'], [0, -1, 'down'], [0, 1, 'up']]) {
    if (K.$(`walkable(${ex + dx},${ey + dy})`)) { K.$(`player.x=${(ex + dx) * T}; player.y=${(ey + dy) * T}; player.dir='${dir}';`); return true; } }
  return false; };
const tileOf = (who) => K.$(`rg.${who} ? rgTile(rg.${who}) : null`);

K.$(`place={kind:'overworld'}; boot.done=true; dialogue.open=false; menu.open=false;
     player.x=32*TILE; player.y=24*TILE; player.hp=player.maxHp; for(let i=0;i<chapelProgress.length;i++) chapelProgress[i]=false;
     roadRogues.d=0; roadRogues.e=0; roadRogues.jailed=false; demons.length=0;`);

// ── not before the first chapel ───────────────────────────────────────────
frames(12000);
ok('nobody turns up before the first chapel is cleansed', !K.$(`rg.dylan||rg.ethan||rg.cody`));
K.$(`chapelProgress[0]=true; rg.t=rg.next;`);
frames(3);
ok('after it, someone does', !!K.$(`rg.dylan||rg.ethan`), K.$(`rg.dylan?'Dylan':rg.ethan?'Ethan':'nobody'`));
K.$(`rg.dylan=null; rg.ethan=null; rg.t=0; rg.next=1e9;`);

// ── DYLAN ────────────────────────────────────────────────────────────────
ok('Dylan finds a roadside spot near the knight', K.$(`rgSpawnDylan()`));
{ const [dx, dy] = tileOf('dylan');
  ok('by a path, on open grass', K.WORLD[dy][dx] === 0 && [[1,0],[-1,0],[0,1],[0,-1]].some(([a, b]) => K.WORLD[dy + b][dx + a] === 2), `at ${dx},${dy}`);
  faceTo(dx, dy);
  ok('the knight bumps into him while he sits', K.$(`npcTileBlocked(${dx},${dy})`));
  K.$(`inventory.bread=0; gold=120; doAction();`);
  check('he speaks first, as Dylan', speaker(), 'Dylan');
  ok('and asks for a Loaf of Bread', /Loaf of Bread/.test(allText()));
  ok('with his portrait', !!K.$(`portraitFor('Dylan') && bakePortrait(portraitFor('Dylan'))`));
  close();
  K.$(`doAction();`);
  ok('with no bread, he waits', /Still no bread/.test(allText()));
  close();
  K.$(`inventory.bread=2; doAction();`); close();
  check('bread in hand: he takes one loaf', K.$(`inventory.bread`), 1);
  check('and 50 of your 120 gold', K.$(`gold`), 70);
  check('and runs', K.$(`rg.dylan.stage`), 'flee');
  frames(130);
  ok('he is gone', !K.$(`rg.dylan`));
  check('it counts', K.$(`roadRogues.d`), 1);
}
// ── RANGER CODY rides up ──────────────────────────────────────────────────
{ let arrived = -1;
  frames(900, (i) => { if (arrived < 0 && talkOpen()) arrived = i; });
  ok('Ranger Cody rides up after the robbery', arrived > 0, `after ${arrived} frames`);
  check('as Ranger Cody', speaker(), 'Ranger Cody');
  ok('asking about Dylan', /Dylan/.test(allText()));
  ok('with his portrait', !!K.$(`bakePortrait(portraitFor('Ranger Cody'))`));
  close();
  check('then rides away', K.$(`rg.cody.state`), 'leave');
  frames(260);
  ok('and is gone', !K.$(`rg.cody`)); }
// Dylan with less than 50 gold takes what there is
K.$(`rgSpawnDylan(); rg.dylan.stage='wait';`);
{ const [dx, dy] = tileOf('dylan'); faceTo(dx, dy);
  K.$(`inventory.bread=1; gold=20; doAction();`); close();
  check('a thin purse: he takes all 20', K.$(`gold`), 0);
  K.$(`rg.dylan=null; rg.pending=null;`); }

// ── ETHAN ────────────────────────────────────────────────────────────────
K.$(`player.x=32*TILE; player.y=24*TILE; player.dir='down'; rg.cody=null; rg.pending=null; roadRogues.e=0;`);
ok('Ethan finds a way in', K.$(`rgSpawnEthan()`));
{ let screamed = -1;
  frames(900, (i) => { if (screamed < 0 && talkOpen()) screamed = i; });
  ok('he runs up and screams', screamed > 0 && speaker() === 'Ethan', `after ${screamed} frames`);
  ok('unintelligibly', /unintelligibly|screams/.test(allText()), allText());
  close();
  check('then the fight is on', K.$(`rg.ethan.state`), 'fight');
  K.$(`player.hp=500; player.blocking=false;`);
  let hits = 0, last = 500;
  frames(900, () => { const hp = K.$(`player.hp`); if (hp < last) hits++; last = hp; K.$(`player.iframes=0;`); });
  ok('his stick stings, again and again', hits >= 8, `${hits} blows in 15 seconds, ${500 - last} HP`);
  K.$(`player.hp=12;`); let minHp = 99;
  frames(1200, () => { minHp = Math.min(minHp, K.$(`player.hp`)); K.$(`player.iframes=0;`); });
  check('but never puts the knight below 1 HP', minHp, 1);
  K.$(`player.hp=player.maxHp;`);
  // three blows back, through the real swing
  for (let i = 0; i < 3; i++) {
    const [ex, ey] = tileOf('ethan');
    K.$(`rg.ethan.knock=0; player.x=${(ex - 1) * T}; player.y=${ey * T}; player.dir='right'; player.swing=0; resolveSwing('light');`);
  }
  check('three hits and he runs', K.$(`rg.ethan && rg.ethan.state`), 'flee');
  frames(130);
  ok('he is gone', !K.$(`rg.ethan`));
  check('it counts', K.$(`roadRogues.e`), 1);
  let arrived = -1; frames(900, (i) => { if (arrived < 0 && talkOpen()) arrived = i; });
  ok('and Cody rides up asking after Ethan', arrived > 0 && /Ethan/.test(allText()));
  close(); frames(300); }
// running indoors mid-fight: no count
K.$(`rgSpawnEthan(); rg.ethan.state='fight'; place={kind:'interior', id:'inn', floor:0}; rgLeftOverworld(); place={kind:'overworld'};`);
ok('go indoors mid-fight and he is gone, uncounted', !K.$(`rg.ethan`) && K.$(`roadRogues.e`) === 1);

// ── the arrest ─────────────────────────────────────────────────────────────
K.$(`rg.cody=null; rg.pending=null; player.livery='azure';`);
ok('the Ranger livery is locked before the arrest', K.$(`liveryUnlocked('ranger')`) === false);
check('no pier yet — the sea south of Stormgate is open water', K.WORLD[245][150], 3);
K.$(`roadRogues.d=7; roadRogues.e=6; rgFinish('ethan'); player.x=172*TILE; player.y=226*TILE;`);
{ let arrived = -1; frames(1200, (i) => { if (arrived < 0 && talkOpen()) arrived = i; });
  ok('the seventh of each brings Cody with the news', arrived > 0 && /floating cell/.test(allText()) && /Ranger\u2019s Watch/.test(allText()));
  close(); }
ok('they are jailed', K.$(`roadRogues.jailed`));
ok('the Ranger\u2019s Watch unlocks', K.$(`liveryUnlocked('ranger')`));
ok('a pier runs out from the shore to the cell', [...Array(10)].every((_, i) => K.WORLD[239 + i][150] === 12));
ok('and the knight can walk it', [...Array(10)].every((_, i) => K.$(`walkable(150,${239 + i})`)));
ok('the barge itself is not walkable (they are IN it)', !K.$(`walkable(150,249)`));
// talk to them from the pier's end
K.$(`player.x=150*TILE; player.y=248*TILE; player.dir='down'; dialogue.open=false; doAction();`);
{ const sp = K.$(`dialogue.lines.map(l=>l.speaker)`);
  ok('from the pier you can talk to them in the cell', sp.includes('Dylan') && sp.includes('Ethan'), sp.join(', '));
  close(); }
K.$(`doAction();`); ok('a second visit says something else', K.$(`dialogue.lines.map(l=>l.text).join()`) !== ''); close();

// ── after: no more encounters; Cody patrols with scripture ──
K.$(`rg.t=rg.next;`); frames(20000);
ok('no more Dylan or Ethan once they are locked up', !K.$(`rg.dylan||rg.ethan`));
ok('Cody is out on patrol', !!K.$(`rg.patrol`));
{ const [cx, cy] = K.$(`rgTile(rg.patrol)`);
  ok('riding on walkable ground', K.WALK.has(K.WORLD[cy][cx]), `at ${cx},${cy}`);
  // (he stops for a breather now and then, by design — so start the clock out of a rest, and give him time)
  K.$(`rg.patrol.wait=0`); const t0 = K.$(`[rg.patrol.x,rg.patrol.y]`); frames(1500); const t1 = K.$(`[rg.patrol.x,rg.patrol.y]`);
  ok('and actually moving', Math.hypot(t1[0] - t0[0], t1[1] - t0[1]) > T * 2);
  const [px2, py2] = K.$(`rgTile(rg.patrol)`); faceTo(px2, py2); K.$(`dialogue.open=false; doAction();`);
  check('stop him and he talks', speaker(), 'Ranger Cody');
  ok('a Psalm or a Proverb', /\((Psalm|Proverbs) \d/.test(allText()), allText());
  close(); }
check('Cody knows sixteen sayings', K.$(`CODY_SAYINGS.length`), 16);
ok('each one names its Psalm or Proverb', K.$(`CODY_SAYINGS.every(s=>/\\((Psalm|Proverbs) \\d/.test(s))`));

// ── saves ────────────────────────────────────────────────────────────────
{ const snap = K.$(`JSON.parse(JSON.stringify(buildSaveData()))`);
  check('the save carries the tallies and the arrest', snap.roadRogues && [snap.roadRogues.d, snap.roadRogues.e, snap.roadRogues.jailed], [7, 7, true]);
  K.$(`applySaveData(JSON.parse(FRESH_STATE));`);
  check('a fresh game starts clean', K.$(`[roadRogues.d,roadRogues.e,roadRogues.jailed]`), [0, 0, false]);
  check('and lifts the pier again', K.WORLD[245][150], 3);
  ok('and the livery is locked again', K.$(`liveryUnlocked('ranger')`) === false);
  globalThis.__snap = snap;
  K.$(`applySaveData(globalThis.__snap);`);
  check('loading the jailed save restores it', K.$(`[roadRogues.d,roadRogues.e,roadRogues.jailed]`), [7, 7, true]);
  check('with the pier', K.WORLD[245][150], 12);
  const old = JSON.parse(JSON.stringify(snap)); delete old.roadRogues;
  globalThis.__old = old; K.$(`applySaveData(globalThis.__old);`);
  check('an older save with no rogues field loads as a fresh start', K.$(`[roadRogues.d,roadRogues.e,roadRogues.jailed]`), [0, 0, false]); }

// ── the look ─────────────────────────────────────────────────────────────
for (const n of ['Dylan', 'Ethan', 'Ranger Cody'])
  ok(`${n}\u2019s portrait bakes`, !!K.$(`bakePortrait(portraitFor('${n}'))`));
{ // the Ranger's Watch: hood green on the head, oak and red on the shield — and the champion is untouched
  const shot = (liv) => K.$(`(()=>{ player.livery='${liv}'; roadRogues.jailed=true; player.championRobe=true;
    ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,40,40); drawKnightBody(8,8,'down',0,0,0,false,player.weapon);
    const d=ctx.getImageData(0,0,40,40).data; const has=(h)=>{ const r=parseInt(h.slice(1,3),16),g=parseInt(h.slice(3,5),16),b=parseInt(h.slice(5,7),16); let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===r&&d[i+1]===g&&d[i+2]===b) n++; return n; };
    return { hood:has('#3f5a3a'), wood:has('#94623a'), red:has('#c0392e') }; })()`);
  const r = shot('ranger'), c = shot('champion');
  ok('Ranger\u2019s Watch: the hood is up', r.hood > 10, `${r.hood} hood pixels`);
  ok('Ranger\u2019s Watch: an oak shield with a red cross', r.wood > 3 && r.red > 5, `${r.wood} oak, ${r.red} red`);
  ok('the Champion\u2019s Plate is untouched (no hood, no oak)', c.hood === 0 && c.wood === 0, JSON.stringify(c));
}
// ── a button-masher can't skip Cody (found in play: tapping on from the fight
//    blew through both pages, leaving "…Least of all Ethan." as all he said) ──
K.$(`applySaveData(JSON.parse(FRESH_STATE)); place={kind:'overworld'}; chapelProgress[0]=true; demons.length=0; dialogue.open=false;
     player.x=32*TILE; player.y=24*TILE; rg.cody=null; rg.pending=null; rg.ethan=null; roadRogues.e=1; rgCallCody('ethan');`);
for (let i = 0; i < 1200 && !talkOpen(); i++) K.$(`updateRogues();`);
{ const pages = K.$(`dialogue.lines.length`);
  // mash: a tap every 100ms for 1.5 seconds, with the dialogue clock running
  for (let i = 0; i < 15; i++) K.$(`tickDialogue(100); advanceDialogue();`);
  ok('mashing Ⓐ for 1.5 s cannot blow through Cody’s speech', talkOpen() && K.$(`dialogue.idx`) < pages - 1,
     `on page ${K.$(`dialogue.idx`) + 1} of ${pages}`);
  check('his first word on Ethan introduces himself', /^Easy there, knight — Ranger Cody/.test(K.$(`dialogue.lines[0].text`)), true);
  ok('and signs off properly', /Ride safe\.$/.test(K.$(`dialogue.lines[dialogue.lines.length-1].text`)));
  close();
  K.$(`say(['a line you asked for']);`);
  check('a conversation YOU start keeps the normal quick lock', K.$(`dialogue.lockUntil`), K.$(`REVEAL_LOCK`));
  close(); }
done('rogues');

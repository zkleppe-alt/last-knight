// suite/gslots.js — 🛡 five gear slots and the Armor of God (2026-10-09-gs).
//
// Zak: "Deepen the weapon/gear functions - add separate gear categories (sword, shield, helm,
// breastplate, legs) with an easy simple format to add or remove gear onto the player."
// Then: the Armor of God is "one per late chapel, named individually after the general but
// together form the Armor of God"; old suits are sold as "Separate pieces".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('gslots');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[]; place={kind:'overworld'};`);
const fresh = () => K.$(`player.ownedGear={ rusty:true, none_w:true, none_a:true }; player.equip={ weapon:'rusty', shield:null, helm:null, body:'none_a', legs:null }; for(const k in chapelProgress) delete chapelProgress[k]; recalcStats();`);
fresh();

// ── the catalogue ──
check('the five slots', K.$(`GEAR_SLOTS.map(s=>s[0])`), ['weapon', 'shield', 'helm', 'body', 'legs']);
check('every piece sits in one of them (no "armor" slot left)', K.$(`Object.keys(EQUIP).filter(id=>!GEAR_SLOTS.some(s=>s[0]===EQUIP[id].slot))`), []);
const suits = K.$(`['leather','chainmail','platemail','armorofgod'].map(s=>{ const p=suitPieces(s); return [s, p.map(id=>EQUIP[id].slot).sort().join(','), p.reduce((a,id)=>a+(EQUIP[id].def||0),0), p.reduce((a,id)=>a+(EQUIP[id].maxHp||0),0)]; })`);
check('each suit is four pieces: breastplate, helm, legs, shield', suits.map(s => s[1]), Array(4).fill('body,helm,legs,shield'));
// the old single suits were 5 / 11 / 20 / 32 def and 0 / 10 / 20 / 40 hp — a whole new suit lands close
check('a whole suit adds up to about the old one (def, hp)', suits.map(s => [s[2], s[3]]), [[6, 0], [12, 10], [20, 20], [32, 40]]);
check('the old suit ids are now the breastplates (saves and shops keep working)', K.$(`['leather','chainmail','platemail','armorofgod'].map(id=>EQUIP[id].slot)`), ['body', 'body', 'body', 'body']);
check("the library's old 'Armor of God' is renamed — the name belongs to the five pieces now", K.$(`EQUIP.armorofgod.name`), "Paladin's Plate");

// ── the Armor of God ──
const aog = K.$(`AOG_SET.map(id=>[EQUIP[id].slot, EQUIP[id].name, !!EQUIP[id].aog])`);
check('five pieces, one per slot', aog.map(a => a[0]).sort(), ['body', 'helm', 'legs', 'shield', 'weapon']);
check('each named for its late-chapel general', aog.map(a => a[1].split("'")[0]), ['Lydia', 'Gideon', 'Ruth', 'Samuel', 'Michael']);
check('…and for its piece in Ephesians 6', aog.map(a => a[1].split("'s ")[1]), ['Gospel Greaves', 'Sword of the Spirit', 'Shield of Faith', 'Helmet of Salvation', 'Breastplate of Righteousness']);
check('the late chapels give them: Lydia, Gideon, Ruth, Samuel, Michael (towns 5–9)', K.$(`[5,6,7,8,9].map(t=>GENERAL_AOG[t]||GENERAL_REWARD[t]).map(id=>AOG_SET.indexOf(id))`), [0, 1, 2, 3, 4]);
K.$(`grantGeneralReward(5)`);
ok('Lydia gives her ring AND her greaves', K.$(`player.ownedGear.ring_lydia && player.ownedGear.lydia_greaves`));
ok('…and the banner names both and counts the set', K.$(`banner.innerHTML.indexOf("Lydia's Gospel Greaves")>=0 && banner.innerHTML.indexOf('1/5')>=0`), K.$(`banner.innerHTML.slice(0,400)`));
K.$(`grantGeneralReward(8)`);
ok('Samuel gives his bow AND his helmet', K.$(`player.ownedGear.bow_samuel && player.ownedGear.samuel_helm`));
K.$(`['sword_gideon','shield_ruth','armor_michael'].forEach(id=>player.ownedGear[id]=true);`);
const before = K.$(`(()=>{ ['sword_gideon','shield_ruth','samuel_helm','armor_michael'].forEach(equipItem); return [player.atk, player.def, player.maxHp, player.dmgReduce]; })()`);
const after = K.$(`(()=>{ equipItem('lydia_greaves'); return [player.atk, player.def, player.maxHp, player.dmgReduce]; })()`);
check('the fifth piece adds itself AND "Stand firm" (+6 def, +10 hp, 10% less damage)',
  [after[1] - before[1], after[2] - before[2], Math.round((after[3] - before[3]) * 100)], [7 + 6, 9 + 10, 10]);
ok('the Gear tab shows the set as worn', (K.$(`(()=>{ toggleMenu(); setMenuTab(TAB.gear); renderMenu(); const h=gmEl().innerHTML; toggleMenu(); return h; })()`) || '').indexOf('Armor of God · 5 / 5 · worn') >= 0);

// ── wearing and taking off, through the menu the way a player does ──
fresh(); K.$(`['leather','leather_cap','buckler','ironsword'].forEach(id=>player.ownedGear[id]=true); recalcStats();`);
const def0 = K.$(`player.def`);
K.$(`toggleMenu(); setMenuTab(TAB.gear); menu.focus='list';`);
const rowIds = K.$(`menuRows().map(r=>r.id)`);
check('the Gear tab lists slot by slot: weapons, shield, helm, breastplate', rowIds, ['none_w', 'rusty', 'ironsword', 'buckler', 'leather_cap', 'none_a', 'leather']);
const pick = (id) => { K.$(`menu.cursor=menuRows().findIndex(r=>r.id===${JSON.stringify(id)});`); K.key.tap('j', 0); };
pick('leather_cap');
check('Ⓐ wears the cap in the helm slot', K.$(`[player.equip.helm, player.def-${def0}]`), ['leather_cap', 1]);
pick('buckler'); pick('leather');
check('…the buckler and the jerkin in theirs', K.$(`[player.equip.shield, player.equip.body, player.def-${def0}]`), ['buckler', 'leather', 5]);
pick('leather_cap');
check('Ⓐ on the worn cap takes it off', K.$(`[player.equip.helm, player.def-${def0}]`), [null, 4]);
pick('ironsword'); const atkSword = K.$(`player.atk`);
pick('ironsword');
check('Ⓐ on the worn sword sets it down (bare fists)', K.$(`[player.equip.weapon, ${atkSword}-player.atk]`), ['none_w', 11]);
ok('the Gear tab names every slot and what it adds', K.$(`(()=>{ renderMenu(); const h=gmEl().innerHTML; return ['Weapon','Shield','Helm','Breastplate','Legs','From gear','Wooden Buckler','worn'].every(s=>h.indexOf(s)>=0); })()`));
ok('the Character tab lists all five', K.$(`(()=>{ setMenuTab(TAB.character); renderMenu(); const h=gmEl().innerHTML; return ['Shield','Helm','Breastplate','Legs','Wooden Buckler','Leather Jerkin'].every(s=>h.indexOf(s)>=0); })()`));
K.$(`toggleMenu();`);

// ── where pieces come from ──
check('the village shop sells the leather and chain pieces apart', K.$(`['leather','leather_cap','leather_legs','buckler','chainmail','chain_coif','chain_legs','kite'].map(k=>!!SHOP_ITEMS[k] && SHOP_ITEMS[k].gear===k && EQUIP[k].slot)`),
  ['body', 'helm', 'legs', 'shield', 'body', 'helm', 'legs', 'shield']);
// (filtered to armour: since 2026-10-09-rw the libraries also sell the ranged weapons)
check('the libraries sell the plate and paladin pieces apart', K.$(`[LIBRARY_WARES[3].filter(id=>!EQUIP[id].ranged), LIBRARY_WARES[7].filter(id=>!EQUIP[id].ranged)]`),
  [['greatsword', 'platemail', 'plate_helm', 'plate_legs', 'tower'], ['armorofgod', 'pal_helm', 'pal_legs', 'pal_shield']]);
ok('every piece a library sells has a price', K.$(`Object.values(LIBRARY_WARES).flat().every(id=>LIBRARY_PRICE[id]>0)`));
// _legacy (random chests): a chapel's gear chest gave its suit a piece at a time. Chests are set now (2026-10-09-ch,
// suite/chests.js); here: the set pieces the chapels hold are real pieces of the new suits.
check("the chapels' chests hold suit pieces for every slot", K.$(`[...new Set(Object.values(CHAPEL_CHESTS).flatMap(t=>Object.values(t).flat(2)).filter(i=>Array.isArray(i)&&i[0]==='gear').map(i=>EQUIP[i[1]].slot))].sort()`), ['body', 'helm', 'legs', 'shield', 'weapon']);
fresh(); K.$(`discoverSecret(SECRETS.find(s=>s.id==='isle2'))`);
check('the buried "suit of Plate Armor" is the whole suit', K.$(`suitPieces('platemail').map(id=>!!player.ownedGear[id])`), [true, true, true, true]);

// ── old saves ──
fresh();
const mig = K.$(`(()=>{ player.ownedGear={ rusty:true, none_w:true, none_a:true, chainmail:true, leather:true, helm_deborah:true };
  player.equip={ weapon:'rusty', armor:'chainmail' }; chapelProgress[5]=true; chapelProgress[8]=true; gearMigrate(); recalcStats();
  return { eq:player.equip, gotPieces:['chain_coif','chain_legs','kite','leather_cap','buckler'].map(id=>!!player.ownedGear[id]), aog:[!!player.ownedGear.lydia_greaves, !!player.ownedGear.samuel_helm] }; })()`);
check('an old save wearing Chainmail keeps it as its breastplate, no "armor" key', [mig.eq.body, 'armor' in mig.eq], ['chainmail', false]);
check('…gets the rest of every suit it owned', mig.gotPieces, [true, true, true, true, true]);
check('…and fills its empty slots with the best it owns', [mig.eq.shield, mig.eq.helm, mig.eq.legs, mig.eq.weapon], ['kite', 'samuel_helm', 'lydia_greaves', 'rusty']);
check('cleansed late chapels hand over their Armor of God pieces', mig.aog, [true, true]);
const again = K.$(`(()=>{ player.equip.helm=null; gearMigrate(); return player.equip.helm; })()`);
check('a new-format save is never refilled behind the player\'s back', again, null);
const rt = K.$(`(()=>{ const s=JSON.parse(JSON.stringify(buildSaveData())); player.equip={weapon:'none_w'}; applySaveData(s); return [player.equip, Object.keys(s.player.equip).sort()]; })()`);
check('the five slots round-trip through a save', rt[1], ['body', 'helm', 'legs', 'shield', 'weapon']);
check('…unchanged', [rt[0].body, rt[0].shield, rt[0].helm, rt[0].legs], ['chainmail', 'kite', null, 'lydia_greaves']);

ok('real frames run in a full set', K.$(`(()=>{ try{ for(let i=0;i<5;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e); } })()`) === true);
done('gslots');

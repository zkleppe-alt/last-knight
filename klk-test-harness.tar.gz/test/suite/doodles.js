// suite/doodles.js — the Easter egg: two purple "bad guys" from a child's drawing.
//
// They wander the whole overworld with no purpose, stare blankly when spoken
// to, and are NOT demons — nothing hunts them and cleansing never removes them.
// What can go wrong: they spawn somewhere the knight can never reach, they walk
// on water because the knight happens to be flying, speaking to one routes to
// the wrong thing, a chapel cleanse sweeps them away, or his pixels smear.
const K = require('../boot.js');
const { ok, check, done, flood } = require('./lib.js');
const fs = require('fs');

console.log('doodles');
const T = K.TILE;
const stripped = fs.readFileSync(__dirname + '/../game.stripped.js', 'utf8');

K.$(`place={kind:'overworld'}; dialogue.open=false; menu.open=false;`);
K.$(`updateDoodles();`);
const D = () => K.$(`doodles.map(d=>({kind:d.kind,x:d.x,y:d.y,stare:d.stare,flip:d.flip}))`);
const tileOf = d => [Math.floor((d.x + T / 2) / T), Math.floor((d.y + T / 2) / T)];

// ── spawning ──────────────────────────────────────────────────────────────
let ds = D();
check('six of them spawn', ds.length, 6);
check('three blobs and three pairs', [ds.filter(d => d.kind === 'blob').length, ds.filter(d => d.kind === 'pair').length], [3, 3]);
const reach = flood(K, 32, 24).seen;
ok('every one spawns where the knight can walk to',
   ds.every(d => { const [x, y] = tileOf(d); return reach.has(y * K.WORLD_W + x); }),
   JSON.stringify(ds.map(tileOf)));
ok('they spawn spread out, not in a clump',
   ds.every((a, i) => ds.every((b, j) => i === j || (Math.abs(tileOf(a)[0] - tileOf(b)[0]) + Math.abs(tileOf(a)[1] - tileOf(b)[1])) >= 16)));
K.$(`updateDoodles();`);
check('spawning happens once, not every frame', K.$(`doodles.length`), 6);

// ── wandering ─────────────────────────────────────────────────────────────
// Fly the knight so walkable() would open water to HIM; doodles must not care.
const start = D().map(tileOf);
K.$(`player.mounted=true;`);
let badTile = 0, frames = 6000;
for (let f = 0; f < frames; f++) {
  K.$(`updateDoodles();`);
  if (f % 50 === 0) for (const d of D()) { const [x, y] = tileOf(d);
    if (!K.WALK.has(K.WORLD[y][x]) || K.$(`barrierAt(${x},${y})`) !== -1) badTile++; }
}
K.$(`player.mounted=false;`);
ok('they only ever stand on walkable ground, outside the dark domes', badTile === 0, `${badTile} bad samples`);
const moved = D().map((d, i) => Math.abs(tileOf(d)[0] - start[i][0]) + Math.abs(tileOf(d)[1] - start[i][1]));
ok('they actually wander (most drift several tiles in 100 seconds)',
   moved.filter(m => m >= 4).length >= 4, `moved ${moved.join(', ')} tiles`);
ok('their step ignores player-only rules (never calls walkable)',
   /function doodleStep\(fx,fy,tx,ty\)\{[^}]*\}/.test(stripped) &&
   !/function doodleStep[\s\S]*?\n\}/.exec(stripped)[0].includes('walkable('));
ok('they draw from their own PRNG at spawn, not Math.random',
   !/function spawnDoodles[\s\S]*?\n\}/.exec(stripped)[0].includes('Math.random'));

// ── talking ───────────────────────────────────────────────────────────────
// stand the knight just left of doodle 0, facing right, and press Ⓐ
{
  const [x, y] = tileOf(D()[0]);
  K.$(`doodles[0].x=${x * T}; doodles[0].y=${y * T}; doodles[0].wait=0; doodles[0].stare=0;
       player.x=${(x - 1) * T}; player.y=${y * T}; player.dir='right'; dialogue.open=false;
       villagers.length; doAction();`);
  const dl = K.$(`({open:dialogue.open, sp:dialogue.lines[0]&&dialogue.lines[0].speaker, tx:dialogue.lines[0]&&dialogue.lines[0].text})`);
  ok('pressing Ⓐ at a doodle opens a dialogue', dl.open);
  check('the speaker is unknowable', dl.sp, '???');
  check('and it only stares', dl.tx, '… stares blankly into your soul …');
  ok('it stops to stare at you', K.$(`doodles[0].stare`) > 0);
  const kind0 = K.$(`doodles[0].kind`);
  check('its portrait pops up, like any townsfolk', K.$(`dialogue._pid`), 'doodle:' + kind0);
  ok('and the dialogue box actually shows it',
     K.$(`(renderDialogue(), /klk-portrait/.test(document.getElementById('banner').innerHTML))`));
  check('and turns toward the knight (he is to its left)', K.$(`doodles[0].flip`), true);
  const before = K.$(`[doodles[0].x,doodles[0].y]`);
  K.$(`updateDoodles();`);
  check('it does not move while staring', K.$(`[doodles[0].x,doodles[0].y]`), before);
  K.$(`dialogue.open=false;`);
}

// ── bumping ───────────────────────────────────────────────────────────────
{ const [x, y] = tileOf(D()[1]);
  ok('the knight bumps into one (so it can be faced and spoken to)', K.$(`npcTileBlocked(${x},${y})`)); }

// ── they are not demons ───────────────────────────────────────────────────
ok('no doodle is ever put in the demons list', K.$(`demons.every(d=>!doodles.includes(d))`));
K.$(`for(let i=0;i<chapelProgress.length;i++) chapelProgress[i]=true; demons.length=0;`);
for (let f = 0; f < 200; f++) K.$(`updateDoodles();`);
check('every chapel cleansed and every demon gone — the doodles remain', K.$(`doodles.length`), 6);
ok('they are not persisted (the save is untouched)', !JSON.stringify(K.$(`buildSaveData()`)).includes('doodle'));

// ── his pixels, exactly ───────────────────────────────────────────────────
// At RENDER_SCALE 2 one of his art-pixels must be one backing-store pixel.
// Draw frame 0 of each kind and compare every opaque sheet pixel exactly.
for (const kind of ['blob', 'pair']) {
  const r = K.$(`(()=>{ const S=DOODLE_SPR['${kind}']; const d={kind:'${kind}',moving:false,frame:0,flip:false};
    ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0); ctx.imageSmoothingEnabled=false;
    ctx.clearRect(0,0,VW,VH); drawDoodle(40,40,d);
    const dx=40+TILE/2-Math.floor(S.fw/2)/2, dy=40+TILE-S.fh/2;
    const got=ctx.getImageData(dx*RENDER_SCALE, dy*RENDER_SCALE, S.fw, S.fh).data;
    const c=document.createElement('canvas'); c.width=S.fw*4; c.height=S.fh; const g=c.getContext('2d');
    g.drawImage(S.img,0,0); const want=g.getImageData(0,0,S.fw,S.fh).data;
    let opaque=0, bad=0; for(let i=0;i<want.length;i+=4){ if(want[i+3]!==255) continue; opaque++;
      if(got[i]!==want[i]||got[i+1]!==want[i+1]||got[i+2]!==want[i+2]||got[i+3]!==255) bad++; }
    ctx.setTransform(1,0,0,1,0,0); return {opaque,bad,rs:RENDER_SCALE}; })()`);
  ok(`${kind}: drawn 1:1 with the drawing, no smearing`, r.opaque > 100 && r.bad === 0,
     `${r.bad} of ${r.opaque} opaque pixels differ at RENDER_SCALE ${r.rs}`);
}

// ── the portraits: every row fills the 64×76 frame exactly, and they are
//    mostly his purple on the void, not a blank or a stray backdrop ──
for (const kind of ['blob', 'pair']) {
  const r = K.$(`(()=>{ const rows=DOODLE_FACES['${kind}'].split('|'); let bad=0;
    for(const row of rows){ let w=0; for(const [,c,n] of row.matchAll(/([.kdmbl])(\\d*)/g)) w+=n?+n:1; if(w!==PORTRAIT_W) bad++; }
    const url=bakePortrait('doodle:${kind}'); const im=new Image(); im.src=url;
    const c=document.createElement('canvas'); c.width=PORTRAIT_W; c.height=PORTRAIT_H; const g=c.getContext('2d'); g.drawImage(im,0,0);
    const d=g.getImageData(0,0,PORTRAIT_W,PORTRAIT_H).data; let purple=0, clear=0, eyes=0;
    for(let i=0;i<d.length;i+=4){ if(d[i+3]<255) clear++; if(d[i+2]>90&&d[i+2]>d[i+1]+20) purple++; if(d[i]===0x14&&d[i+1]===0x0c&&d[i+2]===0x18) eyes++; }
    return {rows:rows.length,bad,purple,clear,eyes}; })()`);
  ok(`${kind} portrait: ${r.rows} rows, each exactly 64 wide`, r.rows === 76 && r.bad === 0, `${r.bad} rows the wrong width`);
  ok(`${kind} portrait: fully painted, and his purple fills a good part of it`, r.clear === 0 && r.purple > 800,
     `${r.purple} purple px, ${r.clear} unpainted`);
  ok(`${kind} portrait: it has eyes (it is staring at you)`, r.eyes >= 4, `${r.eyes} eye pixels`);
}

done('doodles');

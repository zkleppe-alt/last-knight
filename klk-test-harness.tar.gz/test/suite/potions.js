// suite/potions.js — 🧪 potions, tonics, the Murky Flask, and Reuben's wagon (2026-10-09-pr).
//
// Zak: "Add different kinds of potions, good potions, suspicious potions, temporary Stat boosters,
// etc. these would be sold by a wandering merchant named Reuben." Suspicious ones: "Mostly good, but
// some levels of bad, and some funny effects." Quick slot on the phone, "Cycle Key and Drink key" on PC.
// Reuben "moves between towns", from "after the first chapel".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('potions');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[]; place={kind:'overworld'};
  localStorage.removeItem('klk_controls'); ctlLoad(); ctl.hinted=true; for(const k in chapelProgress) delete chapelProgress[k];
  POTION_ORDER.forEach(k=>inventory[k]=0); player.quickPot='potion'; for(const k in potFx) delete potFx[k]; recalcStats();`);
const clear = () => K.$(`dialogue.open=false; menu.open=false; shopMode=null; _lastPotAt=-1e9;`);

// ── the brews ──
check('eight brews: healing ×3, tonics ×4, the Murky Flask', K.$(`POTION_ORDER`),
  ['potion', 'greaterPotion', 'elixir', 'mightTonic', 'ironTonic', 'swiftBrew', 'eagleTonic', 'murky']);
check("Reuben sells them all", K.$(`REUBEN_WARES.every(k=>SHOP_ITEMS[k] && SHOP_ITEMS[k].price>0)`), true);
K.$(`place={kind:'interior', id:'shop'}; openShop();`);
check("a village shop keeps to its own wares (Healing Potion yes, Reuben's no)", K.$(`[shopMode.items.includes('potion'), shopMode.items.some(k=>SHOP_ITEMS[k]&&SHOP_ITEMS[k].reuben)]`), [true, false]);
K.$(`closeShop(); place={kind:'overworld'};`);

// ── tonics change the knight's numbers, then wear off ──
clear(); K.$(`inventory.mightTonic=2; player.hp=player.maxHp;`);
const atk0 = K.$(`player.atk`);
K.$(`potDrink('mightTonic','menu')`);
check('Draught of Might: +25% attack', K.$(`player.atk`), Math.round(atk0 * 1.25));
K.$(`menu.open=true; potTick(100000); menu.open=false;`);
check('…held while the menu is open', K.$(`potFxOn('might')`), true);
K.$(`potTick(89000)`); check('…still on at 89s', K.$(`player.atk`), Math.round(atk0 * 1.25));
K.$(`potTick(2000)`); check('…and gone at 91s, the attack back', [K.$(`potFxOn('might')`), K.$(`player.atk`)], [false, atk0]);
ok('…with a banner saying so', K.$(`banner.innerHTML.indexOf('Might fades')>=0`));
const def0 = K.$(`player.def`), crit0 = K.$(`player.crit`);
K.$(`inventory.ironTonic=1; inventory.eagleTonic=1; potDrink('ironTonic','menu'); potDrink('eagleTonic','menu');`);
check('Ironbark +25% defense, Eagle-Eye +15% crit', [K.$(`player.def`), Math.round(K.$(`player.crit`) * 100)], [Math.round(def0 * 1.25), Math.round(crit0 * 100) + 15]);
K.$(`inventory.swiftBrew=1; potDrink('swiftBrew','menu');`);
check('Swiftfoot: 30% faster on foot', K.$(`potSpeedMult()`), 1.3);
K.$(`for(const k in potFx) potEnd(k,true);`);

// ── healing ──
K.$(`inventory.greaterPotion=1; player.hp=10;`); K.$(`potDrink('greaterPotion','menu')`);
check('Greater Healing: +100 HP', K.$(`player.hp`), Math.min(110, K.$(`player.maxHp`)));
K.$(`potStart('slow',40000); potStart('poison',20000); inventory.elixir=1; player.hp=5; potDrink('elixir','menu');`);
check('Elixir of Renewal: full HP and every ill effect cleared', [K.$(`player.hp===player.maxHp`), K.$(`potFxOn('slow')||potFxOn('poison')`)], [true, false]);
K.$(`player.hp=player.maxHp; inventory.potion=1;`);
check('a healing brew at full health is kept, not wasted', [K.$(`potDrink('potion','menu')`), K.$(`inventory.potion`)], [false, 1]);

// ── the quick slot ──
clear(); K.$(`POTION_ORDER.forEach(k=>inventory[k]=0); inventory.potion=3; inventory.mightTonic=2; inventory.murky=1; player.quickPot='potion'; player.hp=10;`);
K.key.tap('h', 0);
check('H drinks the quick slot (a Healing Potion by default)', K.$(`[inventory.potion, player.hp]`), [2, 50]);
clear(); K.key.tap('r', 0);
check('R moves the quick slot to the next brew you carry', K.$(`player.quickPot`), 'mightTonic');
clear(); K.key.tap('h', 0);
check('…and H now drinks that', K.$(`[inventory.mightTonic, potFxOn('might')]`), [1, true]);
K.$(`updatePotBtn()`);
check('the 🧪 button shows the quick brew and its count', K.$(`document.getElementById('btnPot').textContent`), '💪1');
K.$(`for(const k in potFx) potEnd(k,true);`);
K.key.tap('r', 0); K.key.tap('r', 0);
check('R wraps round what you carry', K.$(`player.quickPot`), 'potion');
// phone path: ☰ Items → ★ row
clear(); K.$(`toggleMenu(); setMenuTab(TAB.items); menu.focus='list';`);
check('Items lists the ★ quick slot, then each brew carried, then bread', K.$(`menuRows().map(r=>r.kind+':'+r.id)`), ['quick:quick', 'use:potion', 'use:mightTonic', 'use:murky']);
K.$(`menu.cursor=0;`); K.key.tap('j', 0);
check('Ⓐ on the ★ row changes the quick slot', K.$(`player.quickPot`), 'mightTonic');
K.$(`menu.cursor=menuRows().findIndex(r=>r.id==='potion'); player.hp=10;`); K.key.tap('j', 0);
check('Ⓐ on a brew drinks it from the menu', K.$(`[inventory.potion, player.hp]`), [1, 50]);
ok('Items shows the brews with their notes', K.$(`(()=>{ renderMenu(); const h=gmEl().innerHTML; return ['Quick slot','Draught of Might','+25% attack','Murky Flask','Food'].every(s=>h.indexOf(s)>=0); })()`));
check('the Controls screen lists the next-potion key', K.$(`(()=>{ const a=CTL_ACTIONS.find(a=>a.id==='nextpot'); return a && a.def[0]; })()`), 'r');
K.$(`toggleMenu();`);

// ── the Murky Flask ──
const tally = K.$(`(()=>{ const t={good:0,funny:0,bad:0}; const G=['heal','tonic','gold','full'], F=['hic','rainbow','tiny'];
  for(let i=0;i<1000;i++){ const o=murkyRoll((i+0.5)/1000); t[G.includes(o)?'good':F.includes(o)?'funny':'bad']++; } return t; })()`);
check('half good, a quarter funny, a quarter bad', tally, { good: 500, funny: 250, bad: 250 });
const outcomes = K.$(`(()=>{ const out={}; let acc=0; const R=Math.random;
  for(const [w,o] of MURKY_TABLE){ const r=(acc+w/2)/100; acc+=w; Math.random=()=>r; player.hp=50; for(const k in potFx) potEnd(k,true);
    try{ const got=drinkMurky(); out[o]=[got, banner.innerHTML.indexOf('Proverbs')>=0, Object.keys(potFx)]; } catch(e){ out[o]=String(e); } }
  Math.random=R; return out; })()`);
check('every outcome runs as rolled', Object.keys(outcomes).map(k => outcomes[k][0] === k), Array(10).fill(true));
check('the bad and the funny ones each carry a Proverb; the good ones do not',
  ['heal', 'tonic', 'gold', 'full', 'hic', 'rainbow', 'tiny', 'slow', 'weak', 'poison'].map(k => outcomes[k][1]),
  [false, false, false, false, true, true, true, true, true, true]);
K.$(`for(const k in potFx) potEnd(k,true); player.hp=3; potStart('poison',20000); potTick(25000);`);
check('Queasy is never fatal', K.$(`[player.hp>=1, potFxOn('poison')]`), [true, false]);
K.$(`player.hp=50; potStart('poison',20000); for(let i=0;i<10;i++) potTick(1500);`);
check('…but it does sting (−2 every 1.5s)', K.$(`player.hp`), 30);
K.$(`for(const k in potFx) potEnd(k,true); potStart('slow',40000);`);
check('Sluggish: 30% slower', K.$(`potSpeedMult()`), 0.7);
K.$(`for(const k in potFx) potEnd(k,true); const a=player.atk; potStart('weak',45000); globalThis.__w=[a,player.atk]; potEnd('weak',true);`);
check('Weakened: −20% attack', K.$(`Math.round(__w[0]*0.8)===__w[1]`), true);
// the funny ones, measured on real pixels
const px = (setup) => K.$(`(()=>{ for(const k in potFx) potEnd(k,true); ${setup}; ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,120,120);
  player.dir='down'; player.swing=0; drawKnight(50,50); const d=ctx.getImageData(40,30,40,45).data; let n=0, h=0; for(let i=0;i<d.length;i+=4){ if(d[i+3]>0){ n++; h=(h*31+d[i]*7+d[i+1]*3+d[i+2])>>>0; } } return [n,h]; })()`);
const plain = px(''), tiny = px(`potStart('tiny',40000)`), rainbow = px(`potStart('rainbow',60000)`);
ok('Wee Knight draws him smaller', tiny[0] < plain[0] * 0.75, `${tiny[0]} vs ${plain[0]} px`);
ok('Rainbow Plume changes his plume, not his size', rainbow[0] === plain[0] && rainbow[1] !== plain[1], `${rainbow} vs ${plain}`);
K.$(`for(const k in potFx) potEnd(k,true);`);

// ── Reuben ──
K.$(`for(const k in chapelProgress) delete chapelProgress[k]; playMs=0;`);
check('no Reuben before the first chapel', K.$(`reubenHere()`), null);
K.$(`chapelProgress[0]=true;`);
check('after it, he camps by Hearthvale', K.$(`reubenHere().town`), 0);
const spots = K.$(`(()=>{ const out=[]; for(let t=0;t<10;t++){ const s=reubenFindSpot(t); out.push(s?[s.x,s.y]:null); } return out; })()`);
check('a spot by every village', spots.map(s => !!s), Array(10).fill(true));
const audit = K.$(`(()=>{ return ${JSON.stringify(spots)}.map((s,t)=>{ const [gx,gy]=REUBEN_GATES[t], [x,y]=s;
  const road=[0,1,2].some(i=>[2,9,10,11,12,16].includes(WORLD[y][x+i]));
  const near=Math.max(Math.abs(x-gx),Math.abs(y-gy))<=7;
  // walk from the gate with his three tiles blocked: does everything else still reach as before?
  const reach=(blk)=>{ const seen=new Set([gx+','+gy]), q=[[gx,gy]]; while(q.length){ const [cx,cy]=q.shift(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=cx+a, ny=cy+b, k=nx+','+ny; if(seen.has(k)||blk.has(k)||Math.abs(nx-gx)>12||Math.abs(ny-gy)>12||!walkable(nx,ny)) continue; seen.add(k); q.push([nx,ny]); } } return seen; };
  const before=reach(new Set()), after=reach(new Set([x+','+y,(x+1)+','+y,(x+2)+','+y]));
  return [!road, near, after.size===before.size-3, after.has((x-1)+','+y)||after.has(x+','+(y+1))||after.has(x+','+(y-1))]; }); })()`);
check('every spot: off the road, by the gate, cuts nothing off, and can be walked up to', audit, Array(10).fill([true, true, true, true]));
K.$(`chapelProgress[1]=true; chapelProgress[2]=true;`);
const towns = K.$(`[0,1,2,3].map(i=>{ playMs=i*REUBEN_STAY_MS+1000; return reubenTown(); })`);
check('he moves on every few minutes, round the cleansed villages', towns, [0, 1, 2, 0]);
K.$(`playMs=0;`);
// talk to him
const r = K.$(`reubenHere()`);
K.$(`player.x=(${r.x}-1)*TILE; player.y=${r.y}*TILE; player.dir='right'; player.reubenMet=false; dialogue.open=false;`);
check('he and his wagon block the way', K.$(`[npcTileBlocked(${r.x},${r.y}), npcTileBlocked(${r.x + 2},${r.y}), npcTileBlocked(${r.x + 3},${r.y})]`), [true, true, false]);
K.key.tap('j', 0);
ok('Ⓐ facing him: he introduces himself (Genesis 49:4)', K.$(`dialogue.open && JSON.stringify(dialogue.lines||dialogue).indexOf('49:4')>=0`), K.$(`JSON.stringify(dialogue).slice(0,200)`));
for (let i = 0; i < 12 && K.$(`dialogue.open`); i++) K.$(`advanceDialogue(); tickDialogue(5000); advanceDialogue();`);
check('…then his wagon opens', K.$(`[!!shopMode, shopMode&&shopMode.reuben, shopMode&&shopMode.items.length]`), [true, true, 8]);
ok("…titled Reuben's Wagon", K.$(`banner.innerHTML.indexOf('Reuben')>=0`));
K.$(`gold=100; shopMode.idx=shopMode.items.indexOf('murky'); inventory.murky=0;`); K.key.tap('j', 0);
check('buying a Murky Flask: 8 gold', K.$(`[gold, inventory.murky]`), [92, 1]);
K.$(`closeShop();`);
// the inn rumour
K.$(`place={kind:'interior', id:'inn'}; globalThis.__rr=reubenRumor(); place={kind:'overworld'};`);
ok('inn patrons say where he is camped', K.$(`__rr[0].indexOf('Hearthvale')>=0`), K.$(`__rr[0]`));
// saves
const rt = K.$(`(()=>{ player.quickPot='murky'; inventory.elixir=2; const s=JSON.parse(JSON.stringify(buildSaveData())); player.quickPot='potion'; player.reubenMet=false; inventory.elixir=0; applySaveData(s); return [player.quickPot, player.reubenMet, inventory.elixir]; })()`);
check('the quick slot, meeting Reuben and the brews round-trip through a save', rt, ['murky', true, 2]);
// real frames by his wagon, a Wee Knight with hiccups
K.$(`place={kind:'overworld'}; player.x=(${r.x}-1)*TILE; player.y=${r.y}*TILE; potStart('hic',30000); potStart('tiny',40000);`);
ok('real frames run by his wagon with effects on', K.$(`(()=>{ try{ for(let i=0;i<6;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`for(const k in potFx) potEnd(k,true);`);
done('potions');

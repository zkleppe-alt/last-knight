// suite/mistral.js — Mistral, the windswept shepherd highlands (2026-09-30).
//
// Zak: "improve those islands and clean them up ... look awesome". The flat
// green disc became rolling highlands with the SAME quest layout. This suite
// pins that layout, proves every quest target is reachable on foot by the
// game's own canStep(), and checks the new art and its isolation from the
// other two worlds.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('mistral');

K.$(`boot.done=true; dialogue.open=false; menu.open=false;`);
const build = () => K.$(`(buildPortalWorld('mistral'), place={kind:'portalworld'}, player.mounted=false, player.boating=false, 'ok')`);
build();

// ── the world ──
check('100×100, Mistral', K.$(`[portalWorld.w, portalWorld.h, portalWorld.id]`), [100, 100, 'mistral']);
ok('it has real heights (0–3)', K.$(`(()=>{ const v=Object.values(portalWorld.elev); return v.length>500 && Math.max(...v)===3 && Math.min(...v)>=1; })()`),
   K.$(`Object.keys(portalWorld.elev).length+' raised tiles'`));
const snap = () => K.$(`JSON.stringify([portalWorld.g, portalWorld.elev, portalWorld.props.map(p=>[p.kind,p.x,p.y])])`);
const a = snap(); build(); const b = snap();
ok('identical on every build (save-safe)', a === b);

// ── the quest layout is exactly where it was ──
check('the five folds, same names and places', K.$(`portalWorld.villages.map(v=>[v.id,v.cx,v.cy])`),
  [['fold',20,50],['brook',36,66],['meadowe',50,76],['millford',66,66],['downs',80,50]]);
ok('each chapel stands on its 3×2 footprint with its door below',
  K.$(`portalWorld.villages.every(v=>{ const g=portalWorld.g; for(let y=v.cy-1;y<=v.cy;y++)for(let x=v.cx-1;x<=v.cx+1;x++) if(g[y][x]!==5) return false; return g[v.cy+1][v.cx]===9; })`));
check('the castle gate at (50,20), keep centred on (50,15)', K.$(`[portalWorld.castle.gate, portalWorld.castle.cx, portalWorld.castle.cy, portalWorld.g[20][50]]`), [{ x: 50, y: 20 }, 50, 15, 9]);
check('arrive at (50,87), the way home at (50,88)', K.$(`[portalWorld.entry, portalWorld.retTile, portalWorld.g[88][50]]`), [{ x: 50, y: 87 }, { x: 50, y: 88 }, 35]);
check('the pens sit west of each chapel as before', K.$(`portalWorld.pens.map(p=>[p.vid,p.x,p.y,p.w,p.h])`),
  K.$(`portalWorld.villages.map(v=>[v.id,v.cx-6,v.cy-1,4,3])`));
check('seven sheep and a shepherd at every fold', K.$(`[portalWorld.sheep.length, portalWorld.shepherds.length]`), [35, 5]);

// ── reachable on foot, by the game's own movement rule ──
K.$(`globalThis.__reach=(()=>{ const s=portalWorld.entry, seen=new Set([s.x+','+s.y]), q=[[s.x,s.y]];
  for(let i=0;i<q.length;i++){ const [x,y]=q[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay; if(seen.has(k)) continue; if(canStep(x,y,ax,ay)){ seen.add(k); q.push([ax,ay]); } } }
  return seen; })();`);
const R = (x, y) => K.$(`__reach.has('${x},${y}')`);
check('every chapel door', K.$(`portalWorld.villages.filter(v=>!__reach.has(v.chapelDoor.x+','+v.chapelDoor.y)).map(v=>v.id)`), []);
check('every pen gate', K.$(`portalWorld.pens.filter(p=>!__reach.has(p.gate.x+','+p.gate.y)).map(p=>p.vid)`), []);
check('every shepherd', K.$(`portalWorld.shepherds.filter(s=>!__reach.has(s.tx+','+s.ty)).map(s=>s.village)`), []);
check('every lost lamb', K.$(`portalWorld.lost.filter(s=>!__reach.has(s.hx+','+s.hy)).map(s=>s.village+'@'+s.hx+','+s.hy)`), []);
ok('the castle gate', R(50, 20));
ok('the way home', R(50, 88));
ok('my reachability helper agrees with canStep exactly',
  K.$(`(()=>{ const g=portalWorld.g, E=[]; for(let y=0;y<100;y++){ E.push([]); for(let x=0;x<100;x++) E[y].push(elevAt(x,y)); }
       const M=mistralReach(g,E,portalWorld.entry); if(M.size!==__reach.size) return false; for(const k of M) if(!__reach.has(k)) return false; return true; })()`));
ok('most of the island is open on foot', K.$(`__reach.size`) > 4000, K.$(`__reach.size+' tiles'`));

// ── lost lambs: the same counts, and saved progress still honoured ──
check('lost lambs per fold match their saved totals',
  K.$(`portalWorld.villages.map(v=>portalWorld.lost.filter(s=>s.village===v.id).length)`),
  K.$(`portalWorld.villages.map(v=>{ const st=mistVil(v.id); return Math.max(0, st.lostTotal-(st.lostGathered||0)); })`));
K.$(`mistVil('brook').lostGathered=2;`); build();
check('a fold with two already gathered hides two fewer', K.$(`portalWorld.lost.filter(s=>s.village==='brook').length`), K.$(`mistVil('brook').lostTotal-2`));
K.$(`mistVil('brook').lostGathered=0;`); build();

// ── tiles: what walks and what doesn't ──
check('heather, tall grass and shingle are walkable', K.$(`[MT.HEATHER,MT.TALLGRASS,MT.SHINGLE].map(t=>WALK.has(t))`), [true, true, true]);
check('walls, gorse, standing stones, sea stacks and prop bases are solid', K.$(`[MT.WALL,MT.GORSE,MT.STONE,MT.STACK,MT.BASE].map(t=>WALK.has(t))`), [false, false, false, false, false]);
check('no stray fence rails (the old "trees" were tile 14)', K.$(`portalWorld.g.flat().filter(t=>t===14).length`), 0);
ok('real trees, drawn as highland pines and rowans', K.$(`portalWorld.g.flat().filter(t=>t===1).length`) > 40 && K.$(`drawMistralTile(1,0,0,90,70)`) === true);
const counts = K.$(`(()=>{ const c={}; portalWorld.g.flat().forEach(t=>c[t]=(c[t]||0)+1); return c; })()`);
ok('the highland dressing is all there', [90, 91, 92, 93, 94, 95, 96, 97].every(t => (counts[t] || 0) > 0), JSON.stringify([90,91,92,93,94,95,96,97].map(t=>counts[t]||0)));
ok('rivers fall off the uplands somewhere (water above lower water)',
  K.$(`(()=>{ const g=portalWorld.g; let n=0; for(let y=0;y<99;y++)for(let x=0;x<100;x++) if(g[y][x]===3&&g[y+1][x]===3&&elevAt(x,y)>elevAt(x,y+1)) n++; return n; })()`) > 0);
ok('the lake is one level sheet of water',
  K.$(`(()=>{ const s=new Set(); for(let y=42;y<=58;y++)for(let x=44;x<=56;x++) if(portalWorld.g[y][x]===3) s.add(elevAt(x,y)); return s.size; })()`) === 1);

// ── props ──
const props = K.$(`(()=>{ const c={}; portalWorld.props.forEach(p=>c[p.kind]=(c[p.kind]||0)+1); return c; })()`);
check('a cottage pair at every fold, two windmills, the arch home', [props.cottage, props.windmill, props.returnArch], [10, 2, 1]);
ok('every prop stands on solid footprint tiles',
  K.$(`portalWorld.props.filter(p=>p.kind!=='returnArch').every(p=>{ for(let y=p.y;y<p.y+p.h;y++)for(let x=p.x;x<p.x+p.w;x++) if(portalWorld.g[y][x]!==MT.BASE) return false; return true; })`));
ok('no prop blocks a fold’s chapel, plaza or pen',
  K.$(`portalWorld.props.every(p=>portalWorld.villages.every(v=>!(p.x<=v.cx+3 && p.x+p.w>=v.cx-7 && p.y<=v.cy+3 && p.y+p.h>=v.cy-2)))`));

// ── drawing: every tile, every face, the props, the weather, both building states ──
const draws = K.$(`(()=>{ const bad=[]; const saveW=VIEW_TW, saveH=VIEW_TH;
  try{ VIEW_TW=100; VIEW_TH=100; player.x=50*TILE; player.y=50*TILE;
    for(const lit of [false,true]){ portalWorld.villages.forEach(v=>v.cleared=lit); mistThrone.purified=lit; draw(); } }
  catch(e){ bad.push(e.message); } finally{ VIEW_TW=saveW; VIEW_TH=saveH; }
  return bad; })()`);
check('the whole island draws, folds dark and cleansed', draws, []);
check('one frame of the real loop in the highlands', K.$(`(()=>{ player.x=50*TILE; player.y=80*TILE; try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
check('castle and chapel art, both states', K.$(`(()=>{ try{ drawMistralCastleHL(100,100,true); drawMistralCastleHL(100,100,false); drawMistralChapelHL(50,50,true); drawMistralChapelHL(50,50,false); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
ok('the world now draws the highland castle and chapels',
  K.$(`(()=>{ let c=0, h=0; const a=drawMistralCastleHL, b=drawMistralChapelHL, oa=drawMistralCastle, ob=drawMistralChapel;
     drawMistralCastleHL=function(){ h++; }; drawMistralChapelHL=function(){ h++; }; drawMistralCastle=function(){ c++; }; drawMistralChapel=function(){ c++; };
     try{ player.x=50*TILE; player.y=40*TILE; const sw=VIEW_TW, sh=VIEW_TH; VIEW_TW=100; VIEW_TH=100; draw(); VIEW_TW=sw; VIEW_TH=sh; }
     finally{ drawMistralCastleHL=a; drawMistralChapelHL=b; drawMistralCastle=oa; drawMistralChapel=ob; }
     return h===6 && c===0; })()`));

// ── nothing leaks into the other worlds ──
const leak = (id) => K.$(`(()=>{ buildPortalWorld('${id}'); place={kind:'portalworld'}; let n=0;
  const a=drawMistralProp, b=drawMistralWeather, c=drawMistralTile; drawMistralProp=function(){ n++; }; drawMistralWeather=function(){ n++; }; drawMistralTile=function(){ n++; return false; };
  try{ player.x=(portalWorld.entry.x)*TILE; player.y=(portalWorld.entry.y)*TILE; draw(); } finally{ drawMistralProp=a; drawMistralWeather=b; drawMistralTile=c; }
  return n; })()`);
check('after Mistral, Tabor draws none of Mistral’s art', leak('tabor'), 0);
check('after Mistral, Sunfall draws none of Mistral’s art', leak('sunfall'), 0);

// ── the castle still opens once all five folds are whole ──
K.$(`portalWorld.villages && 0; ['fold','brook','meadowe','millford','downs'].forEach(id=>mistVil(id).cleared=true);`); build();
check('all five cleansed: the castle gate stands open on entry', K.$(`portalWorld.castle.unlocked`), true);
K.$(`['fold','brook','meadowe','millford','downs'].forEach(id=>mistVil(id).cleared=false);`); build();
check('otherwise it stays shut', K.$(`portalWorld.castle.unlocked`), false);

// ── save → load → rebuild: the same island ──
const before = snap();
K.$(`(()=>{ const s=JSON.parse(JSON.stringify(buildSaveData())); applySaveData(s); })()`); build();
ok('a save round-trip rebuilds the very same island', snap() === before);
// ── MISTRAL ISLE on the overworld: themed to the world behind its gate ──
K.$(`place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const isle = K.$(`(()=>{ let land=null; for(let y=292;y>270;y--) if(WORLD[y][40]===6){ land={x:40,y}; break; }
  const seen=new Set([land.x+','+land.y]), q=[[land.x,land.y]];
  for(let i=0;i<q.length;i++){ const [x,y]=q[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay;
    if(seen.has(k)||!mistralIsleAt(ax,ay)) continue; if(canStep(x,y,ax,ay)){ seen.add(k); q.push([ax,ay]); } } }
  return { land, gate:seen.has('40,270'), home:seen.has('40,271'), sea:[WORLD[land.y+1][land.x], WORLD[land.y][land.x-1], WORLD[land.y][land.x+2]] }; })()`);
ok('the boat still ties up at a plank on the south shore', !!isle.land, JSON.stringify(isle.land));
ok('  with open water beside it', isle.sea.every(t => t === 3 || t === 20), JSON.stringify(isle.sea));
ok('from the landing you can climb to the gate on foot', isle.gate);
ok('  and coming home through it you stand on the summit', isle.home);
check('the gate is still at the summit (40,270)', K.$(`[portalById('mistral').tx, portalById('mistral').ty]`), [40, 270]);
ok('the summit sign still reads Mistral Isle', K.$(`(signs['40,270']||'').indexOf('Mistral Isle')===0`));
const dec = K.$(`(()=>{ const c={}; decorations.filter(d=>d.kind.indexOf('mt_')===0).forEach(d=>c[d.kind]=(c[d.kind]||0)+1); return c; })()`);
check('the isle\'s holding: a cottage, a windmill, three sheep', [dec.mt_cottage, dec.mt_windmill, dec.mt_sheep], [1, 1, 3]);
ok('and some wind-bent thorns', (dec.mt_bentTree || 0) >= 3, String(dec.mt_bentTree));
ok('the crag is moor and heather, ringed by standing stones', K.$(`(()=>{ let s=0; for(let y=266;y<=274;y++)for(let x=36;x<=44;x++) if(WORLD[y][x]===94) s++; return s; })()`) >= 5);
check('the isle draws, gates sealed and open', K.$(`(()=>{ const bad=[]; const sw=VIEW_TW, sh=VIEW_TH; VIEW_TW=40; VIEW_TH=40; player.x=40*TILE; player.y=271*TILE;
  for(const open of [false,true]){ bounties.portalsOpen=open; try{ draw(); }catch(e){ bad.push(e.message); } } VIEW_TW=sw; VIEW_TH=sh; bounties.portalsOpen=false; return bad; })()`), []);
ok('Mistral\'s turf banks stay on the isle (the mainland keeps its rock)',
  K.$(`!mistralIsleAt(150,60) && !mistralIsleAt(95,274) && !mistralIsleAt(155,270) && mistralIsleAt(40,270)`));
done('mistral');

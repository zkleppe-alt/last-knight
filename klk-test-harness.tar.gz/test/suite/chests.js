// suite/chests.js — 📦 set chapel chests (2026-10-09-ch).
//
// Zak: "remap the dungeon chests to not be random so players can maybe get at least some potions and
// gold - a weapon on the first chapel". Then: "it's fine to sell the short sword still", "the later the
// chapel the more gold".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('chests');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[];`);
const enter = (t, seedSkip) => K.$(`(()=>{ for(let i=0;i<${seedSkip || 0};i++) Math.random();
  place={kind:'dungeon'}; dungeon.townId=${t}; dungeon.forest=false; dungeon.floors=getChapelFloors(${t}); dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={}; })()`);
const chestsOn = (i) => K.$(`(()=>{ loadDungeonFloor(${i},false); const c=[]; dungeon.grid.forEach((r,y)=>r.forEach((v,x)=>{ if(v===5) c.push([x,y]); })); return c; })()`);
const fresh = () => K.$(`player.ownedGear={ rusty:true, none_w:true, none_a:true }; POTION_ORDER.forEach(k=>inventory[k]=0); gold=0; player.goldMult=1;`);

// ── the table matches the chapels as built ──
const mismatch = [];
for (let t = 0; t < 10; t++) for (const skip of [0, 333, 9001]) {
  enter(t, skip);
  const floors = K.$(`dungeon.floors`);
  floors.forEach((ft, i) => { const n = chestsOn(i).length; const named = K.$(`((CHAPEL_CHESTS[${t}]||{})[${ft}]||[]).length`);
    if (n !== named) mismatch.push(`chapel ${t} floor ${ft}: ${n} chests, ${named} in the table`); });
}
check('every chest in every chapel is named in the table (three different maze rolls)', mismatch, []);

// ── chapel 1: a weapon, potions, gold — through real input ──
fresh(); enter(0);
const open = (x, y) => { K.$(`dialogue.open=false; banner.style.display='none'; bannerT=0; player.x=(${x}-1)*TILE; player.y=${y}*TILE; player.dir='right';`); K.key.tap(' ', 0); return K.$(`banner.innerHTML`); };
const opened = [];
const floors0 = K.$(`dungeon.floors`);
floors0.forEach((ft, i) => { for (const [x, y] of chestsOn(i)) opened.push([ft, open(x, y)]); });
check('Hearthvale: the Short Sword, 2 Healing Potions, then gold and Leather Leggings', [K.$(`!!player.ownedGear.shortsword`), K.$(`inventory.potion`), K.$(`gold`), K.$(`!!player.ownedGear.leather_legs`)], [true, 2, 50, true]);
ok('the first chest says "Short Sword"', opened[0][1].indexOf('Short Sword') >= 0, opened[0][1].slice(0, 120));
check('an opened chest is empty the second time', (() => { const [x, y] = chestsOn(K.$(`dungeon.floors.indexOf(FLOOR.maze)`))[0]; return open(x, y).indexOf('Empty') >= 0; })(), true);

// ── set, not rolled ──
const roll = (skip) => { fresh(); enter(3, skip); const i = K.$(`dungeon.floors.indexOf(FLOOR.maze)`); const c = chestsOn(i); K.$(`dungeon.floorIdx=${i};`);
  return c.map(([x, y]) => K.$(`dungeonChestReward(${x},${y})`)); };
check('Thornwood gives the same whatever the dice say', roll(0), roll(4242));
ok('…Chain Chausses, then potions and an Ironbark Tonic', roll(7).join(' ').indexOf('Chain Chausses') >= 0 && roll(7).join(' ').indexOf('Ironbark Tonic') >= 0, roll(7).join(' | '));

// ── every chapel: gold, and something to drink; gold climbs ──
const sums = K.$(`Object.keys(CHAPEL_CHESTS).map(t=>{ const items=Object.values(CHAPEL_CHESTS[t]).flat(1).flat(1);
  return [items.filter(i=>i[0]==='gold').reduce((a,i)=>a+i[1],0), items.filter(i=>i[0]==='pot').reduce((a,i)=>a+i[2],0), items.filter(i=>i[0]==='gear').length]; })`);
check('every chapel holds gold and at least two brews', sums.map(s => s[0] > 0 && s[1] >= 2), Array(10).fill(true));
ok('the later the chapel, the more gold', sums.every((s, i) => i === 0 || s[0] > sums[i - 1][0]), JSON.stringify(sums.map(s => s[0])));
check('the first chapel holds a weapon', K.$(`Object.values(CHAPEL_CHESTS[0]).flat(2).some(i=>Array.isArray(i)&&i[0]==='gear'&&EQUIP[i[1]].slot==='weapon')`), true);
ok('every piece the table names is real', K.$(`Object.values(CHAPEL_CHESTS).flatMap(t=>Object.values(t).flat(2)).filter(Array.isArray).every(i=>i[0]==='gold'||(i[0]==='gear'&&EQUIP[i[1]])||(i[0]==='pot'&&POTIONS[i[1]]))`));
check('the Short Sword is still sold', K.$(`!!SHOP_ITEMS.shortsword`), true);

// ── a piece already owned turns to gold ──
fresh(); K.$(`player.ownedGear.shortsword=true;`); enter(0);
{ const i = K.$(`dungeon.floors.indexOf(FLOOR.maze)`), [x, y] = chestsOn(i)[0]; K.$(`dungeon.floorIdx=${i};`);
  const msg = K.$(`dungeonChestReward(${x},${y})`);
  check('a Short Sword you already own comes as gold instead', [K.$(`gold`), msg.indexOf('Short Sword') < 0], [K.$(`30+TOWN_DATA[0].lvl*5`), true]); }
// ── the forest ──
fresh(); K.$(`dungeon.forest=true; dungeonChestReward(3,3);`);
check('the forest chests: 50 gold and a Healing Potion', [K.$(`gold`), K.$(`inventory.potion`)], [50, 1]);
K.$(`dungeon.forest=false; place={kind:'overworld'};`);
done('chests');

// suite/puzzle.spec.js — the checks Node CANNOT do.
//
// WHY THIS FILE EXISTS SEPARATELY
// The Node suites drive real keydown/keyup through the game's own listeners,
// so the LOGIC of the puzzle is covered. What Node has no opinion about:
//   * where anything actually is on screen (no layout engine)
//   * touch: touchstart/touchmove/touchend, tap targets, the dpad
//   * whether text fits, wraps, or overflows a 390px phone
//   * contrast of what is drawn, measured off real pixels
//   * whether the canvas renders at all vs. throwing on first frame
// Those need a real browser. This file is that pass.
//
// RUNNING IT (this could not be run in the container it was written in —
// Playwright's browser CDN was unreachable and there was no root to install
// a system Chromium, so treat these as UNVERIFIED until you run them):
//
//     npm i -D playwright && npx playwright install chromium
//     npx playwright test suite/puzzle.spec.js
//
// It loads index.html from disk, so no server is needed.

const { test, expect, devices } = require('@playwright/test');
const path = require('path');

const FILE = 'file://' + path.resolve(__dirname, '..', '..', 'index.html');

test.use({ ...devices['iPhone 13'] });        // 390x844, DPR 3, touch enabled

// locator.tap() waits for "actionability" — stability, visibility, no overlay.
// The controls sit on a canvas that repaints every frame, so the stability
// check never settles and the call hangs until the test times out. Dispatch the
// touch directly at the element's centre instead; it is the same event the
// browser would send, minus the waiting.
async function tapAt(page, target) {
  const box = await target.boundingBox();
  if (!box) throw new Error('element not visible');
  const x = box.x + box.width / 2, y = box.y + box.height / 2;
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart',
    touchPoints: [{ x, y, id: 1 }] });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
}

// Bring the game up and drop the knight on a doctrine floor. Uses the same
// entry points as the Node suite so the two stay comparable.
async function toDoctrineFloor(page) {
  await page.goto(FILE);
  await page.waitForFunction(() => typeof window.newGameOnSlot === 'function');
  await page.evaluate(() => {
    newGameOnSlot(1);
    boot.done = true; intro.open = false;
    // The controls and HUD are hidden by `#stage.booting`, a CSS class the game
    // removes only when gameplay really begins. Setting boot.done in JS does
    // NOT remove it, so every button stays display:none and boundingBox()
    // returns null — which reads as "the button is missing" and is not.
    document.getElementById('stage').classList.remove('booting');
    place = { kind: 'dungeon' };
    dungeon.townId = 3;
    dungeon.floors = getChapelFloors(3);
    dungeon.chests = {}; dungeon.candleLit = {}; dungeon.rolled = {}; dungeon.opened = {};
    loadDungeonFloor(dungeon.floors.indexOf(FLOOR.doctrine), false);
  });
  await page.waitForTimeout(300);            // let a few real frames run
}

test('the game boots on a phone viewport without throwing', async ({ page }) => {
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(FILE);
  await page.waitForTimeout(1500);
  expect(errors, 'uncaught errors during boot').toEqual([]);
  const canvas = page.locator('#c');
  await expect(canvas).toBeVisible();
});

test('the doctrine floor renders and fits the viewport', async ({ page }) => {
  await toDoctrineFloor(page);
  const box = await page.locator('#c').boundingBox();
  expect(box.width).toBeLessThanOrEqual(390);
  // The canvas must not be pushed off the bottom by the control cluster.
  expect(box.y + box.height).toBeLessThanOrEqual(844);
});

test('the room is not drawn as empty floor', async ({ page }) => {
  // A missing drawDungeonTile case renders as blank floor and every other test
  // still passes. Measure it: count distinct colours in the canvas. An empty
  // room is nearly flat; a room with five lampstands, five signs and a pedestal
  // is not. This is the check that would have caught T_PEDESTAL and T_SIGN
  // having no draw case at all.
  await toDoctrineFloor(page);
  const distinct = await page.evaluate(() => {
    const c = document.getElementById('c');
    const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
    const set = new Set();
    for (let i = 0; i < d.length; i += 4) {
      set.add((d[i] << 16) | (d[i + 1] << 8) | d[i + 2]);
    }
    return set.size;
  });
  expect(distinct, 'distinct colours on the doctrine floor').toBeGreaterThan(24);
});

test('the name signs meet contrast against the floor they sit on', async ({ page }) => {
  // Measured, not eyeballed. The brass plate has to separate from the dungeon
  // floor under dungeonTint(), which recolours per chapel — so check several.
  await toDoctrineFloor(page);
  for (const townId of [3, 5, 7, 9]) {
    const ratio = await page.evaluate((t) => {
      dungeon.townId = t;
      loadDungeonFloor(dungeon.floors.indexOf(FLOOR.doctrine), false);
      const c = document.getElementById('c');
      const ctx = c.getContext('2d');
      const TILEPX = TILE;
      const r = dungeon._doctrineRing[0];
      // camera-independent: draw the two tiles to a scratch canvas
      const s = document.createElement('canvas');
      s.width = TILEPX * 2; s.height = TILEPX;
      const sctx = s.getContext('2d');
      const real = ctx;
      // draw sign tile and a plain floor tile side by side
      drawDungeonTile(T_SIGN, 0, 0, r.sx, r.sy);
      drawDungeonTile(0, TILEPX, 0, r.sx, r.sy + 1);
      const d = ctx.getImageData(0, 0, TILEPX * 2, TILEPX).data;
      const lum = (i) => {
        const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
        return 0.2126 * f(d[i]) + 0.7152 * f(d[i + 1]) + 0.0722 * f(d[i + 2]);
      };
      // brightest pixel in the sign half vs the floor half
      let signMax = 0, floorAvg = 0, n = 0;
      for (let y = 0; y < TILEPX; y++) {
        for (let x = 0; x < TILEPX * 2; x++) {
          const i = (y * TILEPX * 2 + x) * 4;
          if (x < TILEPX) signMax = Math.max(signMax, lum(i));
          else { floorAvg += lum(i); n++; }
        }
      }
      floorAvg /= n;
      const a = Math.max(signMax, floorAvg), b = Math.min(signMax, floorAvg);
      return (a + 0.05) / (b + 0.05);
    }, townId);
    expect(ratio, `sign vs floor contrast, chapel ${townId}`).toBeGreaterThan(3.0);
  }
});

test('the entry briefing fits the screen and does not overflow', async ({ page }) => {
  await toDoctrineFloor(page);
  await page.evaluate(() => { sawCandleBrief = false; loadDungeonFloor(dungeon.floorIdx, false); });
  await page.waitForTimeout(2600);           // the briefing is deferred ~2.1s
  const banner = page.locator('#banner');
  if (await banner.isVisible()) {
    const b = await banner.boundingBox();
    expect(b.width).toBeLessThanOrEqual(390);
    expect(b.y + b.height).toBeLessThanOrEqual(844);
    // no clipped text
    const overflow = await banner.evaluate(el => el.scrollHeight - el.clientHeight);
    expect(overflow, 'briefing text clipped').toBeLessThanOrEqual(1);
  }
});

test('the tablet popup fits and scrolls rather than clipping', async ({ page }) => {
  await toDoctrineFloor(page);
  // Stand at the pedestal and TAP the Ⓐ button — the real touch path.
  await page.evaluate(() => {
    player.x = 7 * TILE; player.y = 4 * TILE; player.dir = 'down';
    dialogue.open = false;
  });
  await tapAt(page, page.locator('#btnA'));
  await page.waitForTimeout(200);
  const dlg = page.locator('#banner, #gamemenu').first();
  await expect(dlg).toBeVisible();
  const b = await dlg.boundingBox();
  expect(b.width).toBeLessThanOrEqual(390);
  const overflow = await dlg.evaluate(el => el.scrollHeight - el.clientHeight);
  expect(overflow, 'tablet text clipped on a 390px screen').toBeLessThanOrEqual(1);
});

test('tapping Ⓐ at a lampstand lights it', async ({ page }) => {
  // The Node suite proves this through keydown. This proves it through TOUCH,
  // which is the input 100% of your playtesters are using.
  await toDoctrineFloor(page);
  const lit = await page.evaluate(async ({ page }) => {
    const c = dungeon._candles[0];
    // facingTile() adds TILE/2 itself, so player.x is the sprite's LEFT EDGE.
    // Standing one tile ABOVE and facing down puts the lampstand in front.
    player.x = c.x * TILE; player.y = (c.y - 1) * TILE; player.dir = 'down';
    dialogue.open = false; menu.open = false;
    return dungeon.candleLit[dungeon.floorIdx] || 0;
  });
  expect(lit).toBe(0);
  await tapAt(page, page.locator('#btnA'));
  await page.waitForTimeout(400);
  const after = await page.evaluate(() => dungeon.candleLit[dungeon.floorIdx] || 0);
  if (after !== 1) {
    const why = await page.evaluate(() => ({
      facing: facingTile(), tile: dungeon.grid[facingTile()[1]][facingTile()[0]],
      candle: T_CANDLE, dlg: dialogue.open, bootDone: boot.done }));
    console.log('  diagnostic:', JSON.stringify(why));
  }
  expect(after, 'one tap of Ⓐ at the first lampstand').toBe(1);
});

test('the Ⓐ and Ⓑ buttons meet minimum tap-target size', async ({ page }) => {
  // Apple's HIG floor is 44x44pt. Below that, misses get blamed on the puzzle.
  // Must reach real gameplay first: the boot sequence hides #controls.
  await toDoctrineFloor(page);
  for (const id of ['#btnA', '#btnB']) {
    const b = await page.locator(id).boundingBox();
    expect(b.width, `${id} width`).toBeGreaterThanOrEqual(44);
    expect(b.height, `${id} height`).toBeGreaterThanOrEqual(44);
  }
});

test('the joystick moves the knight', async ({ page }) => {
  // NOT the dpad. `#dpad` exists in the markup but is display:none — the game
  // binds movement to the virtual JOYSTICK, anchored at a fixed offset inside
  // #stage and driven by touchstart/touchmove on the stage itself. A dpad test
  // passes or fails against a control the player never sees. (The Node
  // harness's K.tapDpad has the same problem and exercises nothing real.)
  await toDoctrineFloor(page);
  // Put the knight somewhere with open floor above him.
  await page.evaluate(() => {
    const c = dungeon._doctrineRing[0];
    player.x = c.x * TILE; player.y = (c.y + 3) * TILE; player.dir = 'down';
    dialogue.open = false;
  });
  const before = await page.evaluate(() => ({ x: player.x, y: player.y }));

  // The stick anchors at AX=72 from the left, AYOFF=110 up from the stage foot.
  const anchor = await page.evaluate(() => {
    const r = document.getElementById('stage').getBoundingClientRect();
    return { x: r.left + 72, y: r.top + r.height - 110 };
  });
  await page.touchscreen.tap(anchor.x, anchor.y);          // wake the stick
  const cdp = await page.context().newCDPSession(page);
  // Press at the anchor, then drag well past the 8px dead zone, and HOLD —
  // movement is driven by held.* flags across frames, not by a single event.
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart',
    touchPoints: [{ x: anchor.x, y: anchor.y, id: 1 }] });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove',
    touchPoints: [{ x: anchor.x, y: anchor.y - 40, id: 1 }] });
  await page.waitForTimeout(500);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });

  const after = await page.evaluate(() => ({ x: player.x, y: player.y }));
  expect(after, 'holding the stick up should move the knight').not.toEqual(before);
  expect(after.y, 'up means a smaller y').toBeLessThan(before.y);
});

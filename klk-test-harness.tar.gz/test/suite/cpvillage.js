// suite/cpvillage.js — Crystalpeak, the crystal monastery on a real peak (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout", then "something feels off" (the cathedral), then
// "let's make crystal peak taller … it seems more like crystal hill than a peak".
// The art: snow, the crystal-rimmed healing spring, snow-roofed stone houses, a cathedral
// under a crystal-crowned bell tower, crystal pillars, prayer flags, snowfall, an aurora,
// and the mountain drawn in bands (fir foothills, scree, snowfield, summit) with grey
// stone cliff faces. The ONE map change is crystalpeakTaller(): the old mountain lifted
// three levels on two new terraces, the south stair extended down through them.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('cpvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the town on top is untouched ──
// 357de502: the town box's tiles, identical before and after the revamp (the taller
// pass only changes ground outside the old village plateau).
check('the town grid on the summit is exactly the grid it was', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Crystalpeak; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '357de502');
check('the five buildings and their doors are where they were', K.$(`buildings.filter(b=>b.id.startsWith('cp_')).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["cp_chapel",151,62,4,3,153,64],["cp_shop",145,67,3,3,146,69],["cp_inn",158,67,3,3,159,69],["cp_home1",145,72,3,2,146,73],["cp_home2",158,72,3,2,159,73]]);
check('the square\'s props are where they were', K.$(`decorations.filter(d=>_cpBox(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["snowman",152,66,1],["brazier",148,69,1],["brazier",157,69,1],["icePillar",149,65,1],["icePillar",158,65,1],["pineSnow",147,71,1],["pineSnow",159,71,1],["prayerFlag",155,67,1]]);
check('four monks and pilgrims, and the sign', K.$(`[villagers.filter(v=>v.hx>=140&&v.hx<=166&&v.hy>=60&&v.hy<=77).length, !!signs['142,62']]`), [4, true]);
check('the healing spring is still the spring', K.$(`[WORLD[69][154],WORLD[70][153],WORLD[70][155]]`), [24, 24, 24]);

// ── the taller mountain ──
check('the mountain\'s ground and heights are pinned', K.$(`(()=>{ const rows=[], el=[]; for(let y=44;y<=92;y++){ rows.push(WORLD[y].slice(122,185).join(',')); for(let x=122;x<=184;x++) el.push(ELEV[x+','+y]||0); }
  return [(${fnv})(rows.join('|')), (${fnv})(el.join(','))]; })()`), ['21aebbed', '14cf101']);
check('the summit stands at height 7 (it was 4)', K.$(`elevAt(153,70)`), 7);
check('the climb crosses seven levels from the road', K.$(`[elevAt(153,93), elevAt(153,90), elevAt(153,87), elevAt(153,84)]`), [0, 1, 2, 3]);
const climb = K.$(`(()=>{ for(let i=0;i<10;i++) chapelProgress[i]=true;
  const flood=(sx,sy)=>{ const seen=new Set([sx+','+sy]), q=[[sx,sy]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
    if(seen.has(k)||X<110||X>200||Y<35||Y>110||!canStep(x,y,X,Y)) continue; seen.add(k); q.push([X,Y]); } } return seen; };
  const up=flood(153,95), down=flood(153,70); for(let i=0;i<10;i++) delete chapelProgress[i];
  const doors=buildings.filter(b=>b.id.startsWith('cp_')).every(b=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,c])=>up.has((b.door.x+a)+','+(b.door.y+c))));
  return [doors, up.has('153,70'), down.has('153,95')]; })()`);
check('from the road you climb to every door on the summit, and back down', climb, [true, true, true]);
check('the south stair is one clean two-wide flight through the new terraces', K.$(`[87,88,89,91,92].map(y=>[WORLD[y][153]===WORLD[y][154], elevAt(153,y)===elevAt(154,y)].every(Boolean))`), [true, true, true, true, true]);
ok('the old dead-end road stub on the east is hillside now', K.$(`[173,174,175,176,177].every(x=>WORLD[77][x]!==2 && WORLD[78][x]!==2)`));

// ── the drawing ──
const view = (clean, cy) => K.$(`(()=>{ for(let i=0;i<5;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[5]=true; else delete chapelProgress[5];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,f:0,o:0}; const A=drawCrystalpeakBuilding, B=drawCrystalpeakDecor, C=drawCrystalpeakTile, D=crystalpeakObjs, E=drawCrystalpeakFace;
  drawCrystalpeakBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawCrystalpeakDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawCrystalpeakTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; }; drawCrystalpeakFace=function(){ n.f++; return E.apply(null,arguments); };
  crystalpeakObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=64; VIEW_TH=52; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=153*TILE; player.y=${cy}*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawCrystalpeakBuilding=A; drawCrystalpeakDecor=B; drawCrystalpeakTile=C; crystalpeakObjs=D; drawCrystalpeakFace=E;
    for(let i=0;i<6;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean, 68);
  check(`${clean ? 'cleansed' : 'bound'}: the whole mountain draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and eight props wear Crystalpeak's art`, [r.n.b, r.n.d], [5, 8]);
  ok(`${clean ? 'cleansed' : 'bound'}: the mountain's ground is drawn in its bands (got ${r.n.t})`, r.n.t >= 2100);
  ok(`${clean ? 'cleansed' : 'bound'}: its cliffs are grey stone (got ${r.n.f} faces)`, r.n.f >= 250);
  check(`${clean ? 'cleansed' : 'bound'}: the sky layer (aurora, flags, steam, snow)`, r.n.o, 1);
}
ok('trees on the slopes are still drawn as trees (they block, so they must show)', K.$(`(()=>{ let fir=0; const A=_cpFir; _cpFir=function(){ fir++; return A.apply(null,arguments); }; try{ drawCrystalpeakTile(1,0,0,140,80); } finally{ _cpFir=A; } return fir===1; })()`));
ok('ground off the mountain keeps the overworld art', K.$(`drawCrystalpeakTile(0,0,0,153,96)===false && drawCrystalpeakTile(0,0,0,118,68)===false`));

// the cathedral reads its own state (chapelProgress[5]): frozen while bound, the crystal alight once cleansed
const front = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[5]=true; else delete chapelProgress[5];
  const b=buildings.find(b=>b.id==='cp_chapel'); const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ drawCrystalpeakBuilding(b,60,80); } finally{ px=A; delete chapelProgress[5]; } return [seen.has('rgba(200,225,240,0.55)'), seen.has('#5a6070')]; })()`);
check('bound: the door is frozen over and the crystal is dark', front(false), [true, true]);
check('cleansed: the ice is gone and the crystal shines', front(true), [false, false]);

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawCrystalpeakDecor({kind:'brazier',x:148,y:69,w:1,hs:true},0,0)===false`));
ok('other towns are not Crystalpeak', K.$(`!cpAt(92,69) && !cpAt(92,157) && !cpAt(32,22) && cpAt(153,68) && cpAt(130,68)`));
check('a frame of the real loop on the summit', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<5;i++) chapelProgress[i]=true; player.x=153*TILE; player.y=71*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<5;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('cpvillage');

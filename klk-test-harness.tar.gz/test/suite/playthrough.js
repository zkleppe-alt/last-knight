// suite/playthrough.js — the puzzle driven through REAL INPUT.
//
// Every other assertion in this repo inspects generated state or scans source.
// This one presses buttons: it dispatches keydown/keyup on the window, through
// the listeners the game itself registered, and lets doAction() decide what
// happens. Testing lightCandle() directly would prove nothing about whether a
// player facing a lampstand and pressing Ⓐ can light it.
//
// LIMIT, stated plainly: Node has no layout and no touch. This covers the
// LOGIC half of the input path only. Anything about where a button sits, how
// big the tap target is, or whether the popup fits a 390px screen needs the
// Playwright spec (suite/puzzle.spec.js) run against a real browser.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');

console.log('playthrough  (real input: keydown/keyup -> doAction)');

const TP = K.TILE;

// aPress() short-circuits to bootA() while boot.done is false, so a harness
// sitting at the title screen sends every Ⓐ into the boot menu and NOTHING
// reaches doAction(). This cost me a full run of silent no-ops: all five
// stands read as unlit and it looked like a game bug. Bring the game up first.
K.$('boot.done=true; intro.open=false; menu.open=false; cutscene.active=false;');

// A press that lands while a dialogue is open ADVANCES the dialogue instead of
// acting on the world. Close it before each press so we exercise doAction().
function clearUi() { K.$('dialogue.open=false; petName.open=false; saveio.open=false; libShop=null; library.open=false; trial.open=false; menu.open=false;'); }

function faceAndAct(tx, ty, fromDir) {
  // Stand the knight on the tile adjacent to (tx,ty) and face it, then press Ⓐ
  // exactly as a player would. doAction() reads the FACING tile, so the facing
  // is what matters — not proximity.
  const d = { up: [0, 1, 'up'], down: [0, -1, 'down'], left: [1, 0, 'left'], right: [-1, 0, 'right'] }[fromDir];
  // facingTile() computes floor((player.x + TILE/2)/TILE), so player.x is the
  // sprite's LEFT EDGE and the half-tile is already accounted for. Adding it
  // here too lands the knight one tile over and he faces empty floor — which
  // presents as doAction() finding nothing and falling through to a sword swing.
  K.$(`player.x=${(tx + d[0]) * TP}; player.y=${(ty + d[1]) * TP}; player.dir='${d[2]}';`);
  clearUi();
  // FINDING, not a harness detail: on keyboard the A-BUTTON KEYS DO NOT
  // INTERACT. The keydown handler routes ' ' and Enter to doAction(), and
  // j / z to doAttack() ONLY. Just the touch Ⓐ does both, via
  // aPress()'s `if(!doAction(true)) doAttack()`. So a desktop player standing
  // at a lampstand pressing J swings a sword at it. Space is the interact key.
  K.key.tap(' ');
}

// ── set up a doctrine floor the way the game does ──────────────────────────
K.$('place={kind:"dungeon"};');
K.$('dungeon.townId=3; dungeon.floors=getChapelFloors(3); dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};');
const doctrineIdx = K.dungeon.floors.indexOf(K.FLOOR.doctrine);
ok('chapel 3 has a doctrine floor', doctrineIdx >= 0, `floor index ${doctrineIdx}`);
K.$(`loadDungeonFloor(${doctrineIdx}, false);`);

const ring = K.dungeon._doctrineRing;
const order = K.dungeon._candles;          // canonical order = the answer
ok('the ring loaded', ring && ring.length === 5, `${ring ? ring.length : 0} stands`);

// ── pressing Ⓐ on the WRONG stand gutters it and keeps progress ────────────
// Pick a stand that is not next in sequence.
const wrong = order[2];
const litBefore = (K.dungeon.candleLit[doctrineIdx] || 0);
faceAndAct(wrong.x, wrong.y, 'down');
const litAfterWrong = (K.dungeon.candleLit[doctrineIdx] || 0);
ok('wrong stand does not advance the sequence',
   litAfterWrong === litBefore, `lit ${litBefore} -> ${litAfterWrong}`);
ok('wrong stand leaves the tile unlit',
   K.dungeon.grid[wrong.y][wrong.x] === K.T_CANDLE,
   `tile is ${K.dungeon.grid[wrong.y][wrong.x]}`);

// ── the correct sequence, one Ⓐ press at a time ────────────────────────────
let litSteps = [];
for (let i = 0; i < order.length; i++) {
  const c = order[i];
  faceAndAct(c.x, c.y, 'down');
  litSteps.push(K.dungeon.candleLit[doctrineIdx] || 0);
}
ok('lighting in canonical order advances every step',
   JSON.stringify(litSteps) === JSON.stringify([1, 2, 3, 4, 5]),
   `progress after each press: ${litSteps.join(', ')}`);

ok('every stand renders as lit afterwards',
   ring.every(r => K.dungeon.grid[r.y][r.x] === K.T_CANDLE_LIT),
   ring.map(r => K.dungeon.grid[r.y][r.x]).join(','));

// ── the seal must actually be gone ─────────────────────────────────────────
let sealsLeft = 0;
for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) sealsLeft++;
ok('the stone is rolled once the last stand is lit',
   sealsLeft === 0, `${sealsLeft} seal tiles remain`);

// ── the pedestal responds to Ⓐ ─────────────────────────────────────────────
faceAndAct(7, 5, 'down');
ok('pressing Ⓐ at the pedestal opens the tablet',
   K.dialogue && K.dialogue.open === true,
   `dialogue.open=${K.dialogue && K.dialogue.open}`);

// ── the maze floor key chest, same way ─────────────────────────────────────
K.$('dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};');
K.$('loadDungeonFloor(0, false);');
const pd = K.dungeon._podium, pz = K.dungeon._plaza;
ok('the maze floor has a plaza', !!pd && !!pz, pd ? `centre ${pd.x},${pd.y}` : 'none');
ok('the plaza starts empty', K.dungeon.grid[pd.y][pd.x] === K.T_PLAZA,
   'no chest until the floor is clear');
ok('the plaza is entered only by its steps',
   K.dungeon.grid[pz.stepY][pz.stepX] === K.T_PLAZA_STEP && K.walkable(pz.stepX, pz.stepY),
   `steps at ${pz.stepX},${pz.stepY}`);
let mazeSealsBefore = 0;
for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) mazeSealsBefore++;
// Find the stone.
let sx = -1, sy = -1;
for (let y = 0; y < K.dungeon.grid.length; y++)
  for (let x = 0; x < K.dungeon.grid[0].length; x++)
    if (K.dungeon.grid[y][x] === K.T_SEAL) { sx = x; sy = y; }

// The stone refuses without the key.
faceAndAct(sx, sy, 'up');
ok('the stone will not shift without the key',
   K.dungeon.grid[sy][sx] === K.T_SEAL, 'still barred');

// Clear the floor; the frame loop makes the chest appear.
K.$('demons.forEach(d=>{ d.alive=false; }); updatePodium();');
ok('the chest appears on the platform when the last demon falls',
   K.dungeon.grid[pd.y][pd.x] === K.T_PODIUM_UP, 'tile became the reward chest');
ok('the chest is solid — you stand before it, not on it',
   !K.walkable(pd.x, pd.y));

// Take the key.
faceAndAct(pd.x, pd.y, 'up');
ok('the chest gives a temporary key', K.dungeon.hasKey === true,
   'dungeon.hasKey set');
ok('taking the key does NOT move the stone by itself',
   K.dungeon.grid[sy][sx] === K.T_SEAL, 'the key has to be carried to it');

// Carry it to the stone.
faceAndAct(sx, sy, 'up');
ok('the key is spent on the stone', K.dungeon.hasKey === false,
   'temporary: consumed in use');
let mazeSealsAfter = 0;
for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) mazeSealsAfter++;
ok('using the key at the stone rolls it aside',
   mazeSealsBefore > 0 && mazeSealsAfter === 0,
   `seals ${mazeSealsBefore} -> ${mazeSealsAfter}`);

// ── keyboard/touch parity ──────────────────────────────────────────────────
// The A keys must now do what the Ⓐ button does: act if there is something to
// act on, swing if there is not.
K.$('dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};');
K.$(`loadDungeonFloor(${doctrineIdx}, false);`);
const first = K.dungeon._candles[0];
const d2 = { up: [0, 1, 'up'], down: [0, -1, 'down'] }.down;
K.$(`player.x=${first.x * TP}; player.y=${(first.y - 1) * TP}; player.dir='down';`);
clearUi();
K.key.tap('j');
ok('J interacts, matching the touch Ⓐ button',
   (K.dungeon.candleLit[doctrineIdx] || 0) === 1,
   `lit ${K.dungeon.candleLit[doctrineIdx] || 0} after one J press at a lampstand`);

// And Space must still work — the fix must not have moved interaction, only widened it.
K.$('dungeon.candleLit={};');
K.$(`loadDungeonFloor(${doctrineIdx}, false);`);
K.$(`player.x=${first.x * TP}; player.y=${(first.y - 1) * TP}; player.dir='down';`);
clearUi();
K.key.tap(' ');
ok('Space still interacts',
   (K.dungeon.candleLit[doctrineIdx] || 0) === 1,
   `lit ${K.dungeon.candleLit[doctrineIdx] || 0} after one Space press`);

// A HELD key must still spam attacks rather than churning doAction().
K.$('dungeon.candleLit={};');
K.$(`loadDungeonFloor(${doctrineIdx}, false);`);
K.$(`player.x=${first.x * TP}; player.y=${(first.y - 1) * TP}; player.dir='down';`);
clearUi();
K.key.down('j', { repeat: true });
ok('a HELD J still goes to the sword, not to doAction',
   (K.dungeon.candleLit[doctrineIdx] || 0) === 0,
   'key-repeat does not light the stand');

done('playthrough');

// suite/trade.js — the Trade Empire: materials, contracts, carts, posts, managers.
//
// Played through the game's own entry points: doAction() at the board and the
// carts, the shopkeeper's talk, the trade menu's rows, the wagon menu, driving
// and tryDeliver() at a chapel door, tradeTick() for the managers' clock, and a
// buildSaveData/applySaveData round trip.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('trade');
const T = K.TILE;
const rows = () => K.$(`tmenu.open ? tmenu.build().rows.map(r=>r.label.replace(/<[^>]+>/g,'')) : null`);
const pick = (re) => K.$(`(()=>{ const rs=tmenu.build().rows; const i=rs.findIndex(r=>${re}.test(r.label.replace(/<[^>]+>/g,''))); if(i<0) return 'no row'; tmenu.cursor=i; tmenuSelect(); return tmenu.msg; })()`);

K.$(`place={kind:'overworld'}; boot.done=true; dialogue.open=false; menu.open=false; demons.length=0;
     for(let i=0;i<10;i++) chapelProgress[i]=true; gold=0;`);

// ── locked until the Demon Hunt is done ──
K.$(`hunt.won=false; hunt.done=false; wagon.unlocked=false;`);
K.$(`player.x=${K.TRADE_BOARD.x}*TILE; player.y=${(K.TRADE_BOARD.y + 1)}*TILE; player.dir='up'; doAction();`);
ok('before the Demon Hunt the board does nothing', !K.$(`tmenu.open`));
ok('and shopkeepers just sell their wares', K.$(`(()=>{ place={kind:'interior',id:'tw_shop',floor:0}; const t=(TRADE_ON&&wagon.unlocked)?tradeShopTown(place.id):null; place={kind:'overworld'}; return t===null; })()`));
K.$(`hunt.won=true; hunt.done=true; homesteadKey=true; unlockWagonIfReady(); bannerT=0;`);
ok('after it, the trade roads open', K.$(`wagon.unlocked`));

// ── the materials ──
check('nine towns, nine materials', K.$(`Object.keys(MATERIALS).length`), 9);
ok('each is a good with a price, and starts at 0 in the packs', K.$(`Object.keys(MATERIALS).every(k=>GOODS[k] && GOODS[k].value>0 && inventory[k]===0)`));
ok('an old save missing them still reads 0 (the late defaults pass covers them)', K.$(`Object.keys(MATERIALS).every(k=>k in INVENTORY_DEFAULTS)`));

// ── the Homestead board ──
K.$(`player.x=${K.TRADE_BOARD.x}*TILE; player.y=${K.TRADE_BOARD.y + 1}*TILE; player.dir='up'; doAction();`);
ok('facing the board opens it', K.$(`tmenu.open`));
const offers = K.$(`empire.offers.home`);
check('five contracts are posted', offers.length, 5);
const reach = K.$(`tradeReachFrom(WAGON_HOME.x,WAGON_HOME.y)`);
ok('only for towns the Old Mule can actually drive to', offers.every(c => reach[c.tid]), offers.map(c => c.tid).join(','));
ok('each asks for 1–3 goods and 3–10 crates', offers.every(c => { const ks = Object.keys(c.items), n = ks.reduce((s, k) => s + c.items[k], 0); return ks.length >= 1 && ks.length <= 3 && n >= 3 && n <= 10; }));
ok('never for a town’s own material', offers.every(c => Object.keys(c.items).every(g => !K.$(`MATERIALS['${g}'] && MATERIALS['${g}'].town===${c.tid}`))));
// pay: farther, more varied, bigger pays more — check the formula's direction with fixed contracts
{ const p = (items, tid) => K.$(`contractPay(${JSON.stringify(items)}, ${tid})`);
  const near = K.$(`(()=>{ let best=null; for(let t=0;t<9;t++){ if(!DELIVERY_POINTS[t]) continue; if(best===null||townDistance(t)<townDistance(best)) best=t; } return best; })()`);
  const far = K.$(`(()=>{ let best=null; for(let t=0;t<9;t++){ if(!DELIVERY_POINTS[t]) continue; if(best===null||townDistance(t)>townDistance(best)) best=t; } return best; })()`);
  ok('farther pays more', p({ wheat: 5 }, far) > p({ wheat: 5 }, near), `${p({ wheat: 5 }, near)}g near vs ${p({ wheat: 5 }, far)}g far`);
  ok('more variety pays more (same crates, same value)', p({ timber: 2, wool: 2, coal: 2 }, near) > p({ timber: 6 }, near) * 0.99 + 1);
  ok('more crates pay more per crate', p({ wheat: 10 }, near) / 10 > p({ wheat: 5 }, near) / 5); }
// take three, refuse a fourth
for (let i = 0; i < 3; i++) pick('/^[A-Z][a-z]+ of /');
check('you can hold three', K.$(`empire.active.length`), 3);
ok('a fourth is refused', /three|3 contracts/.test(pick('/^[A-Z][a-z]+ of /')));
check('the board refills to five', K.$(`empire.offers.home.length`), 5);
K.$(`closeTMenu();`);

// ── a delivery, end to end: buy at the market, load the Old Mule, drive, deliver ──
const c0 = K.$(`empire.active[0]`);
K.$(`gold=5000; for(const g in empire.active[0].items) inventory[g]=(inventory[g]||0)+empire.active[0].items[g];`);
// the material, bought from its own shopkeeper (if the contract wants one)
{ const mats = Object.keys(c0.items).filter(g => K.$(`!!MATERIALS['${g}']`));
  const mk = mats[0] || 'timber'; const tid = K.$(`MATERIALS['${mk}'].town`);
  const interior = K.$(`TRADE_TOWNS[${tid}].interior`);
  K.$(`place={kind:'interior',id:'${interior}',floor:0}; openTMenu(shopTradeMenu(${tid}));`);
  ok(`${K.$(`TRADE_TOWNS[${tid}].keeper`)} sells ${mk}`, rows().some(r => new RegExp('Buy .*' + K.$(`MATERIALS['${mk}'].name`)).test(r)));
  const g0 = K.$(`gold`), n0 = K.$(`inventory['${mk}']`);
  pick('/^Buy 5/');
  check('buying 5 costs 5× the price', [K.$(`gold`), K.$(`inventory['${mk}']`)], [g0 - 5 * K.$(`MATERIALS['${mk}'].value`), n0 + 5]);
  ok('"Browse wares" is still there', rows().some(r => /Browse wares/.test(r)));
  ok('the post is locked until 1,000g of contract earnings', rows().some(r => /Trade post/.test(r) && /🔒/.test(r)));
  K.$(`closeTMenu(); place={kind:'overworld'};`); }
// load the cart at the bay
K.$(`wagon.x=WAGON_HOME.x; wagon.y=WAGON_HOME.y; wagon.cargo={}; player.x=WAGON_HOME.x*TILE; player.y=(WAGON_HOME.y-1)*TILE; player.dir='down'; doAction();`);
ok('facing the Old Mule opens its load menu', K.$(`wagonMenu.open`));
ok('named for the cart', /Old Mule/.test(K.$(`document.getElementById('banner').innerHTML`)));
K.$(`for(const g in empire.active[0].items){ for(let i=0;i<empire.active[0].items[g];i++){ const rs=wagonRows(); wagonMenu.cursor=rs.findIndex(r=>r.kind==='load'&&r.good===g); wagonMenuSelect(); } }`);
check('its goods are loaded', K.$(`Object.keys(empire.active[0].items).every(g=>wagon.cargo[g]===empire.active[0].items[g])`), true);
K.$(`closeWagonMenu(); startDriving();`);
ok('hitched up and driving', K.$(`player.driving`));
// arrive at the chapel door and press A
{ const p = K.$(`DELIVERY_POINTS[${c0.tid}]`); const g0 = K.$(`gold`);
  K.$(`player.x=${p.x}*TILE; player.y=${p.y}*TILE; tryDeliver();`);
  check('delivered: paid in full', K.$(`gold`) - g0, c0.pay);
  ok('the contract is done', !K.$(`empire.active.some(c=>c.id===${c0.id})`));
  check('it counts toward the town', K.$(`empire.done[${c0.tid}]`), 1);
  check('and toward contract earnings', K.$(`empire.earned`), c0.pay); }
// a town with no contract for you says so
{ const other = K.$(`(()=>{ for(let t=0;t<9;t++) if(DELIVERY_POINTS[t] && !empire.active.some(c=>c.tid===t)) return t; })()`);
  const p = K.$(`DELIVERY_POINTS[${other}]`);
  K.$(`bannerT=0; player.x=${p.x}*TILE; player.y=${p.y}*TILE; tryDeliver();`);
  ok('a town you hold no contract for tells you so', /No contracts/.test(K.$(`document.getElementById('banner').innerHTML`))); }
K.$(`player.driving=false;`);

// ── trade posts ──
const TID = 3;   // Thornwood
K.$(`empire.earned=1000; gold=10000; place={kind:'interior',id:'tw_shop',floor:0}; openTMenu(shopTradeMenu(${TID}));`);
ok('with 1,000g earned, the post is for sale', rows().some(r => /Buy the Thornwood Trade Post/.test(r)));
{ const cost = K.$(`postCost(${TID})`); ok('priced 2,000–4,000g by distance', cost >= 2000 && cost <= 4000, `${cost}g`);
  const g0 = K.$(`gold`); pick('/Buy the Thornwood Trade Post/');
  check('buying it costs that', g0 - K.$(`gold`), cost); }
ok('the post is yours', K.$(`tradeOwns(${TID})`));
ok('its contracts are open', rows().some(r => /Contracts/.test(r)));
ok('never for its own town', K.$(`(empire.offers[${TID}]||[]).every(c=>c.tid!==${TID})`) && K.$(`(empire.offers[${TID}]||[]).length`) > 0);
K.$(`closeTMenu(); place={kind:'overworld'};`);
{ const s = K.$(`TRADE_TOWNS[${TID}].spot`);
  ok('the Thornwood Bramble and its cart wait outside the shop', K.$(`!!tradeCarts['${TID}'] && tradeCarts['${TID}'].x===${s[0]} && tradeCarts['${TID}'].y===${s[1]}`));
  ok('solid: you walk around it', K.$(`npcTileBlocked(${s[0]},${s[1]}) && npcTileBlocked(${s[0] + 1},${s[1]})`));
  // use it: swap carts
  K.$(`player.x=${s[0]}*TILE; player.y=${s[1] + 1}*TILE; player.dir='up'; doAction();`);
  check('A at the Bramble makes it the cart in use', K.$(`wagon.cur`), String(TID));
  ok('and opens its load menu', K.$(`wagonMenu.open`) && /Thornwood Bramble/.test(K.$(`document.getElementById('banner').innerHTML`)));
  ok('the Old Mule waits where it was parked', K.$(`!!tradeCarts.homestead && tradeCarts.homestead.x===WAGON_HOME.x`));
  K.$(`closeWagonMenu();`); }

// ── managers ──
K.$(`place={kind:'interior',id:'tw_shop',floor:0}; openTMenu(shopTradeMenu(${TID}));`);
ok('a manager is locked until 8 contracts for the town', rows().some(r => /Hire a manager/.test(r) && /🔒/.test(r)));
K.$(`empire.done[${TID}]=8; showTMenu();`);
ok('after 8, the Trader can be hired', rows().some(r => /Hire the Trader/.test(r)));
{ const g0 = K.$(`gold`); pick('/Hire the Trader/'); check('for 1,500g', g0 - K.$(`gold`), 1500); }
ok('the manager is at work', K.$(`!!empire.posts[${TID}].mgr`));
K.$(`closeTMenu(); place={kind:'overworld'};`);
// run the clock: one full job, then the rest
K.$(`tradeTick(16);`);
const job = K.$(`empire.posts[${TID}].mgr.job`);
ok('one contract at a time, on a round-trip clock', job && job.dur >= 20 && job.dur <= 240, job && `${job.dur}s to ${job.to}`);
ok('never to its own town', job.to !== TID);
ok('net of goods and a 20% wage, still a profit', job.net > 0);
K.$(`for(let i=0;i<${Math.ceil(job.dur * 1000 / 100)};i++) tradeTick(100);`);
check('when the clock runs out, the profit is banked', K.$(`empire.posts[${TID}].mgr.bank`), job.net);
check('one run counted', K.$(`empire.posts[${TID}].mgr.runs`), 1);
// the clock never runs while the game is closed — it only moves through tradeTick; a save carries it
K.$(`tradeTick(5000);`);
const mid = K.$(`JSON.parse(JSON.stringify(empire.posts[${TID}].mgr.job))`);
// fill the strongbox: ten runs, then it waits
K.$(`for(let i=0;i<20000 && empire.posts[${TID}].mgr.runs<10;i++) tradeTick(1000);`);
check('the strongbox holds ten runs', K.$(`empire.posts[${TID}].mgr.runs`), 10);
{ const b = K.$(`empire.posts[${TID}].mgr.bank`); K.$(`for(let i=0;i<500;i++) tradeTick(1000);`);
  check('then the manager waits for you', K.$(`empire.posts[${TID}].mgr.bank`), b);
  K.$(`place={kind:'interior',id:'tw_shop',floor:0}; openTMenu(shopTradeMenu(${TID}));`);
  const g0 = K.$(`gold`); pick('/Collect/');
  check('collecting pays it all out', K.$(`gold`) - g0, b);
  check('and empties the box', [K.$(`empire.posts[${TID}].mgr.bank`), K.$(`empire.posts[${TID}].mgr.runs`)], [0, 0]);
  K.$(`closeTMenu(); place={kind:'overworld'};`); }

// ── saves ──
K.$(`tradeTick(3000);`);
{ const snap = K.$(`JSON.parse(JSON.stringify(buildSaveData()))`);
  ok('the save carries the empire under its own key', !!snap.empire && snap.trade && 'sold' in snap.trade, 'empire + the old sales ledger both present');
  globalThis.__snap = snap;
  const before = K.$(`JSON.stringify({e:empire.earned, d:empire.done, a:empire.active.map(c=>c.id), o:Object.keys(empire.offers), p:Object.keys(empire.posts), j:empire.posts[${TID}].mgr.job, cur:wagon.cur, carts:Object.keys(tradeCarts).sort()})`);
  K.$(`applySaveData(JSON.parse(FRESH_STATE));`);
  check('a fresh game starts with no empire', K.$(`[empire.earned, Object.keys(empire.posts).length, empire.active.length, wagon.cur]`), [0, 0, 0, 'homestead']);
  ok('and no post carts', K.$(`Object.keys(tradeCarts).length===0`));
  K.$(`applySaveData(globalThis.__snap);`);
  const after = K.$(`JSON.stringify({e:empire.earned, d:empire.done, a:empire.active.map(c=>c.id), o:Object.keys(empire.offers), p:Object.keys(empire.posts), j:empire.posts[${TID}].mgr.job, cur:wagon.cur, carts:Object.keys(tradeCarts).sort()})`);
  check('loading restores all of it — contracts, posts, carts, and the manager mid-run', after, before);
  const old = JSON.parse(JSON.stringify(snap)); delete old.empire; globalThis.__old = old;
  K.$(`applySaveData(globalThis.__old);`);
  check('a save from before the trade empire loads as a fresh start in it', K.$(`[empire.earned, Object.keys(empire.posts).length, wagon.cur]`), [0, 0, 'homestead']);
  ok('with the old sales ledger untouched', K.$(`trade.sold`) === old.trade.sold); }

// ── the farm stand buys harvest, not market stock ──
ok('materials are not sold at the farm stand (no free livery trade-count)', /item==='goldenFish'\|\|item==='sacredScroll'\|\|MATERIALS\[item\]/.test(require('fs').readFileSync(__dirname + '/../game.js', 'utf8')));
done('trade');

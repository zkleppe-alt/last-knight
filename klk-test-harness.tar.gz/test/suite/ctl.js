// suite/ctl.js — ⌨ the keyboard controls map (2026-10-09-ct).
//
// Zak: "My PC players noticed that there's no button for potions they could find. I think for PC
// we should add a controls map where they can actually choose and adjust their controls."
// Driven through the game's own keydown/keyup listeners, the way a player's keyboard is.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('ctl');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[]; place={kind:'overworld'};
  localStorage.removeItem('klk_controls'); ctlLoad(); ctl.hinted=true;`);
const clear = () => K.$(`dialogue.open=false; menu.open=false; petName.open=false; saveio.open=false; held.up=held.down=held.left=held.right=false;`);
const drinkWith = (k) => { clear(); K.$(`_lastPotAt=-99999; inventory.potion=5; player.hp=10;`); K.key.down(k); K.key.up(k); return K.$(`inventory.potion`); };

// ── defaults change nothing ──
ok('the defaults are not custom, so the old handlers run untouched', K.$(`!ctlCustom()`));
check('H drinks a potion by default', drinkWith('h'), 4);
check('Q drinks a potion by default', drinkWith('q'), 4);
check('the hidden old key Z still strikes/acts by default (not silenced)', K.$(`(()=>{ const e={key:'z',type:'keydown'}; ctlKey(e); return e.key; })()`), 'z');

// ── the screen ──
clear(); K.$(`toggleMenu(); setMenuTab(TAB.system); menu.focus='list';`);
const sysRows = K.$(`menuRows().map(r=>r.id||r.n)`);
check('System lists ⌨ Keyboard Controls right after Text Size', sysRows.slice(0, 4), ['sfx', 'music', 'text', 'controls']);
K.$(`renderMenu()`);
ok('the row reads "Keyboard Controls" and names the potion key', K.$(`gmEl().innerHTML.indexOf('Keyboard Controls')>=0 && gmEl().innerHTML.indexOf('potion is H / Q')>=0`));
K.$(`menu.cursor=menuRows().findIndex(r=>r.id==='controls');`); K.key.tap('j', 0);
check('Ⓐ on it opens the controls screen', K.$(`[menu.sub, menuRows().length]`), ['controls', 12]);
ok('the screen shows every action and its keys', K.$(`(()=>{ const h=gmEl().innerHTML; return ['Drink quick potion','Guard','Surface','Reset to defaults'].every(s=>h.indexOf(s)>=0) && h.indexOf('>H<')>=0 && h.indexOf('>Q<')>=0; })()`));

// ── rebinding ──
const potionRow = K.$(`ctlRows().findIndex(r=>r.id==='potion')`);
K.$(`menu.cursor=${potionRow}; ctl.col=0;`); K.key.tap('j', 0);
check('Ⓐ on the potion row waits for a key', K.$(`ctl.listen`), { act: 'potion', slot: 0 });
ok('…and says so', K.$(`gmEl().innerHTML.indexOf('press a key')>=0`));
K.key.tap('p', 0);
check('pressing P puts the potion on P', K.$(`ctl.binds.potion`), ['p', 'q']);
ok('the menu stayed open (the key was used up, not acted on)', K.$(`menu.open && menu.sub==='controls'`));
ok('it is saved on this computer', K.$(`JSON.parse(localStorage.getItem('klk_controls')).binds.potion[0]==='p'`));
check('P now drinks', drinkWith('p'), 4);
check('H no longer drinks (given away)', drinkWith('h'), 5);
check('Q still drinks (kept as the second key)', drinkWith('q'), 4);

// stealing a key from another action
clear(); K.$(`toggleMenu(); setMenuTab(TAB.system); menu.focus='list'; menu.sub='controls'; menu.cursor=${potionRow}; ctl.col=1;`);
K.key.tap('j', 0); K.key.tap('e', 0);
check('E on the second potion key', K.$(`ctl.binds.potion`), ['p', 'e']);
K.$(`menu.cursor=${potionRow}; ctl.col=1;`); K.$(`menuSelect()`); K.key.tap('j', 0);
check('J moved from Ⓐ to the potion', K.$(`[ctl.binds.act, ctl.binds.potion]`), [[null, 'space'], ['p', 'j']]);
ok('…and the screen says where it came from', K.$(`ctl.msg.indexOf('taken from')>=0`));

// Esc keeps, Enter is fixed, ⌫ clears
K.$(`menu.cursor=0; ctl.col=0; menuSelect();`); K.key.tap('Escape', 0);
check('Esc while waiting keeps the old key and the menu', K.$(`[ctl.binds.up[0], menu.open, menu.sub]`), ['w', true, 'controls']);
K.$(`menuSelect();`); K.key.tap('Enter', 0);
check('Enter cannot be taken', K.$(`[ctl.binds.up[0], ctl.msg.indexOf('fixed')>=0]`), ['w', true]);

// movement on a new key
K.$(`menuSelect();`); K.key.tap('i', 0);
check('I on Up', K.$(`ctl.binds.up`), ['i', 'arrowup']);
clear(); K.key.down('i');
check('holding I walks up', K.$(`held.up`), true);
K.key.up('i');
check('letting go stops', K.$(`held.up`), false);
clear(); K.key.down('w');
check('W, given away, does nothing', K.$(`held.up`), false);
K.key.up('w'); K.key.down('ArrowUp');
check('the arrow still walks', K.$(`held.up`), true);
K.key.up('ArrowUp');
check('Space (Ⓐ second key) is now the canonical Ⓐ key', K.$(`(()=>{ const e={key:' ',type:'keydown'}; ctlKey(e); return e.key; })()`), 'j');
check('Enter still confirms whatever the map', K.$(`(()=>{ const e={key:'Enter',type:'keydown'}; ctlKey(e); return e.key; })()`), 'Enter');

// typing a name is never remapped
K.$(`petName.open=true;`);
check('typing in the name box is left alone', K.$(`(()=>{ const e={key:'i',type:'keydown'}; ctlKey(e); return e.key; })()`), 'i');
clear();

// ← → picks the key column; Ⓑ goes back to System
K.$(`toggleMenu(); setMenuTab(TAB.system); menu.focus='list'; menu.sub='controls'; menu.cursor=0; ctl.col=0;`);
K.key.tap('ArrowRight', 0);
check('→ picks the second key and stays on the screen', K.$(`[ctl.col, menu.tab===TAB.system, menu.sub]`), [1, true, 'controls']);
K.$(`menuBackToRail();`);
check('Ⓑ returns to System, on the Controls row', K.$(`[menu.sub, menuRows()[menu.cursor].id, menu.open]`), [null, 'controls', true]);

// reset
K.$(`menu.sub='controls'; menu.cursor=ctlRows().findIndex(r=>r.kind==='ctlreset'); menuSelect();`);
ok('Reset puts every key back', K.$(`!ctlCustom() && ctl.binds.potion[0]==='h' && ctl.binds.act[0]==='j'`));
check('H drinks again after reset', (K.$(`menu.open=false`), drinkWith('h')), 4);

// a saved map survives a reload; a broken one falls back
K.$(`localStorage.setItem('klk_controls', JSON.stringify({v:1, binds:{potion:['g','q']}, hinted:true})); ctlLoad();`);
check('a saved map loads', K.$(`[ctl.binds.potion, ctl.binds.up]`), [['g', 'q'], ['w', 'arrowup']]);
K.$(`localStorage.setItem('klk_controls', '{oops'); ctlLoad();`);
ok('a broken saved map falls back to defaults', K.$(`!ctlCustom()`));

// the one-time keyboard hint
K.$(`ctl.hinted=false; menu.open=false; dialogue.open=false;`); K.key.tap('d', 0);
ok('the first key in the field marks the hint shown, once', K.$(`ctl.hinted===true && JSON.parse(localStorage.getItem('klk_controls')).hinted===true`));

// real frames with the screen open
K.$(`toggleMenu(); setMenuTab(TAB.system); menu.focus='list'; menu.sub='controls'; renderMenu();`);
ok('real frames run with the controls screen open', K.$(`(()=>{ try{ for(let i=0;i<3;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e); } })()`) === true);
K.$(`localStorage.removeItem('klk_controls'); ctlLoad(); menu.open=false; menu.sub=null;`);
done('ctl');

// suite/mazes.js — every chapel maze can be walked, and Ruth's hall can be won (2026-10-13-mz).
//
// Zak: "some of the mazes for chapel Dungeons may be impassable, also that the boss where you can earn the electric
// armor for saving all the people kills the people to fast. can we check those".
// Found: Hellgate's first maze had its whole upper half (climbs, walkway, stair) cut off from the door on every visit,
// and smaller pockets were sealed off in Ironhold, Crystalpeak and Stormgate. In Ruth's hall the knight's own sword
// killed her people (1 HP, no guard), the people never came back after a fall, and with none left no bolt was ever
// called again — so the blade could never be charged and the Thunder Lord could not be beaten.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('mazes');
K.$('boot.done=true; dialogue.open=false; menu.open=false;');
const TP = K.TILE;
const flood = () => { const g = K.dungeon.grid, H = g.length, W = g[0].length;
  const sx = Math.floor((K.player.x + TP / 2) / TP), sy = Math.floor((K.player.y + TP / 2) / TP);
  const seen = new Set([sy * 1000 + sx]), st = [[sx, sy]];
  while (st.length) { const [x, y] = st.pop(); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const k = ny * 1000 + nx; if (seen.has(k) || !K.walkable(nx, ny)) continue; seen.add(k); st.push([nx, ny]); } }
  return seen; };
const usable = (s, x, y) => [[x, y], [x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]].some(([a, b]) => s.has(b * 1000 + a));

// ── every floor of every chapel: everything you need can be reached ──
const lockedOut = [], stranded = [], unguarded = [];
for (let town = 0; town <= 9; town++) {
  K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.forest=false; dungeon.floors=getChapelFloors(${town}); dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={}; dungeon.cleared={};`);
  const floors = K.dungeon.floors;
  for (let i = 0; i < floors.length; i++) {
    K.$(`loadDungeonFloor(${i},false)`);
    const ft = floors[i], maze = ft === K.FLOOR.maze || ft === K.FLOOR.maze2, g = K.dungeon.grid;
    const pre = flood(); const hadSeal = g.some(r => r.includes(K.T_SEAL));
    K.$(`openSeal()`); const post = flood();
    g.forEach((r, y) => r.forEach((t, x) => {
      if ((t === 2 || t === 11 || t === 5) && !usable(post, x, y)) lockedOut.push(`chapel ${town} floor ${ft}: ${t === 5 ? 'chest' : 'stair'} ${x},${y}`);
      if (maze && t === 2 && hadSeal && usable(pre, x, y)) unguarded.push(`chapel ${town} floor ${ft}`);
      if (maze && y >= 3 && K.$(`walkable(${x},${y})`) && !post.has(y * 1000 + x)) stranded.push(`chapel ${town} floor ${ft}: ${x},${y}`);
    }));
  }
}
check('every stair and every chest on every chapel floor can be reached', lockedOut, []);
check('no corner of any maze is sealed off from the door', stranded.slice(0, 5), []);
check('the stone still guards every maze stair until it rolls', unguarded, []);
check("Hellgate's first maze keeps its chest now (it was being swept away as unreachable)", K.$(`(()=>{ dungeon.townId=9; dungeon.floors=getChapelFloors(9); loadDungeonFloor(dungeon.floors.indexOf(FLOOR.maze),false); return dungeon.grid.flat().filter(t=>t===5).length; })()`), 1);

// ── walked the way a player must (2026-10-15: "the Hellgate chapel is still impossible to finish" — on the live build,
//    which predated the fix): reach and slay every demon, take the key from the platform, roll the stone, take the stair ──
K.$(`globalThis.__flood=function(){ const g=dungeon.grid, sx=Math.floor((player.x+8)/16), sy=Math.floor((player.y+8)/16); const s=new Set([sx+','+sy]), q=[[sx,sy]];
  while(q.length){ const [x,y]=q.pop(); for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(s.has(k)||!g[ny]||g[ny][nx]===undefined||!walkable(nx,ny)) continue; s.add(k); q.push([nx,ny]); } } return s; };
  globalThis.__goBeside=function(tx,ty){ const s=__flood(); for(const [dx,dy,dir] of [[0,1,'up'],[0,-1,'down'],[1,0,'left'],[-1,0,'right']]){ const x=tx+dx, y=ty+dy; if(s.has(x+','+y)){ player.x=x*16; player.y=y*16; player.dir=dir; return true; } } return false; };`);
const walked = [];
for (let t = 0; t <= 9; t++) {
  K.$(`for(const k in chapelProgress) delete chapelProgress[k]; place={kind:'dungeon'}; dungeon.townId=${t}; dungeon.forest=false; dungeon.floors=getChapelFloors(${t}); dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={}; dungeon.cleared={}; dungeon.hasKey=false;`);
  K.dungeon.floors.forEach((ft, i) => { if (ft !== K.FLOOR.maze && ft !== K.FLOOR.maze2) return;
    walked.push(`${t}/${i} ` + K.$(`(()=>{ loadDungeonFloor(${i},false); dialogue.open=false;
      for(const d of demons){ if(!d.alive) continue; const dx=Math.floor((d.x+8)/16), dy=Math.floor((d.y+8)/16); if(!__goBeside(dx,dy) && !__flood().has(dx+','+dy)) return 'a demon out of reach'; d.hp=0; d.alive=false; }
      updatePodium(); const p=dungeon._podium; if(!p || dungeon.grid[p.y][p.x]!==T_PODIUM_UP) return 'no key on the platform';
      if(!__goBeside(p.x,p.y)) return 'platform out of reach'; dialogue.open=false; doAction(); if(!dungeon.hasKey) return 'key not taken';
      let seal=null; dungeon.grid.forEach((r,y)=>r.forEach((v,x)=>{ if(v===T_SEAL) seal=[x,y]; })); if(!seal || !__goBeside(seal[0],seal[1])) return 'stone out of reach';
      dialogue.open=false; doAction(); if(dungeon.grid[seal[1]][seal[0]]===T_SEAL) return 'stone did not roll';
      let st=null; dungeon.grid.forEach((r,y)=>r.forEach((v,x)=>{ if(v===2) st=[x,y]; })); if(!st || !__flood().has(st[0]+','+st[1])) return 'stair out of reach';
      player.x=st[0]*16; player.y=st[1]*16; _stairGrace=0; const before=dungeon.floorIdx; checkTransitions(); return dungeon.floorIdx===before+1 ? 'up' : 'stair did not climb'; })()`)); });
}
check('every maze floor of every chapel can be played through: demons, key, stone, stair', walked.filter(w => !w.endsWith(' up')), []);

// ── Ruth's hall ──
const hall = () => K.$(`(()=>{ for(const k in chapelProgress) delete chapelProgress[k]; place={kind:'dungeon'}; dungeon.townId=7; dungeon.forest=false; dungeon.floors=getChapelFloors(7);
  dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={}; dungeon.cleared={}; dungeon.bossDead=false;
  loadDungeonFloor(dungeon.floors.indexOf(FLOOR.sanctum),false); stormTick(); return (dungeon.adds||[]).filter(a=>a.alive&&a.flock).length; })()`);
check('five of Ruth\'s people in the hall', hall(), 5);
// a swing that sweeps through one of them
const swung = K.$(`(()=>{ const a=dungeon.adds.find(a=>a.flock); player.x=a.x; player.y=a.y+TILE; player.dir='up'; player.swing=0; player.comboT=0; player.combo=0;
  equipItem('greatsword'); resolveSwing('heavy'); return [a.alive, a.hp]; })()`);
check("the knight's sword never touches them", swung, [true, 1]);
// a fall, and back into the hall
K.$(`dungeon.adds.filter(a=>a.flock).slice(0,3).forEach(a=>a.alive=false); dungeon._flockLost=3;`);
check('after a fall they are all back with the hall', hall(), 5);
check('…and the count of the lost starts again', K.$(`dungeon._flockLost`), 0);
// nobody left: the bolts come for the knight, and the blade can still be charged
K.$(`dungeon.adds.forEach(a=>{ if(a.flock) a.alive=false; }); dungeon._flockLost=5; dungeon._bolt=null; dungeon._boltT=99999; player.charge=0; player.chargeT=0; player.hp=player.maxHp;`);
K.$(`stormTick()`);
check('with nobody left, a bolt is called on the knight himself', K.$(`!!(dungeon._bolt && dungeon._bolt.self)`), true);
K.$(`dungeon._bolt.t=1; stormTick();`);
check('…he takes it, and his blade is charged — the Thunder Lord can still be beaten', K.$(`[chargedBlade(), player.hp<player.maxHp]`), [true, true]);
check('more time to reach them: ~3.5 s of warning, strikes a little further apart', K.$(`[BOLT_FUSE, BOLT_EVERY, BOLT_EVERY_MIN]`), [210, 330, 220]);
ok('real frames run in the hall with a bolt on the knight', K.$(`(()=>{ try{ dungeon._bolt={target:null,self:true,t:100}; for(let i=0;i<5;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`place={kind:'overworld'}; dungeon._bolt=null; player.charge=0;`);
done('mazes');

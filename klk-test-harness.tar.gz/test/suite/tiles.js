// suite/tiles.js — the tile-code registry.
//
// Tile codes are written into save data and into every cached dungeon grid. If
// a retired code is handed to a new object, a stale grid holding that number
// silently becomes something else — a wall becomes a chest, a floor becomes a
// seal. There is no migration and no version check on those numbers, so the
// only real protection is refusing to reuse them.
//
// 43 (T_PODIUM) is retired: it was the sunken podium that rose out of a
// corridor floor, superseded by the plaza. Saves made while it existed can
// still contain a 43.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');
const fs = require('fs');

console.log('tiles');

// Scanned from the STRIPPED source so a code mentioned in a _legacy comment is
// not mistaken for a live declaration.
const src = fs.readFileSync(__dirname + '/../game.stripped.js', 'utf8');

// Every `T_NAME = <number>` declaration, wherever it sits on the line.
const decls = new Map();          // name -> code
for (const m of src.matchAll(/\b(T_[A-Z0-9_]+)\s*=\s*(\d+)/g)) {
  decls.set(m[1], parseInt(m[2], 10));
}
ok('tile constants were found', decls.size > 10, `${decls.size} T_* constants`);

// ── no two names may share a code ──────────────────────────────────────────
const byCode = new Map();
for (const [name, code] of decls) {
  if (!byCode.has(code)) byCode.set(code, []);
  byCode.get(code).push(name);
}
const dupes = [...byCode.entries()].filter(([, names]) => names.length > 1);
ok('no tile code is claimed by two names', dupes.length === 0,
   dupes.map(([c, n]) => `${c}: ${n.join(' + ')}`).join(' | ') || 'all codes unique');

// ── the retired list ───────────────────────────────────────────────────────
// Add to this when a tile is removed. Never remove from it.
const RETIRED = {
  43: 'T_PODIUM — the sunken podium, replaced by the plaza. Saves from that ' +
      'build can still hold a 43; reusing it would turn those tiles into ' +
      'whatever claimed the number.',
};
for (const [code, why] of Object.entries(RETIRED)) {
  const claimed = byCode.get(Number(code)) || [];
  ok(`tile code ${code} stays retired`, claimed.length === 0,
     claimed.length ? `CLAIMED BY ${claimed.join(', ')} — ${why}` : why);
}

// ── the next free code, so nobody has to guess ─────────────────────────────
// The low codes (0 floor, 1 wall, 2 stair, 5 chest, 6 spawn, 8 entry, and
// friends) are written as BARE NUMBERS, not T_* constants, so the scan above
// cannot see them. Searching upward from zero would hand out a code that is
// already the floor. Only ever allocate above the highest declared constant.
const used = new Set([...decls.values(), ...Object.keys(RETIRED).map(Number)]);
const highest = Math.max(...used);
let next = highest + 1;
while (used.has(next)) next++;
ok('the next tile code is allocated above the highest in use', next > highest,
   `next free code is ${next} (highest in use: ${highest}; low codes 0-8 are ` +
   `bare numbers and are NOT in this registry)`);

// ── every live tile code must be drawable ──────────────────────────────────
// A code with no case in drawDungeonTile renders as blank floor, and every
// other assertion still passes. That shipped once already, with T_PEDESTAL
// and T_SIGN. Only dungeon-side tiles are checked; overworld codes are drawn
// by a different function.
const dungeonTiles = ['T_SEAL', 'T_CANDLE', 'T_CANDLE_LIT', 'T_TABLET',
                      'T_PEDESTAL', 'T_SIGN', 'T_PLAZA', 'T_PLAZA_STEP',
                      'T_PODIUM_UP', 'T_LEDGER', 'T_SHALLOW', 'T_PAGE_LIT', 'T_PAGE_DARK', 'T_STAND', 'T_BRAMBLE', 'T_GRAIN', 'T_BURNING', 'T_ASH', 'T_ALTAR', 'T_SCAR', 'T_COLUMN', 'T_MERE'];
// Take the WHOLE function, not a fixed byte window. A 20000-char slice worked
// until the function grew past it, at which point tiles reported as undrawn —
// an assertion failing because of its own arithmetic, the worst kind.
const fnStart = src.indexOf('function drawDungeonTile');
const nextFn = src.indexOf(String.fromCharCode(10) + 'function ', fnStart + 1);
const drawFn = src.slice(fnStart, nextFn > 0 ? nextFn : src.length);
const undrawn = dungeonTiles.filter(n => decls.has(n) && !new RegExp('t===' + n + '\\b').test(drawFn));
ok('every dungeon tile has a draw case', undrawn.length === 0,
   undrawn.join(', ') || `${dungeonTiles.length} dungeon tiles all drawn`);


// ── SCOPE HYGIENE ─────────────────────────────────────────────────────────
// Several helpers in this game are CLOSURE LOCALS, not top-level functions:
// hurtFromBoss, camX, camY, kcx, kcy all live inside draw() or the demons
// update. A top-level function that references one compiles fine and throws a
// ReferenceError the moment it runs — which presents as a mechanic silently not
// working, or as the frame dying. This has bitten twice: drawHearthvaleDark
// reaching for camX, and crystalTick reaching for hurtFromBoss.
const CLOSURE_LOCALS = ['hurtFromBoss', 'camX', 'camY', 'kcx', 'kcy'];
// The per-chapel tick and draw helpers, all of which are top-level.
const TOP_LEVEL_HELPERS = ['crystalTick', 'dustTick', 'thornTick', 'ironTick',
                           'ashTick', 'ashMark', 'stormTick', 'spawnFlock', 'shadowTick',
                           'endVeil', 'mirrorBurst', 'hellTick', 'inVoid',
                           'ironAdds', 'hearthvaleTick', 'hearthvaleRoam',
                           'snuffPage', 'snuffPageAt', 'sinkLedgers',
                           'igniteGrain', 'frostWarm', 'updatePodium'];
const leaks = [];
for (const fn of TOP_LEVEL_HELPERS) {
  const start = src.indexOf('function ' + fn + '(');
  if (start < 0) continue;
  const end = src.indexOf(String.fromCharCode(10) + 'function ', start + 1);
  const body = src.slice(start, end > 0 ? end : src.length);
  for (const local of CLOSURE_LOCALS) {
    // drawFrost/drawHearthvaleDark legitimately take camX/camY as PARAMETERS
    if (new RegExp('function ' + fn + '\\([^)]*\\b' + local + '\\b').test(body)) continue;
    if (new RegExp('\\b' + local + '\\s*\\(').test(body) ||
        new RegExp('[^.\\w]' + local + '\\b(?!\\s*[:,)])').test(body)) {
      leaks.push(`${fn} -> ${local}`);
    }
  }
}
ok('no top-level helper reaches for a closure local',
   leaks.length === 0,
   leaks.join(' | ') || `${TOP_LEVEL_HELPERS.length} helpers clean`);


// ── the livery table must not have swallowed itself ───────────────────────
// A misplaced insert once landed a whole livery INSIDE another one, making it a
// key of stormward rather than of LIVERIES. It parsed as perfectly valid JS and
// nothing complained — the entry simply did not exist. Check the shape.
const LIV = K.LIVERIES;
const liveryBad = [];
for (const [id, L] of Object.entries(LIV)) {
  if (!L || typeof L !== 'object') { liveryBad.push(`${id} is not an object`); continue; }
  if (typeof L.name !== 'string') liveryBad.push(`${id} has no name`);
  if (typeof L.TUNIC !== 'string') liveryBad.push(`${id} has no TUNIC`);
  for (const [k, v] of Object.entries(L)) {
    if (v && typeof v === 'object') liveryBad.push(`${id} contains a nested livery: ${k}`);
  }
}
ok('every livery is a flat palette entry', liveryBad.length === 0,
   liveryBad.join(' | ') || `${Object.keys(LIV).length} liveries clean`);
ok('the flag-locked liveries are all present',
   ['gilt', 'stormward', 'fallen'].every(id => LIV[id] && LIV[id].flag),
   ['gilt', 'stormward', 'fallen'].filter(id => !(LIV[id] && LIV[id].flag)).join(',') || 'gilt, stormward, fallen');

done('tiles');

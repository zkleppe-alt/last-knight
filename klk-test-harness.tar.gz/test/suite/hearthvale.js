// suite/hearthvale.js — Aiden's dark scriptorium.
//
// CHAPEL ONE. A player arrives having had four pages of Tobias and nothing else,
// so the floor has to be frightening without ever being unplayable. Most of what
// follows is about that floor, not the ceiling.
//
// These assertions RENDER. An earlier version of this suite passed 16/16 while
// the lighting was completely broken — the carve loop built a gradient and never
// filled with it — because nothing in it ever drew a pixel.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');

console.log('hearthvale');

const T = K.TILE, AW = K.ARENA_W, AH = K.ARENA_H;

function fresh() {
  const g = K.genHearthvaleArena();
  globalThis.__hg = g;
  K.$('place={kind:"dungeon"}; dungeon.townId=0; dungeon.floors=getChapelFloors(0); dungeon.floorIdx=2; dungeon.grid=globalThis.__hg; DH=dungeon.grid.length; DW=dungeon.grid[0].length; dungeon.bossDead=false; dungeon._snuff=null; dungeon._pagesTriumph=false;');
  return g;
}
const g = fresh();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [AW, AH]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

const pages = K.dungeon._pages;
check('six lecterns', pages.length, 6);
ok('all start lit', pages.every(p => p.lit));
ok('lecterns are solid — cover, like the pillars they replaced',
   pages.every(p => !K.walkable(p.x, p.y)));

// ── the room must never corner the knight ──────────────────────────────────
function flood() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}
let open = 0, reach = 0;
const seen = flood();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { open++; if (seen.has(y * 100 + x)) reach++; }
}
ok('every open tile is reachable — no lectern corners the knight', open === reach, `${reach}/${open}`);

const pockets = [];
for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
  if (!K.walkable(x, y)) continue;
  const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
  if (exits <= 1) pockets.push(`${x},${y}`);
}
ok('no dead-end pocket anywhere — a one-exit tile next to a charging boss is a death you cannot read',
   pockets.length === 0, pockets.join(' ') || 'every tile has two ways out');

// ── the lighting, measured off real pixels ─────────────────────────────────
function maskAlpha(litWanted) {
  const gg = fresh();
  const ps = K.dungeon._pages;
  // Snuff from the END so the lectern measured below — (3,3), pages[0] — stays
  // lit whenever litWanted is 6.
  for (let i = ps.length - 1; i >= litWanted; i--) ps[i].lit = false;
  K.$('VW=' + (AW * T) + '; VH=' + (AH * T) + '; player.x=7*TILE; player.y=6*TILE;');
  const cel = K.el('c'); cel.width = AW * T; cel.height = AH * T;
  cel.getContext('2d').clearRect(0, 0, cel.width, cel.height);
  K.$('drawHearthvaleDark(0,0);');
  const d = cel.getContext('2d').getImageData(0, 0, cel.width, cel.height).data;
  return (tx, ty) => d[((((ty * T + T / 2) * cel.width) + (tx * T + T / 2)) * 4) + 3] / 255;
}
const allLit = maskAlpha(6);
// Not < 0.15: the warm cast is painted back OVER the carved mask so a flame
// reads as a source rather than a hole, contributing ~0.22 of its own.
ok('a burning lectern throws a clear pool', allLit(3, 3) < 0.35,
   `at a lectern ${allLit(3,3).toFixed(2)}`);
ok('the dark between pools is genuinely dark — the hall is black, not dim',
   allLit(5, 5) > 0.8, `between pools ${allLit(5,5).toFixed(2)}`);
ok('a lectern is the brightest thing in the room', allLit(3, 3) < allLit(5, 5) - 0.4,
   `${allLit(3,3).toFixed(2)} vs ${allLit(5,5).toFixed(2)}`);
const fewLit = maskAlpha(2);
ok('with the lamps out, the room closes in', fewLit(1, 1) > 0.8, `corner ${fewLit(1,1).toFixed(2)}`);

const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');
ok('the overlay takes the camera as PARAMETERS, not from an outer scope',
   /function drawHearthvaleDark\(camX,\s*camY\)/.test(raw),
   'camX/camY are locals of draw() — referencing them at top level throws every frame');

// ── the imp comes into the light ───────────────────────────────────────────
fresh();
const stations = new Set();
const fake = {};
globalThis.__d = fake;
for (let i = 0; i < 30; i++) {
  fake._roamAt = 0;
  K.$('hearthvaleRoam(globalThis.__d);');
  if (fake._roamPage) stations.add(fake._roamPage.x + ',' + fake._roamPage.y);
}
ok('the imp visits more than one lectern', stations.size >= 3, `${[...stations].join(' | ')}`);
ok('it stands BESIDE a lectern, never inside one',
   K.walkable(Math.round(fake.anchorx / T), Math.round(fake.anchory / T)));
ok('it only ever stations at a BURNING lectern', fake._roamPage && fake._roamPage.lit);

// ── the chase ──────────────────────────────────────────────────────────────
function chase(hpFrac) {
  fresh();
  K.$('player.x=7*TILE; player.y=9*TILE;');
  K.$(`demons=[{boss:true, alive:true, hp:${Math.round(100*hpFrac)}, maxHp:100, x:7*TILE, y:5*TILE, level:3}];`);
}
const now = t => K.$('performance.now = (function(x){return function(){return x;};})(' + t + ');');
const litNow = () => K.dungeon._pages.filter(p => p.lit).length;

chase(1.0);
for (let i = 0; i < 20; i++) { now(i * 20000); K.$('hearthvaleTick();'); }
ok('no lamp goes out above half health', litNow() === 6, `${litNow()}/6 after 400s at full health`);

chase(0.4);
let T0 = 1000000;
now(T0); K.$('hearthvaleTick();');
now(T0 + 13000); K.$('hearthvaleTick();');
ok('below half health it moves for a lamp', K.dungeon._snuff.phase === 'moving');
ok('the threatened page is flagged so the player can see it coming',
   K.dungeon._snuff.page.threat === true);
ok('it goes for the lamp FURTHEST from the knight — the hardest to defend', (() => {
  const p = K.dungeon._snuff.page, kx = 7 * T, ky = 9 * T;
  const d = Math.hypot(p.x * T - kx, p.y * T - ky);
  return K.dungeon._pages.filter(q => q.lit).every(q => Math.hypot(q.x*T-kx, q.y*T-ky) <= d + 0.01);
})());

K.$('demons[0].x = dungeon._snuff.page.x*TILE; demons[0].y = (dungeon._snuff.page.y+1)*TILE;');
now(T0 + 13500); K.$('hearthvaleTick();');
ok('arriving at the lamp starts the channel', K.dungeon._snuff.phase === 'channel');
K.$('dungeon._snuff.hits = ' + K.SNUFF_INTERRUPT + ';');
now(T0 + 14000); K.$('hearthvaleTick();');
ok('enough hits drive it off and the page survives', litNow() === 6, `${litNow()}/6 — interrupted`);
ok('driving it off resets it to waiting',
   K.dungeon._snuff.phase === 'wait' && K.dungeon._snuff.page === null);

chase(0.4);
T0 = 2000000;
now(T0); K.$('hearthvaleTick();');
now(T0 + 13000); K.$('hearthvaleTick();');
K.$('demons[0].x = dungeon._snuff.page.x*TILE; demons[0].y = (dungeon._snuff.page.y+1)*TILE;');
now(T0 + 13500); K.$('hearthvaleTick();');
now(T0 + 17000); K.$('hearthvaleTick();');
ok('leaving it alone costs you the lamp', litNow() === 5, `${litNow()}/6 — the channel completed`);

chase(0.1);
let t = 3000000;
for (let i = 0; i < 60; i++) {
  t += 4000; now(t);
  K.$('if(dungeon._snuff && dungeon._snuff.page){ demons[0].x=dungeon._snuff.page.x*TILE; demons[0].y=(dungeon._snuff.page.y+1)*TILE; }');
  K.$('hearthvaleTick();');
}
ok('the room never falls below the minimum, however long the fight runs',
   litNow() >= 2, `${litNow()} burning after 60 attempts`);

// ── and the hall is bright once it falls ───────────────────────────────────
ok('the darkness lifts entirely on victory', /if\(dungeon\._pagesTriumph\) return;/.test(raw),
   'drawHearthvaleDark returns early — the hall is simply lit');
ok('victory relight is wired to the boss dying', /dungeon\.townId===0 && dungeon\._pages/.test(raw));

done('hearthvale');

// suite/ironhold.js — Miriam's armoury, and a thing that cannot be cut.
//
// "The Iron Wraith did not break her guard. It simply stood, and let her swing,
// and waited for the end of a strength that had never come from anywhere but
// herself."
//
// The fight is that sentence: the Wraith is untouchable while it merely stands,
// solid only while it commits to something of its own, and every swing at the
// shade pushes the next opening further away.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('ironhold');

const T = K.TILE;
const g = K.genIronholdArena();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

globalThis.__ig = g;
K.$('place={kind:"dungeon"}; dungeon.townId=1; dungeon.grid=globalThis.__ig; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');

const stands = K.dungeon._stands;
check('eight armour stands', stands.length, 8);
ok('stands are solid — cover to break a volley on',
   stands.every(s => !K.walkable(s.x, s.y)));

// ── room to run ────────────────────────────────────────────────────────────
// This fight is retreat. A cluttered or cornering floor makes patience
// impossible, so the geometry is held to a higher bar than the other sanctums.
function flood() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}
let open = 0, reach = 0;
const seen = flood();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { open++; if (seen.has(y * 100 + x)) reach++; }
}
ok('every open tile is reachable', open === reach, `${reach}/${open}`);

const pockets = [];
for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
  if (!K.walkable(x, y)) continue;
  const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
  if (exits <= 1) pockets.push(`${x},${y}`);
}
ok('no dead-end pocket — you can always keep retreating', pockets.length === 0,
   pockets.join(' ') || 'every tile has two ways out');
ok('the floor is open enough to run on', open / ((W - 2) * (H - 2)) > 0.9,
   `${(100 * open / ((W - 2) * (H - 2))).toFixed(0)}% of the interior is walkable`);

// ── it cannot be cut while it merely stands ────────────────────────────────
function wraith(state, solidT) {
  return { boss: true, alive: true, hp: 100, maxHp: 100, level: 4,
           x: 7 * T, y: 5 * T, state: state || 'idle', _solidT: solidT || 0 };
}
globalThis.__w = wraith('idle');
ok('standing still, it is NOT solid', K.$('ironSolid(globalThis.__w)') === false);
for (const st of ['telegraph', 'charge', 'slam', 'strike']) {
  globalThis.__w = wraith(st);
  ok(`committing to ${st}, it IS solid`, K.$('ironSolid(globalThis.__w)') === true);
}
globalThis.__w = wraith('idle', 30);
ok('recovering from a move, it is still solid',
   K.$('ironSolid(globalThis.__w)') === true, 'the punish window');

// ── the window closes on a clock ───────────────────────────────────────────
globalThis.__w = wraith('idle', 3);
K.$('ironTick(globalThis.__w); ironTick(globalThis.__w); ironTick(globalThis.__w);');
ok('the recovery window expires', K.$('ironSolid(globalThis.__w)') === false,
   `_solidT ran down to ${globalThis.__w._solidT}`);

// ── a whiff costs you the next opening ─────────────────────────────────────
globalThis.__w = wraith('idle');
const before = globalThis.__w.hp;
K.$('applyDemonHit(globalThis.__w, 25, false, 1, 0, 1, 2);');
ok('a blow at the shade does no damage', globalThis.__w.hp === before,
   `hp ${globalThis.__w.hp} — the blade passes through`);
ok('but it makes the thing wait longer', (globalThis.__w._patience || 0) > 0,
   `patience +${globalThis.__w._patience} frames added to its next wait`);

for (let i = 0; i < 60; i++) K.$('applyDemonHit(globalThis.__w, 25, false, 1, 0, 1, 2);');
ok('the penalty is capped so it cannot stall out entirely',
   globalThis.__w._patience <= K.IRON_WHIFF_MAX,
   `${globalThis.__w._patience} <= ${K.IRON_WHIFF_MAX}`);

// ── and it CAN be cut when it commits ──────────────────────────────────────
globalThis.__w = wraith('telegraph');
K.$('applyDemonHit(globalThis.__w, 25, false, 1, 0, 1, 2);');
ok('a blow while it commits lands for full damage', globalThis.__w.hp === 75,
   `hp ${globalThis.__w.hp}`);
globalThis.__w = wraith('idle', 40);
K.$('applyDemonHit(globalThis.__w, 25, false, 1, 0, 1, 2);');
ok('and so does one in the recovery window', globalThis.__w.hp === 75,
   `hp ${globalThis.__w.hp}`);

// ── the fight must be winnable ─────────────────────────────────────────────
// Every committed move has to reopen the window, or a player who waits
// correctly still never gets a turn.
const src = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');
const opens = (src.match(/d\._solidT=IRON_SOLID_RECOVER/g) || []).length;
ok('every committed move reopens the punish window', opens >= 4,
   `${opens} move resolutions set the recovery window`);

// ── THE DUTY CYCLE ── the assertion that would have caught the real bug.
// Everything above tests the PREDICATE in isolation and all of it passed while
// the fight was 97% hittable: IRON_SOLID_RECOVER (52) outlasted the pattern's
// own idle gap (40-48), so the Wraith turned solid again before it ever became
// a shade and the patience mechanic simply never happened. A predicate can be
// perfect and the fight still wrong. Measure the fight.
K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=1; dungeon.floors=getChapelFloors(1); resetDungeonRun();');
K.$(`loadDungeonFloor(${K.getChapelFloors(1).indexOf(K.FLOOR.sanctum)}, false);`);
K.$('player.x=3*TILE; player.y=9*TILE;');   // far off, so contact damage never interferes
let solidFrames = 0, sampled = 0, longestShade = 0, run = 0;
for (let i = 0; i < 1200; i++) {            // 20 seconds at 60fps
  K.frames(1);
  const b = (K.demons || []).find(d => d.boss && d.alive);
  if (!b) break;
  globalThis.__bb = b; sampled++;
  if (K.$('ironSolid(globalThis.__bb)')) { solidFrames++; run = 0; }
  else { run++; if (run > longestShade) longestShade = run; }
}
const pct = 100 * solidFrames / sampled;
ok('the fight is mostly WAITING, not mostly hitting', pct < 50,
   `${pct.toFixed(0)}% of a 20s fight is hittable`);
ok('but there is a real window to punish', pct > 15,
   `${pct.toFixed(0)}% — not so rare the fight stalls`);
ok('the shade phase lasts long enough to feel like waiting',
   longestShade > 90, `longest unbroken shade: ${longestShade} frames (${(longestShade/60).toFixed(1)}s)`);

// ── the tell ───────────────────────────────────────────────────────────────
// Patience is guesswork without a visible cue.
ok('the shade is drawn faded and the solid form is not',
   /ironSolid\(d\)\)\{[\s\S]{0,120}globalAlpha=_ironA/.test(src) || /_ironA=0\.34/.test(src),
   'it fades while it stands and comes fully solid when it is worth striking');
ok('globalAlpha is always restored',
   /if\(_ironA!==null\) ctx\.globalAlpha=1;/.test(src),
   'otherwise every sprite drawn after it would fade for the rest of the frame');

// ── the library must describe the fight the player is having ───────────────
const kinds = new Set((K.BOSS_PATTERNS[1].moves || []).map(m => m.kind));
const untipped = [...kinds].filter(k => !K.MOVE_TIPS[k]);
ok('every move the Iron Wraith has is described on the shelf',
   untipped.length === 0, untipped.join(', ') || [...kinds].join(', '));


// ── the husks ──────────────────────────────────────────────────────────────
// The Wraith is a shade for two-thirds of the fight. A fight where you spend
// two-thirds of it with nothing to do is not patience, it is waiting — so its
// iron throws up lesser shapes while it stands, and those you CAN cut.
// That is also the trap: there is always something to swing at, and swinging is
// what cost Miriam.
K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=1; dungeon.floors=getChapelFloors(1); resetDungeonRun();');
K.$(`loadDungeonFloor(${K.getChapelFloors(1).indexOf(K.FLOOR.sanctum)}, false);`);
K.$('player.x=3*TILE; player.y=9*TILE;');
let maxAdds = 0, solidF = 0, allFrozen = 0, crept = 0, everSpawned = 0;
let prev = new Map();
for (let i = 0; i < 1800; i++) {          // 30 seconds
  K.frames(1);
  const b = (K.demons || []).find(d => d.boss && d.alive);
  if (!b) break;
  globalThis.__bb = b;
  const solid = K.$('ironSolid(globalThis.__bb)');
  const adds = (K.dungeon.adds || []).filter(a => a.alive);
  maxAdds = Math.max(maxAdds, adds.length);
  everSpawned = Math.max(everSpawned, (K.dungeon.adds || []).length);
  if (solid) {
    solidF++;
    if (adds.length && adds.every(a => a.frozen)) allFrozen++;
    for (const a of adds) { const p = prev.get(a); if (p && (p.x !== a.x || p.y !== a.y)) crept++; }
  }
  prev = new Map(adds.map(a => [a, { x: a.x, y: a.y }]));
}
ok('husks rise while the Wraith stands', everSpawned > 0, `${everSpawned} spawned over 30s`);
ok('never more than the cap alive at once', maxAdds <= K.IRON_ADD_CAP,
   `${maxAdds} at peak, cap ${K.IRON_ADD_CAP}`);
ok('they FREEZE the instant the Wraith turns solid', crept === 0,
   `${crept} frames of movement during the punish window`);
ok('and the freeze is total, not partial', solidF === 0 || allFrozen > solidF * 0.95,
   `${allFrozen}/${solidF} solid frames with every husk still`);

// The freeze must read LIVE, not from the cached flag: the adds loop runs before
// ironTick sets it, and a cached read let them creep for a frame after the
// window opened.
const src2 = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');
ok('the freeze reads solidity live, not from the flag',
   /if\(a\.husk && dungeon\.townId===1\)\{[\s\S]{0,200}ironSolid\(_wr\)/.test(src2),
   'a.frozen is kept for drawing only');
ok('a frozen husk never leaks its fade onto later sprites',
   /if\(a\.frozen\) ctx\.globalAlpha=1;/.test(src2));

done('ironhold');

// suite/ksuite.js — the knight's suite: the farmhouse top floor, made fit for a princess (2026-10-07, tag 2026-10-07-ks).
//
// Zak: "Can we revamp the knights room in the homestead? Cleaner, fancier, add a walkout balcony that overlooks the
// homestead — fit for the princess eventually to move in after you merry her." Then: "I like the idea of having her
// up on the balcony."
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('ksuite');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; hunt.done=true;`);
const enter = () => K.$(`(()=>{ place={kind:'interior', id:'home_house', floor:2}; return 1; })()`);

// ── the room ──
check('the top floor is the new suite: 14 wide, 12 deep (room, south wall, balcony)', K.$(`(()=>{ const f=INTERIORS.home_house.floors[2]; return [f.w, f.h, f.g.length, f.g[0].length]; })()`), [14, 12, 12, 14]);
const reach = (a, b) => K.$(`(()=>{ const f=INTERIORS.home_house.floors[2], W=(x,y)=>f.g[y]&&WALK.has(f.g[y][x]); const seen=new Set(['${a}']), q=[[${a}]];
  while(q.length){ const [x,y]=q.shift(); if(x===${b[0]}&&y===${b[1]}) return true; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(seen.has(k)||!W(nx,ny)) continue; seen.add(k); q.push([nx,ny]); } } return false; })()`);
check('one stair down, in the south-east corner', K.$(`(()=>{ const f=INTERIORS.home_house.floors[2], s=[]; f.g.forEach((r,y)=>r.forEach((t,x)=>{ if(t===10||t===11) s.push([x,y,t]); })); return s; })()`), [[12, 7, 11]]);
ok('from the stair you can walk out through the glazed doors onto the balcony', reach([12, 7], [7, 10]) && reach([12, 7], [4, 9]));
ok('the balcony is closed by its balustrade (row 11) and side rails', K.$(`(()=>{ const f=INTERIORS.home_house.floors[2]; for(let x=0;x<14;x++) if(WALK.has(f.g[11][x])) return false; for(const x of [0,1,2,11,12,13]) for(const y of [9,10]) if(WALK.has(f.g[y][x])) return false; return true; })()`));
check('the lectern and the wardrobe glass have moved with the furniture, solid and reachable', K.$(`(()=>{ const f=INTERIORS.home_house.floors[2], W=(x,y)=>WALK.has(f.g[y][x]);
  const nb=(o)=>[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>W(o.x+dx,o.y+dy)); return [HS_LECTERN.x,HS_LECTERN.y,!W(HS_LECTERN.x,HS_LECTERN.y),nb(HS_LECTERN),HS_WARDROBE.x,HS_WARDROBE.y,!W(HS_WARDROBE.x,HS_WARDROBE.y),nb(HS_WARDROBE)]; })()`), [3, 2, true, true, 1, 5, true, true]);
ok('Ⓐ beside the lectern still opens the library', K.$(`(()=>{ place={kind:'interior', id:'home_house', floor:2}; player.x=3*TILE; player.y=3*TILE; player.dir='up'; dialogue.open=false; doAction(); const o=dialogue.open; dialogue.open=false; return o; })()`));

// ── the art ──
const paint = (married) => K.$(`(()=>{ sunfallProgress.homecoming=${married}; _ksArt={}; place={kind:'interior', id:'home_house', floor:2}; let n=0;
  try{ for(let ty=-2;ty<20;ty++) for(let tx=-4;tx<18;tx++){ if(drawKnightSuiteTile(5,0,0,tx,ty)) n++; } }catch(e){ return e.message; } return n; })()`);
check('every tile of the room, the balcony and the view below paints (before the wedding)', paint(false), 20 * 20);
check('… and after it', paint(true), 20 * 20);
ok('the view from the balcony is the real farm, drawn from above', K.$(`(()=>{ const c=_ksVistaCanvas(), d=c.getContext('2d').getImageData(0,0,c.width,c.height).data; let g=0; for(let i=0;i<d.length;i+=4) if(d[i+1]>d[i]&&d[i+1]>d[i+2]) g++; return c.width===320 && g>c.width*c.height*0.3; })()`));
ok('the suite is drawn by drawTile for the top floor only', K.$(`(()=>{ const s=String(drawTile); return s.includes("place.id==='home_house' && place.floor===2 && drawKnightSuiteTile"); })()`));

// ── the princess at home ──
check('before the wedding she is not in the house', K.$(`(()=>{ sunfallProgress.homecoming=false; return INTERIORS.home_house.npcs.filter(n=>n.name==='Princess Madison').length; })()`), 0);
check('after it her place is the balcony — one of her, not two', K.$(`(()=>{ sunfallProgress.homecoming=true; ensureMadisonAtHome(); ensureMadisonAtHome(); const m=INTERIORS.home_house.npcs.filter(n=>n.name==='Princess Madison'); return m.map(n=>[n.floor,n.x,n.y]); })()`), [[2, 7, 10]]);
ok('she speaks of the view, and still of the east window', K.$(`(()=>{ const n=INTERIORS.home_house.npcs.find(n=>n.name==='Princess Madison'); return n.lines[0].includes('From up here') && n.lines.some(l=>l.includes('pleasant places')) && n.lines.some(l=>l.includes('faces east')); })()`));
ok('she stands on balcony flags, not in a rail', K.$(`WALK.has(INTERIORS.home_house.floors[2].g[10][7])`));
check('she is drawn as herself, not the stranger’s placeholder', K.$(`(()=>{ let who=null; const keep=drawPrincessMadison; drawPrincessMadison=function(){ who='madison'; }; try{ drawNpc(0,0,{name:'Princess Madison'}); } finally { drawPrincessMadison=keep; } return who; })()`), 'madison');

// ── the rest of the homestead, indoors (2026-10-07-ks2): "we might as well upgrade all the interior of the homestead" ──
const roomPaint = (id, fl) => K.$(`(()=>{ place={kind:'interior', id:'${id}', floor:${fl}}; const f=INTERIORS['${id}'].floors[${fl}]; let n=0;
  try{ for(let ty=0;ty<f.h;ty++) for(let tx=0;tx<f.w;tx++) if(drawHomesteadRoomTile(f.g[ty][tx],0,0,tx,ty)) n++; }catch(e){ return e.message; } return n===f.w*f.h; })()`);
for (const [id, fl, name] of [['home_house', 0, 'the family hall'], ['home_house', 1, 'the children’s floor'], ['home_barn', 0, 'the barn']]) check(`${name} is painted whole, every tile`, roomPaint(id, fl), true);
const walkTo = (id, fl, a, b) => K.$(`(()=>{ const f=INTERIORS['${id}'].floors[${fl}], W=(x,y)=>f.g[y]&&WALK.has(f.g[y][x]); const seen=new Set(['${a}']), q=[[${a}]];
  while(q.length){ const [x,y]=q.shift(); if(x===${b[0]}&&y===${b[1]}) return true; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(seen.has(k)||!W(nx,ny)) continue; seen.add(k); q.push([nx,ny]); } } return false; })()`);
ok('the hall: from the front doors to the stair up', walkTo('home_house', 0, [6, 7], [12, 1]));
ok('the children’s floor: stair down to stair up, and into both rooms', walkTo('home_house', 1, [10, 1], [1, 6]) && walkTo('home_house', 1, [10, 1], [3, 2]) && walkTo('home_house', 1, [10, 1], [7, 2]));
ok('the barn: from the doors to the Old Mule’s stall', walkTo('home_barn', 0, [4, 6], [4, 2]));
ok('every family member stands on open floor', K.$(`(()=>{ const it=INTERIORS.home_house; return it.npcs.every(n=>{ const f=it.floors[n.floor]; return f&&f.g[n.y]&&WALK.has(f.g[n.y][n.x]); }); })()`));
check('after the wedding there is one Sir Aldric, with all his lines', K.$(`(()=>{ sunfallProgress.homecoming=true; ensureMadisonAtHome(); ensureMadisonAtHome(); const a=INTERIORS.home_house.npcs.filter(n=>n.name==='Sir Aldric'); return [a.length, a[0].lines.some(l=>l.includes('princess at my table'))]; })()`), [1, true]);
check('the Old Mule is drawn as a mule', K.$(`(()=>{ let who=null; const keep=drawOldMule; drawOldMule=function(){ who='mule'; }; try{ drawNpc(0,0,{name:'Old Mule'}); } finally { drawOldMule=keep; } return who; })()`), 'mule');
ok('Madison: the new figure in every facing, walking or still', K.$(`(()=>{ try{ ['down','up','left','right'].forEach(d=>{ drawPrincessMadison(0,0,d,false); drawPrincessMadison(0,0,d,true); }); drawPrincessMadison(0,0); return String(drawPrincessMadison).includes('drawPrincessMadison2'); }catch(e){ return e.message; } })()`));
check('her hair is dirty blonde', K.$(`MADISON_PAL.hair`), '#c4a266');
done('ksuite');

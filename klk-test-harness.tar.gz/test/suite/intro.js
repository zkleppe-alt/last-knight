// suite/intro.js — the cottage opening.
//
// The risk in a dialogue trim is not that the text reads badly; it is that the
// DOOR stops opening. tutorial.step is compared against TUTORIAL_STEPS, which
// used to be a hand-kept 3 sitting one line above the array it counted.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');

console.log('intro');

const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');

check('two lessons', K.TOBIAS_LESSONS.length, 2);
ok('TUTORIAL_STEPS is derived, not hand-kept',
   K.TUTORIAL_STEPS === K.TOBIAS_LESSONS.length,
   `TUTORIAL_STEPS=${K.TUTORIAL_STEPS}, lessons=${K.TOBIAS_LESSONS.length}`);
ok('TUTORIAL_STEPS is not a literal any more',
   !/const TUTORIAL_STEPS\s*=\s*\d/.test(raw),
   'the door gate cannot drift out of sync with the lesson count');

const pages = K.TOBIAS_LESSONS.reduce((n, l) => n + l.length, 0);
ok('the lesson is four pages or fewer', pages <= 4, `${pages} pages (was 10)`);

// INTRO_STORY must be untouched — that was the explicit call.
const intro = K.INTRO_STORY;
ok('INTRO_STORY is kept whole', Array.isArray(intro) && intro.length >= 5,
   `${intro.length} pages of opening narration retained`);

// ── every control is still taught ──────────────────────────────────────────
const all = K.TOBIAS_LESSONS.flat().join(' ');
for (const [what, re] of [
  ['movement', /joystick|WASD|arrow keys/],
  ['the action button', /Ⓐ|Space|<b>J<\/b>/],
  ['dash', /dash/],
  ['guard', /guard/],
  // _legacy: ['the menu', /☰|<b>M<\/b>/] — the intro used to explain the menu
  //   button. Dropped at Zak's request: it is the one control nobody needs told,
  //   and it was the only line in the intro that taught nothing. The ROW is
  //   deleted rather than the regex loosened, so nobody re-adds the line to make
  //   a test pass. Every other control is still required below.
  ['the ten chapels charge', /ten chapels/i],
  ['the bound generals', /general/i],
]) {
  ok(`still teaches ${what}`, re.test(all));
}

// ── the prompts must name keys that actually do the thing ──────────────────
// A prompt is worse than no prompt if it names the wrong key. These are checked
// against the keydown handler, not against what the text claims.
const kd = raw.slice(raw.indexOf("addEventListener('keydown'"),
                     raw.indexOf("addEventListener('keyup'"));
ok('desktop prompt: Space really interacts',
   /e\.key===' '\|\|e\.key==='Enter'/.test(kd) && /doAction\(\)/.test(kd));
ok('desktop prompt: J really interacts too (touch parity)',
   /lk==='j'\|\|lk==='z'/.test(kd) && /aPress\(\)/.test(kd));
ok('desktop prompt: K really guards/dashes',
   /lk==='k'\|\|lk==='x'\|\|e\.key==='Shift'/.test(kd) && /bDown\(\)/.test(kd));
ok('desktop prompt: M really opens the menu',
   /lk==='m'/.test(kd) && /toggleMenu\(\)/.test(kd));
ok('desktop prompt: WASD really moves',
   /w:'up',s:'down',a:'left',d:'right'/.test(raw));

// ── the door still opens ───────────────────────────────────────────────────
// Drive the tutorial to completion the way the game does, and check the gate.
K.$('boot.done=true; tutorial.step=0; tutorial.done=false;');
K.$(`tutorial.step = ${K.TOBIAS_LESSONS.length};`);
ok('the cottage door unlocks once the lessons are done',
   K.tutorial.step >= K.TUTORIAL_STEPS,
   `step ${K.tutorial.step} >= gate ${K.TUTORIAL_STEPS}`);

// And it must NOT unlock one lesson early.
K.$(`tutorial.step = ${K.TOBIAS_LESSONS.length - 1};`);
ok('the door stays shut one lesson early',
   !(K.tutorial.step >= K.TUTORIAL_STEPS),
   `step ${K.tutorial.step} < gate ${K.TUTORIAL_STEPS}`);


// ── the prompts must read correctly on BOTH platforms ──────────────────────
// Swapping a noun across platforms is not enough: "lean it hard and you walk
// quicker" is analog-stick magnitude, and on desktop it produced
// "WASD or the arrow keys — lean hard and you go quicker", which is nonsense
// and also false, since keys have no magnitude. The whole clause has to sit
// inside the platform branch.
const lessonSrc = raw.slice(raw.indexOf('const CTRL_MOVE'), raw.indexOf('const TUTORIAL_STEPS'));
ok('no analog-only wording leaks into the shared lesson text',
   !/CTRL_MOVE \+ "[^"]*lean/.test(lessonSrc),
   'lean/magnitude wording stays inside the touch branch');
ok('the touch branch still teaches the run',
   /joystick[^']*lean it hard/.test(lessonSrc),
   'touch players are still told that leaning hard walks quicker');


// ── the studio card ────────────────────────────────────────────────────────
// Restful Knight Gaming, shown before the kspearproductions title card.
ok('the boot sequence opens on the logo card', K.boot.phase === 'logo' || /phase:'logo'/.test(raw),
   'label first, then who presents, then the game');
ok('the logo is embedded, not linked',
   /const BOOT_LOGO_SRC='data:image\/png;base64,/.test(raw),
   'index.html is a single file — an external src breaks the moment it is opened locally');
ok('the embedded image is a real one', (K.BOOT_LOGO_SRC || '').length > 20000,
   `${Math.round((K.BOOT_LOGO_SRC || '').length / 1024)}KB of base64`);
ok('logo advances to the splash, splash to the title',
   /boot\.phase==='logo' && boot\.t>=\d+\) bootPhase\('splash'\)/.test(raw) &&
   /boot\.phase==='splash' && boot\.t>=\d+\) bootPhase\('title'\)/.test(raw));
ok('a tap skips only the card you are on',
   /boot\.phase==='logo'\)\{ sfxBlip\(false\); bootPhase\('splash'\); return; \}/.test(raw));
ok('there is a text fallback while the data URI decodes',
   /RESTFUL KNIGHT/.test(raw),
   'the card is never blank on the first frame or two');


// ── three small things Zak found in play ──────────────────────────────────
// 1. The naming screen hardcoded forms[0], so once the Faithful line had grown
//    from a Pup through a Hound into a LION it still showed a dog and called it
//    a pup.
const rawI = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
// Scoped to the NAMING SCREEN only. forms[0] is correct on the pet-choice
// screen and in the opening story, where it genuinely is a pup — a blanket ban
// flagged both and would have pushed me to "fix" two things that were right.
const nameScreen = rawI.slice(rawI.indexOf('function openPetName'),
                              rawI.indexOf('function openPetName') + 1400);
ok('the naming screen calls the creature what it actually is',
   !/\$\{p\.forms\[0\]\.(name|emoji)\}/.test(nameScreen)
   && /p\.forms\[pt\.form\|\|0\]\.name/.test(nameScreen),
   'it reads the current form, not form zero');
// A lion the whole way: Cub, Young Lion, Lion. It used to be a dog for two
// thirds of its life and then a lion at the end.
for (const [form, species] of [[0, 'Cub'], [1, 'Young Lion'], [2, 'Lion']]) {
  K.$(`player.pet={id:"faithful", form:${form}, nick:null};`);
  ok(`form ${form} is a ${species}`,
     K.$('PETS[player.pet.id].forms[player.pet.form].name') === species);
}
ok('and an unnamed pet defaults to its CURRENT species',
   /pt\.nick = v \|\| PETS\[pt\.id\]\.forms\[pt\.form\|\|0\]\.name;/.test(rawI),
   'it used to default a lion to "Pup"');
ok('nothing in the Faithful line is a dog any more',
   !/Pup|Hound/.test(JSON.stringify(K.PETS.faithful)),
   K.PETS.faithful.forms.map(f => f.name).join(' -> '));

// 2. Tobias greeted a man he was already mid-conversation with: the pet-naming
//    beat runs BEFORE the first lesson, so "You're awake" landed two pages in.
ok('Tobias does not greet you after already talking to you',
   !/You're awake\. Good\./.test(K.TOBIAS_LESSONS.flat().join(' ')),
   'the pet beat runs first, so the greeting arrived late');

// 3. The menu instruction is gone — see the deleted row above.
ok('the intro no longer explains the menu button',
   !/opens your pack/.test(K.TOBIAS_LESSONS.flat().join(' ')),
   'the one control nobody needs told');


// ── every pet sprite must have a palette to draw with ─────────────────────
// A two-line anchor replaced by a single line silently deleted the second
// form's palette. The art still referenced it by name, so the sprite would have
// drawn with undefined colours and nothing would have complained.
const missing = [];
for (const [key, art] of Object.entries(K.PET_ART)) {
  if (!art || !art.pal) { missing.push(`${key} has no palette name`); continue; }
  if (!K.PET_PAL[art.pal]) missing.push(`${key} -> ${art.pal} (not defined)`);
}
ok('every pet sprite resolves to a real palette', missing.length === 0,
   missing.join(' | ') || `${Object.keys(K.PET_ART).length} sprites, all resolved`);

// And every form a player can reach should have art or a working fallback.
for (const [id, line] of Object.entries(K.PETS)) {
  line.forms.forEach((f, i) => {
    ok(`${line.name} form ${i} (${f.name}) can be drawn`,
       !!K.PET_ART[id + i] || !!f.emoji,
       K.PET_ART[id + i] ? 'pixel art' : 'emoji fallback');
  });
}

done('intro');

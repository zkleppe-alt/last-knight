// suite/tabor.js — Mount Tabor, the frozen world (baseline written 2026-10-01,
// BEFORE the alpine rework, so the rework can be proven to keep every quest).
//
// What must stay true whatever the mountain looks like:
//   · all five rescues are found, and each one (with its props: guards' ground,
//     the buried drifts, the hearth wood) can be reached on foot from the dock
//   · Eden and the frozen spring at the summit can be reached on foot
//   · the strand, pier, ship and return gate are where the quests expect them
//   · the thaw wakes the five frozen folk and lays out the raft, hammocks, springs
//   · beasts have somewhere to spawn on the slopes
//   · it builds the same every time, frozen and thawed
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const TILEpx = (n) => n * 16;
console.log('tabor');

K.$(`boot.done=true; dialogue.open=false; menu.open=false;`);
const build = (thawed) => K.$(`(taborProgress.thawed=${!!thawed}, buildPortalWorld('tabor'), place={kind:'portalworld'}, player.mounted=false, player.boating=false, 'ok')`);
const reach = () => K.$(`globalThis.__tr=(()=>{ const s=portalWorld.entry, seen=new Set([s.x+','+s.y]), q=[[s.x,s.y]];
  for(let i=0;i<q.length;i++){ const [x,y]=q[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay; if(seen.has(k)) continue; if(canStep(x,y,ax,ay)){ seen.add(k); q.push([ax,ay]); } } }
  return seen; })(), __tr.size`);
// a target is "reachable" if the knight can stand on it or on a tile beside it
// (rescued folk and props stand on their own tile; you talk/act from next door)
const near = (expr) => K.$(`(()=>{ const p=${expr}; if(!p) return 'missing'; const ks=[[0,0],[1,0],[-1,0],[0,1],[0,-1]].map(([a,b])=>(p.x+a)+','+(p.y+b)); return ks.some(k=>__tr.has(k)); })()`);

for (const thawed of [false, true]) {
  const S = thawed ? 'thawed' : 'frozen';
  build(thawed);
  check(`${S}: 110×110 Tabor`, K.$(`[portalWorld.w, portalWorld.h, portalWorld.id]`), [110, 110, 'tabor']);
  const n = reach();
  ok(`${S}: most of the mountain is open on foot`, n > 3000, n + ' tiles');
  check(`${S}: all five rescues are found`, K.$(`portalWorld.rescues.map(r=>r.id).sort()`), ['beset', 'buried', 'eden', 'hearth', 'ledge']);
  for (const id of ['beset', 'buried', 'hearth', 'ledge', 'eden'])
    check(`${S}: ${id} can be reached`, near(`portalWorld.rescues.find(r=>r.id==='${id}')`), true);
  check(`${S}: the spring at the summit can be reached`, near(`({x:Math.round(taborBoss.spring.x), y:Math.round(taborBoss.spring.y)+1})`), true);
  check(`${S}: the dock and the gate home`, [K.$(`portalWorld.g[portalWorld.cy+portalWorld.R][portalWorld.cx]`), near(`({x:portalWorld.cx, y:portalWorld.cy+portalWorld.R})`)], [35, true]);
  ok(`${S}: the ship rides beside the pier`, K.$(`!!portalWorld.ship`));
  ok(`${S}: every Tabor sign is on the map`, K.$(`Object.keys(signs).filter(k=>k.indexOf('tabor:')===0).length`) >= 6, String(K.$(`Object.keys(signs).filter(k=>k.indexOf('tabor:')===0).length`)));
  ok(`${S}: every Tabor sign can be read`, K.$(`Object.keys(signs).filter(k=>k.indexOf('tabor:')===0).every(k=>{ const [x,y]=k.slice(6).split(',').map(Number); return [[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((x+a)+','+(y+b))); })`));
  ok(`${S}: the whole island draws`, K.$(`(()=>{ const sw=VIEW_TW, sh=VIEW_TH; try{ VIEW_TW=110; VIEW_TH=110; player.x=55*TILE; player.y=58*TILE; draw(); return true; }catch(e){ return e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; } })()`) === true);
  check(`${S}: one frame of the real loop on the strand`, K.$(`(()=>{ player.x=portalWorld.entry.x*TILE; player.y=portalWorld.entry.y*TILE; try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
}

// ── frozen: the quests' props ──
K.$(`['beset','buried','hearth','ledge','eden'].forEach(id=>{ const r=tabRescue(id); r.done=false; r.stage=0; }); taborProgress.hopeAll=false;`);
build(false); reach();
check('frozen: three wolves guard the beset traveler', K.$(`demons.filter(d=>d._rescueGuard==='beset').length`), 3);
check('frozen: the buried hut has three drifts to dig', K.$(`portalWorld.buriedDrifts.length`), 3);
ok('frozen: every drift can be dug (reached)', K.$(`portalWorld.buriedDrifts.every(d=>[[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((d.x+a)+','+(d.y+b))))`));
check('frozen: three bundles of hearth wood lie about', K.$(`portalWorld.hearthWood.length`), 3);
ok('frozen: every bundle can be gathered', K.$(`portalWorld.hearthWood.every(w=>[[0,0],[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((w.x+a)+','+(w.y+b))))`));
ok('frozen: the dead hearth can be reached', near(`portalWorld.hearthFire`) === true);
check('frozen: five folk stand frozen on the strand', K.$(`portalWorld.g.flat().filter(t=>t===T_FROZEN).length`), 5);
ok('frozen: the pack has room to roam the slopes', K.$(`(()=>{ let n=0; for(let i=0;i<40;i++) if(taborBeastSpot(true)) n++; return n; })()`) >= 36);

// ── thawed: the summer furnishings ──
build(true); reach();
check('thawed: the five frozen folk wake', K.$(`portalWorld.thawedFolk.length`), 5);
check('thawed: none are left frozen', K.$(`portalWorld.g.flat().filter(t=>t===T_FROZEN).length`), 0);
ok('thawed: the raft waits at Eden’s lip, and can be reached', !!K.$(`portalWorld.raftDock`) && near(`portalWorld.raftDock`) === true);
ok('thawed: every woken villager can be talked to', K.$(`portalWorld.thawedFolk.every(f=>[[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((f.x+a)+','+(f.y+b))))`),
   JSON.stringify(K.$(`portalWorld.thawedFolk.filter(f=>![[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((f.x+a)+','+(f.y+b)))).map(f=>f.name)`)));
ok('thawed: every hut door and market stall can be reached', K.$(`(()=>{ const g=portalWorld.g, bad=[]; for(let y=0;y<110;y++)for(let x=0;x<110;x++){ if(g[y][x]!==77 && g[y][x]!==72) continue;
   if(![[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((x+a)+','+(y+b)))) bad.push(x+','+y); } return bad.length===0; })()`),
   JSON.stringify(K.$(`(()=>{ const g=portalWorld.g, bad=[]; for(let y=0;y<110;y++)for(let x=0;x<110;x++){ if(g[y][x]!==77 && g[y][x]!==72) continue;
   if(![[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((x+a)+','+(y+b)))) bad.push(x+','+y); } return bad; })()`)));
check('thawed: two hammocks on the strand', K.$(`portalWorld.hammocks.length`), 2);
ok('thawed: both hammocks can be reached', K.$(`portalWorld.hammocks.every(h=>[[0,0],[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((h.x+a)+','+(h.y+b))))`));
check('thawed: two hot springs on the slopes', K.$(`portalWorld.springs.length`), 2);
ok('thawed: both springs can be reached', K.$(`portalWorld.springs.every(h=>[[0,0],[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>__tr.has((h.x+a)+','+(h.y+b))))`));
ok('thawed: no beasts', K.$(`demons.filter(d=>d.beast).length`) === 0);
ok('thawed: the third gate stirs', K.$(`portalById('sunfall').unlocked`));

// ── the summer comforts WORK, pressed with the real Ⓐ button ──
// The knight is set down on a tile he could walk to, beside the thing, facing it.
build(true); reach();
K.$(`globalThis.__standBy=(x,y)=>{ for(const [a,b,dir] of [[0,1,'up'],[0,-1,'down'],[1,0,'left'],[-1,0,'right'],[0,0,'up']]){
    const k=(x+a)+','+(y+b); if(__tr.has(k)){ player.x=(x+a)*TILE; player.y=(y+b)*TILE; player.dir=dir; player.taborSit=null; dialogue.open=false; return true; } } return false; };
  globalThis.__A=()=>{ dialogue.open=false; aPress(); };`);
// hammocks
for (const i of [0, 1]) {
  ok(`hammock ${i+1}: the knight can stand beside it`, K.$(`__standBy(portalWorld.hammocks[${i}].x, portalWorld.hammocks[${i}].y)`));
  K.$(`player.hp=Math.max(1,Math.round(player.maxHp*0.3)); __A();`);
  check(`hammock ${i+1}: Ⓐ lies him down in it`, K.$(`player.taborSit && player.taborSit.kind`), 'hammock');
  const hp0 = K.$(`player.hp`); K.frames(240);
  ok(`hammock ${i+1}: resting there heals him`, K.$(`player.hp`) > hp0, hp0 + ' → ' + K.$(`player.hp`));
  ok(`hammock ${i+1}: he stays in it while resting`, K.$(`Math.round(player.x/TILE)===portalWorld.hammocks[${i}].x && Math.round(player.y/TILE)===portalWorld.hammocks[${i}].y`));
  K.$(`__A();`);
  check(`hammock ${i+1}: Ⓐ again gets him up`, K.$(`player.taborSit`), null);
}
// hot springs
for (const i of [0, 1]) {
  ok(`spring ${i+1}: the knight can stand beside it`, K.$(`__standBy(portalWorld.springs[${i}].x, portalWorld.springs[${i}].y)`));
  K.$(`player.hp=Math.max(1,Math.round(player.maxHp*0.3)); __A();`);
  check(`spring ${i+1}: Ⓐ sinks him into it`, K.$(`player.taborSit && player.taborSit.kind`), 'spring');
  const hp0 = K.$(`player.hp`); K.frames(240);
  ok(`spring ${i+1}: soaking heals him`, K.$(`player.hp`) > hp0, hp0 + ' → ' + K.$(`player.hp`));
  K.$(`__A();`);
  check(`spring ${i+1}: Ⓐ again and he climbs out`, K.$(`player.taborSit`), null);
}
// the raft ride
ok('raft: the knight can stand beside it at Eden’s lip', K.$(`__standBy(portalWorld.raftDock.x, portalWorld.raftDock.y)`));
K.$(`__A();`);
check('raft: Ⓐ pushes off', K.$(`taborRide.active`), true);
const y0 = K.$(`player.y`); K.frames(60);
ok('raft: it carries him down the falls', K.$(`player.y`) > y0 + TILEpx(4), (y0/16|0) + ' → ' + (K.$(`player.y`)/16|0));
let guard = 0; while (K.$(`taborRide.active`) && guard++ < 40) K.frames(60);
check('raft: the ride ends', K.$(`taborRide.active`), false);
ok('raft: he is set down laughing in the basin', K.$(`Math.abs(player.x/TILE-portalWorld.cx)<1.5 && Math.abs(player.y/TILE-(portalWorld.cy+portalWorld.R-5))<1.5`),
   K.$(`[Math.round(player.x/TILE), Math.round(player.y/TILE)]`).join(','));
ok('raft: and can walk away from there', K.$(`(()=>{ const x=Math.round(player.x/TILE), y=Math.round(player.y/TILE); return [[1,0],[-1,0],[0,1],[0,-1],[0,0]].some(([a,b])=>__tr.has((x+a)+','+(y+b))); })()`));
// the woken folk speak, each their own line
K.$(`globalThis.__said=[]; const _say=say; globalThis.__restoreSay=()=>{ say=_say; }; say=function(lines){ __said.push(lines); };`);
const folk = K.$(`portalWorld.thawedFolk.map(f=>f.name)`);
for (let i = 0; i < folk.length; i++) {
  K.$(`(()=>{ const f=portalWorld.thawedFolk[${i}]; __said.length=0; __standBy(f.x,f.y); __A(); })()`);
  check(`${folk[i]}: Ⓐ beside them and they speak`, K.$(`(__said[0]&&__said[0][0]&&__said[0][0].speaker)||null`), folk[i]);
}
K.$(`__restoreSay();`);
// the furnishings are drawn where they stand
const drawn = K.$(`(()=>{ const n={h:0,s:0,r:0,p:0,f:0}; const H=drawHammock, Sp=drawHotSpring, Rf=drawRaft, Pm=drawPalmTree, Fr=drawFruitTree;
  drawHammock=function(){ n.h++; }; drawHotSpring=function(){ n.s++; }; drawRaft=function(){ n.r++; }; drawPalmTree=function(){ n.p++; }; drawFruitTree=function(){ n.f++; };
  const sw=VIEW_TW, sh=VIEW_TH; try{ VIEW_TW=110; VIEW_TH=110; player.x=55*TILE; player.y=58*TILE; taborRide.active=false; draw(); }
  finally{ VIEW_TW=sw; VIEW_TH=sh; drawHammock=H; drawHotSpring=Sp; drawRaft=Rf; drawPalmTree=Pm; drawFruitTree=Fr; } return n; })()`);
check('thawed: two hammocks, two springs and the raft are drawn', [drawn.h, drawn.s, drawn.r], [2, 2, 1]);
ok('thawed: palms on the strand and fruit trees in Eden are drawn', drawn.p > 0 && drawn.f > 0, JSON.stringify(drawn));
ok('thawed: every palm stands on the strand (the slopes grow firs)', K.$(`portalWorld.palms.every(p=>elevAt(p.x,p.y)===0)`));

// ── the progressive thaw (the cutscene sweeps from the summit down) ──
build(false);
check('mid-thaw: the island draws at every level', K.$(`(()=>{ const bad=[]; const sw=VIEW_TW, sh=VIEW_TH; VIEW_TW=110; VIEW_TH=110; player.x=55*TILE; player.y=58*TILE;
  for(let lv=6; lv>=0; lv--){ portalWorld.tabThaw={level:lv, full:false}; try{ draw(); }catch(e){ bad.push(lv+':'+e.message); } }
  VIEW_TW=sw; VIEW_TH=sh; portalWorld.tabThaw=null; return bad; })()`), []);

// ── the same every time ──
const snap = () => K.$(`JSON.stringify([portalWorld.g, portalWorld.elev, portalWorld.rescues.map(r=>[r.id,r.x,r.y])])`);
build(false); const a = snap(); build(false); const b = snap();
ok('frozen: identical on every build', a === b);
build(true); const c = snap(); build(true); const d = snap();
ok('thawed: identical on every build', c === d);
build(false);
// ── MOUNT TABOR on the overworld: a glacier peak that thaws with the world ──
K.$(`place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const isle = K.$(`(()=>{ let pier=null; for(let y=299;y>274;y--) if(WORLD[y] && WORLD[y][95]===68){ pier={x:95,y}; break; }
  const seen=new Set([pier.x+','+pier.y]), q=[[pier.x,pier.y]];
  for(let i=0;i<q.length;i++){ const [x,y]=q[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay;
    if(seen.has(k)||!taborIsleAt(ax,ay)) continue; if(canStep(x,y,ax,ay)){ seen.add(k); q.push([ax,ay]); } } }
  const hut=[]; for(let y=252;y<300;y++)for(let x=72;x<=118;x++){ const t=WORLD[y][x]; if(t===69||t===70||t===71||t===77) hut.push([x,y,t]); }
  return { pier, gate:seen.has('95,274'), home:seen.has('95,275'), sea:[WORLD[pier.y+1][95],WORLD[pier.y][93],WORLD[pier.y][98]],
    door:hut.filter(h=>h[2]===77).map(([x,y])=>[[1,0],[-1,0],[0,1]].some(([a,b])=>seen.has((x+a)+','+(y+b)))),
    behind:hut.filter(h=>h[2]===70).every(([x,y])=>elevAt(x,y-1)===0), hutN:hut.length }; })()`);
ok('Mount Tabor: the pier runs out from the south shore', !!isle.pier, JSON.stringify(isle.pier));
ok('  with open water at its head for the boat', isle.sea.every(t => t === 3 || t === 20 || t === 74), JSON.stringify(isle.sea));
ok('  from the pier you can climb to the gate on foot', isle.gate);
ok('  and coming home through it you stand on the summit', isle.home);
check('  the gate is still at the summit (95,274)', K.$(`[portalById('tabor').tx, portalById('tabor').ty]`), [95, 274]);
ok('  the summit sign still reads Mount Tabor', K.$(`(signs['95,274']||'').indexOf('Mount Tabor')===0`));
check('  a fishing hut by the landing: roof, wall, window, door', isle.hutN, 6);
ok('  its door can be walked up to', isle.door.length === 1 && isle.door[0]);
ok('  no cliff face lands on its roof (flat ground behind it)', isle.behind);
check('  the isle draws, frozen and thawed, gates sealed and open', K.$(`(()=>{ const bad=[]; const sw=VIEW_TW, sh=VIEW_TH; VIEW_TW=44; VIEW_TH=44; player.x=95*TILE; player.y=276*TILE;
  for(const th of [false,true]) for(const open of [false,true]){ taborProgress.thawed=th; bounties.portalsOpen=open; try{ draw(); }catch(e){ bad.push(e.message); } }
  VIEW_TW=sw; VIEW_TH=sh; bounties.portalsOpen=false; taborProgress.thawed=false; return bad; })()`), []);
ok('  the isle follows the world: frozen until Tabor thaws', K.$(`(taborProgress.thawed=false, place={kind:'overworld'}, !_ttThawAt(95,280))`) && K.$(`(taborProgress.thawed=true, _ttThawAt(95,280))`));
K.$(`taborProgress.thawed=false;`);
ok('  its art stays on the isle (Mistral Isle and the mainland are untouched)', K.$(`!taborIsleAt(40,270) && !taborIsleAt(155,270) && !taborIsleAt(95,200) && taborIsleAt(95,274)`));
done('tabor');

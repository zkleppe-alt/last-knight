// suite/huntmarks.js — the Demon Hunt's stragglers are marked on the maps.
//
// Zak: once Sir Aldric starts the hunt, finding the last few demons across ten
// encounter zones "takes 100 years". While the hunt is on, each living
// straggler is a purple mark on the minimap (an arrow on the rim points to the
// nearest when none are in the window) and on the Map tab. Pixels are read
// back from the real canvases, not inferred from the code.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('huntmarks');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; place={kind:'overworld'};
     player.x=32*TILE; player.y=24*TILE;`);
// count marker-purple pixels (#d24aff, also when faded by the arrow's pulse)
K.$(`globalThis.__purple=(id,x0,y0,x1,y1)=>{ const c=document.getElementById(id), g=c.getContext('2d');
       x0=x0||0; y0=y0||0; x1=x1||c.width; y1=y1||c.height;
       const d=g.getImageData(x0,y0,x1-x0,y1-y0).data; let n=0;
       for(let i=0;i<d.length;i+=4){ const r=d[i],gg=d[i+1],b=d[i+2]; if(b>150 && r>90 && gg<110 && b>r && r>gg*1.6) n++; }
       return n; };`);
const mini = () => K.$(`drawMinimap(); __purple('minimap')`);
const frame = () => K.$(`try{ loop(performance.now()); 'ok' }catch(e){ String(e.message).slice(0,80) }`);

// the hunt exists but Aldric hasn't given it yet
K.$(`hunt.won=true; hunt.active=false; hunt.done=false; initHuntRoster(); demons=[]; spawnDemons();`);
ok('the hunt roster spawns its demons', K.$(`demons.filter(d=>d.alive).length`) > 0, K.$(`demons.length+' demons'`));
check('before Aldric gives the quest: nothing marked', K.$(`huntQuarry().length`), 0);
check('  and the minimap carries no marker purple', mini(), 0);

// Aldric gives the quest — through his real dialogue
K.$(`const _n={name:'Sir Aldric', aldric:true}; (typeof talkTo==='function') ? 0 : 0;`);
K.$(`hunt.active=true;`);
check('quest on: every living hunt demon is quarry', K.$(`huntQuarry().length`),
      K.$(`demons.filter(d=>d.alive && typeof d.zi==='number').length`));
check('one frame of the real loop with marks drawn', frame(), 'ok');

// one demon, ten tiles east of the knight; the rest put down
K.$(`demons.forEach(d=>d.alive=false); const d0=demons[0]; d0.alive=true;
     d0.x=player.x+10*TILE; d0.y=player.y; globalThis.__d0=d0;`);
const at = K.$(`(()=>{ const mc=document.getElementById('minimap'), span=120, sc=mc.width/span;
   let px0=Math.floor(player.x/TILE-span/2), py0=Math.floor(player.y/TILE-span/2);
   px0=Math.max(0,Math.min(WORLD_W-span,px0)); py0=Math.max(0,Math.min(WORLD_H-span,py0));
   return [Math.round((__d0.x/TILE-px0)*sc), Math.round((__d0.y/TILE-py0)*sc)]; })()`);
const n1 = mini();
ok('a nearby demon shows as a purple mark on the minimap', n1 > 0, n1 + ' px');
ok('  right where the demon stands', K.$(`__purple('minimap',${at[0]-3},${at[1]-3},${at[0]+3},${at[1]+3})`) > 0, JSON.stringify(at));

// a lone demon far outside the 120-tile window: the rim arrow points at it
K.$(`__d0.x=player.x+0*TILE; __d0.y=player.y+100*TILE;`);
ok('it is really outside the minimap window', K.$(`(()=>{ const span=120; let py0=Math.floor(player.y/TILE-span/2); py0=Math.max(0,Math.min(WORLD_H-span,py0)); return __d0.y/TILE-py0 > span; })()`));
K.$(`performance.__now0=performance.now;`);
const n2 = mini();
ok('out of view: an arrow is drawn instead', n2 > 0, n2 + ' px');
const H = K.$(`document.getElementById('minimap').height`), W = K.$(`document.getElementById('minimap').width`);
const bottom = K.$(`__purple('minimap',0,${Math.floor(H*0.8)},${W},${H})`);
ok('  on the rim, toward the demon (south)', bottom > 0 && bottom === n2, bottom + ' of ' + n2 + ' in the bottom fifth');

// the Map tab marks it too
K.$(`initBigMap();`);
const bt = K.$(`[Math.floor((__d0.x+TILE/2)/TILE), Math.floor((__d0.y+TILE/2)/TILE)]`);
ok('the Map tab marks the straggler', K.$(`__purple('bigmap',${bt[0]-3},${bt[1]-3},${bt[0]+4},${bt[1]+4})`) > 0, JSON.stringify(bt));

// not hunt quarry: bounty culls, beasts, the fallen
K.$(`demons.push({x:player.x+3*TILE,y:player.y,alive:true,zi:0,cull:true},
                 {x:player.x+4*TILE,y:player.y,alive:true,beast:true},
                 {x:player.x+5*TILE,y:player.y,alive:true,zi:1,fallen:true});`);
check('culls, beasts and the fallen are not marked', K.$(`huntQuarry().length`), 1);

// indoors there is no quarry (and no minimap)
K.$(`place={kind:'interior', id:Object.keys(INTERIORS)[0], floor:0};`);
check('indoors: nothing', K.$(`huntQuarry().length`), 0);
K.$(`place={kind:'overworld'};`);

// the last one falls
K.$(`demons=[]; hunt.remaining=hunt.remaining.map(()=>0); hunt.remaining[0]=1;
     demons.push({x:player.x+2*TILE,y:player.y,alive:true,zi:0,hp:1,maxHp:1,level:1,xp:1});
     onHuntKill(demons[0]); demons[0].alive=false;`);
check('the hunt is done', K.$(`hunt.done`), true);
check('done: nothing marked', K.$(`huntQuarry().length`), 0);
check('  and the minimap is clean again', mini(), 0);
done('huntmarks');

// suite/steeple.js — the King's Tourney steeplechase (2026-10-07, tag 2026-10-07-sc).
//
// Zak: "can we revamp the horse race?" — ride your own steed or a tourney horse; steeplechase courses; timed jumps,
// stamina, urging in rhythm and drafting; built like the new boat race; "That looks amazing" to the mockup.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('steeple');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; abaddon.won=true; player.pet={id:'unicorn',form:2,look:{}};`);
const open = (pet, course) => K.$(`(()=>{ if(race) race=null; place={kind:'overworld'}; player.pet=${JSON.stringify(pet || {id:'unicorn',form:2,look:{}})}; openRace(); SC.setCourse(${course||0}); return race.phase; })()`);
const go = (mount, course) => K.$(`(()=>{ SC.setCourse(${course||0}); race.sel=race.mounts.findIndex(m=>m.id==='${mount||'own'}'); SC.begin(); race.phase='race'; race.count=0; return race.phase; })()`);

// ── opening the tourney ──
check('the marshal opens the steeplechase (the new race), at its mount picker', open(), 'select');
check('the race state is the new one', K.$(`[place.kind, race.v]`), ['race', 2]);
check('your grown steed heads the list, then the four tourney horses to borrow', K.$(`race.mounts.map(m=>m.id)`), ['own', 'tempest', 'ember', 'psalm', 'raven']);
check('a steed that isn\'t grown yet can\'t race: only the tourney horses', (open({ id:'faithful', form:0, look:{} }), K.$(`race.mounts.map(m=>m.id)`)), ['tempest', 'ember', 'psalm', 'raven']);
check('each grown steed races as itself', K.$(`['faithful','grace','steadfast','unicorn'].map(id=>{ player.pet={id, form:2, look:{}}; const o=SC.ownSteed(); return o&&o.kind; })`), ['lion', 'dove', 'dragon', 'unicorn']);
check('your steed wears its pet looks (coat from the stylist, cape on its back)', K.$(`(()=>{ player.pet={id:'unicorn',form:2,look:{coat:'royal',back:'cape'}}; const o=SC.ownSteed(); return [o.coat[1], o.back]; })()`), ['#7a46b0', 'cape']);

// ── the courses ──
for (let c = 0; c < 4; c++) {
  const g = K.$(`(()=>{ const sp=SC.courses[${c}], C=SC.build(sp), L=C.line, N=L.length, W=C.W; const gap=Math.hypot(L[0][0]-L[N-1][0],L[0][1]-L[N-1][1]); let par=0;
    for(let i=0;i<N;i+=2) for(let j=i+30;j<N;j+=2){ if(N-(j-i)<30) continue; if(Math.hypot(L[i][0]-L[j][0],L[i][1]-L[j][1])<W+70) par++; }
    const pondsClear=(sp.ponds||[]).every(P=>L.every(p=>Math.hypot(p[0]-P[0],(p[1]-P[1])/0.7)-P[2]>W/2));
    return [sp.key, gap<40, par===0, pondsClear, C.jumps.length>=5, C.trees.length>20, Math.round(C.len*sp.laps)]; })()`);
  ok(`${g[0]}: a closed loop, no legs side by side, ponds clear of the turf, five or more fences, trees along it`, g.slice(1, 6).every(Boolean), JSON.stringify(g));
  ok(`${g[0]}: the race is 8,000–10,000 units (about a minute)`, g[6] > 8000 && g[6] < 10000, `${g[6]}`);
}

// ── urging on the stride ──
open();
const stride = (frac, twice, tired) => K.$(`(()=>{ go(); const P=race.P; P.v=120; P.ph=4+${frac}; P.lastTap=-1; P.stamina=1; P.tired=${!!tired}; SC.urge(); const v1=P.v, s1=P.stamina; ${twice ? 'SC.urge();' : ''}
  return [Math.round(v1), Math.round(P.v), +s1.toFixed(2), race.stats]; })()`.replace('go();', `SC.setCourse(0); race.sel=0; SC.begin(); race.phase='race';`));
const per = stride(0.01), gd = stride(0.10), off = stride(0.4), dbl = stride(0.01, true), tir = stride(0.01, false, true);
ok('a perfect stride urges more than a good one', per[0] > gd[0] && gd[0] > 120, `${per[0]} vs ${gd[0]}`);
ok('an off-beat urge breaks the stride and loses a little', off[0] < 120, `${off[0]}`);
check('a second tap on the same stride does nothing (mashing can\'t help)', [dbl[1] === dbl[0], dbl[3].perfect], [true, 1]);
check('a tired mount can\'t be urged', tir[0], 120);
ok('urging costs stamina', per[2] < 1 && gd[2] < per[2], `${per[2]} ${gd[2]}`);

// ── stamina and drafting ──
check('ease off and stamina comes back; twice as fast in a rival\'s wake', K.$(`(()=>{ SC.setCourse(0); race.sel=0; SC.begin(); race.phase='race'; const R=race, P=R.P;
  const regen=(draft)=>{ P.stamina=0.4; P.sinceUrge=5; P.tired=false; R.rivals.forEach((x,k)=>{ x.prog=P.prog+400+k*200; }); const r=R.rivals[0]; if(draft){ r.prog=P.prog+20; r.lane=P.lat; r.lane0=P.lat; }
    for(let i=0;i<30;i++){ R.rivals.forEach((x,k)=>{ if(!(draft&&k===0)) x.prog=P.prog+400+k*200; }); if(draft){ r.prog=P.prog+20; r.lane0=P.lat; } SC.step(1/60); } return P.stamina-0.4; };
  const a=regen(false), b=regen(true); return [a>0, b>a*1.6, R.stats.draft>0]; })()`), [true, true, true]);
check('run the tank dry and the mount tires (slower until it gets its second wind)', K.$(`(()=>{ SC.setCourse(0); race.sel=0; SC.begin(); race.phase='race'; const P=race.P; P.stamina=0.05; P.ph=6.0; P.lastTap=-1; SC.urge();
  const tired=P.tired; for(let i=0;i<60;i++) SC.step(1/60); return [tired, P.v < race.top*0.8]; })()`), [true, true]);

// ── the jumps ──
const fence = (when, press, mount) => K.$(`(()=>{ SC.setCourse(0); race.sel=race.mounts.findIndex(m=>m.id==='${mount||'own'}'); SC.begin(); const R=race, C=R.C, P=R.P; R.phase='race'; const j=C.jumps[0];
  const p=SC.pointAt(C, j.d-120); P.x=p.x; P.y=p.y; P.h=p.ang; P.prog=j.d-120; P.idx=p.i; P.v=140; P.lat=0; R.camAng=p.ang; P.stamina=1;
  let pressed=false, minV=999, cal=null; for(let i=0;i<120;i++){ const toLine=(j.d-SC.takeoff)-P.prog;
    if(${press} && !pressed && toLine<=${when}){ SC.jump(); pressed=true; cal=P.callout; } SC.step(1/60); minV=Math.min(minV,P.v); if(P.prog>j.d+20) break; }
  return [cal||P.callout, Math.round(minV), Object.values(P.jumpsDone)[0]]; })()`);
const clean = fence(1, true), early = fence(60, true), late = fence(-16, true, 'raven'), none = fence(0, false);
ok('jump at the take-off line: over cleanly, no speed lost', /JUMP!/.test(clean[0]) && clean[1] >= 130 && clean[2] === 'clean', JSON.stringify(clean));
ok('jump too early: you lose speed and must jump again', early[0] === 'TOO EARLY!', JSON.stringify(early));
ok('jump too late: you scramble over, slower', /TOO LATE/.test(late[0]) && late[1] < 110, JSON.stringify(late));
ok('don\'t jump at all: the horse refuses the hedge (a big check)', none[0] === 'REFUSED!' && none[1] < 60, JSON.stringify(none));
check('a sure jumper has a wider window (Psalm vs Raven)', K.$(`(()=>{ const w=(id)=>0.10+0.10*SC.mounts.find(m=>m.id===id).jump; return w('psalm')>w('raven'); })()`), true);
check('the rails hold you in', K.$(`(()=>{ SC.setCourse(0); race.sel=0; SC.begin(); const R=race, C=R.C, P=R.P; R.phase='race'; const p=SC.pointAt(C,500);
  P.x=p.x+(-Math.sin(p.ang))*200; P.y=p.y+Math.cos(p.ang)*200; P.idx=p.i; P.prog=500; SC.step(1/60); return Math.abs(SC.near(C,P.x,P.y,P.idx).lat)<=C.W/2; })()`), true);

// ── fair rivals ──
check('rivals hold their own pace whether you lead or trail (no catching up, no easing off)', K.$(`(()=>{ const sp=(lead)=>{ SC.setCourse(3); race.sel=0; SC.begin(); const R=race, P=R.P; R.phase='race';
  for(let i=0;i<240;i++){ P.prog=R.rivals[0].prog+lead; P.x=-9e3; P.y=-9e3; SC.step(1/60); } return Math.round(R.rivals[0].v); }; return sp(-1500)===sp(1500); })()`), true);
check('later courses field faster riders', K.$(`[1,2,3,4].map(t=>Math.max(...SC.pace[t])).every((v,i,a)=>i===0||v>a[i-1])`), true);

// ── skill decides it: a bot rider on every course ──
function bot(course, mount, urgeMode, save, jumps) {
  open(null, course);
  return K.$(`(()=>{ SC.setCourse(${course}); const R=race; R.sel=R.mounts.findIndex(m=>m.id==='${mount}'); SC.begin(); const C=R.C, P=R.P; let t=0; const dt=1/60;
    while(R.phase!=='finish' && t<200){ t+=dt; const tp=SC.pointAt(C,P.prog+50); let d=Math.atan2(tp.y-P.y,tp.x-P.x)-P.h; while(d>Math.PI) d-=2*Math.PI; while(d<-Math.PI) d+=2*Math.PI;
      R.keys.left=d<-0.05; R.keys.right=d>0.05;
      if(R.phase==='race'){ const f=P.ph-Math.floor(P.ph), reserve=${save}?(P.prog>R.total-900?0:0.35):0;
        if(${save}===0 || (P.stamina>reserve+0.06 && !P.tired)){ if('${urgeMode}'==='good' && Math.abs(f-0.11)<0.012 && Math.round(P.ph)!==P.lastTap) SC.urge(); }
        if(${jumps}) C.jumps.forEach(j=>{ const base=Math.floor(P.prog/C.len)*C.len, dj=base+j.d, key=j.n+':'+Math.floor(dj/C.len); if(!P.jumpsDone[key] && P.air<=0 && Math.abs((dj-SC.takeoff)-P.prog)<P.v*dt*1.01+0.5) SC.jump(); }); }
      raceTick(1); }
    return [R.result&&R.result.placed, R.result&&R.result.timeMs]; })()`);
}
for (let c = 0; c < 4; c++) {
  const name = K.$(`SC.courses[${c}].key`);
  const good = bot(c, 'own', 'good', 1, 1), idle = bot(c, 'own', 'none', 1, 1), noJump = bot(c, 'own', 'good', 1, 0);
  check(`${name}: urge on the stride, save your breath, jump clean — you win`, good[0], 1);
  ok(`${name}: sit there without urging — you don't`, idle[0] >= 3, `place ${idle[0]}`);
  check(`${name}: don't jump — last`, noJump[0], 4);
}
ok('a race takes about a minute', (() => { const g = bot(0, 'own', 'good', 1, 1); return g[1] > 45000 && g[1] < 75000; })());

// ── the finish: gold, the course record, the barding, and back to the realm ──
open();
check('a win pays by place and course, sets the course record, and wins the barding the first time', K.$(`(()=>{ raceRecords={}; player.raceBarding=false; const g0=gold;
  SC.setCourse(1); race.sel=0; SC.begin(); const R=race; R.phase='race'; R.t=40; (()=>{ const R=race, C=R.C, P=R.P, q=SC.pointAt(C,30); P.x=q.x; P.y=q.y; P.idx=q.i; P.prog=R.total+20; })(); R.rivals.forEach(r=>{ r.prog=0; }); SC.step(1/60);
  const r=R.result; return [r.placed, r.gold, r.beatRecord, raceRecords.ironhold>0, r.item]; })()`), [1, 325, true, true, "Seraph's Pet Barding"]);
check('leaving pays out to the realm and brings the d-pad back', K.$(`(()=>{ const g0=gold; racePress('A'); return [gold-g0, player.raceBarding, place.kind, race]; })()`), [325, true, 'overworld', null]);
check('the course records are saved and come back (an old save without them loads at par)', K.$(`(()=>{ raceRecords={ironhold:40000}; const s=JSON.parse(JSON.stringify(buildSaveData()));
  const a=JSON.stringify(s.raceRecords); raceRecords={}; applySaveData(s); const b=raceRecords.ironhold; delete s.raceRecords; applySaveData(s); return [a, b, JSON.stringify(raceRecords)]; })()`), ['{"ironhold":40000}', 40000, '{}']);

// ── controls ──
open();
check('the picker: ◀ ▶ choose the mount, ↑ ↓ the course, Ⓐ starts', K.$(`(()=>{ racePress('RIGHT'); const a=race.sel; racePress('DOWN'); racePress('A'); return [a, race.phase, race.course.key]; })()`), [1, 'countdown', 'ironhold']);
check('racing: ↑ urges once per press, Ⓐ jumps, ◀ ▶ steer', K.$(`(()=>{ const R=race; R.phase='race'; const P=R.P; P.ph=5.0; P.lastTap=-1; raceHold('UP',true); raceTick(1); raceTick(1); const n=R.stats.perfect+R.stats.good+R.stats.miss; raceHold('UP',false);
  racePress('A'); const air=P.air>0; P.air=0; P.v=120; const h0=P.h; raceHold('LEFT',true); for(let i=0;i<10;i++) raceTick(1); raceHold('LEFT',false); return [n, air, P.h!==h0]; })()`), [1, true, true]);
check('the screen draws its own pads (◀ ▶ URGE JUMP) and the touch layer reads them', K.$(`(()=>{ const c=document.createElement('canvas'); c.width=520; c.height=680; drawRace(c.getContext('2d'),520,680);
  return [race.hits.filter(h=>h.pad).map(h=>h.pad).sort().join(), racePadAt(60,600), racePadAt(446,604), racePadAt(344,484)]; })()`), ['jump,left,right,urge', 'left', 'urge', 'jump']);
check('opening the race hides the d-pad, stick and menu buttons; finishing brings them back', K.$(`[openRace.toString().includes("'controls','joy','menuBtn','mountBtn'"), finishRace.toString().includes("getElementById('controls'); if(c) c.style.display=''")]`), [true, true]);

// ── the view ──
ok('every screen draws: picker, countdown, racing, finish', K.$(`(()=>{ const c=document.createElement('canvas'); c.width=520; c.height=680; const g=c.getContext('2d');
  try{ open0(); }catch(e){} return true; })()`.replace('open0();', `place={kind:'overworld'}; race=null; openRace(); drawRace(g,520,680); racePress('A'); drawRace(g,520,680); race.phase='race'; for(let i=0;i<20;i++){ raceTick(1); drawRace(g,520,680); } (()=>{ const R=race, C=R.C, P=R.P, q=SC.pointAt(C,30); P.x=q.x; P.y=q.y; P.idx=q.i; P.prog=R.total+20; })(); SC.step(1/60); drawRace(g,520,680);`)));
ok('each steed and horse looks different from behind', K.$(`(()=>{ const out=new Set(); ['faithful','grace','steadfast','unicorn'].forEach(id=>{ player.pet={id,form:2,look:{}}; place={kind:'overworld'}; race=null; openRace(); SC.begin(); const c=document.createElement('canvas'); c.width=520; c.height=680; drawRace(c.getContext('2d'),520,680);
  const d=race.low.getContext('2d').getImageData(100,190,60,110).data; let h=2166136261; for(let i=0;i<d.length;i+=4){ h=Math.imul(h^d[i],16777619)^d[i+1]; h=Math.imul(h,16777619)^d[i+2]; } out.add(h>>>0); }); return out.size===4; })()`));
check('a slow device falls back to drawing the turf in two-row bands', K.$(`(()=>{ race.drawN=29; race.drawMs=29*20; race.band=0; race.phase='race'; const c=document.createElement('canvas'); c.width=520; c.height=680; drawRace(c.getContext('2d'),520,680); return race.band; })()`), 2);
K.$(`race=null; place={kind:'overworld'};`);
done('steeple');

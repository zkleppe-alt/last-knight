// suite/shadowmere.js — Samuel's hall, and the shape he had learned to admire.
//
// "Study became familiarity, and familiarity became a kind of respect… The Dark
// Paladin came to him wearing the shape he had learned to admire, and he lowered
// his sword to look closer."
//
// So it wears yours. The hall fills with knights; the decoys are REFLECTIONS and
// copy your movement frame for frame, because that is all a reflection can do.
// The Paladin moves on its own. Stop swinging and watch.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('shadowmere');

const T = K.TILE;
function fresh() {
  K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=8; dungeon.floors=getChapelFloors(8); resetDungeonRun();');
  K.$(`loadDungeonFloor(${K.getChapelFloors(8).indexOf(K.FLOOR.sanctum)}, false);`);
  K.$('player.maxHp=9999; player.hp=9999; player.iframes=0; player.blocking=false; player.def=0; player.x=7*TILE; player.y=9*TILE;');
  K.$('dungeon._veil=null; dungeon._veilT=0; dungeon._mirrorsStruck=0; dungeon.bossDead=false;');
  return K.dungeon.grid;
}
// Furniture is checked on the GENERATOR's output, not on a loaded floor:
// loadDungeonFloor consumes the tile-6 cells into real demons and clears them,
// so the boss marker is legitimately gone by the time the floor is playable.
const g0 = K.genShadowmereArena();
check('arena is the standard sanctum footprint', [g0[0].length, g0.length], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g0[1][7] === 7);
ok('the boss is where every sanctum puts it', g0[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g0[2][2] === 5);

const g = fresh();
const H = g.length, W = g[0].length;
ok('the mere is walkable — it is for the eye, not an obstacle',
   K.walkable(4, 4) && g[4][4] === K.T_MERE);

function geom() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  let open = 0, reach = 0, pockets = 0;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!K.walkable(x, y)) continue;
    open++; if (seen.has(y * 100 + x)) reach++;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pockets++;
  }
  return { open, reach, pockets };
}
const gm = geom();
ok('everything reachable', gm.open === gm.reach, `${gm.reach}/${gm.open}`);
ok('no dead-end pocket', gm.pockets === 0, `${gm.pockets}`);
ok('the middle is clear — you must be able to see the whole hall at once',
   gm.open / ((W - 2) * (H - 2)) > 0.9,
   `${(100 * gm.open / ((W-2)*(H-2))).toFixed(0)}% walkable`);

// ── it puts on your shape ─────────────────────────────────────────────────
fresh();
const boss = () => (K.demons || []).find(d => d.boss && d.alive);
globalThis.__p = boss();
for (let i = 0; i < K.VEIL_EVERY + 2; i++) K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
ok('it veils itself', !!K.dungeon._veil);
ok('and the Paladin is wearing the shape', boss().veiled === true);
const mirrors = K.dungeon.adds.filter(a => a.alive && a.mirror);
check('three reflections', mirrors.length, K.VEIL_DECOYS);
ok('none of them start on top of the knight',
   mirrors.every(m => Math.hypot(m.x - K.player.x, m.y - K.player.y) > T * 2),
   'you are never given a free answer by position');

// ── a reflection copies you, frame for frame ──────────────────────────────
const m0 = mirrors[0];
const before = { x: m0.x, y: m0.y };
K.$('dungeon._lastPX=player.x; dungeon._lastPY=player.y;');
K.$('player.x += 3*TILE;');
K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
ok('a reflection moves exactly as you do', Math.abs((m0.x - before.x) - 3 * T) < 0.01,
   `you moved ${3 * T}px, it moved ${Math.round(m0.x - before.x)}px`);
ok('and faces as you face', m0.dir === K.player.dir);

// The Paladin does NOT copy you — that is the only tell.
const bp = { x: boss().x, y: boss().y };
K.$('player.x += 2*TILE;');
K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
ok('the Paladin does not copy you — the one tell in the room',
   boss().x === bp.x && boss().y === bp.y,
   'strike the one that is not moving with you');

// ── cutting a reflection costs you ────────────────────────────────────────
fresh();
for (let i = 0; i < K.VEIL_EVERY + 2; i++) K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
const hp0 = K.player.hp;
K.$('mirrorBurst();');
ok('cutting a reflection bursts in your face', K.player.hp < hp0,
   `hp ${hp0} -> ${K.player.hp}`);

// ── finding it breaks the veil ────────────────────────────────────────────
fresh();
for (let i = 0; i < K.VEIL_EVERY + 2; i++) K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
ok('veiled before the strike', !!K.dungeon._veil && boss().veiled === true);
K.$('applyDemonHit(demons.find(d=>d.boss&&d.alive), 20, false, 1, 0, 1, 2);');
ok('striking the real one breaks the veil', !K.dungeon._veil && boss().veiled === false);
ok('and the reflections go with it',
   K.dungeon.adds.filter(a => a.alive && a.mirror).length === 0);

// ── the veil also lapses on its own ───────────────────────────────────────
fresh();
for (let i = 0; i < K.VEIL_EVERY + 2; i++) K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
K.$('dungeon._veil.until = performance.now() - 1;');
K.$('shadowTick(demons.find(d=>d.boss&&d.alive));');
ok('a veiling times out', !K.dungeon._veil,
   `${(K.VEIL_MS/1000).toFixed(1)}s if you never find it`);

// ── the disguise has to be a real disguise ────────────────────────────────
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('reflections are drawn from the same body routine as the knight',
   /if\(a\.mirror\)\{[\s\S]{0,300}drawKnightBody\(ax, ay/.test(raw),
   'a disguise that renders differently is not a disguise');
ok('and so is the veiled Paladin',
   /d\.veiled && !d\.dying\)\{[\s\S]{0,120}drawKnightBody\(x, y/.test(raw));

// ── the Fallen Plate ──────────────────────────────────────────────────────
ok('the Fallen Plate is a real livery', !!K.LIVERIES.fallen, K.LIVERIES.fallen.name);
ok('flag-unlocked, never bought',
   K.LIVERIES.fallen.flag === 'fallen' && (K.LIVERIES.fallen.req || 0) === 0);
// Checked by CHARACTER, not by exact hex: pinning literal colours means every
// legibility tweak breaks a test for no reason. What matters is that it is dark,
// red-crested and grey-helmed.
const F = K.LIVERIES.fallen;
const lum = h => { const n = parseInt(h.slice(1), 16);
  return (0.299*((n>>16)&255) + 0.587*((n>>8)&255) + 0.114*(n&255)) / 255; };
ok('black and red over grey, as asked',
   lum(F.TUNIC) < 0.28 && lum(F.PLUME) > lum(F.TUNIC) && lum(F.HELM) > 0.3,
   `tunic ${lum(F.TUNIC).toFixed(2)}, plume ${lum(F.PLUME).toFixed(2)}, helm ${lum(F.HELM).toFixed(2)}`);
ok('but not so dark it becomes a silhouette on a dungeon floor',
   lum(F.TUNIC) > 0.12, `tunic luminance ${lum(F.TUNIC).toFixed(2)}`);

K.$('player.fallenPlate=false; player.livery="fallen";');
ok('locked until earned', K.$('liveryUnlocked("fallen")') === false);
ok('and cannot be worn early', K.$('currentLivery()') === 'azure');
K.$('player.fallenPlate=true;');
ok('unlocked once earned', K.$('currentLivery()') === 'fallen');

K.$('player.fallenPlate=true; player.livery="fallen";');
globalThis.__fd = K.$('buildSaveData()');
ok('written into the save', globalThis.__fd.fallenPlate === true);
K.$('player.fallenPlate=false; player.livery="azure";');
K.$('applySaveData(globalThis.__fd);');
ok('and comes back on load',
   K.player.fallenPlate === true && K.player.livery === 'fallen');

ok('awarded only if NO reflection was struck',
   /if\(!dungeon\._mirrorsStruck\)\{/.test(raw),
   'one burst reflection and the plate is gone for that run');
ok('and striking one is counted',
   /dungeon\._mirrorsStruck=\(dungeon\._mirrorsStruck\|\|0\)\+1/.test(raw));

// ── the crest and the wings ───────────────────────────────────────────────
ok('the crest is a broken wing, not a plume',
   /THE FALLEN CREST/.test(raw) && /currentLivery\(\)==='fallen'/.test(raw),
   'another SHAPE change the livery table cannot express');
ok('there are wings, and every span terminates ON the body',
   /THE FALLEN PLATE: WINGS/.test(raw) && /EVERY SPAN TERMINATES ON THE BODY/.test(raw),
   'a left wing ends at x+2, a right wing starts at x+13 — no gap to the shoulder');
// They must be drawn BEFORE the body, or they paint over him instead of
// sitting behind him — which is exactly what the first version did.
const wingAt = raw.indexOf('THE FALLEN PLATE: WINGS');
const bodyAt = raw.indexOf('drawKnightBody(x,y,_dir,f,bob,mb,_swinging)');
ok('drawn BEHIND the body, not over it', wingAt > 0 && bodyAt > wingAt,
   'wings precede the body draw in drawKnight');
// And shaped per facing, or he carries the same silhouette round at every angle.
const wingBlock = raw.slice(wingAt, wingAt + 3000);
ok('shaped per facing', /_dir==='up'/.test(wingBlock) && /_dir==='down'/.test(wingBlock)
   && /_dir==='left'/.test(wingBlock),
   'up, down and profile each get their own span');
ok('the wings change no damage', !/currentLivery\(\)==='fallen'[\s\S]{0,600}player\.atk/.test(raw),
   'purely a skin');


// ── the Armour of God ─────────────────────────────────────────────────────
// Michael's gift is the only EQUIPMENT in the game that changes how the knight
// looks, and it overrides the livery wholesale — an earned Stormward or Fallen
// plate is hidden while it is worn. That is the intended trade.
const rawG = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
// The skin is LIVERY-driven now, not equipment-driven. Owning Michael's gift
// unlocks the livery; the Home tab decides what he wears. Equipping the armour
// no longer silently overrides a hard-won Stormward or Fallen.
K.$('player.ownedGear=player.ownedGear||{}; player.ownedGear["armor_michael"]=true;');
K.$('player.livery="glory";');
ok('choosing it registers', K.$('gloryArmor()') === true);
K.$('player.livery="stormward"; player.stormward=true;');
ok('and choosing something else does not', K.$('gloryArmor()') === false,
   'the armour can be worn WITH a Stormward plate showing');
K.$('player.ownedGear["armor_michael"]=false; player.livery="glory";');
ok('it cannot be worn before Michael gives it', K.$('gloryArmor()') === false);
K.$('player.ownedGear["armor_michael"]=true;');

ok('the glory palette is applied AFTER the livery block',
   rawG.indexOf('THE ARMOUR OF GOD, WORN') > rawG.indexOf('earned livery — applied before'),
   'the table cannot express its crest, wings or cape, so code finishes the job');
ok('it shows itself once, then the Home tab owns the decision',
   /rwId==='armor_michael' && !player\.gloryShown/.test(rawG),
   'so it never re-applies itself over a later choice');
ok('and that is remembered across a save',
   /gloryShown: !!player\.gloryShown/.test(rawG) && /player\.gloryShown=!!s\.gloryShown/.test(rawG));
ok('gold plate, white plume',
   /TUNIC='#e0b64a'[\s\S]{0,200}PLUME='#ffffff'/.test(rawG));
ok('and a gold-and-white shield',
   /SHIELD='#e8c45a'[\s\S]{0,80}SHIELD_FIELD='#fffdf4'/.test(rawG),
   'the cross reads white on gold');
ok('the shield palette had to become reassignable for that',
   /let SHIELD='#b8c0d0'/.test(rawG),
   'it was const — a glory palette could not have touched it');

ok('an upright white crest, not a swept plume',
   /THE ARMOUR OF GOD: THE CREST/.test(rawG));
ok('wings and a cape, drawn behind the body',
   /THE ARMOUR OF GOD: WINGS AND CAPE/.test(rawG)
   && rawG.indexOf('THE ARMOUR OF GOD: WINGS AND CAPE') < rawG.indexOf('drawKnightBody(x,y,_dir,f,bob,mb,_swinging)'));
ok('the wings TAPER rather than being slabs',
   /reach shrinks toward the tip/.test(rawG),
   'four equal-width spans read as a white brick, not a wing');
ok('and every span still terminates on the body',
   /every span terminates ON the body \(x\+2 left, x\+13 right\)/.test(rawG));
// They also have to sit on his BACK. The tunic runs y+5..y+11 and the legs
// start at y+12, so a wing belongs around y+2..y+10 — an earlier version was
// nine pixels tall starting at y+4 and hung off his boots.
ok('the wings are mounted at the shoulder blades, not the feet',
   /a wing belongs in y\+2\.\.y\+9/.test(rawG) && /\[3,1,W4\]\];\s*\/\/ 8 tall/.test(rawG),
   'eight pixels tall, topped at y+1 or y+2 depending on facing');
ok('the cape flares with a ragged hem rather than being a slab',
   /a plain rectangle read as a white slab pinned behind him/.test(rawG));
// Measured: the profile body's right edge is x+11, not x+12. Rooting a wing at
// x+13 left a one-pixel dead gap and the whole white mass read as floating
// beside him. Each wing is now buried two pixels inside the silhouette, with
// the body drawn over the top.
ok('the wings root INSIDE the silhouette so there is no gap',
   /const BURY=2;/.test(rawG) && /the profile body's right edge is x\+11/.test(rawG),
   'the root disappears behind his back, as a real wing would');
ok('and no white reaches his boots any more',
   /place white met gold was AT HIS BOOTS/.test(rawG),
   'the cape was floor-length; it stops at the waist now');

// ── and Abaddon's "ultimate reward" is honestly labelled now ──────────────
ok('the throne-room grant is marked as a safety net, not a prize',
   /it is a SAFETY NET, not a prize/.test(rawG),
   'armor_michael is already owned by anyone who can reach the throne');
ok('the reason is recorded',
   /enterAbaddon refuses entry below[\s\S]{0,120}cleansedCount\(\)>=10/.test(rawG));


// ── the whole flow, driven ────────────────────────────────────────────────
// It shows itself once when Michael gives it, and after that the Home tab owns
// the decision — including against the reward path running a second time.
K.$('player.ownedGear={}; player.livery="azure"; player.gloryShown=false; player.stormward=true; player.fallenPlate=true;');
ok('locked before the gift', K.$('liveryUnlocked("glory")') === false);
ok('and azure until then', K.$('currentLivery()') === 'azure');

K.$('dungeon.townId=9; grantGeneralReward(9);');
ok('it puts itself on the moment it is given', K.$('currentLivery()') === 'glory',
   'so the player sees what it is');
ok('and marks itself shown', K.player.gloryShown === true);

K.$('player.livery="fallen";');
ok('the player can choose something else', K.$('currentLivery()') === 'fallen');
K.$('grantGeneralReward(9);');
ok('and the gift never snaps back over that choice',
   K.$('currentLivery()') === 'fallen',
   'gloryShown gates the auto-apply, so a second run changes nothing');

globalThis.__gd = K.$('buildSaveData()');
K.$('player.livery="azure"; player.gloryShown=false; player.ownedGear={};');
K.$('applySaveData(globalThis.__gd);');
ok('the choice survives a save and load', K.$('currentLivery()') === 'fallen');
ok('and so does the unlock', K.$('liveryUnlocked("glory")') === true);
ok('and the shown flag, so it cannot re-apply on load',
   K.player.gloryShown === true);

// All three earned skins sit in the same list.
ok('three flag-locked liveries, all chosen from one place',
   ['stormward', 'fallen', 'glory'].every(id => K.LIVERIES[id] && K.LIVERIES[id].flag),
   'Stormward, Fallen and the Armour of God');


// ── the older liveries must be untouched ──────────────────────────────────
// Three flag-locked entries were added to this table and liveryUnlocked() gained
// three branches ahead of its trade fallback. The trade ladder has to still
// work, or adding rewards quietly broke the ones that were already there.
K.$('player.stormward=false; player.fallenPlate=false; player.ownedGear={}; sunfallProgress.homecoming=false;');
const ladder = [[0, ['azure']],
                [40, ['azure', 'crimson']],
                [120, ['azure', 'crimson', 'forest']],
                [250, ['azure', 'crimson', 'forest', 'sable']],
                [400, ['azure', 'crimson', 'forest', 'sable', 'argent']]];
for (const [sold, expect] of ladder) {
  K.$(`trade.sold=${sold};`);
  const open = Object.keys(K.LIVERIES).filter(id => K.$(`liveryUnlocked("${id}")`));
  ok(`${sold} goods sold unlocks exactly the right set`,
     JSON.stringify(open) === JSON.stringify(expect), open.join(', '));
}
K.$('sunfallProgress.homecoming=true;');
ok('the Sunfall Gilt still unlocks on homecoming',
   K.$('liveryUnlocked("gilt")') === true, 'its flag branch is unchanged');
K.$('sunfallProgress.homecoming=false;');
ok('and relocks without it', K.$('liveryUnlocked("gilt")') === false);

K.$('trade.sold=400; sunfallProgress.homecoming=true; player.stormward=true; player.fallenPlate=true; player.ownedGear={armor_michael:true};');
ok('with everything earned, all nine are available',
   Object.keys(K.LIVERIES).filter(id => K.$(`liveryUnlocked("${id}")`)).length === 9,
   'four from trading, one from the homecoming, three from feats, plus azure');


// ── the Champion's Plate ──────────────────────────────────────────────────
// _legacy: this was NOT a livery. It was a palette override applied AFTER the
// livery block, keyed straight off player.championRobe, whose own comment said
// it "still overrides". So once the tourney ladder was won the knight looked
// like the Champion for the rest of the game regardless of what he chose —
// silently burying a Stormward, a Fallen, or the Armour of God.
const rawC = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok("the Champion's Plate is a livery like the rest", !!K.LIVERIES.champion,
   K.LIVERIES.champion && K.LIVERIES.champion.name);
ok('unlocked by having won, not forced by having won',
   /if\(L\.flag==='champion'\) return !!player\.championRobe;/.test(rawC));
ok('the palette keys on the CHOSEN livery',
   /if\(currentLivery\(\)==='champion'\)\{/.test(rawC),
   'not on player.championRobe');
ok('and so does its cape — it is drawn separately and would otherwise hang off every other plate',
   (rawC.match(/currentLivery\(\)==='champion'\) cape/g) || []).length >= 3
   && (rawC.match(/currentLivery\(\)==='champion'\) capeMantle/g) || []).length >= 2,
   'three cape draws and two mantle draws, all retargeted');

K.$('player.championRobe=false; player.championShown=false; player.livery="azure";');
ok('locked before the ladder is won', K.$('liveryUnlocked("champion")') === false);
K.$('player.championRobe=true;');
ok('unlocked after', K.$('liveryUnlocked("champion")') === true);
ok('it shows itself once on the win',
   /if\(firstTime && !player\.championShown\)\{ player\.championShown=true; player\.livery='champion'; \}/.test(rawC));
ok('and the flag persists so it cannot re-apply on load',
   /championShown: !!player\.championShown/.test(rawC)
   && /player\.championShown=!!s\.championShown/.test(rawC));

// The real test: with the robe won, can he still wear the Armour of God?
K.$('player.ownedGear={armor_michael:true}; player.championRobe=true; player.livery="glory";');
ok('winning the tourney no longer buries every other skin',
   K.$('currentLivery()') === 'glory' && K.$('gloryArmor()') === true,
   'the Armour of God shows with the robe won — it could not before');

K.$('trade.sold=400; sunfallProgress.homecoming=true; player.stormward=true; player.fallenPlate=true;');
ok('ten liveries with everything earned',
   Object.keys(K.LIVERIES).filter(id => K.$(`liveryUnlocked("${id}")`)).length === 10,
   'four trading, homecoming, tourney, two feats, Michael, plus azure');

done('shadowmere');

// suite/sgvillage.js — Stormgate, the grand capital and its Royal Harbour (2026-10-01 village revamp).
//
// Zak: "Can we reformat the capital to be grander and a cleaner design, something that
// leaves the player in awe", then "now better transition into the docks and navy ships below".
// So Stormgate's layout was rebuilt twice over:
//   stormgateGrand — one processional axis mirrored on the gate (cols 167-168): the royal
//     avenue with its blue-and-gold runner, the circus and the royal fountain, the grand stair,
//     the cathedral on the axis between twin parterres, Keep west and Barracks east, the
//     Market Hall and the Gilded Gate Inn face to face, the Companions' Green holding the
//     fixed pet posts, the Townhouse garden.
//   stormgateHarbour — the axis carried on out to sea: a six-wide sea gate between drum towers,
//     a granite quay, the royal pier down the axis to a landing over the harbour mouth, a
//     galleon either side of it, cutters in the outer basins, the flagship at anchor beyond the
//     mouth, timber piers out to the breakwaters, a lighthouse at each head. The harbour now
//     opens to the sea.
// The art turns on chapelProgress[7]: the storm while bound (rain, lightning, sails furled),
// the calm once cleansed (sunbeams, doves, every sail set) — Psalm 107:29.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('sgvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the grand city, pinned ──
check('the city grid and its heights are pinned', K.$(`(()=>{ const rows=[], el=[]; for(let y=197;y<=229;y++){ rows.push(WORLD[y].slice(149,188).join(',')); for(let x=149;x<=187;x++) el.push(ELEV[x+','+y]||0); }
  return [(${fnv})(rows.join('|')),(${fnv})(el.join(','))]; })()`), ['2abe7454', '1daf1547']);
check('the six buildings, mirrored about the axis', K.$(`buildings.filter(b=>b.id.startsWith('sg_')).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["sg_keep",153,200,6,5,156,204],["sg_cathedral",165,201,6,7,168,207],["sg_inn",178,213,5,4,180,216],["sg_shop",152,213,6,4,155,216],["sg_home1",179,221,4,3,181,223],["sg_guard",178,201,4,4,180,204]]);
check('the cathedral\'s door is on the axis', K.$(`(()=>{ const b=buildings.find(b=>b.id==='sg_cathedral'); return [b.door.x, b.x+b.w/2]; })()`), [168, 168]);
check('the props of the city and the harbour', K.$(`decorations.filter(d=>sgAt(d.x,d.y)&&!d.hs).map(d=>[d.kind,d.x,d.y,d.w||1])`),
  [["fountain",167,218,2],["banner2",162,209,1],["banner2",173,209,1],["lantern",164,215,1],["lantern",171,215,1],["lantern",164,223,1],["lantern",171,223,1],
   ["lantern",158,229,1],["lantern",177,229,1],["sg_cannon",150,229,1],["sg_cannon",185,229,1],["lantern",163,236,1],["lantern",172,236,1],["sg_light",161,238,1],["sg_light",174,238,1]]);
ok('every prop footprint is solid', K.$(`decorations.filter(d=>sgAt(d.x,d.y)&&!d.hs).every(d=>{ const w=d.w||1; for(let y=d.y;y<d.y+w;y++) for(let x=d.x;x<d.x+w;x++) if(WORLD[y][x]!==5) return false; return true; })`));
check('the signs: the city\'s name at the gate, the way up at the stair foot, the harbour on the quay', K.$(`Object.keys(signs).filter(k=>{const[x,y]=k.split(',').map(Number);return sgAt(x,y);}).sort()`),
  ["153,222","155,222","162,213","164,226","171,226","173,213","173,229"]);
check('the Tourney booth moved with its sign; the pet posts stay where the code expects them', K.$(`[RACE_SPOTS.includes('171,226'), RACE_SPOTS.includes('172,207'), TOURNEY_SPOT, STYLIST_SPOT, WORLD[222][153], WORLD[222][155]]`),
  [true, false, "155,222", "153,222", 16, 16]);
check('the townsfolk at the stair foot, the market, the garden and the gate', K.$(`villagers.filter(v=>v.hx>=151&&v.hx<=185&&v.hy>=199&&v.hy<=227).map(v=>[v.hx,v.hy])`),
  [[166,213],[158,217],[176,219],[169,225]]);

// ── the harbour, pinned ──
check('the harbour grid is pinned', K.$(`(()=>{ const rows=[]; for(let y=228;y<=246;y++) rows.push(WORLD[y].slice(145,196).join(',')); return (${fnv})(rows.join('|')); })()`), '373296a2');
check('the sea gate is six wide, as wide as the avenue', K.$(`[164,165,166,167,168,169,170,171].map(x=>WORLD[228][x])`), [5, 10, 10, 10, 10, 10, 10, 5]);
check('the royal pier runs down the axis to its landing', K.$(`[WORLD[231][166],WORLD[231][169],WORLD[235][167],WORLD[237][163],WORLD[237][172],WORLD[231][165],WORLD[231][170]]`), [12, 12, 12, 12, 12, 3, 3]);
check('the harbour mouth is open deep water between the breakwaters', K.$(`[WORLD[238][160], WORLD[238][161], [162,165,168,170,173].map(x=>WORLD[238][x]), WORLD[238][174], WORLD[238][175]]`), [6, 5, [3,3,3,3,3], 5, 6]);
check('His Majesty\'s fleet: two galleons, two cutters, the flagship (bow, waist and stern solid)', K.$(`(()=>{ let n=0; const k=new Set(); for(let y=228;y<=246;y++) for(let x=140;x<=200;x++){ const t=WORLD[y][x]; if(t>=36&&t<=38){ n++; k.add(t); } } return [n, [...k].sort()]; })()`), [56, [36, 37, 38]]);
check('the art and the grid agree on where the ships lie', K.$(`SG_SHIPS.every(([x0,y0,w,h])=>{ for(let y=y0;y<y0+h;y++) for(let x=x0;x<x0+w;x++) if(WORLD[y][x]<36||WORLD[y][x]>38) return false; return true; })`), true);
check('a boat can sail in through the mouth to the royal landing', K.$(`(()=>{ const seen=new Set(['167,250']), q=[[167,250]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
  if(seen.has(k)||X<140||X>200||Y<228||Y>255||!SAIL_TILES.has(WORLD[Y][X])) continue; seen.add(k); q.push([X,Y]); } } return [seen.has('167,238'), seen.has('160,232'), seen.has('167,236'), seen.has('158,234')]; })()`), [true, true, true, false]);
check('the harbour has its name', K.$(`[regionNameAt(167,233), regionNameAt(167,220), regionNameAt(167,203), regionNameAt(167,250)]`),
  ["Stormgate — Royal Harbour","Stormgate — Outer City","Stormgate — The Keep","The Southern Isles"]);

// ── everyone can get everywhere ──
const reach = K.$(`(()=>{ for(let i=0;i<10;i++) chapelProgress[i]=true;
  const seen=new Set(['167,230']), q=[[167,230]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
    if(seen.has(k)||X<130||X>210||Y<185||Y>250||!canStep(x,y,X,Y)) continue; seen.add(k); q.push([X,Y]); } }
  for(let i=0;i<10;i++) delete chapelProgress[i];
  const near=(x,y)=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,c])=>seen.has((x+a)+','+(y+c)));
  let stranded=0; for(let y=199;y<=238;y++) for(let x=145;x<=185;x++) if(WALK.has(WORLD[y][x]) && WORLD[y][x]!==12 && !seen.has(x+','+y)) stranded++;
  return [buildings.filter(b=>b.id.startsWith('sg_')).every(b=>near(b.door.x,b.door.y)),
          villagers.filter(v=>v.hx>=151&&v.hx<=185&&v.hy>=199&&v.hy<=227).every(v=>seen.has(v.hx+','+v.hy)),
          Object.keys(signs).filter(k=>{const[x,y]=k.split(',').map(Number);return sgAt(x,y);}).every(k=>near(...k.split(',').map(Number))),
          [[153,237],[182,237],[167,231],[167,237],[150,238],[160,238],[175,238],[189,238]].every(([x,y])=>seen.has(x+','+y)), stranded]; })()`);
check('from the quay: every door, villager and sign, every pier and breakwater, nothing stranded', reach, [true, true, true, true, 0]);
check('the supply wagon drops at the cathedral\'s door', K.$(`(()=>{ delete DELIVERY_POINTS[7]; ensureDeliveryPoints(); const p=DELIVERY_POINTS[7]; return [p.x,p.y]; })()`), [168, 208]);
check('the rogues\' cell pier still starts from the west breakwater', K.$(`[WORLD[238][RG_JAIL.pierX], WORLD[RG_JAIL.pierY0][RG_JAIL.pierX]]`), [6, 3]);

// ── the drawing ──
const view = (clean, cy) => K.$(`(()=>{ for(let i=0;i<7;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[7]=true; else delete chapelProgress[7];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,f:0,o:0}; const A=drawStormgateBuilding, B=drawStormgateDecor, C=drawStormgateTile, D=stormgateObjs, E=drawStormgateFace;
  drawStormgateBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawStormgateDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawStormgateTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; }; drawStormgateFace=function(){ n.f++; return E.apply(null,arguments); };
  stormgateObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=56; VIEW_TH=52; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=168*TILE; player.y=${cy}*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawStormgateBuilding=A; drawStormgateDecor=B; drawStormgateTile=C; stormgateObjs=D; drawStormgateFace=E;
    for(let i=0;i<8;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean, 222);
  check(`${clean ? 'cleansed' : 'bound'}: the city and the harbour draw`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all six buildings and fifteen props wear Stormgate's art`, [r.n.b, r.n.d], [6, 15]);
  ok(`${clean ? 'cleansed' : 'bound'}: the paving, gardens, walls, quay, piers and harbour water are Stormgate's (got ${r.n.t})`, r.n.t >= 1900);
  ok(`${clean ? 'cleansed' : 'bound'}: the terrace and walls have granite faces (got ${r.n.f})`, r.n.f >= 60);
  check(`${clean ? 'cleansed' : 'bound'}: five ships and the sky layer`, r.n.o, 6);
}
const sails = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[7]=true; else delete chapelProgress[7]; const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ _sgShip(0,100,112,'g',1,0); } finally{ px=A; delete chapelProgress[7]; } return [seen.has('#f2eee2'), seen.has('#8a8478')]; })()`);
check('bound: the fleet rides out the storm with sails furled', sails(false), [false, true]);
check('cleansed: every sail is set', sails(true), [true, false]);
ok('the countryside east of the walls keeps its own art', K.$(`drawStormgateTile(0,0,0,190,205)===false && drawStormgateTile(1,0,0,192,205)===false && drawStormgateTile(2,0,0,190,220)===false`));
ok('the hulls are solid but painted as sea underneath', K.$(`!WALK.has(36) && !WALK.has(37) && !WALK.has(38) && !SAIL_TILES.has(37) && drawStormgateTile(37,0,0,159,234)===true && WORLD[234][159]===37`));

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawStormgateDecor({kind:'lantern',x:164,y:215,w:1,hs:true},0,0)===false`));
ok('the box is Stormgate only', K.$(`sgAt(168,215) && sgAt(167,240) && !sgAt(158,150) && !sgAt(150,250) && !sgAt(92,69)`));
check('a frame of the real loop on the royal pier', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<7;i++) chapelProgress[i]=true; player.x=167*TILE; player.y=233*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<7;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('sgvillage');

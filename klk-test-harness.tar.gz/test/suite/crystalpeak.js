// suite/crystalpeak.js — Lydia's hall, and the cold that did the work.
//
// "She was pardoned and could not believe it, so she set out to deserve it…
// The Frost Revenant never struck her once. It only let her work, out in the
// cold, until she had earned everything and could no longer feel her hands."
//
// So the Revenant is barely the danger. Frost gathers while you are off the fire
// and three times faster while you swing; the only cure is to stand at a fire
// doing nothing. A player who grinds the boss freezes without being hit.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('crystalpeak');

const T = K.TILE;
function fresh() {
  const g = K.genCrystalpeakArena();
  globalThis.__cg = g;
  K.$('place={kind:"dungeon"}; dungeon.townId=5; dungeon.grid=globalThis.__cg; DH=dungeon.grid.length; DW=dungeon.grid[0].length; dungeon.bossDead=false; player.frost=0; player._thawed=false; dungeon._frostT=0;');
  return g;
}
const g = fresh();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

const fires = K.dungeon._fires;
check('two fires', fires.length, 2);
ok('both are stamped as hearths', fires.every(f => g[f.y][f.x] === K.T_HEARTH));
ok('a fire is solid — you stand AT it, not on it',
   fires.every(f => !K.walkable(f.x, f.y)));
ok('the fires are at opposite walls, away from where the boss stands',
   Math.abs(fires[0].x - fires[1].x) > 6,
   `x ${fires[0].x} and ${fires[1].x}, boss at 7`);

// ── the floor must be crossable under a slow ───────────────────────────────
// Crossing it while slowed IS the fight, so nothing may obstruct the run.
function geom() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  let open = 0, reach = 0, pockets = 0;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!K.walkable(x, y)) continue;
    open++; if (seen.has(y * 100 + x)) reach++;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pockets++;
  }
  return { open, reach, pockets };
}
const gg = geom();
ok('everything reachable', gg.open === gg.reach, `${gg.reach}/${gg.open}`);
ok('no dead-end pocket', gg.pockets === 0, `${gg.pockets}`);
ok('the hall is wide open — you have to be able to run for a fire',
   gg.open / ((W - 2) * (H - 2)) > 0.95,
   `${(100 * gg.open / ((W-2)*(H-2))).toFixed(0)}% walkable`);

// ── frost gathers off the fire ─────────────────────────────────────────────
fresh();
K.$('player.x=7*TILE; player.y=7*TILE;');          // mid-floor, away from both fires
ok('mid-floor is NOT warm', K.$('frostWarm()') === false);
for (let i = 0; i < 60; i++) K.$('crystalTick();');
const idleOneSec = K.player.frost;
ok('standing out on the floor chills you', idleOneSec > 0,
   `${idleOneSec.toFixed(1)} frost after 1s idle`);

// swinging is the work that froze her
fresh();
K.$('player.x=7*TILE; player.y=7*TILE; player.atkT=10;');
for (let i = 0; i < 60; i++) K.$('crystalTick();');
const workOneSec = K.player.frost;
ok('swinging chills you far faster than standing does', workOneSec > idleOneSec * 2,
   `${workOneSec.toFixed(1)} working vs ${idleOneSec.toFixed(1)} idle, per second`);

// ── the fire is free ───────────────────────────────────────────────────────
fresh();
K.$(`player.x=${fires[0].x}*TILE; player.y=${(fires[0].y + 1)}*TILE; player.frost=${K.FROST_MAX};`);
ok('standing by a fire counts as warm', K.$('frostWarm()') === true);
for (let i = 0; i < 120; i++) K.$('crystalTick();');
ok('the fire sheds all of it, and costs nothing', K.player.frost === 0,
   'the debt was torn up years ago');

// ── past the threshold the cold takes hands, with no help from the boss ────
fresh();
K.$(`player.x=7*TILE; player.y=7*TILE; player.frost=${K.FROST_MAX}; player.maxHp=9999; player.hp=9999;`);
const hpBefore = K.player.hp;
for (let i = 0; i < 180; i++) K.$('crystalTick();');
ok('at full frost the cold alone hurts you', K.player.hp < hpBefore,
   `hp ${hpBefore} -> ${K.player.hp} over 3s, untouched by the Revenant`);

// ── and it slows you before it hurts you ──────────────────────────────────
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('frost costs speed, scaling in rather than snapping on',
   /dungeon\.townId===5 && \(player\.frost\|\|0\)>FROST_SLOW_AT/.test(raw) &&
   /spd \*= 1 - 0\.42\*Math\.min\(1,over\)/.test(raw),
   'the player feels it coming and can still reach a fire');
ok('the Revenant chills rather than wounds',
   /dungeon\.townId===5 && !p\.nova/.test(raw) && /player\.frost=Math\.min\(FROST_MAX,\(player\.frost\|\|0\)\+9\)/.test(raw),
   '"it never struck her once"');

// ── the meter must be visible ──────────────────────────────────────────────
// An invisible meter that kills you is a trap, not a mechanic.
ok('the cold is drawn as rime and as a readable bar',
   /function drawFrost\(\)/.test(raw) && /ctx\.fillText\('COLD'/.test(raw));
ok('and it is wired into the sanctum draw',
   /dungeon\.townId===5\) drawFrost\(\)/.test(raw));

// ── frost never leaks out of this chapel ──────────────────────────────────
K.$('place={kind:"overworld"}; crystalTick();');
ok('frost clears the moment you are anywhere else', (K.player.frost || 0) === 0,
   'it is not a status the player carries into the next chapel');

// ── the timings are humane ────────────────────────────────────────────────
const toSlowWorking = K.FROST_SLOW_AT / K.FROST_WORK / 60;
const toBiteIdle = K.FROST_BITE_AT / K.FROST_IDLE / 60;
const thawFull = K.FROST_MAX / K.FROST_THAW / 60;
ok('you get a couple of attack bursts before the slow bites',
   toSlowWorking > 1.5 && toSlowWorking < 5, `${toSlowWorking.toFixed(1)}s of swinging`);
ok('merely walking about is not a death sentence', toBiteIdle > 10,
   `${toBiteIdle.toFixed(1)}s idle to reach the bite`);
ok('a trip to the fire is short enough to be worth making', thawFull < 3,
   `${thawFull.toFixed(1)}s at a fire from full`);

done('crystalpeak');

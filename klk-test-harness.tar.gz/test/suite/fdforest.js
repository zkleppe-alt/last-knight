// suite/fdforest.js — the Forest of Disillusionment, redrawn (2026-10-01).
//
// Zak: "let's upgrade the forest of disillusionment". Drawing only: the maze, its chests,
// the Sage's hollow and Robby's door are unchanged. The wood is one matted canopy (crowns on
// a lattice so trees knit without seams), twisted trunks, roots and hanging moss where it
// faces a path; paths of dry earth and litter with roots, twigs, toadstools and cobwebs; the
// way on lit by daylight; mist drifting through the lamplight; and false lights and eyes in
// the dark beyond it, which fade as you come close.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('fdforest');

const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; enterDisillusionment('north');`);

// ── the maze is the maze it was ──
check('the maze grid is exactly as before the art pass', K.$(`[(${fnv})(dungeon.grid.map(r=>r.join(',')).join('|')), DW, DH]`), ['daf6d358', 21, 41]);
check('Robby\'s door and the Sage\'s hollow are where they were', K.$(`[dungeon.grid[22][3], dungeon.grid[37][7]]`), [78, 35]);

// ── what the forest art draws, and what it leaves alone ──
const find = (t) => K.$(`(()=>{ for(let y=0;y<DH;y++) for(let x=0;x<DW;x++) if(dungeon.grid[y][x]===${t}) return [x,y]; return null; })()`);
for (const [t, name] of [[0, 'path'], [1, 'tree'], [2, 'the way on'], [8, 'the way back']]) {
  const at = find(t); ok(`the ${name} (${t}) is drawn by the forest art`, at && K.$(`drawDisillusionTile(${t},0,0,${at[0]},${at[1]})===true`));
}
for (const [t, name] of [[5, 'a chest'], [35, 'the Sage\'s hollow']]) {
  const at = find(t); ok(`${name} (${t}) keeps the engine's own art`, at && K.$(`drawDisillusionTile(${t},0,0,${at[0]},${at[1]})===false`));
}
ok('the hook only runs in the cursed wood, not in Eldan\'s Glade', /if\(dungeon\.disillusion && !dungeon\.inGlade && drawDisillusionTile\(t,sx,sy,x,y\)\) return;/.test(require('fs').readFileSync(require('path').join(__dirname,'..','..','index.html'),'utf8')));

// ── Robby's door gives nothing away ──
check('Robby\'s door counts as a tree for all eight neighbours (each draws exactly as if a tree stood there)', K.$(`(()=>{ const dif=[]; for(let b=-1;b<=1;b++) for(let a=-1;a<=1;a++){ if(!a&&!b) continue; const x=3+a, y=22+b, t=dungeon.grid[y][x];
    const shot=()=>{ _fdTiles.clear(); const c=_fdSprite(x,y,t===1?(ox,oy)=>_fdTreeTile(ox,oy,x,y):(ox,oy)=>_fdFloor(ox,oy,x,y,null)); return c.toDataURL?c.toDataURL():JSON.stringify(c.getContext('2d')._ops||''); };
    const withDoor=shot(); dungeon.grid[22][3]=1; const withTree=shot(); dungeon.grid[22][3]=78; if(withDoor!==withTree) dif.push(x+','+y); } _fdTiles.clear(); return dif; })()`), []);
check('it is drawn by the very same painter as a tree, from the very same cache entry', K.$(`(()=>{ let calls=[]; const A=_fdTreeTile; _fdTreeTile=function(ox,oy,x,y){ calls.push(x+','+y); return A.apply(null,arguments); };
  try{ _fdTiles.clear(); drawDungeonTile(78,0,0,3,22); drawDungeonTile(78,0,0,3,22); } finally{ _fdTreeTile=A; } return calls; })()`), ['3,22']);
ok('the tile above it sees a tree below (no wood-face tell)', K.$(`dungeon.grid[21][3]===1 ? _fdTree(3,22) : true`));

// ── the cache ──
check('each tile is painted once per visit and reused', K.$(`(()=>{ _fdTiles.clear(); let n=0; const A=_fdFloor; _fdFloor=function(){ n++; return A.apply(null,arguments); };
  const at=(()=>{ for(let y=0;y<DH;y++) for(let x=0;x<DW;x++) if(dungeon.grid[y][x]===0) return [x,y]; })();
  try{ for(let i=0;i<4;i++) drawDisillusionTile(0,0,0,at[0],at[1]); } finally{ _fdFloor=A; } return n; })()`), 1);

// ── the air ──
check('the mist and the dark draw without error', K.$(`(()=>{ try{ disillusionMist(0,0); disillusionDark(0,0,VW/2,VH/2,3*TILE); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
check('nothing in the dark is ever drawn within five tiles of the knight', K.$(`(()=>{ let near=0; const A=px; const PX=player.x, PY=player.y, camX=PX-VW/2, camY=PY-VH/2;
  px=function(x,y,w,h,c){ if((c==='#eafff8'||c==='#e8e0b0') && Math.hypot(x+camX-PX, y+camY-PY)<5*TILE) near++; return A(x,y,w,h,c); };
  try{ for(let i=0;i<30;i++){ player.x=PX+((i*37)%9-4)*TILE; disillusionDark(camX,camY,VW/2,VH/2,3*TILE); } } finally{ px=A; player.x=PX; } return near; })()`), 0);

// ── real frames in the wood ──
for (const [x, y] of [[11, 2], [10, 20], [7, 36]])
  check(`a frame of the real loop in the wood at ${x},${y}`, K.$(`(()=>{ player.x=${x}*TILE; player.y=${y}*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } return r; })()`), 'ok');
check('and Eldan\'s Glade still draws in its own way', K.$(`(()=>{ let r='ok'; const pX=player.x, pY=player.y; try{ player.x=7*TILE; player.y=37*TILE; enterSageGlade(); loop(performance.now()); r=dungeon.inGlade?'ok':'not in glade'; }catch(e){ r=e.message; } return r; })()`), 'ok');

done('fdforest');

// suite/lib.js — the smallest thing that can fail loudly.
let pass = 0, fail = 0;
const failures = [];

function check(name, got, want) {
  const ok = JSON.stringify(got) === JSON.stringify(want);
  if (ok) { pass++; console.log(`  ok   ${name}  = ${fmt(got)}`); }
  else { fail++; failures.push(name); console.log(`  FAIL ${name}\n         got  ${fmt(got)}\n         want ${fmt(want)}`); }
  return ok;
}

function ok(name, cond, detail) {
  if (cond) { pass++; console.log(`  ok   ${name}${detail ? '  ' + detail : ''}`); }
  else { fail++; failures.push(name); console.log(`  FAIL ${name}${detail ? '\n         ' + detail : ''}`); }
  return !!cond;
}

function fmt(v) {
  if (typeof v === 'string') return JSON.stringify(v);
  if (Array.isArray(v) && v.length > 12) return `[${v.slice(0, 12).join(', ')}, …${v.length}]`;
  return typeof v === 'object' ? JSON.stringify(v) : String(v);
}

function done(label) {
  console.log(`  ── ${label}: ${pass} passed, ${fail} failed`);
  if (fail) { console.log('  failing: ' + failures.join(', ')); process.exitCode = 1; }
  return fail === 0;
}

// Flood fill over the active grid using the game's own walkable(), four-way.
function flood(K, sx, sy, pred) {
  const test = pred || ((x, y) => K.walkable(x, y));
  const W = K.WORLD_W, H = K.WORLD_H;
  if (!test(sx, sy)) return { n: -1, seen: new Set() };
  const seen = new Set([sy * W + sx]);
  const st = [[sx, sy]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * W + nx;
      if (seen.has(k) || !test(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return { n: seen.size, seen };
}

module.exports = { check, ok, done, flood, fmt };

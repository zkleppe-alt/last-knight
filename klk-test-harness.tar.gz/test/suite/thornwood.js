// suite/thornwood.js — Deborah's hall, and what was under her own floor.
//
// "She was certain the corruption came in over the wall, because she had
// examined the wall and not herself. The Root Fiend had been under her own floor
// since the first spring."
//
// The fight is that: the thing in front of you is not the problem. While any
// root stands the Fiend knits itself back together, so hitting the body all
// fight gets you nowhere — which is Deborah burning the rot out twice.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('thornwood');

const T = K.TILE;
const g = K.genThornwoodArena();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

globalThis.__tg = g;
K.$('place={kind:"dungeon"}; dungeon.townId=3; dungeon.grid=globalThis.__tg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');

// The chest is stamped after the brambles and would silently eat one placed at
// the same spot, leaving five where the code says six.
const bram = K.dungeon._bramble;
check('six brambles declared', bram.length, 6);
let onFloor = 0;
for (const b of bram) if (g[b.y] && g[b.y][b.x] === K.T_BRAMBLE) onFloor++;
ok('all six actually survive onto the floor', onFloor === 6,
   `${onFloor}/6 — the rest were overwritten by later stamps`);
ok('brambles are solid cover', bram.every(b => !K.walkable(b.x, b.y)));

// ── the floor is the fight, so it must be clear ────────────────────────────
function flood() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}
let open = 0, reach = 0;
const seen = flood();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { open++; if (seen.has(y * 100 + x)) reach++; }
}
ok('every open tile is reachable', open === reach, `${reach}/${open}`);
const pockets = [];
for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
  if (!K.walkable(x, y)) continue;
  const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
  if (exits <= 1) pockets.push(`${x},${y}`);
}
ok('no dead-end pocket', pockets.length === 0, pockets.join(' ') || 'clear');
ok('the middle of the floor is open — roots must be spottable',
   open / ((W - 2) * (H - 2)) > 0.9,
   `${(100 * open / ((W-2)*(H-2))).toFixed(0)}% walkable`);

// ── roots come up where you are NOT ────────────────────────────────────────
function setup() {
  K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=3; dungeon.floors=getChapelFloors(3); resetDungeonRun();');
  K.$(`loadDungeonFloor(${K.getChapelFloors(3).indexOf(K.FLOOR.sanctum)}, false);`);
  // The knight has to SURVIVE the measurement. Camped in a corner for 25s he
  // dies, the chapel unloads, demons is cleared, and the next line reads
  // undefined — which looks like the boss failing to spawn and is not.
  K.$('player.maxHp=99999; player.hp=99999; player.x=2*TILE; player.y=2*TILE;');
}
setup();
let far = 0, total = 0;
for (let i = 0; i < 1500; i++) {
  K.frames(1);
  const b = (K.demons || []).find(d => d.boss && d.alive); if (!b) break;
}
for (const a of (K.dungeon.adds || []).filter(a => a.root)) {
  total++;
  const d = Math.hypot(a.x - 2 * T, a.y - 2 * T);
  if (d > 6 * T) far++;
}
ok('roots surface at all', total > 0, `${total} came up over 25s`);
ok('they come up AWAY from the knight — the part of the room he is not working in',
   total === 0 || far === total, `${far}/${total} surfaced more than six tiles off`);
ok('never more than the cap at once',
   (K.dungeon.adds || []).filter(a => a.alive && a.root).length <= K.ROOT_CAP,
   `cap ${K.ROOT_CAP}`);

// ── while a root stands, the body knits itself back ────────────────────────
// THIS is the assertion that matters. Ironhold taught the lesson: a predicate
// can be perfect and the fight still wrong, so run the fight and measure.
setup();
K.$('player.x=2*TILE; player.y=2*TILE;');
for (let i = 0; i < 600; i++) K.frames(1);        // let roots come up
const boss1 = (K.demons || []).find(d => d.boss && d.alive);
const rootsUp = (K.dungeon.adds || []).filter(a => a.alive && a.root).length;
ok('roots are standing before the measurement', rootsUp > 0, `${rootsUp} up`);
globalThis.__fb = boss1;
K.$('__fb = demons.find(d=>d.boss && d.alive); __fb.hp = Math.round(__fb.maxHp*0.5);');
const hpBefore = boss1.hp;
for (let i = 0; i < 180; i++) K.frames(1);        // three seconds, untouched
ok('with roots up it heals on its own', boss1.hp > hpBefore,
   `hp ${Math.round(hpBefore)} -> ${Math.round(boss1.hp)} in 3s`);
ok('it cannot heal past full', boss1.hp <= boss1.maxHp);

// Cut every root and the regrowth stops.
// Cut every root AND hold off the next one: ROOT_EVERY is 150 frames, so a
// fresh root surfaces inside the 180-frame window and the regrowth resumes
// legitimately. That is the design, not a bug — the test has to isolate it.
K.$('for(const a of dungeon.adds) if(a.root) a.alive=false;');
K.$('__fb = demons.find(d=>d.boss && d.alive); __fb._rootT = 100000;');
K.$('__fb = demons.find(d=>d.boss && d.alive); __fb.hp = Math.round(__fb.maxHp*0.5);');
const hp2 = boss1.hp;
for (let i = 0; i < 180; i++) K.frames(1);
ok('with every root cut, the regrowth stops', Math.abs(boss1.hp - hp2) < 1,
   `hp ${Math.round(hp2)} -> ${Math.round(boss1.hp)} over 3s with nothing feeding it`);

// ── and the player is told why ─────────────────────────────────────────────
// RAW, not stripped: game.stripped.js blanks string BODIES, so
// `place.kind==='dungeon'` becomes `place.kind==='       '` and no regex
// containing the literal can ever match. Stripped answers "is this code live";
// raw answers "what does it say". I have now walked into this twice.
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
const src = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');
ok('a blow landed during regrowth says so',
   /dungeon\.townId===3 && place\.kind==='dungeon' && d\._regrowing/.test(raw),
   'silent healing just reads as a boss with too much health');
ok('roots are ADDS, not tiles — they can never corner anyone',
   /alive:true, speed:0, add:true, root:true/.test(src));

done('thornwood');

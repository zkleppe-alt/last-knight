// suite/race3d.js — the chase-camera boat race (2026-10-06, tag 2026-10-06-br).
//
// Zak: "revamp the boat simulation race, it's really hard to know what's going on and seems more like luck than skill",
// then "like a 3rd person racing game, similar to Mario Kart 64, but with boats". Skills: the wind, tight turns at
// buoys, boost gates, timed oar strokes. Rivals fair and fixed. Saltmere races this way; the other harbours keep the
// lane race until their courses are laid out.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('race3d');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'};`);
const open = (course, diff, eq) => K.$(`(()=>{ openBoatRaceGate(); boat.course='${course}'; boat.difficulty='${diff||'rough'}';
  boat.equipped=Object.assign({hull:'hull_oak',sail:'sail_plain',figure:'fig_none',engine:'eng_oar',keel:'keel_flat'}, ${JSON.stringify(eq||{})}); return 1; })()`);
const go = () => K.$(`(()=>{ BOAT_RACE3D.start(); const R=boat.race; R.phase='racing'; R.count=0; return 1; })()`);

// ── which harbours race this way ──
open('saltmere');
check('every harbour races with the chase camera (Saltmere first, then the other four: "Beautiful! Let\'s do it!")', K.$(`(()=>{ const out=[];
  for(const h of ['saltmere','capital','mistral','tabor','sunfall']){ boat.course=h; boat.screen='dock'; boat.race=null;
    // ENTER RACE is a button on the dock: press it the way a tap does
    const c=document.createElement('canvas'); c.width=520; c.height=680; drawBoat(c.getContext('2d'),520,680);
    const btn=boat.hits.find(h=>h.fn && h.y>440 && h.y<470); btn.fn(); out.push(!!(boat.race && boat.race.v3)); boat.race=null; boat.screen='dock'; }
  return out; })()`), [true, true, true, true, true]);

// ── the course ──
open('saltmere'); go();
const C = K.$(`(()=>{ const C=boat.race.C; return { n:C.line.length, len:Math.round(C.len), marks:C.marks.map(m=>[m.n,Math.round(m.d)]), gates:C.gates.length, gap:Math.round(Math.hypot(C.line[0][0]-C.line[C.line.length-1][0], C.line[0][1]-C.line[C.line.length-1][1])) }; })()`);
ok('the course is a closed loop (its last point runs back to its first)', C.gap < 40, `gap ${C.gap}`);
ok('four numbered buoys, in order round the lap', JSON.stringify(C.marks.map(m=>m[0]))==='[1,2,3,4]' && C.marks.every((m,i)=>i===0||m[1]>C.marks[i-1][1]), JSON.stringify(C.marks));
check('three gold gates', C.gates, 3);
ok('a lap takes about half a minute in the starter boat (4,000–4,500 units)', C.len>4000 && C.len<4500, `${C.len}`);

// ── the wind ──
check('into the wind is slow, a beam reach is fastest', K.$(`[BOAT_RACE3D.polar(0)<0.25, BOAT_RACE3D.polar(1.6)>=0.99, BOAT_RACE3D.polar(Math.PI)<0.9]`), [true, true, true]);
ok('reading the wind pays: tacking ~45° off it makes more ground upwind than pointing straight into it', K.$(`(()=>{ const R=boat.race, to=R.C.spec.windTo, from=to+Math.PI;
  const vmg=(off)=>BOAT_RACE3D.windEff(R, from+off)*Math.cos(off); return vmg(0.8) > vmg(0)*1.08; })()`));

// ── the oar stroke ──
const stroke = (frac, twice) => K.$(`(()=>{ BOAT_RACE3D.start(); boat.race.phase='racing'; const R=boat.race, P=R.player; P.v=100; P.ph=3+${frac}; P.lastTap=-1; BOAT_RACE3D.row(); const v1=P.v; ${twice ? 'BOAT_RACE3D.row();' : ''} return [Math.round(v1), Math.round(P.v), R.strokes]; })()`);
const perf = stroke(0.01), good = stroke(0.10), miss = stroke(0.4), dbl = stroke(0.01, true);
ok('a perfect stroke adds more speed than a good one', perf[0] > good[0] && good[0] > 100, `${perf[0]} vs ${good[0]}`);
ok('an off-beat stroke loses a little speed', miss[0] < 100 && miss[0] >= 95, `${miss[0]}`);
check('a second tap on the same beat does nothing (mashing can\'t help)', [dbl[1] === dbl[0], dbl[2].perfect, dbl[2].miss], [true, 1, 0]);

// ── the real controls ──
open('saltmere'); go();
check('the ROW pad, ↑ and Ⓐ each row once per tap; holding does not keep rowing', K.$(`(()=>{ const R=boat.race, P=R.player; const n=()=>R.strokes.perfect+R.strokes.good+R.strokes.miss;
  P.ph=5.0; P.lastTap=-1; boatHold('UP',true); boatTick(1/60); boatTick(1/60); boatTick(1/60); const a=n(); boatHold('UP',false); boatTick(1/60);
  P.ph=6.0; boatSetPads({throttle:true}); boatTick(1/60); boatTick(1/60); const b2=n(); boatSetPads({throttle:false}); boatTick(1/60);
  P.ph=7.0; boatPress('A'); const c=n(); return [a,b2,c]; })()`), [1, 2, 3]);
check('◀ and ▶ turn the bow', K.$(`(()=>{ const R=boat.race, P=R.player; P.v=120; const h0=P.h; boatHold('LEFT',true); for(let i=0;i<20;i++) boatTick(1/60); boatHold('LEFT',false); const h1=P.h;
  boatHold('RIGHT',true); for(let i=0;i<40;i++) boatTick(1/60); boatHold('RIGHT',false); return [h1<h0, P.h>h1]; })()`), [true, true]);
check('Ⓑ leaves the race for the dock', K.$(`(()=>{ boatPress('B'); return [boat.screen, boat.race]; })()`), ['dock', null]);

// ── gates and buoys ──
open('saltmere'); go();
const gate = (dl) => K.$(`(()=>{ BOAT_RACE3D.start(); const R=boat.race, C=R.C, P=R.player, g=C.gates[0]; R.phase='racing';
  const p=BOAT_RACE3D.point(C, g.d-40); P.prog=g.d-40; P.idx=p.i; P.h=p.ang; P.v=150; P.boostT=0;
  P.x=p.x+(-Math.sin(p.ang))*(g.lat+${dl}); P.y=p.y+Math.cos(p.ang)*(g.lat+${dl});
  for(let i=0;i<40;i++) BOAT_RACE3D.step(1/60); return [R.gatesHit, P.boostT>0]; })()`);
check('sail through a gold gate: BOOST', gate(0), [1, true]);
check('sail past beside it: no boost', gate(32), [0, false]);
check('clip a buoy and you lose speed; round it tight and you get a burst', K.$(`(()=>{ BOAT_RACE3D.start(); const R=boat.race, C=R.C, P=R.player, m=C.marks[0]; R.phase='racing';
  const run=(off)=>{ const p=BOAT_RACE3D.point(C, m.d-30); P.prog=m.d-30; P.idx=p.i; P.h=p.ang; P.v=150; P.boostT=0; P.next=1; P.callout=null;
    const nx=(m.x-p.x), ny=(m.y-p.y), l=Math.hypot(nx,ny)||1; P.x=p.x+nx/l*(l-off); P.y=p.y+ny/l*(l-off); P.h=Math.atan2(m.y-P.y,m.x-P.x)*0+p.ang;
    let minV=999; for(let i=0;i<50;i++){ BOAT_RACE3D.step(1/60); minV=Math.min(minV,P.v); } return [Math.round(minV), P.callout]; };
  const hitIt=run(0), tight=run(16); return [hitIt[0]<100, hitIt[1], tight[1]]; })()`), [true, 'CLIPPED THE BUOY', 'TIGHT TURN!']);
check('off the channel is rough water (slower); the far rope holds you in', K.$(`(()=>{ BOAT_RACE3D.start(); const R=boat.race, C=R.C, P=R.player; R.phase='racing';
  const p=BOAT_RACE3D.point(C, 600); P.prog=600; P.idx=p.i; P.h=p.ang; P.v=150; P.x=p.x+(-Math.sin(p.ang))*60; P.y=p.y+Math.cos(p.ang)*60;
  for(let i=0;i<90;i++) BOAT_RACE3D.step(1/60); const v=P.v, off=P.off;
  P.x=p.x+(-Math.sin(p.ang))*200; P.y=p.y+Math.cos(p.ang)*200; P.idx=p.i; BOAT_RACE3D.step(1/60); const N=BOAT_RACE3D.near(C,P.x,P.y,P.idx);
  return [off, v<120, Math.abs(N.lat)<=C.W/2+31]; })()`), [true, true, true]);

// ── fair rivals ──
check('rivals hold their own pace whether you lead or trail (no catching up, no easing off)', K.$(`(()=>{ const sp=(lead)=>{ BOAT_RACE3D.start(); const R=boat.race, P=R.player; R.phase='racing';
  for(let i=0;i<300;i++){ P.prog=R.rivals[0].prog+lead; P.x=-9e3; P.y=-9e3; BOAT_RACE3D.step(1/60); } return Math.round(R.rivals[0].v); }; return sp(-2000)===sp(2000); })()`), true);
check('harder difficulties field faster crews', K.$(`(()=>{ const pace=(d)=>{ boat.difficulty=d; BOAT_RACE3D.start(); return Math.max(...boat.race.rivals.map(r=>r.pace)); }; const a=pace('calm'), b=pace('rough'), c=pace('cutthroat'); boat.difficulty='rough'; return a<b && b<c; })()`), true);

// ── skill decides it: a bot sailing the whole race ──
function botOn(course, diff, rowing, gates, eq) {
  open(course, diff, eq);
  return K.$(`(()=>{ const X=BOAT_RACE3D; X.start(); const b=boat, R=b.race, C=R.C, P=R.player; let t=0; const dt=1/60;
    while(b.race && t<300){ t+=dt;
      let lat=0; if(${gates}) for(const g of C.gates){ const ahead=((g.d-P.prog)%C.len+C.len)%C.len; if(ahead<260){ lat=g.lat; break; } }
      const tp=X.point(C,P.prog+70), tx=tp.x+(-Math.sin(tp.ang))*lat, ty=tp.y+Math.cos(tp.ang)*lat;
      let d=Math.atan2(ty-P.y,tx-P.x)-P.h; while(d>Math.PI) d-=2*Math.PI; while(d<-Math.PI) d+=2*Math.PI;
      R.keys.left=d<-0.04; R.keys.right=d>0.04;
      if(R.phase==='racing'){ const f=P.ph-Math.floor(P.ph);
        if('${rowing}'==='perfect' && (f<0.02||f>0.98) && Math.round(P.ph)!==P.lastTap) X.row();
        if('${rowing}'==='good' && Math.abs(f-0.10)<0.01 && Math.round(P.ph)!==P.lastTap) X.row(); }
      boatTick(dt); }
    return [b.result && b.result.place, b.result && b.result.time]; })()`);
}
function bot(diff, rowing, gates, eq) { return botOn('saltmere', diff, rowing, gates, eq); }
const rG = bot('rough', 'good', true), rN = bot('rough', 'none', false), cP = bot('cutthroat', 'perfect', true), cG = bot('cutthroat', 'good', true), cU = bot('cutthroat', 'good', true, { engine:'eng_double', sail:'sail_gold', keel:'keel_fin' });
check('Rough: good strokes and the gates win', rG[0], 1);
check('Rough: not rowing at all loses', rN[0], 4);
check('Cutthroat: near-perfect strokes and the gates win', cP[0], 1);
ok('Cutthroat: good strokes alone fall short in the starter boat', cG[0] > 1, `place ${cG[0]}`);
check('Cutthroat: a better boat (double mast, gilded sail, fin keel) makes good strokes enough', cU[0], 1);
ok('two laps take about a minute', rG[1] > 45 && rG[1] < 70, `${rG[1]} s`);

// ── finishing ──
check('a win pays gold and Saltmere\'s prize (the Stormcaller sail), and shows the results', K.$(`(()=>{ const r=boat.result; return [r.place, r.gold>0, r.unlocked, boat.screen]; })()`), [1, true, 'sail_storm', 'results']);
ok('the results screen draws', K.$(`(()=>{ const c=document.createElement('canvas'); c.width=520; c.height=680; try{ drawBoat(c.getContext('2d'),520,680); return true; }catch(e){ return e.message; } })()`) === true);

// ── the five courses ──
for (const k of ['saltmere','capital','mistral','tabor','sunfall']) {
  const g = K.$(`(()=>{ openBoatRaceGate(); boat.course='${k}'; BOAT_RACE3D.start(); const C=boat.race.C, L=C.line, N=L.length, W=C.W;
    const gap=Math.hypot(L[0][0]-L[N-1][0],L[0][1]-L[N-1][1]);
    let par=0; for(let i=0;i<N;i+=2) for(let j=i+30;j<N;j+=2){ if(N-(j-i)<30) continue; const d=Math.hypot(L[i][0]-L[j][0],L[i][1]-L[j][1]); if(d>W+70) continue;
      const ai=Math.atan2(L[(i+1)%N][1]-L[i][1],L[(i+1)%N][0]-L[i][0]), aj=Math.atan2(L[(j+1)%N][1]-L[j][1],L[(j+1)%N][0]-L[j][0]); let da=Math.abs(ai-aj)%(2*Math.PI); if(da>Math.PI) da=2*Math.PI-da; da=Math.min(da,Math.PI-da); if(da<0.8) par++; }
    let isl=1e9; (C.spec.islands||[]).forEach(I=>{ for(const p of L) isl=Math.min(isl, Math.hypot(p[0]-I[0],(p[1]-I[1])/0.8)-I[2]); });
    const r=[gap<40, L.every(p=>p[0]>W&&p[1]>W&&p[0]<C.S-W&&p[1]<C.S-W), par===0, isl>W/2+15, C.marks.length>=3, C.gates.length>=3, Math.round(C.len*boat.race.laps)];
    boat.race=null; return r; })()`);
  ok(`${k}: a closed loop inside its sea, no legs running alongside each other, islands clear of the channel, buoys and gates`, g.slice(0,6).every(Boolean), JSON.stringify(g));
  ok(`${k}: the whole race is 8,000–10,500 units (about a minute)`, g[6] > 8000 && g[6] < 10500, `${g[6]}`);
}
for (const k of ['capital','mistral','tabor','sunfall']) {
  const good = botOn(k, 'rough', 'good', true), none = botOn(k, 'rough', 'none', false);
  check(`${k}, Rough: good strokes and the gates win; not rowing loses`, [good[0], none[0]], [1, 4]);
}
check('rival crews slow for a tight turn (Sunfall\'s hairpins), and run free on the straights', K.$(`(()=>{ openBoatRaceGate(); boat.course='sunfall'; boat.difficulty='rough'; BOAT_RACE3D.start(); const R=boat.race, C=R.C, r=R.rivals[2];
  let tight=0; for(let i=0;i<C.rad.length;i++) if(C.rad[i]<C.rad[tight]) tight=i; let straight=0; for(let i=0;i<C.rad.length;i++) if(C.rad[i]>C.rad[straight]) straight=i;
  const at=(i)=>{ r.prog=C.dist[i]; r.v=r.pace; R.phase='racing'; for(let k=0;k<60;k++){ r.prog=C.dist[i]; R.player.x=-9e3; R.player.y=-9e3; R.player.prog=-1e6; BOAT_RACE3D.step(1/60); } return r.v; };
  const vt=at(tight), vs=at(straight); boat.race=null; return [vt < r.pace*0.8, vs > r.pace*0.85]; })()`), [true, true]);
check('a hard turn bleeds a little speed (so you can take a hairpin)', K.$(`(()=>{ openBoatRaceGate(); boat.course='tabor'; BOAT_RACE3D.start(); const R=boat.race, P=R.player; R.phase='racing';
  const run=(steer)=>{ const p=BOAT_RACE3D.point(R.C,800); P.x=p.x; P.y=p.y; P.h=p.ang; P.prog=800; P.idx=p.i; P.v=R.stats.speed; R.camAng=p.ang; R.keys.left=false; R.keys.right=steer;
    for(let k=0;k<40;k++) BOAT_RACE3D.step(1/60); R.keys.right=false; return P.v; };
  const a=run(false), b2=run(true); boat.race=null; return b2 < a*0.97; })()`), true);

// ── the view ──
open('saltmere', 'rough'); go();
ok('race frames draw (count, racing), with the ROW, ◀ and ▶ pads registered', K.$(`(()=>{ const c=document.createElement('canvas'); c.width=520; c.height=680; const g=c.getContext('2d');
  boat.race.phase='count'; boat.race.count=3; drawBoat(g,520,680); boat.race.phase='racing'; for(let i=0;i<10;i++){ boatTick(1/60); drawBoat(g,520,680); }
  const pads=boat.hits.filter(h=>h.pad).map(h=>h.pad).sort().join(','); return pads==='left,right,throttle'; })()`));
const look = (eq) => { open('saltmere', 'rough', eq); go(); return K.$(`(()=>{ const R=boat.race, g=R.low.getContext('2d'); const c=document.createElement('canvas'); c.width=520; c.height=680; drawBoat(c.getContext('2d'),520,680);
  const d=g.getImageData(80,150,100,190).data; let h=2166136261; for(let i=0;i<d.length;i+=4){ h=Math.imul(h^d[i],16777619)^d[i+1]; h=Math.imul(h,16777619)^d[i+2]; } return h>>>0; })()`); };
ok('your boat in the race wears your fitted hull, sail and rig', new Set([look({}), look({ hull:'hull_crimson' }), look({ sail:'sail_cross' }), look({ engine:'eng_double' })]).size === 4);
check('the controls: ◀ and ▶ side by side on the left, ROW on the right (Zak, br2)', K.$(`(()=>{ const c=document.createElement('canvas'); c.width=520; c.height=680; drawBoat(c.getContext('2d'),520,680);
  const P={}; boat.hits.filter(h=>h.pad).forEach(h=>P[h.pad]=h); return [P.left.x+P.left.w<=P.right.x, P.right.x+P.right.w<=260, P.throttle.x>=320, P.throttle.x+P.throttle.w<=520]; })()`), [true, true, true, true]);
check('a slow device falls back to drawing the water in two-row bands', K.$(`(()=>{ const R=boat.race; R.drawN=29; R.drawMs=29*20; R.band=0; const c=document.createElement('canvas'); c.width=520; c.height=680; drawBoat(c.getContext('2d'),520,680); return R.band; })()`), 2);
K.$(`boat.race=null; boat.screen='dock';`);
done('race3d');

// suite/doors.js — nobody gets stuck in a doorway (2026-10-14-dr).
//
// Zak: "Some of my players keep getting stuck in doorways - especially the intro when they try to exit the building
// before talking to Tobias". Tobias's "Not yet" was said with the knight left standing ON the door, so the next frame
// said it again — forever, with movement frozen under the dialogue. Every other door is audited here as well.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('doors');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; tutorial.step=0; tutorial.done=false;
  place={kind:'interior', id:'tobias', floor:0}; escort.on=false;`);
const door = K.$(`(()=>{ const f=_inGrid(); for(let y=0;y<f.h;y++) for(let x=0;x<f.w;x++) if(f.g[y][x]===9) return [x,y]; })()`);
K.$(`player.x=${door[0]}*TILE; player.y=${door[1]}*TILE; player.dir='down';`);
K.$(`checkTransitions()`);
check('walking into the door before the lessons: Tobias calls you back', K.$(`[dialogue.open, place.kind]`), [true, 'interior']);
check('…and you are stepped back into the room, off the door', K.$(`tileAt(Math.floor((player.x+TILE/2)/TILE), Math.floor((player.y+TILE/2)/TILE))!==9 && walkable(Math.floor((player.x+TILE/2)/TILE), Math.floor((player.y+TILE/2)/TILE))`), true);
K.$(`closeDialogue()`);
let reopened = 0; for (let f = 0; f < 30; f++) { K.$(`loop(performance.now()+${f}*16)`); if (K.$('dialogue.open')) { reopened++; K.$('closeDialogue()'); } }
check('closing it, it does not come straight back while you stand still', reopened, 0);
K.$(`held.up=true;`); for (let f = 0; f < 30; f++) K.$(`loop(performance.now()+${f}*16)`); K.$(`held.up=false;`);
ok('…and you can walk away from the door', K.$(`player.y`) < (door[1] - 1.5) * K.TILE, K.$(`player.y/TILE`));
K.$(`tutorial.done=true;`);
K.$(`player.x=${door[0]}*TILE; player.y=${door[1]}*TILE; dialogue.open=false; checkTransitions(); let n=0; while(cross.t>0 && n<200){ tickCross(16); n++; }`);
check('with the lessons done, the door lets you out', K.$(`place.kind`), 'overworld');

// every building: you arrive on open floor with room to move, and you leave onto open ground, not onto a door
const bad = K.$(`(()=>{ const out=[]; for(let i=0;i<10;i++) chapelProgress[i]=true; hunt.done=true; hunt.won=true;
  for(const b of buildings.filter(b=>b.door && b.interior && CHAPEL_TOWN[b.id]===undefined && b.id!=='home_barn' && b.id!=='hg_keep')){
    place={kind:'overworld'}; returnStack.length=0; cross.t=0; dialogue.open=false; shopMode=null; player.x=b.door.x*TILE; player.y=b.door.y*TILE;
    enterDoor(b); let n=0; while(cross.t>0 && n<200){ tickCross(16); n++; } if(place.kind==='overworld') continue;
    const tx=Math.floor((player.x+TILE/2)/TILE), ty=Math.floor((player.y+TILE/2)/TILE);
    const room=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>walkable(tx+dx,ty+dy)).length;
    if(!walkable(tx,ty) || tileAt(tx,ty)===9 || !room) out.push(b.id+' inside');
    exitInterior(); n=0; while(cross.t>0 && n<200){ tickCross(16); n++; }
    const ox=Math.floor((player.x+TILE/2)/TILE), oy=Math.floor((player.y+TILE/2)/TILE);
    if(place.kind!=='overworld' || !walkable(ox,oy) || tileAt(ox,oy)===9) out.push(b.id+' outside'); }
  return out; })()`);
check('every building: you arrive on open floor and leave onto open ground', bad, []);
K.$(`place={kind:'overworld'};`);
done('doors');

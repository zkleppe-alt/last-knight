// suite/sproutline.js — the character outline (2026-10-01, sprite upgrade step 1).
//
// Zak: "Let's keep them the same size for now, just maybe more detail and more professional
// looking!", then "Yes please!" to a shared outline first. Every character (the knight in every
// livery and form, townsfolk, named folk, the court, the demons) is drawn with one crisp dark
// outline round its silhouette. The sprite itself is pixel-for-pixel what it was, at the same
// place; the outline only adds pixels around it; the caller's alpha still applies.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('sproutline');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'};`);

check('the characters that wear it', K.$(`SPR_POLISHED.filter(n=>typeof _sprRaw[n]==='function' && globalThis[n]!==_sprRaw[n]).length`), K.$(`SPR_POLISHED.length`));

// draw one character raw and outlined on a clear canvas, and compare
const cmp = (call) => K.$(`(()=>{ const W=cv.width, H=cv.height; const shot=()=>ctx.getImageData(0,0,W,H).data;
  const clear=()=>{ ctx.setTransform(1,0,0,1,0,0); ctx.globalAlpha=1; ctx.clearRect(0,0,W,H); };
  clear(); _SPR.on=false; ${call}; const a=shot(); clear(); _SPR.on=true; ${call}; const b=shot(); clear();
  let same=true, added=0, dark=0, lost=0; for(let i=0;i<a.length;i+=4){ if(a[i+3]===255){ if(a[i]!==b[i]||a[i+1]!==b[i+1]||a[i+2]!==b[i+2]||a[i+3]!==b[i+3]) same=false; }
    else if(a[i+3]===0 && b[i+3]>0){ added++; if(b[i]<40&&b[i+1]<40&&b[i+2]<50) dark++; } }
  return [same, added>20, dark>=Math.round(added*0.6)]; })()`);
// 2026-10-05 (so2): characters land on whole pixels, so he is drawn at a whole x here (40.5 now snaps to 41 by design).
// 2026-10-06 (kp4): facing left, the far shield's edge sits behind him under his outline, so the body is compared alone;
//   the shield has its own checks in kpose.
check('the knight: himself unchanged, an outline added round him', cmp(`player.dir='down'; drawKnight(40,30)`), [true, true, true]);
check('the knight facing left', cmp(`player.dir='left'; { const _e=_kShieldEdge; _kShieldEdge=()=>{}; drawKnight(40,30); _kShieldEdge=_e; }`), [true, true, true]);
check('a townsman', cmp(`drawVillager(40,30,villagers[0])`), [true, true, true]);
check('a royal guard', cmp(`drawRoyalGuard(40,30,1)`), [true, true, true]);
check('the King', cmp(`drawKingLuminar(40,30)`), [true, true, true]);
check('a demon', cmp(`(()=>{ const d=Object.assign({}, demons[0]||{x:0,y:0,alive:true,level:3,hp:5,maxHp:5,kind:'imp'}); drawDemon(40,30,d); })()`), [true, true, true]);

ok('the caller\'s alpha still applies (a fading figure fades, outline and all)', K.$(`(()=>{ ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,cv.width,cv.height); ctx.globalAlpha=0.5; drawVillager(40,30,villagers[0]); ctx.globalAlpha=1;
  const d=ctx.getImageData(0,0,120,90).data; let mx=0; for(let i=3;i<d.length;i+=4) mx=Math.max(mx,d[i]); ctx.clearRect(0,0,cv.width,cv.height); return mx>100&&mx<140; })()`));
ok('a figure drawn inside another is not outlined twice', K.$(`(()=>{ let n=0; const A=_sprPolish; let inner=-1; _SPR.depth=1; ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,cv.width,cv.height); drawVillager(40,30,villagers[0]); const d=ctx.getImageData(0,0,120,90).data; for(let i=0;i<d.length;i+=4) if(d[i+3]>0&&d[i]===0x12&&d[i+1]===0x0c&&d[i+2]===0x18) n++; _SPR.depth=0; ctx.clearRect(0,0,cv.width,cv.height); return n===0; })()`));
ok('the draw always comes back to the screen', K.$(`(()=>{ const m=ctx; try{ drawVillager(40,30,null); }catch(e){} return ctx===m && ctx.canvas===cv && _SPR.depth===0; })()`));
check('real frames: the open country, a town, the Keep', K.$(`(()=>{ const r=[]; for(const [x,y] of [[60,40],[30,22]]){ player.x=x*TILE; player.y=y*TILE; try{ loop(performance.now()); r.push('ok'); }catch(e){ r.push(e.message); } }
  const k=buildings.find(b=>b.id==='sg_keep'); enterKeep(k); try{ loop(performance.now()); r.push('ok'); }catch(e){ r.push(e.message); } exitKeep(); return r; })()`), ['ok', 'ok', 'ok']);

done('sproutline');

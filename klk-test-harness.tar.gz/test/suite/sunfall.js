// suite/sunfall.js — Sunfall, the sky isles at the held sunset → dawn (2026-10-01).
//
// Zak: sky isles at held sunset; Vesper in gaudy false splendour; dawn transforms
// it all; and "make the floating platforms cleaner — they were clunky in their
// movement and would overlap the main platforms".
// The rework is DRAWING ONLY: the grid must be the very grid it was before, so no
// tower, ferry, breach, cache, mooring, brazier, rubble field or house can move.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('sunfall');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[];`);
const build = (dawn, lit) => K.$(`(sunfallProgress.dawn=${!!dawn}, ['lamp1','lamp2','lamp3','lamp4','lamp5'].forEach(id=>sunLamp(id).lit=${!!lit}),
  buildPortalWorld('sunfall'), ${dawn ? 'portalWorld.dawn=true,' : ''} place={kind:'portalworld'}, player.mounted=false, demons=[], 'ok')`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the grid is untouched ──
// 9cd524 is the FNV-1a of JSON(portalWorld.g) in the build BEFORE this rework
// (tag 2026-10-01-ti), at sunset and at dawn alike.
for (const dawn of [false, true]) {
  build(dawn, false);
  check(`${dawn ? 'dawn' : 'sunset'}: the grid is exactly the grid it was`, K.$(`(${fnv})(JSON.stringify(portalWorld.g))`), '9cd524');
}
build(false, false);
check('five lighthouses, eight houses and the cathedral', K.$(`[portalWorld.lampSites.length, portalWorld.vesperTown.houses.length, !!portalWorld.vesperTown.cath]`), [5, 8, true]);

// ── the drawing ──
const drawAll = () => K.$(`(()=>{ const bad=[]; const sw=VIEW_TW, sh=VIEW_TH; try{ VIEW_TW=248; VIEW_TH=248; player.x=124*TILE; player.y=124*TILE; draw(); }catch(e){ bad.push(e.message); } finally{ VIEW_TW=sw; VIEW_TH=sh; } return bad; })()`);
for (const [dawn, lit] of [[false, false], [false, true], [true, true]]) {
  build(dawn, lit);
  check(`${dawn ? 'dawn' : 'sunset'}${lit ? ', lamps lit' : ''}: the whole world draws`, drawAll(), []);
}
build(false, false);
const counts = K.$(`(()=>{ const n={l:0,h:0,c:0,f:0}; const A=_sfLighthouse, B=_sfHouse, C=_sfCathedral, D=drawSunfallFerry;
  _sfLighthouse=function(){ n.l++; }; _sfHouse=function(){ n.h++; }; _sfCathedral=function(){ n.c++; }; drawSunfallFerry=function(){ n.f++; };
  const sw=VIEW_TW, sh=VIEW_TH; try{ VIEW_TW=248; VIEW_TH=248; player.x=124*TILE; player.y=124*TILE; draw(); }
  finally{ VIEW_TW=sw; VIEW_TH=sh; _sfLighthouse=A; _sfHouse=B; _sfCathedral=C; drawSunfallFerry=D; } return n; })()`);
check('every building is drawn over its footprint, and every ferry as a platform', counts, { l: 5, h: 8, c: 1, f: 5 });
ok('the cathedral plaza no longer draws as a green floor (tile 53 has Sunfall art)', K.$(`drawSunfallTile(53,0,0,124,120)===true`));
check('one frame of the real loop on the promenade', K.$(`(()=>{ player.x=portalWorld.entry.x*TILE; player.y=portalWorld.entry.y*TILE; try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
ok('Sunfall’s art stays in Sunfall', K.$(`(()=>{ buildPortalWorld('mistral'); place={kind:'portalworld'}; let n=0; const a=sunfallBuildingObjs, b=drawSunfallLight;
  sunfallBuildingObjs=function(o){ const before=o.length; a(o,0,0); n+=o.length-before; }; drawSunfallLight=function(){ n+=1000; };
  try{ draw(); } finally{ sunfallBuildingObjs=a; drawSunfallLight=b; } return n===0; })()`));

// ── the sky ferries: smooth, and never over the landings ──
build(false, true);
const rides = K.$(`(()=>{ const out=[]; const g0=portalWorld.g.map(r=>r.slice());
  for(const F of portalWorld.ferries) for(const from of [0,1]){
    portalWorld.ferries.forEach(o=>{ if(o!==F) _ferryLift(o); });
    F.t=from; F.p=from; F.dir=from?-1:1; F.dwell=600; _ferryLift(F); const p0=_ferryPos(F); _ferrySet(F,Math.round(p0.x),Math.round(p0.y));
    const c=F.cells.slice().sort((a,b)=>Math.hypot(a[0]-p0.x,a[1]-p0.y)-Math.hypot(b[0]-p0.x,b[1]-p0.y))[0];
    player.x=c[0]*TILE; player.y=c[1]*TILE;
    const st=[player.x,player.y]; let maxStep=0, prev=[player.x,player.y], fr=0, offSky=0;
    while(fr++<900){ portalWorld.ferries.forEach(o=>{ if(o!==F) o.dwell=1e9; }); tickSunfallFerries(16);
      const d=Math.hypot(player.x-prev[0],player.y-prev[1])/TILE; if(d>maxStep) maxStep=d; prev=[player.x,player.y];
      const tx=Math.floor((player.x+8)/16), ty=Math.floor((player.y+8)/16); if(!WALK.has(portalWorld.g[ty][tx])) offSky++;
      if(F.dwell>0 && F.p===(from?0:1)) break; }
    const tx=Math.floor((player.x+8)/16), ty=Math.floor((player.y+8)/16);
    const land=[[1,0],[-1,0],[0,1],[0,-1],[0,0]].some(([a,b])=>{ const t=portalWorld.g[ty+b][tx+a]; return WALK.has(t) && t!==82; });
    out.push({ id:F.id, way:from?'back':'over', maxStep, dist:Math.hypot(player.x-st[0],player.y-st[1])/TILE, offSky, land }); }
  let landTouched=0; for(let y=0;y<portalWorld.h;y++)for(let x=0;x<portalWorld.w;x++){ const a=g0[y][x], b=portalWorld.g[y][x]; if(a!==b && !((a===81||a===82)&&(b===81||b===82))) landTouched++; }
  return { out, landTouched }; })()`);
for (const r of rides.out) {
  ok(`${r.id} ${r.way}: it carries him across`, r.dist >= 2, r.dist.toFixed(1) + ' tiles');
  ok(`${r.id} ${r.way}: smoothly (no tile hops)`, r.maxStep < 0.2, r.maxStep.toFixed(3) + ' tiles/frame at most');
  ok(`${r.id} ${r.way}: never leaving him over the sky`, r.offSky === 0);
  ok(`${r.id} ${r.way}: and sets him down beside solid ground`, r.land);
}
check('no ferry ever writes over a landing (only sky ⇄ deck changes)', rides.landTouched, 0);
ok('a ferry eases: slow off the dock, fastest mid-gulf', K.$(`(()=>{ const F=portalWorld.ferries[0]; const at=(t)=>{ F.t=t; F.p=t*t*(3-2*t); return _ferryPos(F); };
  const a=at(0), b=at(0.05), c=at(0.475), d=at(0.525); return Math.hypot(b.x-a.x,b.y-a.y) < Math.hypot(d.x-c.x,d.y-c.y)*0.3; })()`));
ok('the deck tiles draw as open sky (the platform is one sprite)', K.$(`drawSunfallTile(82,0,0,10,10)===true`));
ok('the platform sprite is clipped to open sky', K.$(`drawSunfallFerry.toString().indexOf('ctx.clip()')>0`));
ok('no rock hangs under a ferry', K.$(`(()=>{ const F=portalWorld.ferries[0]; const q=_ferryPos(F); const x=Math.round(q.x), y=Math.round(q.y)+2;
  const g=portalWorld.g; if(g[y][x]!==81) return true; let rock=0; const P=px; px=function(a,b,w,h,c){ if(c===_sfPal().under||c===_sfPal().underD||c===_sfPal().underDD) rock++; };
  try{ _sfSky(0,0,x,y,_sfPal()); } finally{ px=P; } return rock===0; })()`));
// the causeway still waits for the five lamps
build(false, false);
K.$(`(()=>{ const F=portalWorld.ferries.find(f=>f.id==='ferryCauseway'); F.p=0; F.t=0; for(let i=0;i<10;i++) tickSunfallFerries(16); })()`);
check('the causeway raft stays at Vesper’s side until all five lamps burn', K.$(`portalWorld.ferries.find(f=>f.id==='ferryCauseway').p`), 1);
// ── SUNFALL ATOLL on the overworld: a ringed atoll, held at sunset until the dawn ──
K.$(`place={kind:'overworld'}; player.mounted=false; player.boating=false; sunfallProgress.dawn=false; portalWorld.dawn=false;`);
const isle = K.$(`(()=>{ let pier=null; for(let y=299;y>272;y--) if(WORLD[y] && WORLD[y][155]===68){ pier={x:155,y}; break; }
  const seen=new Set([pier.x+','+pier.y]), q=[[pier.x,pier.y]];
  for(let i=0;i<q.length;i++){ const [x,y]=q[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay;
    if(seen.has(k)||!sunfallIsleAt(ax,ay)) continue; if(canStep(x,y,ax,ay)){ seen.add(k); q.push([ax,ay]); } } }
  // the lagoon must be closed: no water path from it to the open sea for a boat
  const lag=[155,262]; const wseen=new Set([lag.join(',')]), wq=[lag]; let open=false;
  for(let i=0;i<wq.length && !open;i++){ const [x,y]=wq[i]; for(const [ax,ay] of [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]){ const k=ax+','+ay; if(wseen.has(k)) continue;
    const t=WORLD[ay]&&WORLD[ay][ax]; if(t!==3 && t!==20) continue; if(!sunfallIsleAt(ax,ay)){ open=true; break; } wseen.add(k); wq.push([ax,ay]); } }
  return { pier, gate:seen.has('155,270'), home:seen.has('155,271'), sea:[WORLD[pier.y+1][155],WORLD[pier.y][153],WORLD[pier.y][158]], lagoonWater:WORLD[262][155], open,
    lamp:decorations.filter(d=>d.kind==='sf_lighthouse').length, banners:decorations.filter(d=>d.kind==='sf_banner').length }; })()`);
ok('Sunfall Atoll: the pier runs out from the south shore', !!isle.pier, JSON.stringify(isle.pier));
ok('  with open water at its head for the boat', isle.sea.every(t => t === 3 || t === 20), JSON.stringify(isle.sea));
ok('  from the pier you can walk to the gate on the spire', isle.gate);
ok('  and coming home through it you stand on the summit', isle.home);
check('  the gate is still at the summit (155,270)', K.$(`[portalById('sunfall').tx, portalById('sunfall').ty]`), [155, 270]);
ok('  the summit sign still reads Sunfall Atoll', K.$(`(signs['155,270']||'').indexOf('Sunfall Atoll')===0`));
ok('  the lagoon is water, closed to the open sea', isle.lagoonWater === 3 && !isle.open);
check('  a lighthouse on the ring and two banners at the causeway', [isle.lamp, isle.banners], [1, 2]);
ok('  the rogues\' floating jail lies outside its box', K.$(`!sunfallIsleAt(149,249) && !sunfallIsleAt(151,250) && !sunfallIsleAt(150,251)`));
check('  the atoll draws, held sunset and dawn, gates sealed and open', K.$(`(()=>{ const bad=[]; const sw=VIEW_TW, sh=VIEW_TH; VIEW_TW=40; VIEW_TH=40; player.x=155*TILE; player.y=272*TILE;
  for(const dawn of [false,true]) for(const open of [false,true]){ sunfallProgress.dawn=dawn; bounties.portalsOpen=open; try{ draw(); }catch(e){ bad.push(e.message); } }
  VIEW_TW=sw; VIEW_TH=sh; bounties.portalsOpen=false; sunfallProgress.dawn=false; return bad; })()`), []);
ok('  its lighthouse is dark until all five lamps burn, lit after', K.$(`(()=>{ let lit=[]; const L=_sfLighthouse; _sfLighthouse=function(a,b,c,f){ lit.push(!!f); };
  try{ const d=decorations.find(q=>q.kind==='sf_lighthouse'); ['lamp1','lamp2','lamp3','lamp4','lamp5'].forEach(id=>sunLamp(id).lit=false); drawSunfallIsleDecor(d,0,0);
    ['lamp1','lamp2','lamp3','lamp4','lamp5'].forEach(id=>sunLamp(id).lit=true); drawSunfallIsleDecor(d,0,0); } finally{ _sfLighthouse=L; }
  ['lamp1','lamp2','lamp3','lamp4','lamp5'].forEach(id=>sunLamp(id).lit=false); return lit[0]===false && lit[1]===true; })()`));
ok('  its art stays on the atoll', K.$(`!sunfallIsleAt(95,274) && !sunfallIsleAt(40,270) && !sunfallIsleAt(155,240) && sunfallIsleAt(155,270)`));
done('sunfall');

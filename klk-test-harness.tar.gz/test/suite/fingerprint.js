// suite/fingerprint.js — the world baseline. If any of these three move, a
// world edit landed somewhere it shouldn't have.
//
//   reachable  flood fill from the spawn tile through the game's own
//              walkable(), four-way. Catches a fence stamped across a road,
//              a gate that no longer opens, an elevation gate inverted.
//   distinct   count of distinct tile codes present in WORLD. Catches a new
//              tile code introduced (or an old one wiped out) by a builder.
//   plots      farm plots (tile 31). The plots are the reliable homestead
//              landmark — there is an OLD homestead site near the top of the
//              map, so searching for "homestead" finds the wrong thing.
const K = require('../boot.js');
const { check, done, flood } = require('./lib.js');

console.log('fingerprint');

const TILE_PX = K.TILE;
const sx = Math.floor(K.player.x / TILE_PX);
const sy = Math.floor(K.player.y / TILE_PX);

const counts = new Map();
for (let y = 0; y < K.WORLD_H; y++) {
  for (let x = 0; x < K.WORLD_W; x++) {
    const t = K.WORLD[y][x];
    counts.set(t, (counts.get(t) || 0) + 1);
  }
}

// reachable is seed-dependent (coastline noise: ~7 tiles flip between water
// and sand). It is pinned at seed 11 to match the documented baseline; the
// seed-panel suite pins the whole distribution, which is the stronger check.
// This number has never moved. It went to 4212 for one edit, when Robby's cave
// was briefly an overworld building whose door opened two walkable tiles — the
// shift was +2 on EVERY seed, which is what distinguishes a structural change
// from coastline noise. The cave moved into the Forest of Disillusionment and
// the baseline came straight back. Left recorded because "the fingerprint moved
// and I understood why" is the only acceptable reason to touch this line.
check('reachable', flood(K, sx, sy).n, 4210);
check('distinct', counts.size, 36);
check('plots', counts.get(31) || 0, 58);

done('fingerprint');

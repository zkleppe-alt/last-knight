// suite/fingerprint.js — the world baseline. If any of these three move, a
// world edit landed somewhere it shouldn't have.
//
//   reachable  flood fill from the spawn tile through the game's own
//              walkable(), four-way. Catches a fence stamped across a road,
//              a gate that no longer opens, an elevation gate inverted.
//   distinct   count of distinct tile codes present in WORLD. Catches a new
//              tile code introduced (or an old one wiped out) by a builder.
//   plots      farm plots (tile 31). The plots are the reliable homestead
//              landmark — there is an OLD homestead site near the top of the
//              map, so searching for "homestead" finds the wrong thing.
const K = require('../boot.js');
const { check, done, flood } = require('./lib.js');

console.log('fingerprint');

const TILE_PX = K.TILE;
const sx = Math.floor(K.player.x / TILE_PX);
const sy = Math.floor(K.player.y / TILE_PX);

const counts = new Map();
for (let y = 0; y < K.WORLD_H; y++) {
  for (let x = 0; x < K.WORLD_W; x++) {
    const t = K.WORLD[y][x];
    counts.set(t, (counts.get(t) || 0) + 1);
  }
}

// reachable is seed-dependent (coastline noise: ~7 tiles flip between water
// and sand). It is pinned at seed 11 to match the documented baseline; the
// seed-panel suite pins the whole distribution, which is the stronger check.
// This number has never moved. It went to 4212 for one edit, when Robby's cave
// was briefly an overworld building whose door opened two walkable tiles — the
// shift was +2 on EVERY seed, which is what distinguishes a structural change
// from coastline noise. The cave moved into the Forest of Disillusionment and
// the baseline came straight back. Left recorded because "the fingerprint moved
// and I understood why" is the only acceptable reason to touch this line.
// 2026-10-01-vs: 4210 → 4209, on every seed. The village signs moved to their entrances; the spawn
// flood covers Hearthvale and Ironhold, where Hearthvale's sign gave back one tile and took one
// (34,29 → 34,31) and Ironhold's, which had stood inside the Keep's solid footprint, now stands on
// the paving at the head of the south stair (35,74): net one tile fewer. Checked tile by tile.
check('reachable', flood(K, sx, sy).n, 4209);
// distinct went 36 → 44 on 2026-09-30, when Mistral Isle was rebuilt as a
// highland isle and brought Mistral's eight tile codes (90–97: wall, heather,
// tall grass, gorse, standing stone, prop base, shingle, sea stack) onto the
// overworld. Reachable did not move on any seed. The check below pins those
// eight codes INSIDE the isle's box, so they can't creep anywhere else.
// distinct went 44 → 57 on 2026-10-01, when Mount Tabor was rebuilt as a glacier
// peak with its pier and fishing hut, bringing 13 codes onto the overworld (34 trail,
// 61 ice, 62 frozen fall, 68 pier, 69/70/71/77 hut, 73 floe, 74 mooring post,
// 98 fir, 99 crevasse, 100 tarn). Reachable did not move on any seed. Pinned to
// the isle's box below.
// distinct went 57 → 59 on 2026-10-01, when Sunfall Atoll was rebuilt as a ringed
// atoll with a causeway and a lighthouse: 80 (balustrade) and 101 (the
// lighthouse's footprint). Reachable did not move on any seed. Pinned below.
check('distinct', counts.size, 59);
{ const T=[80,101], out=[];
  for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++) {
    const t = K.WORLD[y][x]; if (T.includes(t) && !(x >= 133 && x <= 177 && y >= 252 && y <= 299)) out.push(x + ',' + y + '=' + t); }
  check('Sunfall\'s tile codes only on Sunfall Atoll', out.slice(0, 5), []); }
{ const T=[34,61,62,68,69,70,71,73,74,77,98,99,100], out=[];
  for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++) {
    const t = K.WORLD[y][x]; if (!T.includes(t) || (x >= 72 && x <= 118 && y >= 252 && y <= 299)) continue;
    // the pier planks and mooring posts are shared with Sunfall Atoll's pier
    if ((t === 68 || t === 74) && x >= 133 && x <= 177 && y >= 252 && y <= 299) continue;
    out.push(x + ',' + y + '=' + t); }
  check('Tabor\'s tile codes only on Mount Tabor', out.slice(0, 5), []); }
{ const out=[]; for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++) {
    const t = K.WORLD[y][x]; if (t >= 90 && t <= 97 && !(x >= 22 && x <= 58 && y >= 252 && y <= 288)) out.push(x + ',' + y + '=' + t); }
  check('Mistral\'s tile codes only on Mistral Isle', out.slice(0, 5), []); }
check('plots', counts.get(31) || 0, 58);

done('fingerprint');

// suite/karl.js — King Karl of Luminar, and whose glory it is.
//
// The King of Luminar is King Karl: a great king, and a man. Worship and
// praise go to God. Before this pass, twenty lines said "the King" meaning
// God (the Good Shepherd, the returning Bridegroom, "Blessed be the King"),
// which next to a named earthly king reads as praise of him. This pins it:
//  - he speaks as King Karl, with his portrait;
//  - no text the player sees says "the King"/"your King"/"true King" bare —
//    God is "the Lord", "God", or "the King of kings"; Karl is "King Karl".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');
console.log('karl');
const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');

// every string literal (the text a player can see), comments excluded
const lits = [];
for (const m of raw.matchAll(/'(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`/g)) lits.push(m[0]);
const text = lits.map(l => l.replace(/\\u2019/g, '’').replace(/\\u2014/g, '—').replace(/\\u201c/g, '“').replace(/\\u201d/g, '”'));

check('nobody speaks as "The King of Luminar" any more', text.filter(t => /The King of Luminar/.test(t)).length, 0);
ok('he speaks as King Karl', text.filter(t => t === "'King Karl'").length >= 15, `${text.filter(t => t === "'King Karl'").length} lines`);
ok('with his portrait', !!K.$(`portraitFor('King Karl')`) && !!K.$(`bakePortrait(portraitFor('King Karl'))`));

// bare "the King" in player-facing text — allowed only when it plainly names
// someone: King Karl, the King of kings, the King of the Shadows, or the
// King's Tourney / Rangers / Navy (institutions of Karl's realm)
const OK_AFTER = /^(?: Karl| of kings| of the Shadows|['’]s (?:Tourney|Rangers|Navy|Fleet))/;
const bare = [];
for (const t of text) for (const m of t.matchAll(/\b(?:the|your|his|true|a true|my) King\b/g)) {
  const after = t.slice(m.index + m[0].length);
  if (!OK_AFTER.test(after)) bare.push(t.slice(Math.max(0, m.index - 30), m.index + 50));
}
ok('no player-facing line says "the King" / "your King" without saying who', bare.length === 0, bare.slice(0, 4).join(' | ') || 'clean');

// the lines that were about God now say so
for (const [what, re] of [
  ['the Good Shepherd is the King of kings', /one true Shepherd, the King of kings/],
  ['the Bridegroom is the Lord', /The Lord returns for a Bride/],
  ['Tabor blesses the Lord', /Blessed be the Lord\. It was never my sword/],
  ['the Pretender mocks your God, not your king', /Where was your God when the villages burned\?/],
  ['the freed villagers bow only to the Lord', /We bow now only to the Lord\./],
]) ok(what, text.some(t => re.test(t)));

// and Karl himself gives the glory to God
ok('King Karl credits God, not himself', text.some(t => /It was His strength in your arm this day/.test(t)) && text.some(t => /the God who guides it/.test(t)));
// quoted scripture is KJV (public domain) — the modern-translation wording of
// Psalm 144:1 that Karl used to quote is gone, and he names his psalms
ok('Karl quotes Psalm 144:1 in the KJV', text.some(t => /Blessed be the LORD my strength, which teacheth my hands to war, and my fingers to fight\.\u201d<\/i> \u2014 Psalm 144:1/.test(t))
   && !text.some(t => /Praise be to the Lord my Rock/.test(t)));
ok('and Psalm 27:1 in the KJV', text.some(t => /The LORD is my light and my salvation; whom shall I fear\?\u201d<\/i> \u2014 Psalm 27:1/.test(t)));
done('karl');

// suite/vsigns.js — every village's name-sign, by its main entrance (2026-10-01).
//
// Zak: "remind me to add sign fixes around the map", then "you can actually just move them".
// Each town's sign is a real signpost (tile 16), drawn in its town's art (never a bare grass
// square), stands within a few steps of the way in, and can be walked up to from that entrance.
// Dusthaven had no sign at all; it has one now. Ashfield, Stormgate, Shadowmere, Hellgate and the
// Homestead were moved in their own passes and are pinned here too.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('vsigns');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'};`);

// [name on the sign, sign tile, the entrance tile it serves]
const SIGNS = [
  ['HEARTHVALE', '34,31', '32,32'], ['IRONHOLD', '35,74', '33,75'], ['SALTMERE', '30,206', '28,207'],
  ['THORNWOOD', '94,147', '92,146'], ['DUSTHAVEN', '90,79', '92,80'], ['CRYSTALPEAK', '152,74', '153,75'],
  ['ASHFIELD', '166,163', '168,165'], ['STORMGATE', '164,226', '167,228'], ['SHADOWMERE', '216,158', '218,159'],
  ['HELLGATE', '224,25', '225,26'], ['THE HOMESTEAD', '14,160', '13,162'],
];
for (const [name, at, gate] of SIGNS) {
  const r = K.$(`(()=>{ const [x,y]=${JSON.stringify(at)}.split(',').map(Number), [gx,gy]=${JSON.stringify(gate)}.split(',').map(Number);
    const txt=(signs[x+','+y]||''); const named=txt.toUpperCase().indexOf(${JSON.stringify(name)})>=0;
    // walk from the entrance (heights respected the engine's way: same height or a stair) and see if any side of the sign is reached
    const seen=new Set([gx+','+gy]), q=[[gx,gy]]; let reached=false, n=0;
    const can=(t)=>WALK.has(t);
    while(q.length && n<6000){ const [cx,cy]=q.shift(); n++;
      for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=cx+a, ny=cy+b; if(nx===x&&ny===y){ reached=true; continue; }
        const k=nx+','+ny; if(seen.has(k)||!WORLD[ny]||!can(WORLD[ny][nx])) continue; if(Math.abs(nx-gx)>14||Math.abs(ny-gy)>14) continue; seen.add(k); q.push([nx,ny]); } }
    return [named, WORLD[y][x], Math.max(Math.abs(x-gx),Math.abs(y-gy))<=4, reached]; })()`);
  check(`${name}: its sign (${at}) is a signpost by the way in (${gate}), and you can walk up to it`, r, [true, 16, true, true]);
}
check('each town has exactly one name-sign', K.$(`${JSON.stringify(SIGNS.map(s=>s[0]))}.map(n=>Object.values(signs).filter(t=>t.split('\\n')[0].toUpperCase().startsWith(n) && t.toUpperCase().indexOf('HARBO')<0).length)`), SIGNS.map(() => 1));   // (Stormgate's Royal Harbour has its own sign on the quay)
ok('the old spots are ground again', K.$(`['34,29','32,53','30,199','79,158','142,62'].every(k=>{ const [x,y]=k.split(',').map(Number); return signs[k]===undefined && WORLD[y][x]!==16; })`));

// drawn in each town's own art, not on a bare grass square
check('Ironhold, Crystalpeak and Thornwood draw their own signposts', K.$(`[drawIronholdTile(16,0,0,35,74), drawCrystalpeakTile(16,0,0,152,74), drawThornwoodTile(16,0,0,94,147), drawDusthavenTile(16,0,0,90,79), drawSaltmereTile(16,0,0,30,206)]`), [true, true, true, true, true]);
check('a real frame at each new sign', K.$(`${JSON.stringify(SIGNS.slice(0,6).map(s=>s[1]))}.map(k=>{ const [x,y]=k.split(',').map(Number); player.x=x*TILE; player.y=(y+1)*TILE; try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })`), ['ok', 'ok', 'ok', 'ok', 'ok', 'ok']);

done('vsigns');

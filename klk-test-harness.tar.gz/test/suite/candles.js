// suite/candles.js — assertions written BEFORE any fix, to prove the two
// claims are real rather than eyeballed.
//
//   A. a lampstand's church is discoverable BEFORE you light it
//   B. a lampstand does not block the corridor it stands in
//
// Both are expected to FAIL on the current build. That is the point.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');

console.log('candles');
const src = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');

// Generate the candle floor for a spread of towns and seeds, so the findings
// are about the system and not one unlucky layout.
const floors = [];
for (const townId of [1, 3, 5, 7, 9]) {
  for (const seed of [11, 42, 12345]) {
    globalThis.__reseed(seed);
    const g = K.genMazeFloor(townId, 0);
    floors.push({ townId, seed, g, candles: (K.dungeon._candles || []).slice() });
  }
}

// Maze floors must now carry NO lampstands and exactly one key chest — the
// key is what opens their seal, since lightCandle() no longer can.
let mazeCandles = 0, noKey = 0, keyNotDeepest = 0, mazeFloors = 0;
for (const f of floors) {
  mazeFloors++;
  if (f.candles.length) mazeCandles++;
  const pd = K.dungeon._podium;
  if (!pd) noKey++;
}
ok('maze floors carry no lampstands', mazeCandles === 0,
   `${mazeCandles}/${mazeFloors} maze floors still place candles`);
ok('every maze floor places a plaza', noKey === 0,
   `${noKey}/${mazeFloors} floors had no plaza`);

// The podium must be stamped as a real T_PODIUM tile, or the rise never fires
// and the floor cannot be finished.
let notAPodium = 0;
for (const townId of [1, 3, 5, 7, 9]) {
  for (const seed of [11, 42, 12345, 7, 99]) {
    globalThis.__reseed(seed);
    const g = K.genMazeFloor(townId, 0);
    const pd = K.dungeon._podium;
    if (!pd || g[pd.y][pd.x] !== K.T_PLAZA) notAPodium++;
  }
}
ok('the plaza centre is open floor at generation', notAPodium === 0,
   `${notAPodium}/25 plaza centres were not T_PLAZA`);

// ── A. is the church visible before lighting? ──────────────────────────────
// Now measured on the DOCTRINE ring, which is where the puzzle lives. Each
// lampstand has a T_SIGN on the tile facing the centre carrying its name, so
// two stands with different churches are distinguishable without spending an
// attempt. The old maze-floor version failed this 105/105.
let unnamed = 0, unsigned = 0, stands = 0;
for (const townId of [3,4,5,6,7,8,9,10]) {
  const g = K.genDoctrineFloor(townId);
  for (const r of K.dungeon._doctrineRing) {
    stands++;
    if (!r.church) unnamed++;
    if (g[r.sy][r.sx] !== K.T_SIGN) unsigned++;
  }
}
ok('A: every lampstand carries a readable name before lighting',
   unnamed === 0 && unsigned === 0,
   `${stands} stands, ${unnamed} without a church, ${unsigned} without a sign tile`);

// A2: the sign must be reachable AND adjacent to the stand it names, or the
// player reads a name with no way to tell which lamp it belongs to.
let misplaced = 0;
for (const townId of [3,4,5,6,7,8,9,10]) {
  K.genDoctrineFloor(townId);
  for (const r of K.dungeon._doctrineRing) {
    if (Math.abs(r.sx - r.x) + Math.abs(r.sy - r.y) !== 1) misplaced++;
  }
}
ok('A2: each sign is orthogonally adjacent to the stand it names',
   misplaced === 0, `${misplaced} signs not touching their lampstand`);

// A3: the answer must not be readable off the seating. If canonical order and
// ring order ever coincide, that chapel is solvable by walking clockwise.
let degenerate = [];
for (const townId of [3,4,5,6,7,8,9,10]) {
  K.genDoctrineFloor(townId);
  const seats = K.dungeon._doctrineRing.map(r => r.church);
  const order = K.dungeon._candles.map(r => r.church);
  if (JSON.stringify(seats) === JSON.stringify(order)) degenerate.push(townId);
}
ok('A3: no chapel is solvable by walking the ring in order',
   degenerate.length === 0, `degenerate chapels: ${degenerate.join(',') || 'none'}`);

// ── B. does a lampstand block the corridor? ────────────────────────────────
// Dungeon walkability is a blacklist (game.js:7785) and T_CANDLE is on it.
K.$('place = {kind:"dungeon"}');
let blocking = 0, totalCandles = 0;
// walkable() -> tileAt() -> activeGrid() reads dungeon.grid AND the module-level
// DW/DH. Setting the grid alone leaves DW/DH at their 15x11 default, so every
// candle outside that box reads as out-of-bounds tile 1 and looks solid no
// matter what the blacklist says. enterChapel() sets all three together; so
// must the test. (This bit me: 51/63 "solid" was my harness, not the game.)
for (const f of floors) {
  globalThis.__floor = f.g;
  K.$('dungeon.grid = globalThis.__floor; DH = dungeon.grid.length; DW = dungeon.grid[0].length;');
  for (const c of f.candles) {
    totalCandles++;
    if (!K.walkable(c.x, c.y)) blocking++;
  }
}
ok('B: lampstands do not block the tile they stand on',
   blocking === 0,
   `${blocking}/${totalCandles} lampstands are solid — the dungeon walkability ` +
   `blacklist includes T_CANDLE and T_CANDLE_LIT`);

// B2: the doctrine ring is hand-placed, so it needs no sever-checking at all.
let ringBlocking = 0;
for (const townId of [3,4,5,6,7,8,9,10]) {
  const g = K.genDoctrineFloor(townId);
  globalThis.__floor = g;
  K.$('dungeon.grid = globalThis.__floor; DH = dungeon.grid.length; DW = dungeon.grid[0].length;');
  for (const r of K.dungeon._doctrineRing) if (!K.walkable(r.x, r.y) || !K.walkable(r.sx, r.sy)) ringBlocking++;
}
ok('B2: no ring lampstand or sign blocks the floor',
   ringBlocking === 0, `${ringBlocking} solid ring tiles`);

// ── D. the ring is a ring ──────────────────────────────────────────────────
// Measured, not eyeballed: the first layout ran a radius spread of 1.24 tiles
// and rendered as a scattering rather than a circle.
let worstSpread = 0;
for (const townId of [3,4,5,6,7,8,9,10]) {
  K.genDoctrineFloor(townId);
  const ds = K.dungeon._doctrineRing.map(p => Math.hypot(p.x - 7, p.y - 5));
  worstSpread = Math.max(worstSpread, Math.max(...ds) - Math.min(...ds));
}
ok('D: ring radii stay within 0.7 tiles of each other',
   worstSpread <= 0.7, `worst spread ${worstSpread.toFixed(2)} tiles`);

// D2: nothing in the ring may overlap the pedestal, the entry, or the seal.
let collisions = 0;
for (const townId of [3,4,5,6,7,8,9,10]) {
  const g = K.genDoctrineFloor(townId);
  const seen = new Set();
  for (const p of K.dungeon._doctrineRing) {
    for (const [x, y] of [[p.x, p.y], [p.sx, p.sy]]) {
      const k = y * 100 + x;
      if (seen.has(k) || (x === 7 && y === 5) || (x === 7 && y === 0) || (x === 7 && y === 10)) collisions++;
      seen.add(k);
    }
  }
}
ok('D2: no lampstand or sign collides with pedestal, seal, or entry',
   collisions === 0, `${collisions} collisions`);

// ── C. the entry briefing ──────────────────────────────────────────────────
// The briefing tells the player to go read the tablet, so a floor that has
// candles must always have a tablet to read. Measured across every town.
let tabMissing = 0, candleFloors = 0;
for (const townId of [1,2,3,4,5,6,7,8,9,10]) {
  for (const seed of [11,42,12345,7,99,2026,314159,1337]) {
    globalThis.__reseed(seed);
    const g = K.genMazeFloor(townId, 0);
    if (!(K.dungeon._candles || []).length) continue;
    candleFloors++;
    let has = false;
    for (const row of g) if (row.includes(K.T_TABLET)) has = true;
    if (!has) tabMissing++;
  }
}
ok('C: every lampstand floor has a tablet to read',
   tabMissing === 0, `${tabMissing}/${candleFloors} candle floors had no tablet`);

ok('C2: the briefing fires once per playthrough, not once per chapel',
   /sawCandleBrief\s*=\s*true/.test(src) && /sawCandleBrief\s*:\s*sawCandleBrief/.test(src),
   'set on first candle floor and persisted through saveGame()');

ok('C3: the briefing is hooked to the candle floor, not the chapel door',
   !/sawCandleBrief/.test(src.slice(src.indexOf('function enterChapel'),
                                    src.indexOf('function enterChapel') + 1200)),
   'enterChapel() does not reference it — chapel floor 0 is not always a candle floor');


// ── E. the seven heads ─────────────────────────────────────────────────────
let wrongHead = 0, headSet = new Set();
for (const townId of [3,4,5,6,7,8,9,10]) {
  K.genDoctrineFloor(townId);
  for (const r of K.dungeon._doctrineRing) {
    const shape = K.lampShapeAt(r.x, r.y);
    headSet.add(shape);
    if (shape !== K.LAMP_HEADS[r.ord]) wrongHead++;
  }
}
ok('E: each stand draws the head of the church it names',
   wrongHead === 0, `${wrongHead} mismatches across 40 stands`);
ok('E2: a maze-floor stand with no church falls back to the plain taper',
   K.lampShapeAt(999, 999) === 'taper');
ok('E3: all seven heads are reachable across the chapels',
   headSet.size === 7, `saw ${headSet.size}: ${[...headSet].join(', ')}`);


// ── F. the gate wiring ─────────────────────────────────────────────────────
ok('F: the pedestal is readable via doAction',
   /dt===T_TABLET\|\|dt===T_PEDESTAL/.test(src),
   'facing the pedestal and pressing A routes to readTablet()');
ok('F2: openSeal has a second caller, so mazes are not candle-gated',
   (src.match(/openSeal\(\)/g) || []).length >= 3,
   `${(src.match(/openSeal\(\)/g) || []).length} references (declaration + lightCandle + key chest)`);
// NOTE: this one reads the RAW source, not the stripped one. game.stripped.js
// blanks string bodies as well as comments, so any assertion about text the
// player actually SEES is invisible there and fails for the wrong reason.
// Stripped is for "is this code live?"; raw is for "what does it say?".
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
const briefing = raw.slice(raw.indexOf('FIRST LAMPSTAND FLOOR'),
                           raw.indexOf('FIRST LAMPSTAND FLOOR') + 1400);
ok('F3: the entry briefing describes the ring, not a wall tablet',
   /pedestal at the centre/.test(briefing) &&
   !/tablet cut into the wall near the door you came in by\'/.test(briefing),
   'live briefing text points at the pedestal; the old wording survives only as _legacy');

done('candles');

// suite/layout.js — the playfield must not sit under the HUD.
//
// Node has no layout engine, so this drives resize() with a STUBBED HUD
// rectangle and checks the arithmetic. It cannot tell you the banner really
// clears on a device — suite/puzzle.spec.js does that. What it can prove is
// that the reserved band scales with the measured HUD and that the canvas is
// offset by exactly that band.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');

console.log('layout');

function sizeFor(w, h, hudH) {
  globalThis.innerWidth = w; globalThis.innerHeight = h;
  globalThis.visualViewport = { width: w, height: h, scale: 1, offsetTop: 0,
    addEventListener() {}, removeEventListener() {} };
  const hud = K.el('hud');
  hud._rect = { x: 7, y: 7, left: 7, top: 7, width: w - 14, height: hudH,
                right: w - 7, bottom: 7 + hudH };
  K.$('resize();');
  return { top: parseInt(K.el('c').style.top, 10), tw: K.VIEW_TW, th: K.VIEW_TH };
}

// iPhone 12 mini in Safari with the URL bar: 375 x ~630 usable. The chapel
// plaque wraps to two lines there, which is the case that broke.
const mini = sizeFor(375, 630, 74);
ok('iPhone 12 mini: the canvas starts below the HUD', mini.top >= 74,
   `canvas top = ${mini.top}px, HUD bottom = 81px`);
ok('iPhone 12 mini: a playable viewport survives the reserved band',
   mini.tw >= 10 && mini.th >= 8, `${mini.tw}x${mini.th} tiles`);

// A taller phone should reserve the same band, not a proportional one.
const tall = sizeFor(390, 844, 74);
ok('a taller screen reserves the same band, not more',
   Math.abs(tall.top - mini.top) <= 2, `mini ${mini.top}px vs tall ${tall.top}px`);
ok('a taller screen shows more of the map, not less',
   tall.th >= mini.th, `${mini.th} -> ${tall.th} tile rows`);

// A one-line plaque should reserve less than a wrapped two-line one.
const oneLine = sizeFor(375, 630, 40);
ok('the band tracks the measured HUD height', oneLine.top < mini.top,
   `one-line ${oneLine.top}px < wrapped ${mini.top}px`);

// The band must never eat the screen, however tall the HUD reports.
const absurd = sizeFor(375, 630, 400);
ok('the band is capped so the HUD can never swallow the playfield',
   absurd.top <= Math.round(630 * 0.28) && absurd.th >= 8,
   `top ${absurd.top}px, ${absurd.th} rows still visible`);

// And the canvas must still be the width of the screen, not offset sideways.
ok('the canvas is horizontally centred',
   K.el('c').style.top !== undefined,
   'positioned via #c (the old rule was #cv and matched nothing)');

done('layout');

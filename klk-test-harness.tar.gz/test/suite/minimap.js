// suite/minimap.js — the minimap is for the overworld only.
//
// Found on the phone: the minimap sat over the surf minigame's score. It hid
// itself only inside drawMinimap(), and the minigame branches of the frame
// loop return before reaching it, so it stayed pinned from the last overworld
// frame. This drives the REAL loop() in each place kind and checks the element.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('minimap');

const mm = () => K.$(`document.getElementById('minimap').style.display`);
const frame = () => K.$(`try{ loop(performance.now()); 'ok' }catch(e){ String(e.message).slice(0,80) }`);
K.$(`boot.done=true; dialogue.open=false; menu.open=false;`);

K.$(`place={kind:'overworld'}; player.x=32*TILE; player.y=24*TILE;`);
frame();
check('on the overworld the minimap shows', mm(), 'block');

// the surf minigame, started the way the game starts it
K.$(`startSurf();`);
check('startSurf puts us in the surf place', K.$(`place.kind`), 'surf');
frame();
check('in the surf minigame it is out of the way', mm(), 'none');

// every other non-overworld kind, straight from an overworld frame (display 'block')
for (const kind of ['race', 'boatrace', 'tourney', 'blocks', 'interior', 'dungeon', 'portalworld', 'keep', 'throne', 'abaddon']) {
  K.$(`place={kind:'overworld'}; document.getElementById('minimap').style.display='block';`);
  K.$(`place={kind:'${kind}'}; syncMinimapVisibility();`);
  check(`hidden in ${kind}`, mm(), 'none');
}
ok('and the loop hides it before any place branch can return',
   K.$(`(()=>{ const s=loop.toString(); const a=s.indexOf('syncMinimapVisibility()'), b=s.indexOf("place.kind==='surf'"); return a>0 && (b<0 || a<b); })()`));

K.$(`place={kind:'overworld'}; player.x=32*TILE; player.y=24*TILE; if(typeof surf!=='undefined' && surf) surf.active=false;`);
frame();
check('back on the overworld it returns', mm(), 'block');
done('minimap');

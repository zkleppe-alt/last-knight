// suite/hellgate.js — Michael's hall, and the offer to take the weight.
//
// "He fought as though the last day hung on the strength of his arm, and so he
// had no rest in him and no joy either. Hope, for him, was a thing he was
// holding up. The Void Champion offered to take the weight, and showed him an
// ending with nothing on the other side of it, and for one moment he was
// grateful."
//
// Hope drains all the while — that is what holding it up costs — and comes back
// only by going on. The voids look exactly like Crystalpeak's fires and are the
// opposite of them. Telling the two apart is the last thing the game asks.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('hellgate');

const T = K.TILE;
const g0 = K.genHellgateArena();
check('arena is the standard sanctum footprint',
      [g0[0].length, g0.length], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g0[1][7] === 7);
ok('the boss is where every sanctum puts it', g0[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g0[2][2] === 5);

function fresh() {
  K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=9; dungeon.floors=getChapelFloors(9); resetDungeonRun();');
  K.$(`loadDungeonFloor(${K.getChapelFloors(9).indexOf(K.FLOOR.sanctum)}, false);`);
  K.$('player.maxHp=9999; player.hp=9999; player.iframes=0; player.blocking=false; player.def=0; player.x=7*TILE; player.y=7*TILE;');
  K.$('player.hope=undefined; dungeon._voids=[]; dungeon._voidT=0; dungeon.bossDead=false;');
  return K.dungeon.grid;
}
const g = fresh();
const H = g.length, W = g[0].length;
const boss = () => (K.demons || []).find(d => d.boss && d.alive);

// ── the hall is bare on purpose ───────────────────────────────────────────
let open = 0, solid = 0;
for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
  if (K.walkable(x, y)) open++; else solid++;
}
// The only solid things inside the walls are the bound general and the reward
// chest, which every sanctum has. Nothing else: no cover, no furniture, nothing
// to lean on — the whole floor is whether you keep going.
ok('nothing to hide behind or lean on', solid === 2,
   `${solid} solid tiles (the general and the chest, as in every sanctum)`);
ok('and they are exactly those two',
   !K.walkable(7, 1) && !K.walkable(2, 2), 'general at 7,1 and chest at 2,2');

// ── the weight ────────────────────────────────────────────────────────────
fresh();
// The tick that initialises hope also applies one frame of drain, so this is
// HOPE_MAX minus a single frame's worth, not a bug.
K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
ok('hope starts full', K.player.hope > K.HOPE_MAX - 1,
   `${K.player.hope.toFixed(2)} of ${K.HOPE_MAX}`);
for (let i = 0; i < 60; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
const afterSec = K.player.hope;
ok('holding it up costs you, every second', afterSec < K.HOPE_MAX,
   `${afterSec.toFixed(1)} after 1s of simply standing there`);

// ── going on is what holds it up ──────────────────────────────────────────
const before = K.player.hope;
globalThis.__hb = boss();
K.$('applyDemonHit(demons.find(d=>d.boss&&d.alive), 10, false, 1, 0, 1, 2);');
ok('a blow landed gives it back', K.player.hope > before,
   `${before.toFixed(1)} -> ${K.player.hope.toFixed(1)}`);
ok('and it never goes past full',
   (() => { K.$('player.hope=HOPE_MAX;');
     K.$('applyDemonHit(demons.find(d=>d.boss&&d.alive), 10, false, 1, 0, 1, 2);');
     return K.player.hope <= K.HOPE_MAX; })());

// ── the offer ─────────────────────────────────────────────────────────────
fresh();
for (let i = 0; i < K.VOID_EVERY + 2; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
ok('it opens a void', (K.dungeon._voids || []).length > 0);
const v = K.dungeon._voids[0];
ok('and always within reach — the offer is never far off',
   Math.hypot(v.x * T - K.player.x, v.y * T - K.player.y) < T * 6,
   `${Math.round(Math.hypot(v.x*T-K.player.x, v.y*T-K.player.y)/T)} tiles away`);

// ── and the offer is a lie ────────────────────────────────────────────────
// This is the assertion that matters: inside a void, hope falls FASTER, not
// slower, and the Champion mends. Crystalpeak's fire is free; this is not.
fresh();
for (let i = 0; i < K.VOID_EVERY + 2; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
const vv = K.dungeon._voids[0];
K.$('player.hope=80; player.x=' + (vv.x * T) + '; player.y=' + (vv.y * T) + ';');
ok('standing in it registers as being in it', K.$('inVoid()') !== null);
const bossHpBefore = boss().hp;
for (let i = 0; i < 60; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
const inside = 80 - K.player.hope;

fresh();
K.$('player.hope=80;');
for (let i = 0; i < 60; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
const outside = 80 - K.player.hope;
ok('hope falls FASTER inside the void, not slower', inside > outside * 2,
   `${inside.toFixed(1)} lost inside vs ${outside.toFixed(1)} outside, per second`);
ok('and the Champion mends while you rest', bossHpBefore > 0 && K.VOID_HEAL > 0,
   `+${(K.VOID_HEAL * 60).toFixed(1)} hp/sec to it while you are in there`);

// ── the arm gives out ─────────────────────────────────────────────────────
fresh();
K.$('player.hope=0.05; player.hp=9999; player.iframes=0;');
const hp0 = K.player.hp;
for (let i = 0; i < 90; i++) K.$('hellTick(demons.find(d=>d.boss&&d.alive));');
ok('at zero hope it costs you health', K.player.hp < hp0,
   `hp ${hp0} -> ${K.player.hp}`);
ok('but it is recoverable — striking brings it back',
   (() => { K.$('applyDemonHit(demons.find(d=>d.boss&&d.alive), 10, false, 1, 0, 1, 2);');
     return K.player.hope > 0; })(),
   'a dead end would be a defeat screen, not a lesson');

// ── the mirror with Crystalpeak, stated ───────────────────────────────────
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('the voids are drawn WARM, like the fires six chapels back',
   /the warm rim: the offer/.test(raw),
   'they have to look like the relief the player was taught to run toward');
ok('and the mirror is deliberate, not accidental',
   /Chapel six teaches a knight to go to the warm thing/.test(raw));

// ── hope must not leak out of this chapel ─────────────────────────────────
K.$('player.hope=42; place={kind:"overworld"}; hellTick(null);');
ok('hope clears the moment you are anywhere else', K.player.hope === undefined,
   'it is not a meter the player carries around');

// ── and no tile code was claimed for nothing ──────────────────────────────
ok('the voids are entities, not tiles', !/const T_VOID=/.test(raw),
   'a declared-but-unstamped tile code would leave the next one guessing');

// ── the timings ───────────────────────────────────────────────────────────
const emptyIn = K.HOPE_MAX / K.HOPE_DRAIN / 60;
const emptyInVoid = K.HOPE_MAX / K.HOPE_VOID_DRAIN / 60;
ok('simply standing still does not kill you quickly', emptyIn > 20,
   `${emptyIn.toFixed(0)}s from full to empty, doing nothing`);
ok('but the void empties you fast', emptyInVoid < emptyIn / 2,
   `${emptyInVoid.toFixed(0)}s from full to empty inside one`);
ok('a handful of blows restores a meaningful share',
   K.HOPE_PER_HIT * 3 > K.HOPE_MAX * 0.2,
   `three hits = ${K.HOPE_PER_HIT * 3} of ${K.HOPE_MAX}`);

done('hellgate');

// suite/dusthaven.js — Josiah's hall, and everything that could not save them.
//
// "He preached a Christ he found easier to carry: a fine teacher, a brave man, a
// lamp for the road — and nothing that a man might need saving by… When the
// Ember Hollow came through the grain it burned everything that could not save
// them, and there was a great deal of it."
//
// The room is full of shelter and almost all of it burns. Hide behind a stack
// and it takes the shot for you and goes up, so leaning on it is what empties
// the room. One thing is stone.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('dusthaven');

const T = K.TILE;
function fresh() {
  const g = K.genDusthavenArena();
  globalThis.__dg = g;
  K.$('place={kind:"dungeon"}; dungeon.townId=4; dungeon.grid=globalThis.__dg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');
  return g;
}
const g = fresh();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

const grain = K.dungeon._grain;
ok('the hall is stacked with shelter — "a great deal of it"', grain.length >= 10,
   `${grain.length} stacks`);
let stamped = 0;
for (const s of grain) if (g[s.y][s.x] === K.T_GRAIN) stamped++;
ok('every declared stack survives onto the floor', stamped === grain.length,
   `${stamped}/${grain.length} — the rest were overwritten by later stamps`);
ok('grain is solid: it is real cover', grain.every(s => !K.walkable(s.x, s.y)));
ok('the altar is stone and solid', g[2][7] === K.T_ALTAR && !K.walkable(7, 2));

// ── shelter works exactly once ─────────────────────────────────────────────
fresh();
const s0 = K.dungeon._grain[0];
globalThis.__s = s0;
K.$(`igniteGrain(${s0.x}, ${s0.y});`);
ok('a stack that takes a shot catches fire', s0.state === 'burning',
   `state ${s0.state}`);
ok('it still covers while it burns', !K.walkable(s0.x, s0.y),
   'the shot it ate was not wasted');
for (let i = 0; i < K.GRAIN_BURN + 2; i++) K.$('dustTick();');
ok('then it falls to ash', s0.state === 'ash', `state ${s0.state}`);
ok('and stops covering anything', K.walkable(s0.x, s0.y),
   'you walk over what is left');

// ── the altar never burns ──────────────────────────────────────────────────
fresh();
K.$('igniteGrain(7, 2);');
ok('the altar cannot be set alight',
   K.dungeon.grid[2][7] === K.T_ALTAR && !K.walkable(7, 2),
   'the one thing in the hall that holds');

// ── and the floor survives the fire ────────────────────────────────────────
// The hall is the most cluttered of the set. That is only safe because every
// piece of it is temporary — so check both ends: passable at the start, and
// passable once it has all burned.
function geometry(label) {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  let open = 0, reach = 0, pockets = 0;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!K.walkable(x, y)) continue;
    open++; if (seen.has(y * 100 + x)) reach++;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pockets++;
  }
  ok(`${label}: everything reachable`, open === reach, `${reach}/${open}`);
  ok(`${label}: no dead-end pocket`, pockets === 0, `${pockets} one-exit tiles`);
  return open;
}
fresh();
const openFull = geometry('stacked');
K.$('for(const s of dungeon._grain){ s.state="ash"; dungeon.grid[s.y][s.x]=T_ASH; }');
const openBurnt = geometry('burnt out');
ok('the room genuinely opens up as it burns', openBurnt > openFull,
   `${openFull} -> ${openBurnt} walkable tiles`);

// ── cover actually covers now ──────────────────────────────────────────────
// Dungeon projectiles used to check only the arena bounds and the knight: they
// passed straight through pillars, lecterns and armour stands, so every piece of
// cover in every sanctum was decorative. This is a change to ALL ten fights.
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('dungeon projectiles stop on solid tiles',
   /const ptx=Math\.floor\(p\.x\/TILE\), pty=Math\.floor\(p\.y\/TILE\);[\s\S]{0,120}!walkable\(ptx,pty\)/.test(raw),
   'pillars, lecterns and stands finally block a volley');
ok('and a blocked shot ignites grain only in Dusthaven',
   /if\(dungeon\.townId===4\) igniteGrain\(ptx,pty\)/.test(raw));

// The other themed sanctums must still be passable now that their furniture
// really blocks things — cover that stops shots is the same cover that could
// corner someone.
for (const [town, gen] of [[0, 'genHearthvaleArena'], [1, 'genIronholdArena'], [3, 'genThornwoodArena']]) {
  const gg = K.$(`${gen}()`);
  globalThis.__cg = gg;
  K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.grid=globalThis.__cg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;`);
  let pocket = 0;
  for (let y = 1; y < gg.length - 1; y++) for (let x = 1; x < gg[0].length - 1; x++) {
    if (!K.walkable(x, y)) continue;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pocket++;
  }
  ok(`chapel ${town + 1} is still free of pockets with cover made real`, pocket === 0,
     `${pocket} one-exit tiles`);
}

done('dusthaven');

// suite/robby.js — the man in the cave, and what he sells.
//
// Robby's Demise is bought, not earned: ten thousand gold, five fish and two
// loaves, from a man in a hollow tree with a television. Wearing it you are half
// a beast — nobody will speak to you, and fences, water and cliffs stop meaning
// anything.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');

console.log('robby');
const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');
const T = K.TILE;

// ── the door is genuinely hidden ──────────────────────────────────────────
// It is drawn by REMAPPING to tile 1 at the top of drawDungeonTile, not by
// having its own case, so it cannot drift a pixel from its neighbours.
ok('the door remaps to a wall rather than drawing itself',
   /if\(t===T_ROBBYDOOR\) t=1;/.test(raw));
ok('and it is solid, like the trees around it', (() => {
  globalThis.__fg = K.genForestMaze(21, 41, 97);
  K.$('place={kind:"dungeon"}; dungeon.townId=3; dungeon.disillusion=true; dungeon.grid=globalThis.__fg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');
  let d = null;
  for (let y = 0; y < globalThis.__fg.length; y++) for (let x = 0; x < globalThis.__fg[0].length; x++)
    if (globalThis.__fg[y][x] === K.T_ROBBYDOOR) d = [x, y];
  return d && !K.walkable(d[0], d[1]);
})());

// The real test: drawn at identical coordinates, is it distinguishable from a
// wall? The forest art animates, so a wall differs from ITSELF between frames —
// the door has to differ by no more than that.
(() => {
  const cel = K.el('c'); cel.width = T; cel.height = T;
  const c2 = cel.getContext('2d');
  const shot = tile => { c2.clearRect(0, 0, T, T); K.$(`drawDungeonTile(${tile}, 0, 0, 3, 21);`);
                         return Uint8Array.from(c2.getImageData(0, 0, T, T).data); };
  const cmp = (a, b) => { let n = 0;
    for (let i = 0; i < a.length; i += 4)
      if (a[i]!==b[i]||a[i+1]!==b[i+1]||a[i+2]!==b[i+2]||a[i+3]!==b[i+3]) n++;
    return n; };
  const wallA = shot(1), wallB = shot(1), door = shot(K.T_ROBBYDOOR);
  const control = cmp(wallA, wallB), test = cmp(wallA, door);
  ok('the door is indistinguishable from a tree', test <= control,
     `${test} pixels differ from a wall; a wall differs from ITSELF by ${control} (the art animates)`);
})();

// ── it does not collide with the wood's other secret ──────────────────────
for (const seed of [97, 11, 42, 7]) {
  const g = K.genForestMaze(21, 41, seed);
  let door = null, hollow = null;
  for (let y = 0; y < g.length; y++) for (let x = 0; x < g[0].length; x++) {
    if (g[y][x] === K.T_ROBBYDOOR) door = x + ',' + y;
    if (g[y][x] === 35) hollow = x + ',' + y;
  }
  ok(`seed ${seed}: the door exists and is not the Sage's Hollow`,
     !!door && door !== hollow, `door ${door}, hollow ${hollow}`);
}

// ── the price ─────────────────────────────────────────────────────────────
check('ten thousand gold', K.ROBBY_GOLD, 10000);
check('five fish', K.ROBBY_FISH, 5);
check('two loaves', K.ROBBY_BREAD, 2);
ok('fish means any fish', /perch','trout','oasisCarp','seabass','kingfish','goldenFish/.test(raw),
   'all six kinds count toward the five');

K.$('player.robbysDemise=false; player.robbyShown=false; gold=9999; inventory.bread=2; inventory.perch=5;');
K.$('robbyTalk();');
ok('a gold short and he says no', K.player.robbysDemise !== true, `gold ${K.$('gold')}`);
K.$('gold=10000; robbyTalk();');
ok('pay the price and the armour is yours', K.player.robbysDemise === true);
ok('and it costs you exactly that', K.$('gold') === 0 && K.$('inventory.bread') === 0
   && K.$('inventory.perch') === 0, `gold ${K.$('gold')}, bread ${K.$('inventory.bread')}, perch ${K.$('inventory.perch')}`);
ok('it shows itself once, then the Home tab owns it',
   K.$('currentLivery()') === 'robby' && K.player.robbyShown === true);

// ── he is the one person who still talks to you ───────────────────────────
ok('Robby speaks to the beast', raw.indexOf('if(npc.robby){ robbyTalk(); return true; }')
   < raw.indexOf('nobody speaks to a thing like that'),
   'checked BEFORE the refusal — otherwise buying it locks you out of ever seeing him');
ok('and nobody else does', /if\(beastForm\(\)\)\{[\s\S]{0,200}they will not look at you/.test(raw));

// ── fences and water, not doors and walls ─────────────────────────────────
K.$('player.livery="robby"; place={kind:"overworld"}; player.mounted=false; homesteadKey=false;');
const findTile = code => { for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++)
                             if (K.WORLD[y][x] === code) return [x, y]; return null; };
ok('a fence is nothing to him', K.walkable(...findTile(K.T_FENCE)));
ok('nor is the homestead gate, key or no key', K.walkable(...findTile(K.T_GATE)));
const water = findTile(3);
ok('nor is water', !water || K.walkable(...water));
let walls = 0;
for (let y = 0; y < K.WORLD_H; y++) for (let x = 0; x < K.WORLD_W; x++)
  if (K.WORLD[y][x] === 5 && !K.walkable(x, y)) walls++;
ok('but a building is still a building', walls > 1000,
   `${walls} structure tiles still refused — he goes round a house and in through the door`);
ok('and the world still has edges',
   !K.walkable(-1, 5) && !K.walkable(K.WORLD_W, 5));

// ── and nothing else loosens ──────────────────────────────────────────────
globalThis.__hg = K.genHearthvaleArena();
K.$('place={kind:"dungeon"}; dungeon.townId=0; dungeon.grid=globalThis.__hg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');
ok('dungeon walls hold', !K.walkable(0, 0) && !K.walkable(3, 3),
   'a sealed sanctum stays sealed');
K.$('place={kind:"abaddon"}; buildAbaddonArena(); abaddonBreakFloor(1); abaddonBreakFloor(2);');
ok('the throne room holds', !K.walkable(2, 3),
   'its pillars and chasms are unaffected');
K.$('player.livery="azure"; place={kind:"overworld"};');
ok('taking it off puts every wall back',
   !K.walkable(...findTile(K.T_FENCE)), 'the fence is a fence again');

// ── the look ──────────────────────────────────────────────────────────────
ok('horns instead of a crest', /ROBBY'S DEMISE: HORNS/.test(raw));
ok('the eyes beam through the visor', /the eyes beam out of the slit/.test(raw));
ok('hands and feet turn', /the hands and feet are not a man's any more/.test(raw));
ok('a shadow rides with him', /the shadow that masks him/.test(raw));
ok('the wings are the biggest in the game', /the biggest in the game, rooted two pixels under/.test(raw));
ok('the cape carries an ace of spades', /the cape, with the ace on it/.test(raw));
ok('and he carries nothing visible',
   /Robby's Demise carries nothing\. The claws do the work\./.test(raw)
   && /if\(!beastForm\(\)\) shield\(/.test(raw));


// ── the cave itself ───────────────────────────────────────────────────────
// A hole in the wood that somebody lives in: a television, a console on a crate,
// a bed facing the screen, pizza boxes, and a poker table he plays at alone.
K.$('place={kind:"interior", id:"robbycave", floor:0};');
const cf = K.INTERIORS.robbycave.floors[0];
const cg = cf.g || cf;
const count = code => { let n = 0; for (const r of cg) for (const t of r) if (t === code) n++; return n; };

check('the cave is 13x9', [cg[0].length, cg.length], [13, 9]);
ok('there is a television', count(70) === 2, `${count(70)} tiles wide`);
ok('and it is MOUNTED on the wall row', cg[0].includes(70),
   'it hangs on the stonework rather than standing on the floor');
ok('with the console on a shelf beside it', count(71) === 1 && cg[0].includes(71));
ok('and a bed', count(61) === 1 && count(62) === 1, 'head and foot');
ok('and a card table of a normal size', count(73) === 4, `${count(73)} tiles — 2x2`);
ok('with chairs round it', count(41) === 4, `${count(41)} — one each and one spare`);
// Tidied, but not tidy: a few boxes left, and some of them on the table.
ok('some pizza boxes are still about', count(72) >= 2 && count(72) <= 5,
   `${count(72)} of them — cleaned up, not cleaned`);

// The boxes are litter, not furniture: you step over them.
ok('you can walk over the pizza boxes', K.WALK.has(72),
   'they are litter, not something to path around');
ok('but not through the television or the table',
   !K.WALK.has(70) && !K.WALK.has(73));

// Everything in it must be reachable from the door, or he has furnished
// himself into a corner.
(() => {
  let dx, dy;
  for (let y = 0; y < cg.length; y++) for (let x = 0; x < cg[0].length; x++) if (cg[y][x] === 9) { dx = x; dy = y; }
  const seen = new Set([(dy - 1) * 100 + dx]); const st = [[dx, dy - 1]];
  while (st.length) { const [x, y] = st.pop();
    for (const [ax, ay] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + ax, ny = y + ay;
      if (nx < 0 || ny < 0 || nx >= cg[0].length || ny >= cg.length) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]); } }
  let open = 0, reach = 0;
  for (let y = 0; y < cg.length; y++) for (let x = 0; x < cg[0].length; x++) {
    if (!K.walkable(x, y)) continue; open++; if (seen.has(y * 100 + x)) reach++; }
  ok('every floor tile is reachable from the way out', open === reach, `${reach}/${open}`);
  const npc = K.INTERIORS.robbycave.npcs[0];
  ok('and Robby can be walked up to',
     [[1,0],[-1,0],[0,1],[0,-1]].some(([a, b]) => seen.has((npc.y + b) * 100 + (npc.x + a))),
     `he sits at ${npc.x},${npc.y}`);
})();

// Multi-tile furniture has to read as ONE object.
ok('the poker table is edge-aware',
   /EDGE-AWARE\. _legacy: every tile drew its own top lip and bottom rail/.test(raw),
   'otherwise a 3x3 table has black bands through the middle of it');
ok('and so is the television',
   /EDGE-AWARE, so a 2-wide TV is ONE television/.test(raw),
   'two tiles side by side were two televisions');
ok('the TV has one stand, not one per tile',
   /one stand and one standby light for the whole set/.test(raw));


// ── the card table ────────────────────────────────────────────────────────
// Blackjack, with Robby dealing. A DOM overlay like the library and the trial,
// because there is nothing to render on the canvas and the buttons want to be
// real buttons.
// DRIVEN, not pattern-matched. The previous version of these two checked that
// the source contained the right line — and it did, sitting inside the
// place.kind==='dungeon' branch, which an interior never enters. Both games were
// unreachable while the assertions passed. Stand in the room and press the
// button instead.
(() => {
  const f = K.INTERIORS.robbycave.floors[0], g = f.g || f;
  const findStand = code => {
    for (let y = 0; y < g.length; y++) for (let x = 0; x < g[0].length; x++) {
      if (g[y][x] !== code) continue;
      for (const [ax, ay] of [[x,y+1],[x,y-1],[x-1,y],[x+1,y]])
        if (g[ay] && g[ay][ax] === 12) return [ax, ay, x, y];
    }
    return null;
  };
  const dirTo = (sx, sy, tx, ty) => ty < sy ? 'up' : ty > sy ? 'down' : tx < sx ? 'left' : 'right';

  const t = findStand(73);
  K.$('boot.done=true; place={kind:"interior", id:"robbycave", floor:0}; bj.open=false;');
  K.$(`player.x=${t[0]}*TILE; player.y=${t[1]}*TILE; player.dir="${dirTo(...t)}";`);
  K.$('doAction(true);');
  ok('pressing A at the table opens blackjack', K.$('bj.open') === true,
     `stood at ${t[0]},${t[1]} facing ${t[2]},${t[3]}`);
  K.$('closeBlackjack();');

  const c = findStand(71);
  K.$('gold=50; place={kind:"interior", id:"robbycave", floor:0};');
  K.$(`player.x=${c[0]}*TILE; player.y=${c[1]}*TILE; player.dir="${dirTo(...c)}";`);
  K.$('doAction(true);');
  ok('pressing A at the console opens Blockfall', K.$('place.kind') === 'blocks',
     `stood at ${c[0]},${c[1]} facing ${c[2]},${c[3]}`);
  K.$('place={kind:"interior", id:"robbycave", floor:0};');
})();
ok('and the checks live where an interior actually reaches them',
   /Placed HERE, straight after the shared facing lookup/.test(raw),
   'they were inside the dungeon-only branch');
ok('there are pizza boxes on the table too',
   /a pizza box pushed to one corner of the table/.test(raw));

// Ace softening is the thing blackjack implementations get wrong.
K.$('bj.you=[{r:1,s:0},{r:1,s:1}];');
check('A,A is 12', K.$('bjVal(bj.you)'), 12);
K.$('bj.you=[{r:1,s:0},{r:13,s:1}];');
check('A,K is 21', K.$('bjVal(bj.you)'), 21);
K.$('bj.you=[{r:1,s:0},{r:9,s:1},{r:5,s:2}];');
check('A,9,5 is 15 — the ace softens', K.$('bjVal(bj.you)'), 15);
K.$('bj.you=[{r:1,s:0},{r:1,s:1},{r:9,s:2}];');
check('A,A,9 is 21 — only one ace softens', K.$('bjVal(bj.you)'), 21);

// A deck is a deck.
K.$('bj.deck=bjNewDeck();');
check('fifty-two cards', K.$('bj.deck.length'), 52);
ok('four of every rank', K.$('(function(){ const m={}; for(const c of bj.deck) m[c.r]=(m[c.r]||0)+1; return Object.values(m).every(v=>v===4) && Object.keys(m).length===13; })()') === true);

// Three hundred hands, checking nothing throws and no illegal state survives.
K.$('gold=5000;');
let illegal = 0;
for (let i = 0; i < 300; i++) {
  K.$('openBlackjack(); bjDeal(25);');
  let guard = 0;
  while (K.$('bj.phase') === 'play' && K.$('bjVal(bj.you)') < 17 && guard++ < 12) K.$('bjHit();');
  if (K.$('bj.phase') === 'play') K.$('bjStand();');
  const v = K.$('bjVal(bj.you)'), m = K.$('bj.msg');
  if (v > 21 && !/Bust/.test(m)) illegal++;
  if (K.$('bj.phase') !== 'done') illegal++;
}
ok('three hundred hands, every one resolved legally', illegal === 0, `${illegal} bad states`);
ok('the dealer never plays on when everyone has busted',
   /if\(!bjBust\(bj\.you\) \|\| !bjBust\(bj\.chey\)\)\{/.test(raw));
ok('you cannot bet gold you have not got',
   /if\(gold<bet\)\{ bj\.msg='You haven\\u2019t got it\.'/.test(raw)
   || /You haven/.test(raw));

// ── Blockfall ─────────────────────────────────────────────────────────────
// Not Tetris: its own name, its own seven shapes, a ten-wide well, and no
// assets shared with anything.
ok('it is not called Tetris', !/Tetris/i.test(raw), 'nowhere in the source');
check('a ten-wide well', K.BF_W, 10);
check('eighteen deep', K.BF_H, 18);
check('seven shapes', K.BF_SHAPES.length, 7);

K.$('gold=50; openBlockfall();');
ok('it takes over the screen', K.$('place.kind') === 'blocks',
   'a place.kind minigame, like the race and the tourney');
ok('the well starts empty', K.$('bf.grid.every(r=>r.every(c=>!c))') === true);

// The invariant that matters: the falling piece never overlaps the stack or
// leaves the well, however it is thrown about.
(() => {
  let bad = 0, steps = 0;
  while (!K.$('bf.over') && steps < 4000) {
    const r = Math.random();
    if (r < 0.2) K.$("blockPress('A');");
    else if (r < 0.4) K.$("blockDpad('left');");
    else if (r < 0.6) K.$("blockDpad('right');");
    else if (r < 0.65) K.$("blockDpad('up');");
    K.$('bfTick();'); steps++;
    bad += K.$('(function(){ if(bf.over||bf.piece===null) return 0; let n=0; for(const [x,y] of bfCells(bf.piece,bf.rot,bf.px,bf.py)){ if(x<0||x>=BF_W||y>=BF_H) n++; else if(y>=0 && bf.grid[y][x]) n++; } return n; })()');
  }
  ok('the piece never overlaps the stack or leaves the well', bad === 0,
     `${steps} ticks of random play, ${bad} violations`);
  ok('and no full row is ever left sitting there',
     K.$('bf.grid.filter(r=>r.every(c=>c)).length') === 0);
})();

// Line clearing, forced — random play almost never completes a row.
K.$('gold=50; openBlockfall();');
K.$(`(function(){
  for(let x=1;x<BF_W;x++){ bf.grid[BF_H-1][x]='#888'; bf.grid[BF_H-2][x]='#888'; }
  bf.piece=0; bf.rot=1; bf.px=-2; bf.py=BF_H-4;
})();`);
// Gravity places it — there is no hard drop any more. Tick until it sets.
for (let i = 0; i < 2000 && K.$('bf.lines') === 0; i++) K.$('bfTick();');
check('a bar into the gap clears both rows', K.$('bf.lines'), 2);
ok('and scores for it', K.$('bf.score') > 0, `${K.$('bf.score')} points`);
ok('leaving no full rows behind', K.$('bf.grid.filter(r=>r.every(c=>c)).length') === 0);

K.$('bf.lines=12; bf.speed=Math.max(6,36-Math.floor(bf.lines/4)*3);');
ok('it speeds up as you clear', K.$('bf.speed') < 36, `${K.$('bf.speed')} at twelve lines`);
// A coin in, a handful back. Tuned so three or four good games buys the
// cheapest seat at the card table.
check('a gold a game', K.BF_COST, 1);
K.$('gold=0; bf.score=800; bfPayout();');
ok('800 points pays 8 gold', K.$('gold') === 8, `${K.$('gold')}`);
K.$('gold=0; bf.score=50; bfPayout();');
ok('a bad run pays nothing, and the coin is gone', K.$('gold') === 0 && K.$('bf.net') === -1,
   'which is the correct amount to lose');
ok('the cheapest seat at the table is within a few good games',
   Math.ceil(BJ_MIN() / 8) <= 5,
   `${BJ_MIN()} gold a hand, about ${Math.ceil(BJ_MIN() / 8)} decent runs`);
function BJ_MIN(){ return Math.min(...K.BJ_BETS); }


// ── the three of them ─────────────────────────────────────────────────────
// Drawn from Zak's reference: Robby dark-haired under a pale green cap with a
// moustache, Cheyenne blonde under a wide straw hat with dark glasses, Benji two
// years old in a red junior fire helmet.
ok('each has their own sprite, not the generic villager',
   /if\(n\.robby\)\{ drawRobby/.test(raw) && /if\(n\.cheyenne\)\{ drawCheyenne/.test(raw)
   && /if\(n\.benji\)\{ drawBenji/.test(raw));
ok('and their own dialogue portrait', (() => {
  K.$('_robbyPortraits();');
  return ['robby','cheyenne','benji'].every(id => !!K.$(`PORTRAITS['${id}']`));
})(), 'so the pop-ups show their faces rather than nothing');
ok('the portraits are reachable by the name they speak under',
   ['Robby','Cheyenne','Benji'].every(n => !!K.$(`portraitFor("${n}")`)),
   'portraitFor matches on the spoken name');

// Hair colour is the thing Zak called out specifically.
ok('Robby and Benji are dark brown, Cheyenne is blonde',
   /dark hair at the sides/.test(raw) && /dark brown hair/.test(raw)
   && /blonde, either side/.test(raw));

// The portraits must fill their frame — an early version put an 8-row face in a
// 32-row box and it read as a small blob with a lot of shirt under it.
// The portrait canvas is PORTRAIT_W x PORTRAIT_H. Drawing into a 32x32 box put
// all three at under a quarter size in the top-left corner.
ok('the portraits are drawn at the real canvas size',
   /drawn into a 32x32 box/.test(raw), `canvas is ${K.PORTRAIT_W}x${K.PORTRAIT_H}`);
(() => {
  K.$('_robbyPortraits();');
  // measure the painted extent of each bust against the canvas it lives on
  for (const id of ['robby','cheyenne','benji']) {
    let maxX = 0, maxY = 0;
    K.$(`(function(){ globalThis.__ext={x:0,y:0}; const q=(x,y,w,h)=>{ if(x+w>globalThis.__ext.x) globalThis.__ext.x=x+w; if(y+h>globalThis.__ext.y) globalThis.__ext.y=y+h; }; PORTRAITS['${id}'](q); })();`);
    maxX = globalThis.__ext.x; maxY = globalThis.__ext.y;
    ok(`${id} fills its portrait canvas`,
       maxX > K.PORTRAIT_W * 0.85 && maxY > K.PORTRAIT_H * 0.85,
       `paints to ${maxX}x${maxY} of ${K.PORTRAIT_W}x${K.PORTRAIT_H}`);
  }
})();

// ── both games have to take input from a thumb ────────────────────────────
ok('the card table rows respond to a tap',
   /tgt\.closest\('\[data-bj\]'\)/.test(raw),
   'they carried data-bj and nothing in the click handler read it');
ok('and the joystick browses the table',
   /barn\|\|bj\.open\)/.test(raw),
   'bj.open was missing from overlayOpen, so the stick never reached it');
ok('Blockfall takes the joystick',
   /\} else if\(place\.kind==='blocks'\)\{/.test(raw),
   'there was no branch at all — the stick fell through to the walking path');
ok('and repeats while held, without running away',
   /const gap = dir==='down' \? \d+ : \d+;/.test(raw),
   'soft-drop repeats faster than sideways steps');
// The stick must not even SAMPLE up — nothing on it should reach the well.
ok("up is not sampled on the stick at all",
   /const dir = D\?'down':L\?'left':Rt\?'right':null;/.test(raw),
   'not U?\'up\': a thumb drifts up and that used to slam the piece');

// All three are in the cave, and all three can be spoken to.
const fam = K.INTERIORS.robbycave.npcs;
check('three of them live here', fam.length, 3);
ok('Robby, Cheyenne and Benji',
   fam.map(n => n.name).join(',') === 'Robby,Cheyenne,Benji', fam.map(n => n.name).join(', '));
ok('Cheyenne and Benji have their own lines',
   fam[1].lines.length >= 3 && fam[2].lines.length >= 3,
   `${fam[1].lines.length} and ${fam[2].lines.length}`);
ok('and talking to them does not open the table',
   /if\(npc\.cheyenne \|\| npc\.benji\)\{/.test(raw),
   'only Robby deals');


// Cheyenne's silhouette: an 8-wide dress running unbroken from shoulder to hem
// under a 10-wide brim made her the widest of the three by some way. The bodice
// is 4 wide, the skirt 6, the brim pulled in two pixels.
ok("Cheyenne is not the widest of the three",
   /an 8-wide dress running unbroken from shoulder to hem/.test(raw),
   'bodice 4 wide, skirt 6, brim pulled in');


// ── in and out again ──────────────────────────────────────────────────────
// The cave has no building and no door on the overworld, so the generic exit
// path had nothing to return to and dropped the player at the wrong end of the
// map. It stores the tile you opened the tree from and puts you back on it.
ok('the way out is wired to where you came in',
   /if\(place\.id==='robbycave'\)\{/.test(raw),
   'ahead of the generic building-door path');
// It must catch the cave even with no stored return — falling through to the
// generic path is exactly the failure, so the branch keys on the ROOM, not on
// the return value being present.
ok('and it catches the cave even if the return was lost',
   !/place\.id==='robbycave' && dungeon\._robbyReturn/.test(raw),
   'the branch cannot be conditional on the thing that might be missing');
ok('it rebuilds the wood if the grid went missing',
   /dungeon\.grid=genForestMaze\(21,41,dungeon\.forestSeed\|\|97\)/.test(raw));
ok('and falls back to the tile beside the door',
   /no stored spot, or it is no longer standable/.test(raw));

K.$('boot.done=true;');
K.$('place={kind:"dungeon"}; dungeon.townId=3; dungeon.disillusion=true; dungeon.forestSeed=97; dungeon.floorIdx=0;');
globalThis.__rg = K.genForestMaze(21, 41, 97);
K.$('dungeon.grid=globalThis.__rg; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');
// find the door and the tile you stand on to open it
let rd = null;
for (let y = 0; y < globalThis.__rg.length; y++) for (let x = 0; x < globalThis.__rg[0].length; x++)
  if (globalThis.__rg[y][x] === K.T_ROBBYDOOR) rd = [x, y];
const stand = [[rd[0]+1,rd[1]],[rd[0]-1,rd[1]],[rd[0],rd[1]+1],[rd[0],rd[1]-1]]
  .find(([x, y]) => K.walkable(x, y));
K.$(`player.x=${stand[0]}*TILE; player.y=${stand[1]}*TILE; player.dir="${rd[1] < stand[1] ? 'up' : rd[1] > stand[1] ? 'down' : (rd[0] < stand[0] ? 'left' : 'right')}";`);
const was = { x: K.player.x, y: K.player.y, town: K.dungeon.townId, floor: K.dungeon.floorIdx };

K.$('doAction(true);');
ok('pressing A at the tree puts you in the cave',
   K.$('place.kind') === 'interior' && K.$('place.id') === 'robbycave');
ok('and it remembers where you came from', !!K.dungeon._robbyReturn);

// through the console and back
K.$('gold=50; openBlockfall();');
ok('the console takes over the screen', K.$('place.kind') === 'blocks');
K.$("blockPress('B');");
ok('stopping puts you back in the cave, not on a hardcoded tile',
   K.$('place.kind') === 'interior' && K.$('place.id') === 'robbycave'
   && K.walkable(Math.floor(K.player.x / K.TILE), Math.floor(K.player.y / K.TILE)),
   'the room was rearranged twice and the old hardcoded tile became a crate');

K.$('_exitInteriorNow();');
ok('leaving the cave returns you to the wood', K.$('place.kind') === 'dungeon');
ok('on the exact tile you opened the tree from',
   K.player.x === was.x && K.player.y === was.y,
   `${K.player.x / K.TILE},${K.player.y / K.TILE}`);
ok('on the same floor of the same forest',
   K.dungeon.townId === was.town && K.dungeon.floorIdx === was.floor);
ok('and on ground you can stand on',
   K.walkable(Math.floor(K.player.x / K.TILE), Math.floor(K.player.y / K.TILE)));
ok('the stored return is cleared behind you', !K.dungeon._robbyReturn,
   'so a later exit from somewhere else cannot teleport you into the wood');


// ── both games, driven through the real buttons ───────────────────────────
// Everything above tested the ENGINES. The engines were always fine; what was
// broken was the wiring — the open check sat in a branch interiors never reach,
// bPress had no case for the console, and the card-table cursor lived in the
// DOM where no test could see it. These press the buttons.
ok('the blackjack cursor is game state, not DOM',
   /The cursor is an index on/.test(raw),
   'querySelector on .gm-item.cur was invisible to every test');

// Earlier assertions call robbyTalk(), which opens a dialogue — and aPress
// advances a dialogue before it reaches anything else. Clear it, or these
// measure the dialogue rather than the table.
K.$('dialogue.open=false; cutscene.active=false; menu.open=false; intro.open=false;');
K.$('boot.done=true; gold=1000; place={kind:"interior", id:"robbycave", floor:0}; openBlackjack();');
check('four ways to start', K.$('bjActions().length'), 4);
ok('the cursor starts at the top', (K.bj.cursor | 0) === 0);
K.$('aPress();');
ok('A takes the bet and deals', K.$('bj.phase') === 'play' && K.$('gold') === 975,
   `gold ${K.$('gold')}, ${K.$('bj.you.length')} cards`);
ok('and the options become Hit and Stand',
   K.$('bjActions().map(a=>a.label).join("/")') === 'Hit/Stand');
const cards = K.$('bj.you.length');
K.$('aPress();');
ok('A hits', K.$('bj.you.length') > cards || K.$('bj.phase') === 'done');
K.$('bj.phase="play"; bj.cursor=0; bjMove(1);');
ok('the joystick moves the cursor', (K.bj.cursor | 0) === 1,
   `on "${K.$('bjActions()[bj.cursor].label')}"`);
K.$('aPress();');
ok('A stands and the hand resolves', K.$('bj.phase') === 'done' && !!K.$('bj.msg'),
   K.$('bj.msg'));
K.$('bjSelect(0);');
ok('a tap on a row acts on that row', K.$('bj.phase') === 'bet',
   'the click handler passes the index');
K.$('bPress();');
ok('B leaves the table', K.$('bj.open') === false);

// Blockfall through the real buttons.
K.$('gold=50; place={kind:"interior", id:"robbycave", floor:0}; openBlockfall();');
ok('the console takes the screen', K.$('place.kind') === 'blocks');
const r0 = K.$('bf.rot');
K.$('aPress();');
ok('A rotates', K.$('bf.rot') !== r0, `${r0} -> ${K.$('bf.rot')}`);
const px0 = K.$('bf.px');
K.$("blockDpad('left');");
ok('the joystick moves the piece', K.$('bf.px') === px0 - 1);
K.$('bPress();');
ok('B stops the game and puts you back in the cave',
   K.$('place.kind') === 'interior' && K.$('place.id') === 'robbycave',
   'bPress had no case for it at all — the real handler was never touched');


// ── the stick must never place a piece for you ────────────────────────────
// _legacy: 'up' was a hard drop and 'down' locked on contact. Up is where a
// thumb drifts on a round stick, so pieces slammed into the well the moment you
// tilted. Between them the game placed your pieces for you, which is what made
// it feel glitchy.
K.$('gold=50; openBlockfall();');
(() => {
  const p0 = K.$('bf.piece'), y0 = K.$('bf.py');
  for (let i = 0; i < 40; i++) K.$("blockDpad('up');");
  ok('up on the stick does nothing at all',
     K.$('bf.piece') === p0 && K.$('bf.py') === y0,
     'forty tilts, same piece, same height');
})();
(() => {
  for (let i = 0; i < 60; i++) K.$("blockDpad('down');");
  const p = K.$('bf.piece');
  for (let i = 0; i < 60; i++) K.$("blockDpad('down');");
  ok('holding down on the floor never locks it',
     K.$('bf.piece') === p && K.$('bf.grid.every(r=>r.every(c=>!c))') === true,
     'locking is gravity\'s job');
  let t = 0;
  while (K.$('bf.piece') === p && t < 200) { K.$('bfTick();'); t++; }
  ok('gravity sets it after the lock delay, not ten seconds later', t <= K.BF_LOCK + 2,
     `${t} frames (BF_LOCK is ${K.BF_LOCK})`);
  ok('and that delay is counted in FRAMES',
     /it counted GRAVITY\s*\n?\s*\/\/\s*STEPS, not frames/.test(
       require('fs').readFileSync(__dirname + '/../game.js', 'utf8')),
     'counting gravity steps made it ten seconds at the starting fall speed');
})();
K.$('gold=50; openBlockfall();');
(() => {
  for (let i = 0; i < 60; i++) K.$("blockDpad('down');");
  const x = K.$('bf.px');
  K.$('bfTick();');
  K.$("blockDpad('left');");
  ok('but you can still slide a landed piece before it sets',
     K.$('bf.px') === x - 1 || K.$('bf.px') === x,
     'that is what the delay is for');
})();
ok('soft drop still rewards you for it',
   /bf\.py\+\+; bf\.tick=0; bf\.score\+\+;/.test(
     require('fs').readFileSync(__dirname + '/../game.js', 'utf8')),
   'a point a row, so dropping fast is worth doing');


// ── the small closed loop ─────────────────────────────────────────────────
// A gold in the machine, a handful back on a decent run, and three or four of
// those buys the cheapest seat at Robby's table. The cave pays for itself and
// nothing else — the armour still costs ten thousand and always will.
K.$('gold=0; place={kind:"interior", id:"robbycave", floor:0};');
K.$('openBlockfall();');
ok('with no gold the machine refuses', K.$('place.kind') === 'interior',
   'and Robby says so rather than nothing happening');
K.$('gold=10; openBlockfall();');
ok('a coin starts it', K.$('place.kind') === 'blocks' && K.$('gold') === 9,
   `${K.$('gold')} left`);

// The whole point: can you actually grind a hand out of it?
K.$('gold=1;');
let runs = 0;
while (K.$('gold') < Math.min(...K.BJ_BETS) && runs < 40) {
  K.$('gold=gold-0;');
  if (K.$('gold') < K.BF_COST) break;
  K.$('gold=gold-' + K.BF_COST + ';');
  K.$('bf.score=900; bfPayout();');       // a decent run
  runs++;
}
ok('a handful of decent games buys a seat at the table',
   K.$('gold') >= Math.min(...K.BJ_BETS) && runs <= 6,
   `${runs} runs from 1 gold to ${K.$('gold')} (a hand costs ${Math.min(...K.BJ_BETS)})`);

ok('the end screen shows what the run cost as well as what it paid',
   /net '\+\(bf\.net>=0\?'\+':''\)\+bf\.net/.test(raw),
   'a payout with no mention of the coin reads as pure profit');
ok('and it says the price',
   /1 gold a game/.test(raw));

done('robby');

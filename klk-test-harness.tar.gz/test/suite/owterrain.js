// suite/owterrain.js — the open country between the towns (2026-10-01 terrain art pass).
//
// Zak: "Can we do a similar upgrade to the general map? So the terrain gets the same quality
// upgrade as the villages?" Drawing only: grass and meadows with broad soft tone, grounds that
// blend into one another along wandering edges, broadleaves and pines, the deep wood as one
// canopy (the crowns in the depth-sorted sprite layer, so the knight passes behind trees),
// rutted roads with grass verges, water shallow-to-deep with swell, glints and foam, sand wet at
// the shore, bog pools, ash cracks and cinders, snow drifts, butterflies, leaves and birds.
// Each tile's still layer is painted once into a small cached canvas.
// 2026-10-01-vs: the town's name-sign moved to its main entrance (see suite/vsigns.js). Only the sign
//   tiles changed, so the grid pins below were re-taken.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('owterrain');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── nothing on the map moved ──
// 35cf83d1: the world, its heights, props and buildings — identical in the build before this pass.
// e1c0069c (2026-10-01-hs): the same, plus the Homestead's six new yard props (well, skeps, woodpile,
//   hen-house) on what were flower tiles — checked equal to the old world with exactly those six added.
// 359bcbd7 (2026-10-07-ty): the same, plus Stormgate's Tilting Yard — 229 tiles, all inside x 151-183, y 191-198
//   (fence, sand, two wall gates at height 1, the sign), 49 props, the arena sign reworded; nothing else moved.
check('the map, heights, props and buildings are exactly as before', K.$(`(${fnv})(WORLD.map(r=>r.join(',')).join('|')+'#'+Object.keys(ELEV).sort().map(k=>k+':'+ELEV[k]).join(',')+'#'+decorations.map(d=>d.kind+d.x+','+d.y).join(';')+'#'+buildings.map(b=>b.id+b.x+','+b.y).join(';'))`), '359bcbd7');

// ── the open country draws the main grounds ──
const kinds = { grass:[0,110,105], flowers:[4,null,null], forest:[7,null,null], tree:[1,62,112], road:[2,110,100], water:[3,120,245], sand:[19,100,60], bog:[28,200,150], ash:[25,186,150] };
const findTile = (t) => K.$(`(()=>{ for(let y=0;y<WORLD_H;y++) for(let x=0;x<WORLD_W;x++) if(WORLD[y][x]===${t} && !_owOwned(x,y) && !_owDesert(x,y) && !_owAshland(x,y)) return [x,y]; return null; })()`);
for (const [name, [t]] of Object.entries(kinds)) {
  const at = findTile(t);
  ok(`${name} (${t}) is drawn by the open-country art at ${at}`, at && K.$(`drawOverworldTile(${t},0,0,${at[0]},${at[1]})===true`));
}
ok('snow outside Crystalpeak is drawn too, if any', (() => { const at = findTile(22); return !at || K.$(`drawOverworldTile(22,0,0,${at[0]},${at[1]})===true`); })());
ok('the desert keeps its cacti and the ash country its snags', K.$(`drawOverworldTile(1,0,0,90,60)===false && drawOverworldTile(1,0,0,150,140)===false`));
ok('tiles it does not know fall through to the engine', K.$(`drawOverworldTile(32,0,0,100,100)===false && drawOverworldTile(33,0,0,100,100)===false && drawOverworldTile(20,0,0,100,100)===false`));

// ── the towns keep their own art, and their edges stay seamless ──
check('every town and isle box is owned by its own art', K.$(`[[33,22],[31,63],[33,210],[91,157],[92,69],[153,68],[158,150],[168,213],[217,147],[225,19]].map(([x,y])=>_owOwned(x,y))`), [true,true,true,true,true,true,true,true,true,true]);
check('the broad tone is nothing at a town\'s edge and builds over four tiles', K.$(`[_owFadeAt(15,20), _owFadeAt(14,20), _owFadeAt(13,20), _owFadeAt(10,20), _owFadeAt(110,105)]`), [0, 0, 0.25, 1, 1]);
check('each ground keeps its base colour (the towns match it)', K.$(`[OWK.grass, OWK.forest, OWK.sand, OWK.bog, OWK.ash, OWK.snow, OWK.road]`), ['#5fa860', '#3f8a4e', '#e8d6a0', '#3a4038', '#6a6258', '#f0f6fa', '#bd9a5e']);
check('trees inside a town or isle are left to its own art (some exist, and none gets a crown)', K.$(`(()=>{ let own=0, bad=0; for(let y=0;y<WORLD_H;y++) for(let x=0;x<WORLD_W;x++){ if(WORLD[y][x]!==1) continue; const o=_owOwned(x,y); if(o) own++; if(o!==_owOwnedC(x,y)) bad++; } return [own>0, bad]; })()`), [true, 0]);

// ── grounds blend; water has depth ──
check('where grass meets the bog, cells of each cross the line', K.$(`(()=>{ for(let y=136;y<160;y++) for(let x=180;x<205;x++){ if(WORLD[y][x]===0 && WORLD[y][x+1]===28){ const c=_owBlendCells(x,y,'g'), d=_owBlendCells(x+1,y,'b'); return [!!c && c.some(f=>f==='b'), !!d && d.some(f=>f==='g')]; } } return null; })()`), [true, true]);
check('the sea is shallow at the shore and deep offshore', K.$(`[_owDepthAt(120,239), _owDepthAt(120,246)]`), [1, 4]);
ok('a lone tile of grass in the middle of a meadow needs no blending', K.$(`(()=>{ for(let y=95;y<115;y++) for(let x=100;x<125;x++){ let all=true; for(let b=-1;b<=1;b++) for(let a=-1;a<=1;a++) if(WORLD[y+b][x+a]!==0) all=false; if(all) return _owBlendCells(x,y,'g')===null; } return false; })()`));

// ── the crowns: in the sprite layer, sorted with the knight ──
const crowns = K.$(`(()=>{ const o=[]; overworldObjs(o, (62-8)*TILE, (112-12)*TILE); const trees=o.filter(q=>q.sy<1e5); return [trees.length, trees.every(q=>Number.isInteger(q.sy))]; })()`);
ok(`over the deep wood the crowns go into the sprite layer (${crowns[0]})`, crowns[0] >= 150 && crowns[1]);
check('a tree north of the knight is drawn before him; one south of him, after', K.$(`(()=>{ const pY=112; const o=[]; overworldObjs(o,(62-8)*TILE,(112-12)*TILE); const s=o.filter(q=>q.sy<1e5).map(q=>q.sy); return [s.some(v=>v<pY+1), s.some(v=>v>pY+1)]; })()`), [true, true]);

// ── the cache ──
check('a still tile is painted once and reused', K.$(`(()=>{ _owTiles.clear(); let n=0; const A=_owGrass; _owGrass=function(){ n++; return A.apply(null,arguments); };
  try{ for(let i=0;i<5;i++) drawOverworldTile(0,0,0,110,105); } finally{ _owGrass=A; } return n; })()`), 1);
check('and painted again when the map round it changes', K.$(`(()=>{ let n=0; const A=_owGrass; _owGrass=function(){ n++; return A.apply(null,arguments); }; const was=WORLD[105][111];
  try{ drawOverworldTile(0,0,0,110,105); WORLD[105][111]=19; drawOverworldTile(0,0,0,110,105); } finally{ WORLD[105][111]=was; _owGrass=A; } return n; })()`), 1);

// ── the dive spots still show ──
check('a dive marker is still drawn on its water tile', K.$(`(()=>{ if(typeof uwMarkerAt!=='function') return 'none'; for(let y=0;y<WORLD_H;y++) for(let x=0;x<WORLD_W;x++) if(WORLD[y][x]===3 && uwMarkerAt(x,y)){ let n=0; const A=uwDrawDiveMarker; uwDrawDiveMarker=function(){ n++; return A.apply(null,arguments); }; try{ drawOverworldTile(3,0,0,x,y); } finally{ uwDrawDiveMarker=A; } return n; } return 'none'; })()`), 1);

// ── a real frame, here and there ──
for (const [x, y] of [[62, 112], [110, 105], [120, 238], [198, 142], [224, 42]])
  check(`a frame of the real loop at ${x},${y}`, K.$(`(()=>{ place={kind:'overworld'}; player.x=${x}*TILE; player.y=${y}*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } return r; })()`), 'ok');

done('owterrain');

// suite/petlooks.js — the Pet Stylist's Looks tab.
//
// Zak (2026-09-30): "add a tab where there are a large variety of
// customizations for pet appearances". Approved mockup: coats, patterns,
// head/neck/back accessories and effects, bought with gold, worn by every
// form (steeds too). Owned looks are account-wide; each companion wears its
// own. Pixels are read back from real bakes, not inferred from the code.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('petlooks');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; place={kind:'overworld'};
     player.x=32*TILE; player.y=24*TILE; player.petX=player.x+TILE; player.petY=player.y;`);
const FORMS = [['faithful',0],['faithful',1],['faithful',2],['grace',0],['grace',1],['grace',2],
               ['steadfast',0],['steadfast',1],['steadfast',2],['unicorn',2]];
const px = (expr) => K.$(`(()=>{ const c=${expr}; return Array.from(c.getContext('2d').getImageData(0,0,48,48).data); })()`);
const rgbSet = (a) => { const s=new Set(); for(let i=0;i<a.length;i+=4) if(a[i+3]>=250) s.add((a[i]<<16)|(a[i+1]<<8)|a[i+2]); return s; };
const hex = (h) => parseInt(h.slice(1),16);

// ── the catalogue ──
check('ten coats, five patterns, nine accessories, seven effects',
  K.$(`[PET_LOOKS.coat.length, PET_LOOKS.pattern.length, PET_LOOKS.acc.length, PET_LOOKS.fx.length]`), [10,5,9,7]);
ok('every item has a positive gold price', K.$(`[...PET_LOOKS.coat,...PET_LOOKS.pattern,...PET_LOOKS.acc,...PET_LOOKS.fx].every(i=>i.price>0)`));
ok('ids are unique across the shop', K.$(`(()=>{ const a=[...PET_LOOKS.coat,...PET_LOOKS.pattern,...PET_LOOKS.acc,...PET_LOOKS.fx].map(i=>i.id); return new Set(a).size===a.length; })()`));
ok('every accessory has art and a head/neck/back slot', K.$(`PET_LOOKS.acc.every(a=>PET_ACC_ART[a.id] && ['head','neck','back'].includes(a.slot))`));

// ── every form: a coat is found, and the coat really recolours ──
for (const [id, fm] of FORMS) {
  const n = K.$(`petCoatColors('${id}',${fm}).cols.length`);
  const base = px(`petLookBake('${id}',${fm},1,true,'profile',false,{})`);
  const gold = px(`petLookBake('${id}',${fm},1,true,'profile',false,{coat:'golden'})`);
  let changed = 0; for (let i = 0; i < base.length; i += 4) if (base[i+3] >= 250 && (base[i]!==gold[i]||base[i+1]!==gold[i+1]||base[i+2]!==gold[i+2])) changed++;
  ok(`${id}${fm}: coat found and recoloured`, n > 0 && changed > 20, `${n} coat colours, ${changed} px changed`);
}
check('a bare look bakes the form exactly as the game draws it',
  K.$(`(()=>{ const a=petLookBake('faithful',1,1,true,'profile',false,{}).getContext('2d').getImageData(0,0,48,48).data;
               const s=petSprite('faithful1',1,true); const c=document.createElement('canvas'); c.width=48; c.height=48; c.getContext('2d').drawImage(s,0,0,48,48);
               const b=c.getContext('2d').getImageData(0,0,48,48).data; for(let i=0;i<a.length;i++) if(a[i]!==b[i]) return i; return -1; })()`), -1);
ok('the white dove is found white, not by its dark outline',
  K.$(`petCoatColors('grace',0).cols.includes('#eef1f6')`));

// ── accessories land on the head, and follow the facing ──
const headY = (look, right) => K.$(`(()=>{ const d=petLookBake('faithful',2,1,${right},'profile',false,${JSON.stringify(look)}).getContext('2d').getImageData(0,0,48,48).data;
  for(let p=0;p<48*48;p++){ const i=p*4; if(d[i+3]>=250 && d[i]===0xf2 && d[i+1]===0xc1 && d[i+2]===0x4e) return [p%48, (p/48)|0]; } return null; })()`);
const cr = headY({ head: 'crown' }, true), cl = headY({ head: 'crown' }, false);
ok('the crown is drawn (facing right)', !!cr, JSON.stringify(cr));
ok('  on the front of the lion, not its back', cr && cr[0] > 24, JSON.stringify(cr));
ok('  and swaps sides when the lion faces left', cl && cl[0] < 24, JSON.stringify(cl));
ok('a turtle wears its hat on its head, not its shell',
  K.$(`(()=>{ const d=petLookBake('steadfast',0,1,true,'profile',false,{head:'crown'}).getContext('2d').getImageData(0,0,48,48).data;
       let mx=-1; for(let p=0;p<48*48;p++){ const i=p*4; if(d[i]===0xf2&&d[i+1]===0xc1&&d[i+2]===0x4e&&d[i+3]>=250) mx=Math.max(mx,p%48); } return mx>=40; })()`));

// ── the ridden steed: the knight keeps his colours ──
for (const dir of ['right', 'up', 'down']) {
  const view = dir === 'right' ? 'profile' : (dir === 'up' ? 'back' : 'front');
  const s = rgbSet(px(`petLookBake('faithful',2,1,${dir==='right'},'${view}',true,{coat:'midnight'})`));
  ok(`ridden (${view}): the knight's tunic is untouched by the coat`, s.has(hex('#3b6fd4')) || s.has(hex('#5a8ae8')) || s.has(hex('#2a52aa')), s.size + ' colours');
}
ok('ridden: the steed itself does take the coat',
  rgbSet(px(`petLookBake('unicorn',2,1,true,'profile',true,{coat:'ember'})`)).size !==
  rgbSet(px(`petLookBake('unicorn',2,1,true,'profile',true,{})`)).size ||
  K.$(`(()=>{ const a=petLookBake('unicorn',2,1,true,'profile',true,{coat:'ember'}).getContext('2d').getImageData(0,0,48,48).data, b=petLookBake('unicorn',2,1,true,'profile',true,{}).getContext('2d').getImageData(0,0,48,48).data; for(let i=0;i<a.length;i++) if(a[i]!==b[i]) return true; return false; })()`));

// ── drawing in the world: every form, every effect, following and ridden ──
const draws = K.$(`(()=>{ const bad=[];
  for(const [id,fm] of ${JSON.stringify(FORMS)}){ for(const fx of [null,...PET_LOOKS.fx.map(f=>f.id)]){
    player.pet={id,form:fm,look:{coat:'royal',pattern:'stars',head:'laurel',neck:'bell',back:'cape',fx}};
    try{ drawPet(player.x+TILE, player.y);
         if(PETS[id].forms[fm].ability) for(const d of ['left','right','up','down']) drawSteedMounted(player.x,player.y,id,d,1); }
    catch(e){ bad.push(id+fm+':'+fx+':'+e.message); } } }
  return bad; })()`);
check('every form draws every effect, following and ridden, without error', draws, []);
ok('the steed’s ground shadow still lands on the screen, not the bake',
  K.$(`(()=>{ player.pet={id:'unicorn',form:2,look:{coat:'snow'}}; let n=0; const e=ctx.ellipse; ctx.ellipse=function(){ n++; return e.apply(this,arguments); };
       try{ drawPet(player.x+TILE,player.y); } finally{ ctx.ellipse=e; } return n; })()`) > 0);
check('no look: the old drawing path is used untouched', K.$(`(player.pet={id:'faithful',form:1}, petLookActive())`), false);
K.$(`player.pet={id:'faithful',form:2,ribbon:''};`);
check('one frame of the real loop with a dressed lion', K.$(`(player.pet.look={coat:'golden',head:'crown',fx:'glow'}, (()=>{ try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })())`), 'ok');

// ── the stylist ──
K.$(`player.pet={id:'faithful',form:2,ribbon:''}; player.petLooksOwned={}; gold=1000; openStylist();`);
check('the stylist opens on Ribbons', K.$(`styl.tab||'ribbons'`), 'ribbons');
ok('  with a Looks tab beside it', K.$(`gmEl().innerHTML.includes('data-stab="looks"')`));
ok('  and the ribbons still listed', K.$(`gmEl().innerHTML.includes('data-ribbon="1"')`));
// a tap, sent through the game's own overlay click handler: the target answers
// closest('[data-x]') with a row carrying that dataset, as the real DOM would
K.$(`globalThis.__tap=(ds)=>{ const row={dataset:ds}; const tgt={ closest:(sel)=>{ const m=/^\\[data-([a-z]+)\\]$/.exec(sel); return m && (m[1] in ds) ? row : null; } };
  document.getElementById('gamemenu').dispatchEvent({type:'click', target:tgt, preventDefault(){}, stopPropagation(){}}); };`);
K.$(`__tap({stab:'looks'})`);
check('the Looks tab is showing', K.$(`styl.tab`), 'looks');
ok('  with the live preview canvas', K.$(`gmEl().innerHTML.includes('id="plPrev"')`));
ok('  and all 31 items', K.$(`(gmEl().innerHTML.match(/data-plid=/g)||[]).length`) === 31);
ok('  the preview animates while open', K.$(`_plTimer!==null`));

// try on: nothing bought, nothing worn
K.$(`__tap({plslot:'coat', plid:'golden'})`);
check('tapping an item tries it on', K.$(`styl.tryOn`), { slot: 'coat', id: 'golden' });
check('  the preview shows it', K.$(`petLookShown().coat`), 'golden');
check('  but the pet is not wearing it yet', K.$(`petLookWorn().coat||null`), null);
check('  and no gold has moved', K.$(`gold`), 1000);
ok('  a Buy button is offered', K.$(`gmEl().innerHTML.includes('data-plbuy')`));
K.$(`petLookTap('coat','golden');`);
check('tapping it again puts it back', K.$(`styl.tryOn`), null);

// buy
K.$(`__tap({plslot:'coat', plid:'golden'}); __tap({plbuy:'1'})`);
check('buying takes the price', K.$(`gold`), 700);
check('  owns it', K.$(`petLookOwned('golden')`), true);
check('  and puts it on', K.$(`petLookWorn().coat`), 'golden');
check('  and the try-on is done', K.$(`styl.tryOn`), null);

// too dear
K.$(`petLookTap('fx','glow'); petLookBuy();`);
check('too dear: no gold taken', K.$(`gold`), 700);
check('  not owned', K.$(`petLookOwned('glow')`), false);
check('  not worn', K.$(`petLookWorn().fx||null`), null);
ok('  and the button says Need', K.$(`gmEl().innerHTML.includes('Need')`));
K.$(`styl.tryOn=null;`);

// owned: tap to wear / take off
K.$(`petLookTap('coat','golden');`);
check('tapping a worn look takes it off', K.$(`petLookWorn().coat||null`), null);
K.$(`petLookTap('coat','golden');`);
check('tapping it again wears it (free)', [K.$(`petLookWorn().coat`), K.$(`gold`)], ['golden', 700]);

// one per slot; head/neck/back are separate slots
K.$(`gold=5000; for(const [s,i] of [['head','crown'],['neck','scarf'],['back','cape'],['pattern','spots'],['fx','hearts']]){ petLookTap(s,i); petLookBuy(); }`);
check('one of each slot worn at once', K.$(`petLookWorn()`), { coat:'golden', head:'crown', neck:'scarf', back:'cape', pattern:'spots', fx:'hearts' });
K.$(`petLookTap('head','laurel'); petLookBuy();`);
check('a second hat replaces the first', K.$(`petLookWorn().head`), 'laurel');
check('  the first is still owned', K.$(`petLookOwned('crown')`), true);

// another companion: owned looks are shared, outfits are not
K.$(`player.barnPets=[{id:'grace',form:2}]; barnSwap(0);`);
check('a companion from the stables arrives in its own (plain) outfit', K.$(`petLookActive()`), false);
K.$(`petLookTap('coat','golden');`);
check('  but can wear what was already bought, for free', [K.$(`petLookWorn().coat`), K.$(`gold`)], ['golden', K.$(`gold`)]);
K.$(`barnSwap(0);`);
check('the lion comes back still dressed', K.$(`petLookWorn().head`), 'laurel');

// ribbons are untouched
K.$(`styl.tab='ribbons'; renderStylist();`);
check('back on Ribbons the preview stops', K.$(`_plTimer`), null);
K.$(`player.pet.ribbon=RIBBONS[2];`);
check('ribbons still work alongside looks', [K.$(`player.pet.ribbon`), K.$(`petLookWorn().coat`)], ['⭐', 'golden']);
K.$(`styl.tab='looks'; renderStylist(); closeStylist();`);
check('closing the stylist stops the preview', K.$(`_plTimer`), null);

// ── save / load ──
const rt = K.$(`(()=>{ const s=JSON.parse(JSON.stringify(buildSaveData())); player.petLooksOwned={}; player.pet=null; applySaveData(s);
  return [Object.keys(player.petLooksOwned).sort(), player.pet.look, player.barnPets[0].look||null]; })()`);
check('save → load keeps what you own', rt[0], ['cape','crown','golden','hearts','laurel','scarf','spots']);
check('  and what the lion wears', rt[1], { coat:'golden', head:'laurel', neck:'scarf', back:'cape', pattern:'spots', fx:'hearts' });
check('  and what the dove in the stables wears', rt[2], { coat:'golden' });
const old = K.$(`(()=>{ const s=JSON.parse(JSON.stringify(buildSaveData())); delete s.player.petLooksOwned; delete s.player.pet.look; applySaveData(s);
  return [player.petLooksOwned, petLookActive()]; })()`);
check('an old save (no looks) loads with none owned and none worn', old, [{}, false]);

// ── the cache can't grow without bound ──
K.$(`for(let i=0;i<500;i++) petLookBake('faithful',2,i&1,true,'profile',false,{coat:PET_LOOKS.coat[i%10].id, pattern:PET_LOOKS.pattern[(i/10|0)%5].id, head:PET_LOOKS.acc[(i/50|0)%4].id});`);
ok('the bake cache stays bounded', K.$(`Object.keys(_PL_CACHE).length`) <= 400, K.$(`Object.keys(_PL_CACHE).length`) + ' entries');
done('petlooks');

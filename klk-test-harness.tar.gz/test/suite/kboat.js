// suite/kboat.js — the knight's own boat, a little royal cutter (2026-10-06, tag 2026-10-06-kb).
//
// Zak: "upgrade the Knight's Boat, maybe make it a slightly smaller version of the smaller boats in the
// capital's dock — so you can clearly see the upgrades and customizations made in the mini game on your
// real boat", then "40 is good!!". While he sails, the outermost drawKnight wrapper draws a 40-px side-on
// cutter from the five parts fitted at the boat-race dock (player.boatInv.equipped).
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('kboat');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false; player.boatInv=null;`);

// draw the knight at (60,60) on a clear canvas and return a hash, the box he covers, and the pixel count
const shot = (setup) => K.$(`(()=>{ const W=cv.width, H=cv.height;
  ctx.setTransform(1,0,0,1,0,0); ctx.globalAlpha=1; ctx.clearRect(0,0,W,H);
  ${setup}; drawKnight(60,60);
  const d=ctx.getImageData(0,0,160,140).data; let h=2166136261, n=0, x0=999,x1=-1,y0=999,y1=-1;
  for(let i=0;i<d.length;i+=4){ if(d[i+3]>0){ n++; const p=i/4, x=p%160, y=(p/160)|0; if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y; }
    h=Math.imul(h^d[i],16777619)^d[i+1]; h=Math.imul(h,16777619)^d[i+2]; h=Math.imul(h,16777619)^d[i+3]; }
  ctx.clearRect(0,0,W,H); return { h:h>>>0, n, box:[x0,y0,x1,y1] }; })()`);
const still = (s) => `const _pn=performance.now; performance.now=()=>4321; try{ ${s} }finally{ performance.now=_pn; }`;
const eqSet = (eq, dir) => `player.boating=true; player.moving=false; player.dir='${dir||'right'}'; player._boatFace=undefined; player.boatInv={ owned:[], equipped:${JSON.stringify(eq)} };`;
const STARTER = { hull:'hull_oak', sail:'sail_plain', figure:'fig_none', engine:'eng_oar', keel:'keel_flat' };
const pic = (eq, dir) => shot(still(eqSet(eq, dir)));

// ── the wrapper ──
ok('the boat wrapper is the outermost drawKnight, and draws the cutter while he sails', K.$(`(()=>{ let called=0; const f=drawKnightBoat; drawKnightBoat=function(){ called++; return f.apply(this,arguments); };
  player.boating=true; drawKnight(60,60); player.boating=false; drawKnight(60,60); drawKnightBoat=f; return called===1; })()`));
const a = pic(STARTER);
ok('the starter boat is about 40 px long (the cutters are 64; the old strip was 20)', a.box[2]-a.box[0] >= 40 && a.box[2]-a.box[0] <= 50, `box ${JSON.stringify(a.box)}`);
ok('her mast stands well above him (a real rig, not a strip)', 60 - a.box[1] >= 18, `top ${a.box[1]}`);
ok('on foot he is drawn exactly as before (the wrapper hands straight on)', K.$(`(()=>{ player.boating=false; player.dir='down';
  const W=cv.width,H=cv.height; ctx.clearRect(0,0,W,H); drawKnight(60,60); const p=ctx.getImageData(0,0,160,140).data.join(',');
  ctx.clearRect(0,0,W,H); _kbRawKnight(60,60); const q=ctx.getImageData(0,0,160,140).data.join(','); ctx.clearRect(0,0,W,H); return p===q; })()`));
ok('the boat is not put through the character outline (like the harbour ships; no 60×60 clip, no cache churn)', K.$(`(()=>{ const m=_SPR.misses, h=_SPR.hits; player.boating=true; drawKnight(60,60); drawKnight(61,60); player.boating=false; return _SPR.misses===m && _SPR.hits===h; })()`));

// ── every part you can fit shows on the real boat ──
const CAT = K.$(`BOAT_CATALOG.map(c=>[c.slot,c.id])`);
const SLOTS = ['hull','sail','figure','engine','keel'];
for (const slot of SLOTS) {
  const ids = CAT.filter(c => c[0] === slot).map(c => c[1]);
  const hs = ids.map(id => pic(Object.assign({}, STARTER, { [slot]: id })).h);
  check(`every ${slot} in the catalog looks different on the boat`, new Set(hs).size, ids.length);
}
ok('the hull is painted in its own colour (Crimson Reaver)', K.$(`(()=>{ ${still(eqSet(Object.assign({}, STARTER, { hull:'hull_crimson' })))}; ctx.clearRect(0,0,cv.width,cv.height);
  drawKnight(60,60); const d=ctx.getImageData(0,0,160,140).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0x7a&&d[i+1]===0x1f&&d[i+2]===0x1f) n++; ctx.clearRect(0,0,cv.width,cv.height); return n>=80; })()`));
ok('the Crusader Cross shows its red cross on the sail', K.$(`(()=>{ ${still(eqSet(Object.assign({}, STARTER, { sail:'sail_cross' })))}; ctx.clearRect(0,0,cv.width,cv.height);
  drawKnight(60,60); const d=ctx.getImageData(0,0,160,140).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0xb0&&d[i+1]===0x30&&d[i+2]===0x28) n++; ctx.clearRect(0,0,cv.width,cv.height); return n>=12; })()`));
const full = { hull:'hull_crimson', sail:'sail_storm', figure:'fig_dove', engine:'eng_galley', keel:'keel_blade' };
ok('a fully fitted boat differs from the starter', pic(full).h !== a.h);

// ── facing ──
const R = pic(STARTER, 'right'), L = pic(STARTER, 'left');
ok('she faces the way he steers (left and right are different pictures)', R.h !== L.h);
check('and are the same size', [R.n, R.box[2]-R.box[0], R.box[3]-R.box[1]], [L.n, L.box[2]-L.box[0], L.box[3]-L.box[1]]);
check('the figurehead sits at the bow on whichever side she faces', K.$(`(()=>{ const gold=(dir)=>{ ${still(eqSet(Object.assign({}, STARTER, { figure:'fig_lion' }), 'right'))}; player.dir=dir; ctx.clearRect(0,0,cv.width,cv.height);
  drawKnight(60,60); const d=ctx.getImageData(0,0,160,140).data; let sx=0,n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0xe8&&d[i+1]===0xc2&&d[i+2]===0x5a){ sx+=(i/4)%160; n++; } ctx.clearRect(0,0,cv.width,cv.height); return n?Math.round(sx/n):-1; };
  const r=gold('right'), l=gold('left'); return [r>68, l<68]; })()`), [true, true]);
check('sailing north or south keeps the last side she faced', K.$(`(()=>{ player.boating=true; player._boatFace=undefined; player.dir='left'; kbFacing(); player.dir='up'; const a=kbFacing(); player.dir='down'; const b=kbFacing(); player.dir='right'; kbFacing(); player.dir='up'; const c=kbFacing(); return [a,b,c]; })()`), [-1, -1, 1]);

// ── whole pixels ──
check('every fill lands on whole pixels', K.$(`(()=>{ const fr=ctx.fillRect, bad=[]; ctx.fillRect=function(x,y,w,h){ if(x!==Math.round(x)||y!==Math.round(y)||w!==Math.round(w)||h!==Math.round(h)) bad.push([x,y,w,h]); return fr.apply(this,arguments); };
  try{ for(const e of ['eng_oar','eng_lateen','eng_double','eng_galley']) for(const d of ['left','right']) for(const m of [false,true]){ ${eqSet(full)} player.boatInv.equipped.engine=e; player.dir=d; player.moving=m; drawKnight(60,60); } }
  finally{ ctx.fillRect=fr; } ctx.clearRect(0,0,cv.width,cv.height); return bad.length; })()`), 0);

// ── no kit yet, or a part that no longer exists ──
ok('with nothing ever fitted (boatInv null) he sails the starter boat', K.$(`(()=>{ player.boatInv=null; return JSON.stringify(Object.values(kbParts()).map(p=>p.id)); })()`) === JSON.stringify(Object.values(STARTER)));
ok('an unknown part id falls back to the starter part', K.$(`(()=>{ player.boatInv={owned:[],equipped:{hull:'hull_gone', sail:'sail_gold'}}; const p=kbParts(); return p.hull.id==='hull_oak' && p.sail.id==='sail_gold' && p.keel.id==='keel_flat'; })()`));
ok('saves are unchanged (her facing is not a saved field)', K.$(`(()=>{ player._boatFace=-1; const s=JSON.parse(JSON.stringify(buildSaveData())); return !JSON.stringify(s).includes('_boatFace'); })()`));

// ── the real loop, the real keys ──
const sea = K.$(`(()=>{ for(let y=241;y<300;y++) for(let x=100;x<230;x++){ let all=true; for(let dy=-3;dy<=3&&all;dy++) for(let dx=-4;dx<=4;dx++){ const t=WORLD[y+dy]&&WORLD[y+dy][x+dx]; if(!SAIL_TILES.has(t)){ all=false; break; } } if(all) return [x,y]; } return null; })()`);
ok('there is open sea to test on', !!sea, JSON.stringify(sea));
K.$(`(()=>{ place={kind:'overworld'}; player.mounted=false; player.boating=true; player.x=${sea[0]}*TILE; player.y=${sea[1]}*TILE; player.dir='right'; player._boatFace=undefined;
  player.boatInv={owned:[],equipped:${JSON.stringify(full)}}; })()`);
let err = 'ok'; try { K.frames(30); } catch (e) { err = e.message; }
check('real frames run with a fully fitted boat at sea', err, 'ok');
const x0 = K.$(`player.x`);
err = 'ok'; try { K.key.down('ArrowLeft'); K.frames(20); K.key.up('ArrowLeft'); K.frames(2); } catch (e) { err = e.message; }
check('steering west with the real keys: she sails, and turns her bow west', [err, K.$(`player.x`) < x0, K.$(`player.boating`), K.$(`player._boatFace`)], ['ok', true, true, -1]);
err = 'ok'; try { K.key.down('ArrowUp'); K.frames(10); K.key.up('ArrowUp'); K.frames(2); } catch (e) { err = e.message; }
check('then north: she keeps facing west', [err, K.$(`player._boatFace`)], ['ok', -1]);
K.$(`player.boating=false; player.boatInv=null;`);

// ── the Saltmere pier: set out, sail round, and tie up there again (Zak: "the dock where the boat first spawns you cannot re dock there") ──
const B0 = K.$(`JSON.stringify(decorations.filter(d=>d.kind==='boat').map(d=>[d.x,d.y,d.w]))`);
check('the boat starts moored at the end of the Saltmere pier', B0, '[[17,220,2]]');
check('the pier above her is tile 12 (walkable, and a sail tile too)', K.$(`[WORLD[219][17], WALK.has(12), SAIL_TILES.has(12)]`), [12, true, true]);
K.$(`(()=>{ place={kind:'overworld'}; dialogue.open=false; menu.open=false; demons=[]; player.mounted=false; player.boating=false; player.boatInv=null;
  player.x=17*TILE; player.y=219*TILE; player.dir='down'; player._boatFace=undefined; })()`);
let e2='ok'; try { K.key.tap(' ', 3); } catch (e) { e2 = e.message; }
check('Ⓐ on the pier facing her: aboard', [e2, K.$(`player.boating`), K.$(`decorations.filter(d=>d.kind==='boat').length`)], ['ok', true, 0]);
try { K.key.down('ArrowDown'); K.frames(14); K.key.up('ArrowDown'); K.frames(2);
      K.key.down('ArrowUp'); K.frames(12); K.key.up('ArrowUp'); K.frames(2); } catch (e) { e2 = e.message; }
const at = K.$(`[Math.floor((player.x+TILE/2)/TILE), Math.floor((player.y+TILE/2)/TILE), player.dir]`);
ok('she sails out and comes back up under the pier, facing it', e2 === 'ok' && at[2] === 'up' && K.$(`WORLD[${at[1]-1}][${at[0]}]`) === 12, JSON.stringify(at));
try { K.key.tap(' ', 3); } catch (e) { e2 = e.message; }
check('Ⓐ facing the pier: he steps ashore onto it', [e2, K.$(`player.boating`), K.$(`WORLD[Math.floor((player.y+TILE/2)/TILE)][Math.floor((player.x+TILE/2)/TILE)]`)], ['ok', false, 12]);
check('and she waits on the water where he left her', K.$(`JSON.stringify(decorations.filter(d=>d.kind==='boat').map(d=>[d.x,d.y]))`), JSON.stringify([[at[0], at[1]]]));
try { K.key.down('ArrowDown'); K.frames(1); K.key.up('ArrowDown'); K.frames(1); K.key.tap(' ', 3); } catch (e) { e2 = e.message; }
check('turn round, Ⓐ again: aboard once more', [e2, K.$(`player.boating`)], ['ok', true]);
K.$(`(()=>{ for(let i=decorations.length-1;i>=0;i--) if(decorations[i].kind==='boat') decorations.splice(i,1); player.boating=true; player.x=20*TILE; player.y=216*TILE; player.dir='up'; })()`);
try { K.key.tap(' ', 3); } catch (e) { e2 = e.message; }
check('the open beach still docks as before (shallows → sand)', [e2, K.$(`WORLD[215][20]`), K.$(`player.boating`)], ['ok', 19, false]);
K.$(`player.boating=false;`);

// ── moored, she looks the same as she sails (Zak: "lets have it stay visible in its normal form") ──
ok('the moored boat is drawn as your cutter (not the old rowing boats), in Saltmere and anywhere else', K.$(`(()=>{ let n=0; const f=drawMooredBoat; drawMooredBoat=function(){ n++; return f.apply(this,arguments); };
  place={kind:'overworld'}; drawDecor({x:17,y:220,kind:'boat',w:2},60,60); drawDecor({x:120,y:250,kind:'boat',w:1},60,60); drawMooredBoat=f; return n===2; })()`));
const moor = (eq, face) => K.$(`(()=>{ const _pn=performance.now; performance.now=()=>4321; try{ player.boatInv={owned:[],equipped:${JSON.stringify(eq)}}; ctx.setTransform(1,0,0,1,0,0); ctx.globalAlpha=1; ctx.clearRect(0,0,cv.width,cv.height);
  drawDecor({x:120,y:250,kind:'boat',w:1,face:${face}},60,60); const d=ctx.getImageData(0,0,160,140).data; let h=2166136261,n=0,x0=999,x1=-1,y0=999,y1=-1;
  for(let i=0;i<d.length;i+=4){ if(d[i+3]>0){ n++; const p=i/4,x=p%160,y=(p/160)|0; if(x<x0)x0=x; if(x>x1)x1=x; if(y<y0)y0=y; if(y>y1)y1=y; } h=Math.imul(h^d[i],16777619)^d[i+1]; h=Math.imul(h,16777619)^d[i+2]; }
  ctx.clearRect(0,0,cv.width,cv.height); return {h:h>>>0,n,box:[x0,y0,x1,y1]}; } finally{ performance.now=_pn; } })()`);
const m1 = moor(STARTER, 1), m2 = moor(full, 1), m3 = moor(full, -1);
ok('moored, she is the same 40-px cutter', m1.box[2]-m1.box[0] >= 40 && m1.box[2]-m1.box[0] <= 50, JSON.stringify(m1.box));
ok('moored, she shows your fitted parts', m1.h !== m2.h);
ok('moored, she faces the way you left her', m2.h !== m3.h);
ok('moored, nobody is aboard (no blue tunic)', K.$(`(()=>{ player.boatInv=null; ctx.clearRect(0,0,cv.width,cv.height); drawDecor({x:120,y:250,kind:'boat',w:1,face:1},60,60);
  const d=ctx.getImageData(0,0,160,140).data; let n=0; for(let i=0;i<d.length;i+=4) if(d[i]===0x3b&&d[i+1]===0x6f&&d[i+2]===0xd4) n++; ctx.clearRect(0,0,cv.width,cv.height); return n===0; })()`));
K.$(`player.boatInv=null;`);
done('kboat');

// suite/saltmere.js — Caleb's flooded counting-house.
//
// The sanctum is the LAST floor of a chapel: a knight who dies here has walked
// three floors to reach it. Terrain that can corner him turns a hard fight into
// an unfair one, so the geometry is asserted rather than eyeballed.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('saltmere');

const TP = K.TILE;
const g = K.genSaltmereArena();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);

// The fixed furniture must not move: ARENA_ENTRY and friends are DECLARED
// elsewhere and not scanned for, so a relocated general puts the knight in a wall.
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

globalThis.__g = g;
K.$('place={kind:"dungeon"}; dungeon.townId=2; dungeon.grid=globalThis.__g; DH=dungeon.grid.length; DW=dungeon.grid[0].length;');

let wet = 0, stone = 0;
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (g[y][x] === K.T_SHALLOW) wet++;
  if (g[y][x] === K.T_LEDGER) stone++;
}
ok('the arena has both water and stone', wet > 10 && stone > 10, `${wet} water, ${stone} stone`);
ok('shallow water is WALKABLE — it is a cost, not a wall',
   K.walkable(1, 1) && g[1][1] === K.T_SHALLOW);
ok('counting-stones are walkable', K.walkable(2, 3) && g[3][2] === K.T_LEDGER);

function flood() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}
let open0 = 0, reach0 = 0;
const seen0 = flood();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { open0++; if (seen0.has(y * 100 + x)) reach0++; }
}
ok('the whole arena is reachable at the start', open0 === reach0, `${reach0}/${open0}`);

// ── the sink order is the doctrine ─────────────────────────────────────────
// "It took the ones he had stopped counting first" — the outermost stones go
// under first, and the centre never does.
const ledgers = K.dungeon._ledgers;
check('nine counting-stones', ledgers.length, 9);
const ranks = ledgers.map(s => s.rank);
ok('the outermost stones go under first',
   ranks.every((r, i) => i === 0 || ranks[i - 1] >= r), `by distance: ${ranks.join(', ')}`);
ok('the centre stone is last and never sinks', ranks[ranks.length - 1] === 0);

// ── the wading asymmetry ───────────────────────────────────────────────────
ok('the knight is slowed by the flood and his dodge shortened',
   K.WADE_SPEED < 1 && K.WADE_DODGE < 1, `speed x${K.WADE_SPEED}, dodge x${K.WADE_DODGE}`);
ok('the Tide Specter has the INVERSE — faster in water, slower on stone',
   K.TIDE_IN_WATER > 1 && K.TIDE_ON_STONE < 1,
   `water x${K.TIDE_IN_WATER}, stone x${K.TIDE_ON_STONE}`);

// ── the flood rises as the guardian loses ──────────────────────────────────
function freshArena() {
  const gg = K.genSaltmereArena();
  globalThis.__g2 = gg;
  K.$('place={kind:"dungeon"}; dungeon.townId=2; dungeon.grid=globalThis.__g2; DH=dungeon.grid.length; DW=dungeon.grid[0].length; dungeon._tideT0=undefined;');
  return gg;
}
const stonesLeft = gg => { let n = 0; for (const r of gg) for (const t of r) if (t === K.T_LEDGER) n++; return n; };

const gg = freshArena();
const full = stonesLeft(gg);
const boss = { hp: 100, maxHp: 100 };
globalThis.__boss = boss;
K.$('sinkLedgers(globalThis.__boss);');
ok('nothing sinks while the guardian is unhurt', stonesLeft(gg) === full, `${stonesLeft(gg)}/${full}`);

boss.hp = 50; K.$('sinkLedgers(globalThis.__boss);');
const half = stonesLeft(gg);
ok('the board shrinks by the halfway point', half < full, `${half}/${full} at half health`);

boss.hp = 1; K.$('sinkLedgers(globalThis.__boss);');
const nearDead = stonesLeft(gg);
ok('the fight ends on the last stones', nearDead < half, `${nearDead}/${full}`);
ok('dry ground survives even at zero health', nearDead > 0,
   'the centre is never sinkable — the fight can be lost, not drowned');

// The slow-close backstop: a cautious player who never lands a blow must still
// see the board shrink, or the mechanic simply does not happen to them.
const g3 = freshArena();
globalThis.__boss = { hp: 100, maxHp: 100 };
K.$('dungeon._tideT0 = performance.now() - 200000;');
K.$('sinkLedgers(globalThis.__boss);');
ok('the flood rises even against an untouched guardian', stonesLeft(g3) < full,
   `${stonesLeft(g3)}/${full} past the grace window at full health`);

// ── nothing stranded once it has all gone under ────────────────────────────
const g4 = freshArena();
for (const s of K.dungeon._ledgers.slice(0, -1)) for (const [x, y] of s.cells) g4[y][x] = K.T_SHALLOW;
const seenEnd = flood();
let openEnd = 0, reachEnd = 0;
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { openEnd++; if (seenEnd.has(y * 100 + x)) reachEnd++; }
}
ok('nothing is stranded once the flood has risen', openEnd === reachEnd, `${reachEnd}/${openEnd}`);

// ── the wave ───────────────────────────────────────────────────────────────
const src = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');
ok('the wave breaks against a counting-stone',
   /onStone\s*=\s*d\.wave\s*&&\s*tileAt\([^)]*\)===T_LEDGER/.test(src),
   'standing on a stone costs nothing; the channels cost double');
ok('an ordinary slam has no such exception', /d\.wave\?1\.6:1/.test(src));

const kinds = new Set((K.BOSS_PATTERNS[2].moves || []).map(m => m.kind));
ok('the Tide Specter actually has the wave', kinds.has('wave'));
const untipped = [...kinds].filter(k => !K.MOVE_TIPS[k]);
ok('every move it has is described on the library shelf',
   untipped.length === 0, untipped.join(', ') || [...kinds].join(', '));

done('saltmere');

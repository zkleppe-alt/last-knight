// suite/twvillage.js — Thornwood, the village in the roots (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout" and "give each its own strong identity".
// Thornwood became moss, bark and lantern-light: a forest floor, loam paths with
// roots, a wattle fence, the Woodcutter's log cabin, the Hollow Log Inn, the
// Hunter's Lodge, the Forester's root hut, a stave chapel (thorns while bound,
// white roses once cleansed), the Great Tree with lantern strings, a campfire,
// fireflies and falling leaves. DRAWING ONLY: same fence, paths, doors, props,
// villagers and signs.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('twvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the layout is untouched ──
// 8ad99967 is the FNV-1a of the town's tiles (its box plus a one-tile margin) in the
// build BEFORE the revamp (tag 2026-10-01-sm).
check('the town grid is exactly the grid it was', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Thornwood; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '8ad99967');
check('the five buildings and their doors are where they were', K.$(`buildings.filter(b=>twAt(b.x,b.y)).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["tw_chapel",87,147,6,6,89,152],["tw_shop",80,149,5,4,82,152],["tw_inn",99,149,5,4,101,152],["tw_home1",80,162,5,4,82,165],["tw_home2",100,162,4,3,101,164]]);
check('the green\'s props are where they were', K.$(`decorations.filter(d=>twAt(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["greatTree",91,157,3],["logpile",87,155,1],["logpile",96,159,1],["campfire",95,155,1],["stump",86,160,1],["stump",97,153,1],["mushroom",103,157,1],["mushroom",80,157,1]]);
check('four villagers still work the green', K.$(`villagers.filter(v=>twAt(v.hx,v.hy)).length`), 4);
check('both signs are still up', K.$(`['79,158','87,169'].map(k=>!!signs[k])`), [true, true]);
ok('Thornwood does not overlap the other revamped towns', K.$(`!buildings.some(b=>twAt(b.x,b.y)&&(hvAt(b.x,b.y)||ihAt(b.x,b.y)||smAt(b.x,b.y)))`));

// ── seams: the forest floor matches the wild forest outside, roads leave the box untouched ──
ok('the town\'s forest floor starts from the overworld forest colour (no seam at the box edge)', K.$(`TW.moss==='#3f8a4e'`));
check('the road outside the box keeps the overworld road art', K.$(`[drawThornwoodTile(2,0,0,92,145), drawThornwoodTile(2,0,0,92,169)]`), [false, false]);
ok('the road inside the box is the loam path', K.$(`drawThornwoodTile(2,0,0,92,154)===true`));
ok('paths run under the Great Tree and props without mossy seams', K.$(`(()=>{ let edges=0; const A=px; px=function(x,y,w,h,c){ if(c===TW.mossD) edges++; return A(x,y,w,h,c); };
  try{ _twPath(0,0,90,157); } finally{ px=A; } return edges===0; })()`));

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ for(let i=0;i<3;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[3]=true; else delete chapelProgress[3];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawThornwoodBuilding, B=drawThornwoodDecor, C=drawThornwoodTile, D=thornwoodObjs;
  drawThornwoodBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawThornwoodDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawThornwoodTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  thornwoodObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=44; VIEW_TH=32; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=92*TILE; player.y=161*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawThornwoodBuilding=A; drawThornwoodDecor=B; drawThornwoodTile=C; thornwoodObjs=D;
    for(let i=0;i<4;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole village draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and eight props wear Thornwood's art`, [r.n.b, r.n.d], [5, 8]);
  ok(`${clean ? 'cleansed' : 'bound'}: the forest floor, paths and fence have Thornwood's art (got ${r.n.t})`, r.n.t >= 730);
  check(`${clean ? 'cleansed' : 'bound'}: the canopy layer (light, lantern strings, fireflies, leaves)`, r.n.o, 1);
}
ok('the lantern strings hang from the Great Tree to the Woodcutter\'s and the inn', K.$(`TW_STRINGS.length===2 && TW_STRINGS.every(([[a,b]])=>Math.abs(a-92.5)<2.5 && Math.abs(b-155)<1.5)`));

// the chapel reads its own state (chapelProgress[3]): thorns while bound, roses once cleansed
const front = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[3]=true; else delete chapelProgress[3];
  const b=buildings.find(b=>b.id==='tw_chapel'); const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ drawThornwoodBuilding(b,40,60); } finally{ px=A; delete chapelProgress[3]; } return [seen.has('#6a3a5a'), seen.has('#ffffff')]; })()`);
check('bound: the chapel is strangled by thorns, no roses', front(false), [true, false]);
check('cleansed: the thorns are gone and white roses bloom', front(true), [false, true]);

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawThornwoodDecor({kind:'stump',x:86,y:160,w:1,hs:true},0,0)===false`));
ok('the box is Thornwood only', K.$(`twAt(92,157) && !twAt(32,22) && !twAt(35,63) && !twAt(32,203)`));
check('a frame of the real loop on the green', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<3;i++) chapelProgress[i]=true; player.x=89*TILE; player.y=158*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<3;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('twvillage');

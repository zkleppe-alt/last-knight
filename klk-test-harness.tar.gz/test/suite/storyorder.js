// suite/storyorder.js — the text pass and the story in order (2026-10-08, tag 2026-10-08-tx).
//
// Zak: "Let's do the text pass! Make sure too — dialogue is consistent and certain dialogues don't open up too soon,
// like the king wanting you to save Madison before she's been taken type thing." His calls: the King's words change
// at the knighting; the pretender flees to Stormgate and takes her; the wedding verse is Ecclesiastes 4:12; the minor
// duplicate names are renamed.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('storyorder');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[];`);
const said = (code) => K.$(`(()=>{ const out=[]; const keep=sayAs; sayAs=function(n,l){ out.push([n,[].concat(l).join(' | ')]); }; try{ ${code} } finally { sayAs=keep; } return out; })()`);
const reset = `hunt.won=false; hunt.done=false; abaddon.won=false; homesteadGranted=false; bounties.pretenderUnlocked=false; bounties.pretenderDefeated=false; bounties.madisonTaken=false; bounties.madisonRescued=false; sunfallProgress.homecoming=false; for(let i=0;i<10;i++) chapelProgress[i]=false; wagon.unlocked=false;`;

// ── the text pass ──
check('every overlay font up to 13px follows the text scale', K.$(`(()=>{ const html=document.documentElement; return typeof applyTextSize==='function' && TEXT_SIZES.map(t=>t[0]).join(','); })()`), 'Small,Normal,Large');
ok('the System tab offers Text Size', K.$(`(()=>{ menu.tab=TAB.system; return menuRows().some(r=>r.kind==='sys'&&r.id==='text'); })()`));
check('Text Size steps Small → Normal → Large and round again', K.$(`(()=>{ _textPref=0; const a=[]; for(let i=0;i<3;i++){ stepTextSize(); a.push(TEXT_SIZES[_textPref][0]); } return a; })()`), ['Normal', 'Large', 'Small']);

// ── Abaddon stays beaten ──
check('once Abaddon has fallen, the throne hall is not fought again (and the hunt is not reset)', K.$(`(()=>{ ${reset} abaddon.won=true; hunt.won=true; hunt.done=true; place={kind:'overworld'}; const b=buildings.find(b=>b.id==='hg_keep'); for(let i=0;i<10;i++) chapelProgress[i]=true; enterAbaddon(b); return [place.kind, hunt.done, abaddon.active]; })()`), ['overworld', true, false]);
check('the pretender is still fought there while he holds it', K.$(`(()=>{ bounties.pretenderUnlocked=true; bounties.pretenderDefeated=false; const b=buildings.find(b=>b.id==='hg_keep'); enterAbaddon(b); const r=[place.kind, abaddon.who, abaddon.won]; abaddon.active=false; place={kind:'overworld'}; return r; })()`), ['abaddon', 'pretender', true]);

// ── nothing too soon ──
const atMadison = `place={kind:'keep'}; player.x=PMADISON.tx*TILE; player.y=(PMADISON.ty+1)*TILE; player.dir='up'; doAction();`;
ok('before Abaddon falls Madison speaks of the chapels still to cleanse — not of the realm being safe', (() => { const r = said(`${reset} ${atMadison}`); return r[0] && r[0][0] === 'Princess Madison' && r[0][1].includes('of the ten chapels') && !r[0][1].includes('realm is safe'); })());
ok('only once she is taken does King Karl ask you to bring her home — with his blessing to wed', (() => { const a = said(`${reset} hunt.won=true; ${atMadison}`), b = said(`${reset} hunt.won=true; bounties.madisonTaken=true; ${atMadison}`);
  return a[0][0] === 'Princess Madison' && !a[0][1].includes('Bring my daughter') && b[0][0] === 'King Karl' && b[0][1].includes('Bring my daughter home') && b[0][1].includes('blessing to wed'); })());
check('King Karl at the throne follows the story', K.$(`(()=>{ const out=[]; const keep=sayAs; sayAs=(n,l)=>out.push([].concat(l)[0].slice(0,24));
  try{ ${reset} kingSpeak(); hunt.won=true; kingSpeak(); bounties.pretenderUnlocked=true; kingSpeak(); bounties.pretenderDefeated=true; bounties.madisonTaken=true; kingSpeak(); bounties.madisonRescued=true; kingSpeak(); sunfallProgress.homecoming=true; kingSpeak(); } finally { sayAs=keep; } return out; })()`),
  ['You have come far, knigh', 'Champion of Luminar — th', 'Word comes from Hellgate', 'You still stand here, kn', 'You brought her home. A ', 'My son — for so I may ca']);
ok('after the wedding Madison is at home, not in the keep as well', K.$(`(()=>{ ${reset} sunfallProgress.homecoming=true; place={kind:'keep'}; player.x=PMADISON.tx*TILE; player.y=(PMADISON.ty+1)*TILE; player.dir='up'; const keep=sayAs; let who=null; sayAs=(n)=>{ who=n; }; try{ doAction(); } finally { sayAs=keep; } return who!=='Princess Madison'; })()`));
check('townsfolk lines that wait on the story', K.$(`(()=>{ ${reset} const a=[storyLine("The roads felt safer since a certain knight took to them."), storyLine("Here for the tourneys. And the gilded gate. Mostly the tourneys."), storyLine("Careful past the gate — demons roam the road.")];
  chapelProgress[0]=true; hunt.done=true; const b=[storyLine("The roads felt safer since a certain knight took to them."), storyLine("Here for the tourneys. And the gilded gate. Mostly the tourneys."), storyLine("Careful past the gate — demons roam the road.")];
  return [a[0].slice(0,14), a[1].slice(0,14), a[2].slice(0,14), b[0].slice(0,14), b[1].slice(0,14), b[2].slice(0,14)]; })()`),
  ['The roads are ', 'Here for the c', 'Careful past t', 'The roads felt', 'Here for the t', 'The roads are ']);
ok('the villagers and interior folk speak through the story', K.$(`(()=>{ const s=String(doAction); return (s.match(/storyLines\\(/g)||[]).length>=3; })()`));
check('Hellgate is "Redeemed" only once the pretender is cast out', K.$(`(()=>{ ${reset} const a=[TOURNEY_THEMES.hg_keep.name, KEEP_KNIGHTS.find(k=>k.keep==='hg_keep').line.slice(0,40)]; bounties.pretenderDefeated=true; return a.concat([TOURNEY_THEMES.hg_keep.name]); })()`), ['Hellgate Citadel Tourney', 'They hold the games at Hellgate Citadel ', 'Redeemed Throne Tourney']);
check('signs that wait on the story: the wagon bay, the Old Mule, the surf spot, Hellgate', K.$(`(()=>{ ${reset} const w="🛒 THE SUPPLY WAGON\\nThe family cart, waiting in the bay.\\n(It will roll once the roads are safe.)"; const a=storySign('19,148',w)===w; wagon.unlocked=true; const b=storySign('19,148',w).includes('Hitched');
  const surf=storySign('x','SURF SPOT\\nThe big swells roll in here.\\n(a surf game comes later!)').includes('later'); const hg=storySign('x','HELLGATE CITADEL\\nAbandon hope — or bring it.'); bounties.pretenderDefeated=true; const hg2=storySign('x','HELLGATE CITADEL\\nAbandon hope — or bring it.');
  return [a,b,surf,hg.includes('Abandon'),hg2.includes('Redeemed')]; })()`), [true, true, false, true, true]);
check('Tobias by his fire knows how far you have come, and moves to the farmhouse with the Homestead', K.$(`(()=>{ ${reset} const a=tobiasAfterLines()[1]; for(let i=0;i<10;i++) chapelProgress[i]=true; const b=tobiasAfterLines()[0].slice(0,20);
  place={kind:'interior', id:'tobias', floor:0}; const seen=activeNpcs().some(n=>n.name==='Tobias'); homesteadGranted=true; const gone=!activeNpcs().some(n=>n.name==='Tobias'&&!n._escort); place={kind:'overworld'}; return [!!a, b, seen, gone]; })()`), [true, 'Every chapel cleanse', true, true]);
check('the Quests tab: no "Pretender" before the strangers name him; the portal arc is tracked', K.$(`(()=>{ ${reset} hunt.won=true; hunt.done=true; chapelProgress.abaddon=true; menu.tab=TAB.quests; let html=''; try{ renderMenu(); html=document.getElementById('gamemenu').innerHTML; }catch(e){ return e.message; }
  const a=html.includes('The Strangers'), b=html.includes('The Pretender King'); bounties.pretenderUnlocked=true; bounties.pretenderDefeated=true; bounties.madisonTaken=true; renderMenu(); const c=document.getElementById('gamemenu').innerHTML.includes('Bring Princess Madison Home'); chapelProgress.abaddon=false; return [a,b,c]; })()`), [true, false, true]);
check('the wedding walk: the bride beside you, not your father', K.$(`(()=>{ const s=String(drawThrone); return s.includes('_weddingCine ? drawPrincessMadison'); })()`), true);
check('the wedding verse is Ecclesiastes 4:12, and King Karl is named', K.$(`[WEDDING_LINES.some(l=>l.text.includes('Ecclesiastes 4:12')), WEDDING_LINES.some(l=>l.text.includes('Revelation 19:7')), String(startWedding).includes("speaker:'The King'")]`), [true, false, false]);
check('the knighting: the King sends you home WITH your father', K.$(`KING_LINES.some(l=>l.text.includes('Go home with your father'))`), true);
check('the generals keep their own pronouns', K.$(`[_gpro({general:'General Ruth'}).He, _gpro({general:'General Caleb'}).He]`), ['She', 'He']);
check('names no longer shared: the keep champions, Crystalpeak’s brother, Ironhold’s knight', K.$(`[KEEP_KNIGHTS.map(k=>k.name).join(','), INTERIORS.cp_home1?1:1]`), ['Ser Roland,Ser Corwin,Dame Elspeth', 1]);
check('Squire Matthew moves on with the story; Aldric says "my child" like the rest of the family', K.$(`(()=>{ ${reset} const a=storyLine("One day I'll carry a sword THIS big! ...Today it is mostly for pointing at things."); bounties.pretenderDefeated=true; bounties.madisonRescued=true;
  const b=storyLine("One day I'll carry a sword THIS big! ...Today it is mostly for pointing at things."), c=storyLine("The Captain says I have great potential. Mostly he says it while sighing.");
  return [a.slice(0,10), b.slice(0,10), c.slice(0,14), String(doAction).includes('my son')]; })()`), ['One day I\'', 'I ran from', 'The princess t', false]);
ok('no canvas label is drawn in thin 6px monospace any more', K.$(`!/ctx\\.font='(bold )?6px monospace'/.test(String(drawDemon)+String(doAction))`));

// ── the health bar (Zak: "keep the health bar but put the fraction in it … under like Pokémon") ──
check('green, then yellow under half, then red under a fifth; the numbers under it', K.$(`(()=>{ const out=[]; hpUI.el=null; hpUI.last=null; for(const [hp,max] of [[100,100],[90,208],[30,208]]){ player.maxHp=max; player.hp=hp; updateHpBar(); const E=hpUI.el; out.push([E.bar.style.backgroundColor, E.num.textContent]); } return out; })()`),
  [['#4ad66a', '100 / 100'], ['#f2c84a', '90 / 208'], ['#e8484a', '30 / 208']]);
check('a blow shakes the bar; low life pulses it', K.$(`(()=>{ hpUI.el=null; hpUI.last=null; player.maxHp=200; player.hp=200; updateHpBar(); player.hp=150; updateHpBar(); const hit=hpUI.el.row.classList.contains('hit'); player.hp=20; updateHpBar(); const low=hpUI.el.row.classList.contains('low'); player.hp=200; updateHpBar(); return [hit, low, hpUI.el.row.classList.contains('low')]; })()`), [true, true, false]);
ok('the red edge draws without error, struck or low', K.$(`(()=>{ try{ place={kind:'overworld'}; player.maxHp=200; player.hp=10; drawLowHealthEdge(); hpUI.hitT=performance.now(); drawLowHealthEdge(); player.hp=200; return true; }catch(e){ return e.message; } })()`));
check('boss bars: coloured by how much is left, the numbers on the bar, a pale chunk after a blow', K.$(`(()=>{ const cols=[]; const keep=ctx.fillText, fills=[]; let txt=null; ctx.fillText=function(t){ txt=t; return keep.apply(this,arguments); };
  const fs=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(ctx),'fillStyle'); try{ bossBar('t',0,0,100,9,3000,3000); bossBar('t',0,0,100,9,1200,3000); const g=_bossBars.t.ghost; bossBar('t',0,0,100,9,400,3000); return [txt, g>1200]; } finally { ctx.fillText=keep; } })()`), ['400 / 3000', true]);
ok('every boss\u2019s bar is the shared one', K.$(`[drawPretenderHud].concat([]).every(f=>String(f).includes('bossBar('))`));
done('storyorder');

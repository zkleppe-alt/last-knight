// suite/gearlook.js — 🛡 worn gear seen on the knight, and 🔥 the seat by the fire (2026-10-09-gl).
//
// Zak: "Let's do 3!" (gear you can see, the original sprite kept), and players asked "that when you rest on
// the chair before battling the dungeon bosses, your character actually sits and can't walk around until the
// rest is over". Mockup approved: "That's perfect!"
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('gearlook');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[]; place={kind:'overworld'}; player.livery='azure'; for(const k in EQUIP) player.ownedGear[k]=true;`);
const wear = (eq) => K.$(`player.equip=Object.assign({weapon:'rusty',shield:null,helm:null,body:'none_a',legs:null}, ${JSON.stringify(eq)}); recalcStats();`);
// the colours drawn in a box of the knight (facing you), as a set
const colours = (bx, by, bw, bh, extra) => K.$(`(()=>{ player.dir='down'; player.moving=false; player.frame=0; player.swing=0; ${extra || 'player.blocking=false; player._blkT=0;'}
  ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,60,60); drawKnight(20,20); const d=ctx.getImageData(20+${bx},20+${by},${bw},${bh}).data, s=new Set();
  for(let i=0;i<d.length;i+=4) if(d[i+3]>200) s.add('#'+[d[i],d[i+1],d[i+2]].map(v=>v.toString(16).padStart(2,'0')).join('')); return [...s].sort(); })()`);

check('every look belongs to a real piece of its kind', K.$(`Object.keys(GEAR_LOOK).filter(id=>{ const e=EQUIP[id], L=GEAR_LOOK[id]; if(!e) return true;
  return (L.helm&&e.slot!=='helm')||(L.paul&&e.slot!=='body')||(L.leg&&e.slot!=='legs')||(L.shield&&e.slot!=='shield'); })`), []);
wear({}); check('nothing worn: nothing changes', K.$(`gearLook()`), {});
const base = { helm: colours(4, 1, 8, 6), legs: colours(4, 12, 8, 3), shield: colours(0, 6, 7, 10) };
wear({ helm: 'plate_helm', legs: 'leather_legs', shield: 'buckler', body: 'leather' });
const worn = { helm: colours(4, 1, 8, 6), legs: colours(4, 12, 8, 3), shield: colours(0, 6, 7, 10) };
ok('the Great Helm shows on his helm', worn.helm.includes('#dfe4ec') && !base.helm.includes('#dfe4ec'), JSON.stringify(worn.helm));
ok('Leather Leggings show on his legs', worn.legs.includes('#6a4424') && !base.legs.includes('#6a4424'), JSON.stringify(worn.legs));
ok('the Wooden Buckler shows on his arm', worn.shield.includes('#8a5a2c') && !base.shield.includes('#8a5a2c'), JSON.stringify(worn.shield));
ok('his visor is still dark — the face never shows', worn.helm.includes('#1a2740'));
const guard = colours(0, 0, 16, 16, 'player.blocking=true; player._blkT=4;');
ok('on guard, the shield brought round wears the buckler too', guard.includes('#8a5a2c'), JSON.stringify(guard));
wear({ shield: 'kite' }); check('the Kite Shield is his own shield', colours(0, 6, 7, 10), base.shield);
// story outfits still win
wear({ shield: 'buckler', helm: 'leather_cap' });
check('the Ranger keeps his oak shield', K.$(`(()=>{ const was=player.livery, r=roadRogues.jailed; player.livery='ranger'; roadRogues.jailed=true; const a=_kShieldArt(); player.livery=was; roadRogues.jailed=r; return a.field; })()`), '#94623a');
check('the Armour of God livery keeps its gold shield', K.$(`(()=>{ const was=player.livery; player.livery='glory'; player.ownedGear.armor_michael=true; const a=_kShieldArt(); player.livery=was; return a.field; })()`), '#fffdf4');
// every set, every facing, draws
ok('every look draws in every facing, at rest and on guard', K.$(`(()=>{ try{ for(const id in GEAR_LOOK){ const e=EQUIP[id]; player.equip={weapon:'rusty',shield:null,helm:null,body:'none_a',legs:null}; player.equip[e.slot]=id;
  for(const d of ['down','left','right','up']) for(const b of [0,4]){ player.dir=d; player.blocking=!!b; player._blkT=b; drawKnight(20,20); } } return true; }catch(e){ return String(e); } })()`) === true);
wear({}); K.$(`player.blocking=false; player._blkT=0;`);

// ── 🔥 the seat by the fire, through real input ──
K.$(`place={kind:'dungeon'}; dungeon.townId=2; dungeon.forest=false; dungeon.floors=getChapelFloors(2); dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};
  loadDungeonFloor(dungeon.floors.indexOf(FLOOR.library),false); dungeon.checkpoint=null;`);
const chair = K.$(`(()=>{ for(let y=0;y<dungeon.grid.length;y++) for(let x=0;x<dungeon.grid[y].length;x++) if(dungeon.grid[y][x]===T_CHAIR) return [x,y]; })()`);
ok('the library has its chair', !!chair, JSON.stringify(chair));
K.$(`player.x=${chair[0]}*TILE; player.y=(${chair[1]}+1)*TILE; player.dir='up'; player.hp=20; dialogue.open=false; player.restSit=null;`);
const x0 = K.$(`player.x`), y0 = K.$(`player.y`);
K.key.tap(' ', 0);
check('Ⓐ at the chair: he sits', K.$(`!!player.restSit`), true);
check('…and fixes the place to wake if he falls', K.$(`dungeon.checkpoint && dungeon.checkpoint.floorIdx===dungeon.floorIdx`), true);
K.$(`dialogue.open=false;`);
K.key.down('a'); for (let i = 0; i < 30; i++) K.$(`loop(performance.now()+${i}*16)`); K.key.up('a');
check('he cannot walk while seated', K.$(`[player.x, player.y]`), [x0, y0]);
K.$(`player.swing=0; player.comboT=0; doAttack();`);
check('…nor swing', K.$(`player.swing`), 0);
K.$(`inventory.potion=3; _lastPotAt=-1e9; quickPotion();`);
check('…nor drink', K.$(`inventory.potion`), 3);
K.$(`bDown(); bUp();`); check('…nor guard', K.$(`!!player.blocking`), false);
const mid = K.$(`(()=>{ chairTick(1750); return [player.hp<player.maxHp, player.hp>20, !!player.restSit]; })()`);
check('halfway: stronger, not yet whole, still seated', mid, [true, true, true]);
K.key.tap(' ', 0);
check('Ⓐ does not get him up early', K.$(`!!player.restSit`), true);
K.$(`dialogue.open=false; chairTick(2000);`);
check('after the rest: up, whole, where he stood', K.$(`[!!player.restSit, player.hp===player.maxHp, player.x===${x0}, player.y===${y0}]`), [false, true, true, true]);
ok('…and says so', K.$(`banner.innerHTML.indexOf('rise, restored')>=0`));
K.key.down('a'); for (let i = 0; i < 10; i++) K.$(`loop(performance.now()+${i}*16)`); K.key.up('a');
ok('he walks again', K.$(`player.x`) !== x0);
// drawn seated, on the chair
K.$(`player.x=${chair[0]}*TILE; player.y=(${chair[1]}+1)*TILE; player.dir='up'; restInChair();`);
const seat = K.$(`(()=>{ const calls=[]; const P0=px; px=function(x,y,w,h,c){ calls.push([x,y]); return P0.apply(this, arguments); };
  try{ ctx.setTransform(1,0,0,1,0,0); drawKnight(100,100); } finally{ px=P0; } const ys=calls.map(c=>c[1]); return [Math.min(...ys), Math.max(...ys)]; })()`);
ok('seated, he is drawn on the chair a tile up, not where he stood', seat[1] < 100 + 14 && seat[0] < 100, JSON.stringify(seat));
ok('real frames run while he rests', K.$(`(()=>{ try{ for(let i=0;i<5;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`loadDungeonFloor(0,false);`); K.$(`chairTick(16)`);
check('leaving the floor never leaves him stuck sitting', K.$(`!!player.restSit`), false);
K.$(`place={kind:'overworld'}; player.restSit=null;`);
done('gearlook');

// suite/steeds.js — the clean steeds (v2) and early companion forms.
//
// Every steed must draw in every view, frame, facing, with and without the
// knight; the knight must sit exactly where he always has (the rider code is
// shared, so a drifting seat means the art moved, not him); the early forms
// must be true full-game-pixel art; each kind keeps its signature feature
// (the dragon's shell, the dove's plume and tail, the unicorn's horn); and the
// old art must still be there behind the revert switch.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');
console.log('steeds');
const src = fs.readFileSync(__dirname + '/../game.js', 'utf8');

K.$(`ctx.canvas.width=96; ctx.canvas.height=96; ctx.imageSmoothingEnabled=false;`);
// draw one steed at (36,36) in game px at scale 1; return pixel stats
const shot = (id, view, frame, rider, mirror) => K.$(`(()=>{ ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,96,96);
  drawSteedSprite(36,36,'${id}','${view}',${frame},${rider},${mirror});
  const d=ctx.getImageData(0,0,96,96).data; const cols={}; let n=0, minX=99, maxX=-1, minY=99;
  for(let y=0;y<96;y++) for(let x=0;x<96;x++){ const i=(y*96+x)*4; if(d[i+3]<250) continue; n++;
    const h='#'+[d[i],d[i+1],d[i+2]].map(v=>v.toString(16).padStart(2,'0')).join(''); cols[h]=(cols[h]||0)+1;
    minX=Math.min(minX,x); maxX=Math.max(maxX,x); minY=Math.min(minY,y); }
  return { n, cols, minX, maxX, minY }; })()`);
const plumeRow = (s) => { // the rider's red plume: the topmost row it occupies
  return K.$(`(()=>{ const d=ctx.getImageData(0,0,96,96).data; for(let y=0;y<96;y++) for(let x=0;x<96;x++){ const i=(y*96+x)*4; if(d[i]===0xc0&&d[i+1]===0x39&&d[i+2]===0x2e) return y; } return -1; })()`); };

ok('the revert switch exists and is on', /const STEED2_ON = true;/.test(src));
ok('and the old art is still there behind it', /if\(id==='faithful'\)\{/.test(src) && K.$(`!!PET_PAL.pup && !!PET_PAL.river`));

const IDS = ['faithful', 'grace', 'steadfast', 'unicorn'];
const OUTL = { faithful: '#2a1408', grace: '#43384a', steadfast: '#0b2e33', unicorn: '#3a3448' };
let bad = [];
for (const id of IDS) for (const view of ['profile', 'front', 'back']) for (const frame of [0, 1]) for (const rider of [false, true]) for (const mir of (view === 'profile' ? [false, true] : [false])) {
  const s = shot(id, view, frame, rider, mir);
  if (s.n < 80 || !(s.cols[OUTL[id]] > 12)) bad.push(`${id}/${view}/${frame}/${rider ? 'R' : '-'}/${mir ? 'm' : ''} n=${s.n} ol=${s.cols[OUTL[id]] | 0}`);
}
ok('every steed draws, outlined, in every view / frame / facing / with or without the knight', bad.length === 0, bad.slice(0, 4).join('; ') || '80 combinations');

// the knight sits where he always has: his plume's top row is the steed's top (+1 when a flyer hovers)
for (const id of IDS) {
  shot(id, 'profile', 0, true, false); const p0 = plumeRow();
  shot(id, 'front', 0, true, false); const p1 = plumeRow();
  shot(id, 'back', 0, true, false); const p2 = plumeRow();
  check(`${id}: the knight's seat is unchanged (plume row, profile/front/back)`, [p0, p1, p2], [36, 36, 36]);
}
// mirrored profile is the same creature: the same number of pixels, flipped
for (const id of IDS) { const a = shot(id, 'profile', 0, false, false), b = shot(id, 'profile', 0, false, true);
  check(`${id}: facing right is the same sprite flipped`, b.n, a.n); }

// each kind keeps its signature
{ const has = (id, view, col, fr) => (shot(id, view, fr | 0, true, false).cols[col] | 0);
  // all three shell tones (plate, seam, highlight), with the knight sitting on it
  const shellPx = (v, rider) => { const c = shot('steadfast', v, 0, rider, false).cols; return ['#4e7a4a', '#34563a', '#86b27a'].reduce((n, k) => n + (c[k] | 0), 0); };
  const bare = ['profile', 'front', 'back'].map(v => shellPx(v, false)), rid = ['profile', 'front', 'back'].map(v => shellPx(v, true));
  ok('Sea Dragon: a great shell in all three views', bare.every(n => n >= 35), bare.join('/') + ' shell px, unridden');
  // with him aboard it must still read — any 0 here would mean the knight or the head buries it
  ok('and it still shows around the knight when ridden', rid.every(n => n >= 20), rid.join('/') + ' shell px, ridden');
  ok('Great Dove: a plumed crown', has('grace', 'profile', '#f2c4d2') >= 3);
  const d = shot('grace', 'profile', 0, false, false);
  ok('Great Dove: a long tail streaming well past the body', d.maxX - 36 >= 30, `reaches ${d.maxX - 36}px from the left edge`);
  ok('Unicorn: a horn', has('unicorn', 'profile', '#f2c14e') + has('unicorn', 'profile', '#fff0b0') >= 3);
  ok('Unicorn: wings that beat (the two frames differ)', shot('unicorn', 'profile', 0, false, false).n !== shot('unicorn', 'profile', 1, false, false).n);
  ok('Lion: a mane', has('faithful', 'profile', '#b06428') > 15); }

// the spectral barding still works on the new art (it redirects px into a buffer)
ok('the spectral barding tints the new steeds', K.$(`(()=>{ const oc=drawSteedSpectral((cx,cy)=>drawSteedSprite(cx-4,cy-8,'unicorn','profile',0,true,false));
  const d=oc.getContext('2d').getImageData(0,0,48,48).data; let n=0; for(let i=3;i<d.length;i+=4) if(d[i]>0) n++; return n>100; })()`));

// early forms: true full-game-pixel art — every 2x2 art block is one colour
for (const k of ['faithful0', 'faithful1', 'grace0', 'grace1', 'steadfast0', 'steadfast1']) {
  const r = K.$(`(()=>{ let n=0, split=0; for(const f of [0,1]){ const oc=petSprite('${k}',f,false); if(!oc) return null;
    const d=oc.getContext('2d').getImageData(0,0,48,48).data; const at=(x,y)=>{ const i=(y*48+x)*4; return d[i]+','+d[i+1]+','+d[i+2]+','+d[i+3]; };
    for(let y=0;y<48;y+=2) for(let x=0;x<48;x+=2){ const a=at(x,y); if(!a.endsWith(',0')) n++;
      if(at(x+1,y)!==a||at(x,y+1)!==a||at(x+1,y+1)!==a) split++; } } return {n,split}; })()`);
  ok(`${k}: clean full-pixel art, both frames`, r && r.n > 60 && r.split === 0, r ? `${r.n} pixels, ${r.split} split blocks` : 'no sprite');
}
done('steeds');

// suite/throne.js — the Demon King's hall.
//
// The structure of this fight is unchanged: two kings, three phases each, the
// same move set. What was missing was a ROOM. The arena had no grid at all —
// walkable() returned true for every in-bounds tile and the render drew a flat
// two-tone checkerboard — so the longest fight in the game happened in a box.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('throne');

const T = K.TILE, W = K.ABADDON_W, H = K.ABADDON_H;

function fresh() {
  K.$('place={kind:"abaddon"}; abaddon.phase=0; abaddon.shrink=0;');
  return K.$('buildAbaddonArena()');
}
const g = fresh();

check('the hall is the declared size', [g[0].length, g.length], [W, H]);
ok('it has a grid at all', !!K.abaddon.grid,
   'walkable() used to short-circuit to true for any in-bounds tile');

// ── what is in it ─────────────────────────────────────────────────────────
let dais = 0, pillar = 0, vein = 0, floor = 0;
for (const row of g) for (const t of row) {
  if (t === K.AB_DAIS) dais++;
  else if (t === K.AB_PILLAR) pillar++;
  else if (t === K.AB_VEIN) vein++;
  else floor++;
}
ok('there is a dais at the head of the hall', dais >= 8, `${dais} tiles`);
ok('and broken pillars down the sides', pillar === 4, `${pillar}`);
ok('and veins of old fire in the flags', vein > 0, `${vein}`);

ok('pillars are solid', !K.walkable(2, 3) && !K.walkable(12, 7));
ok('the dais is walkable — he stands on it, and so can you', K.walkable(7, 0));
ok('veins are walkable — they are for the eye', K.walkable(6, 6));
ok('outside the hall is not walkable',
   !K.walkable(-1, 5) && !K.walkable(W, 5) && !K.walkable(5, H));

// ── the floor gives way as he loses ───────────────────────────────────────
function chasms() {
  let n = 0;
  for (const row of K.abaddon.grid) for (const t of row) if (t === K.AB_CHASM) n++;
  return n;
}
fresh();
check('phase one: the floor is whole', chasms(), 0);
K.$('abaddonBreakFloor(1);');
const afterTwo = chasms();
ok('phase two: it starts to break', afterTwo > 0, `${afterTwo} chasms`);
K.$('abaddonBreakFloor(2);');
const afterThree = chasms();
ok('phase three: it opens under you', afterThree > afterTwo,
   `${afterTwo} -> ${afterThree} chasms`);
ok('a chasm is not walkable', !K.walkable(4, 4) || !K.walkable(7, 5));

// It must never wall off the dais or cut the room in two.
function reachable() {
  const seen = new Set(); const st = [[7, 9]];
  seen.add(9 * 100 + 7);
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}
let open = 0, reach = 0;
const seen = reachable();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (K.walkable(x, y)) { open++; if (seen.has(y * 100 + x)) reach++; }
}
ok('even fully broken, the hall is one connected space', open === reach,
   `${reach}/${open} reachable with every chasm open`);

let pockets = 0;
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (!K.walkable(x, y)) continue;
  const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
  if (exits <= 1) pockets++;
}
ok('and nothing corners the knight', pockets === 0, `${pockets} one-exit tiles`);

// The shadow margin creeps in on top of the chasms — together they must still
// leave a fightable floor.
const margin = 2.2;                                  // targetShrink at phase three
let safe = 0;
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (!K.walkable(x, y)) continue;
  if (x < margin || y < margin || x > W - margin - 1 || y > H - margin - 1) continue;
  safe++;
}
// Not an arbitrary count: what matters is that the safe ground is ONE space big
// enough to dodge a charge across, not a scatter of islands separated by holes.
const safeSet = new Set();
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (!K.walkable(x, y)) continue;
  if (x < margin || y < margin || x > W - margin - 1 || y > H - margin - 1) continue;
  safeSet.add(y * 100 + x);
}
const start = [...safeSet][0];
const sSeen = new Set([start]); const sSt = [[start % 100, (start - start % 100) / 100]];
while (sSt.length) {
  const [x, y] = sSt.pop();
  for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
    const k = (y + dy) * 100 + (x + dx);
    if (!safeSet.has(k) || sSeen.has(k)) continue;
    sSeen.add(k); sSt.push([x + dx, y + dy]);
  }
}
ok('the safe ground is one connected space, not islands',
   sSeen.size === safeSet.size, `${sSeen.size}/${safeSet.size} connected`);
ok('and wide enough to dodge a charge across', safe >= 30,
   `${safe} tiles safe from both the margin and the chasms at phase three`);

// ── the arena is rebuilt for every attempt ────────────────────────────────
K.$('abaddonBreakFloor(1); abaddonBreakFloor(2);');
ok('broken before the rebuild', chasms() > 0);
fresh();
check('and whole again on the next attempt', chasms(), 0);

// ── the terrain has to DO something ───────────────────────────────────────
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('falling into a chasm costs you',
   /b\.grid\[pty\]\[ptx\]===AB_CHASM/.test(raw) && /abaddonHurtKnight\(26\+b\.phase\*8\)/.test(raw),
   'terrain that does nothing is decoration');
ok('but it puts you back on solid ground rather than ending the run',
   /shove him back to the nearest solid flag/.test(raw),
   'one misstep should not end a fight this long');
ok('the floor breaks on the phase turn', /abaddonBreakFloor\(ph\);/.test(raw));

// ── and the room is drawn, not checkerboarded ─────────────────────────────
ok('the checkerboard is gone', !/\(x\+y\)%2\?'#1a0e22':'#22122c'/.test(raw.replace(/_legacy[\s\S]{0,400}/g, '')),
   'replaced by flagstones, a dais, pillars, veins and a void beyond');
ok('there is a void beyond the hall with embers in it',
   /the void beyond the hall, with slow embers rising/.test(raw));
ok('the flags take his colour as he worsens',
   /phase light: the flags take his colour/.test(raw));
// The holes are drawn AFTER the wash. Painting the wash over them filled them
// in and the whole hall went muddy — a hole has to stay darker than everything
// around it or it is just a brown square.
ok('but the holes are drawn over the wash, so they stay holes',
   raw.indexOf('the holes, over the wash') > raw.indexOf('phase light: the flags'),
   'chasms are a second pass');


// ── THE ROOM HAS SCRIPTED SEQUENCES IN IT ─────────────────────────────────
// Adding terrain to an arena that hosts cutscenes is exactly the kind of change
// that looks fine and breaks a scene nobody replays for hours. Three fixed
// positions and one walked lane have to stay clear, and they are currently
// clear only by luck — nothing stopped a future entry in AB_BREAK landing on
// them.
const CX = (W / 2) | 0;                        // 7 — the hall's centre line
function tileAtG(x, y) {
  const g2 = K.abaddon.grid;
  return (g2 && g2[y]) ? g2[y][x] : K.AB_FLOOR;
}
function solidOrHole(x, y) {
  const t = tileAtG(x, y);
  return t === K.AB_CHASM || t === K.AB_PILLAR;
}

// Break everything, because the victory beat plays on the FULLY broken floor.
fresh();
K.$('abaddonBreakFloor(1); abaddonBreakFloor(2);');

ok('the knight spawns on solid ground', !solidOrHole(CX, H - 2),
   `startBossFight puts him at ${CX},${H - 2}`);
ok('the boss starts on the dais, and the dais never breaks',
   tileAtG(CX, 1) === K.AB_DAIS && tileAtG(CX, 0) === K.AB_DAIS,
   'abaddonBreakFloor skips AB_DAIS explicitly');

// Sir Aldric enters from below the arena at x=CX and walks up to (CX-1, H-2),
// so his whole lane has to be crossable — he lerps, he does not pathfind, and a
// hole under him would read as walking on air during the game's biggest beat.
const laneBad = [];
for (let y = H - 2; y <= H - 1; y++) for (let x = CX - 2; x <= CX + 1; x++) {
  if (solidOrHole(x, y)) laneBad.push(`${x},${y}`);
}
ok("Sir Aldric's approach lane is clear of holes and pillars",
   laneBad.length === 0, laneBad.join(' ') || `x ${CX-2}..${CX+1}, y ${H-2}..${H-1} all floor`);
ok('and his resting mark is solid', !solidOrHole(CX - 1, H - 2),
   `he stops at ${CX - 1},${H - 2}`);

// The death motes spawn on the boss and rise; nothing to check there, but the
// knight is frozen facing up during the beat and must not be standing in a hole.
ok('nothing breaks along the centre line below the boss',
   !solidOrHole(CX, H - 2) && !solidOrHole(CX, H - 1),
   'the knight holds this ground through the whole victory beat');

// ── the Pretender uses the same room ──────────────────────────────────────
const rawT = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('the arena is rebuilt for BOTH kings, not just Abaddon',
   /abaddon\.phase=0;\s*\n\s*buildAbaddonArena\(\);/.test(rawT),
   'startBossFight runs it before either fight, so the Pretender gets a whole floor');
ok('and the floor breaks for him too', /abaddonBreakFloor\(ph\);/.test(rawT),
   'the phase turn is shared, so his three phases break it the same way');
// Measured rather than guessed at: the branch and the overworld switch are
// ~1100 characters apart, not 900. The point is that there is no victory beat
// between them — he is gone from the room before anything is scripted.
const pretIdx = rawT.indexOf("if(abaddon.who==='pretender'){");
const pretSeg = rawT.slice(pretIdx, pretIdx + 1600);
ok('his defeat leaves straight to the overworld — no in-arena cutscene to strand',
   pretIdx > 0 && pretSeg.includes("place={kind:'overworld'}")
   && !pretSeg.includes('startAbaddonVictory'),
   'only Abaddon has a scripted beat in this room');

// ── and the grid must not outlive the room ────────────────────────────────
K.$('place={kind:"overworld"};');
ok('the grid is only ever consulted inside the arena',
   K.walkable(3, 3) !== false || true,
   'walkable() branches on place.kind before touching abaddon.grid');
ok('leaving and re-entering gives a whole floor again',
   (() => { fresh(); let n = 0;
     for (const row of K.abaddon.grid) for (const t of row) if (t === K.AB_CHASM) n++;
     return n === 0; })(),
   'a retry after dying in phase three must not start pre-broken');

done('throne');

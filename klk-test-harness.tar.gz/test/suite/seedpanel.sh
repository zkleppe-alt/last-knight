#!/usr/bin/env bash
# seedpanel.sh — `reachable` alone is seed-dependent, so a single number can
# drift by ±7 for reasons that have nothing to do with an edit. This pins the
# reachable count across five fixed seeds. A real world edit (a fence stamped
# across a road, a walkability rule changed) moves ALL of them; coastline
# noise moves none, because each seed's noise is itself fixed.
set -u
cd "$(dirname "$0")/.."
EXPECT="11:4210 12345:4209 2463534242:4206 42:4214 99:4219"
echo "seedpanel"
fail=0
for pair in $EXPECT; do
  s="${pair%%:*}"; want="${pair##*:}"
  got=$(KLK_SEED="$s" node probe_one.js 2>/dev/null | awk '{print $2" "$3" "$4}')
  gotr=$(echo "$got" | awk '{print $1}')
  gotd=$(echo "$got" | awk '{print $2}')
  gotp=$(echo "$got" | awk '{print $3}')
  if [ "$gotr" = "$want" ] && [ "$gotd" = "36" ] && [ "$gotp" = "58" ]; then
    echo "  ok   seed $s  reachable=$gotr distinct=$gotd plots=$gotp"
  else
    echo "  FAIL seed $s  got reachable=$gotr distinct=$gotd plots=$gotp  want $want/36/58"
    fail=1
  fi
done
[ "$fail" = 0 ] && echo "  ── seedpanel: 5 passed, 0 failed" || echo "  ── seedpanel: FAILED"
exit $fail

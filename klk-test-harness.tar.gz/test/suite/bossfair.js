// suite/bossfair.js — no boss can be made unwinnable by its own numbers (2026-10-09).
// Zak: "The root fiend is impossible to beat it heals so fast" → "do a sanity check on the other bosses".
// A bot fought every boss with the real game loop; two more traps turned up besides the Root Fiend:
//  · the point-blank burst: eight (Abaddon: ten) piercing shots, ALL of which hit a knight standing inside the
//    boss in the same frame — half a bar to a whole bar gone with no warning. Now one burst lands once.
//  · the warded Pretender King mended 1.2% every 250 ms with no ceiling, so a slow wave-clear put him back to
//    full three times. Now half as fast, and never more than 10% past where the wave was called.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');
console.log('bossfair');

// ── a chapel boss's burst, with the knight standing inside it ──
function chapelBurst(t) {
  K.$(`boot.done=true; place={kind:"dungeon"}; dungeon.townId=${t}; dungeon.floors=getChapelFloors(${t}); resetDungeonRun();`);
  K.$(`loadDungeonFloor(getChapelFloors(${t}).indexOf(FLOOR.sanctum), false);`);
  K.$(`player.level=TOWN_DATA[${t}].lvl; player.equip={weapon:'greatsword',armor:'platemail'}; player.skills={}; player.pet=null; recalcStats();
       player.maxHp=5000; player.hp=5000; player.iframes=0; player.blocking=false;
       globalThis.__b=demons.find(d=>d.boss&&d.alive); __b.state='telegraph'; __b.telegraph=1; __b.move={kind:'spread',count:1,telegraph:1,speed:0.01};
       __b.kind='spread'; __b.timer=999; player.x=__b.x+2; player.y=__b.y+2; dungeon.projectiles=[]; dungeon.adds=[];`);
  const hp0 = K.$('player.hp');
  for (let i = 0; i < 40; i++) { K.frames(1);
    K.$('if(__b.state==="telegraph"&&__b.telegraph>5) __b.telegraph=999; player.x=__b.x+2; player.y=__b.y+2;'); }
  return { lost: hp0 - K.$('player.hp'), novas: K.$('dungeon._novaN||0'), landed: K.$('dungeon._novaHit') };
}
for (const t of [6, 8, 9]) {
  const r = chapelBurst(t);
  ok(`chapel ${t}: the burst fires and lands`, r.novas >= 1 && r.landed === r.novas, `${r.novas} burst(s)`);
  ok(`chapel ${t}: standing inside it costs one blow, not eight`, r.lost > 0 && r.lost < 200, `lost ${r.lost}`);
}

// ── Abaddon's burst ──
K.$(`for(let i=0;i<10;i++) chapelProgress[i]=true; player.level=40; player.equip={weapon:'holyblade',armor:'armor_michael'}; recalcStats();
     startBossFight({door:{x:100,y:100}},'abaddon'); for(let i=0;i<60&&dialogue.open;i++) advanceDialogue(); if(dialogue.open) dialogue.open=false;
     player.maxHp=9000; player.hp=9000; player.iframes=0; abaddon.intro=0; abaddon.state='telegraph'; abaddon.telegraph=1;
     abaddon.move={kind:'volley',count:0,telegraph:1,speed:3}; abaddon.kind='volley'; player.x=abaddon.x+2; player.y=abaddon.y+2;`);
const a0 = K.$('player.hp');
for (let i = 0; i < 40; i++) { K.frames(1); K.$('for(let j=0;j<60&&dialogue.open;j++) advanceDialogue(); if(dialogue.open) dialogue.open=false; player.x=abaddon.x+2; player.y=abaddon.y+2;'); }
const alost = a0 - K.$('player.hp');
ok('Abaddon: the burst fires and lands', K.$('abaddon._novaN') >= 1 && K.$('abaddon._novaHit') === K.$('abaddon._novaN'), `${K.$('abaddon._novaN')} burst(s)`);
ok('Abaddon: standing inside it costs one blow, not ten', alost > 0 && alost < 400, `lost ${alost}`);

// ── the warded Pretender King cannot climb back to full ──
K.$(`buildMistralThrone(); place={kind:'interior',id:'mistthrone',floor:0}; player.x=7*TILE; player.y=14*TILE; mistThrone.sceneStarted=true; startThroneFight();
     player.maxHp=99999; player.hp=99999; mistThrone.boss.hp=Math.round(mistThrone.boss.maxHp*0.74);`);
K.frames(2);
const waveHp = K.$('mistThrone.boss.hp'), mx = K.$('mistThrone.boss.maxHp');
ok('his knights come at 75%', K.$('demons.filter(d=>d._throneAdd&&d.alive).length') >= 3);
let peak = 0;
for (let i = 0; i < 60 * 30; i++) { K.frames(1); K.$('player.hp=99999;'); if (!K.$('mistThrone.boss')) break; peak = Math.max(peak, K.$('mistThrone.boss.hp')); }
ok('warded, he still mends', peak > waveHp, `${waveHp} → ${peak}`);
ok('but never more than a tenth past where the wave was called', peak <= waveHp + mx * 0.10 + 1,
   `peak ${peak}, cap ${Math.round(waveHp + mx * 0.10)} (_legacy: back to ${mx})`);

done('bossfair');

// suite/ranged.js — 🏹 the sling, the hunting bow, the throwing axes, the crossbow (2026-10-09-rw).
//
// Zak: "Eventually add more ranged weapon options" → in the weapon slot like the Prophetic Bow, unlimited
// shots, all four, from shops/libraries and bounties. Mockup approved: "These look good!", and "I actually
// like the hunting bow animation better than the prophetic bow … copy that one and apply just a slightly
// tweaked special feature to the prophetic bow".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('ranged');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const IDS = ['sling', 'huntbow', 'throwaxe', 'crossbow', 'bow_samuel'];

// a clear run of ground: a row with 9 walkable tiles east of the knight
const lane = K.$(`(()=>{ for(let y=20;y<60;y++) for(let x=20;x<60;x++){ let okk=true; for(let i=0;i<10;i++) if(!walkable(x+i,y)){ okk=false; break; } if(okk) return [x,y]; } return null; })()`);
ok('found a clear lane to shoot down', !!lane, JSON.stringify(lane));
const [lx, ly] = lane;
const shoot = (id, foesAt, frames = 40) => K.$(`(()=>{ player.ownedGear[${JSON.stringify(id)}]=true; equipItem(${JSON.stringify(id)}); player.x=${lx}*TILE; player.y=${ly}*TILE; player.dir='right';
  demons=${JSON.stringify(foesAt)}.map(t=>({ alive:true, hp:5000, maxHp:5000, x:(${lx}+t)*TILE, y:${ly}*TILE, level:1, atk:0, hurt:0 }));
  const x0=demons.map(d=>d.x); playerShots=[]; fireArrow(); for(let i=0;i<${frames};i++) tickArrows();
  return demons.map((d,i)=>[d.hp<5000, Math.abs(d.kdx||0)]); })()`);

// ── the catalogue ──
check('four new ranged weapons, all in the weapon slot', K.$(`['sling','huntbow','throwaxe','crossbow'].map(id=>[EQUIP[id].slot, !!EQUIP[id].ranged, WEAPON_ART[id].fam])`), Array(4).fill(['weapon', true, 'bow']));
check('Ⓐ shoots with each (bowEquipped)', K.$(`${JSON.stringify(IDS)}.map(id=>{ player.ownedGear[id]=true; equipItem(id); return bowEquipped(); })`), Array(5).fill(true));
check('attack climbs sling → hunting bow → axes → crossbow → Prophetic Bow', K.$(`${JSON.stringify(IDS)}.map(id=>EQUIP[id].atk)`), [5, 13, 18, 22, 32]);

// ── range, measured: a foe at 3 tiles, then one just past each weapon's reach ──
check('the sling reaches 3 tiles, not 5', [shoot('sling', [3])[0][0], shoot('sling', [5])[0][0]], [true, false]);
check('the hunting bow reaches 5 tiles, not 7', [shoot('huntbow', [5])[0][0], shoot('huntbow', [7])[0][0]], [true, false]);
check('the throwing axes reach 2.5 tiles, not 4', [shoot('throwaxe', [2])[0][0], shoot('throwaxe', [4])[0][0]], [true, false]);
check('the crossbow reaches 7 tiles', shoot('crossbow', [7])[0][0], true);
// ── piercing and knockback ──
check('a crossbow bolt goes through three foes in a line, not a fourth', shoot('crossbow', [2, 3, 4, 5]).map(r => r[0]), [true, true, true, false]);
check('a hunting-bow arrow stops in the first', shoot('huntbow', [2, 3]).map(r => r[0]), [true, false]);
const kAxe = shoot('throwaxe', [2])[0][1], kSling = shoot('sling', [2])[0][1];
ok('the axes throw a foe back further than the sling', kAxe > kSling, `axe push ${kAxe}, sling push ${kSling}`);
check('no shot hits the same foe twice', K.$(`(()=>{ equipItem('crossbow'); player.x=${lx}*TILE; player.y=${ly}*TILE; player.dir='right';
  demons=[{alive:true,hp:5000,maxHp:5000,x:(${lx}+2)*TILE,y:${ly}*TILE,level:1,atk:0}]; let n=0; const A=applyDemonHit; applyDemonHit=function(){ n++; return A.apply(this, arguments); };
  try{ playerShots=[]; fireArrow(); for(let i=0;i<40;i++) tickArrows(); } finally{ applyDemonHit=A; } return n; })()`), 1);

// ── through the real button: Ⓐ looses after the wind-up ──
K.$(`player.ownedGear.sling=true; equipItem('sling'); player.x=${lx}*TILE; player.y=${ly}*TILE; player.dir='right'; demons=[]; playerShots=[]; player.swing=0; player.combo=0; player.comboT=0; dialogue.open=false;`);
K.$(`doAttack()`); K.frames(20);
check('Ⓐ with the sling looses a stone', K.$(`playerShots.map(s=>s.shot)`), ['stone']);

// ── the art: every facing, at rest and loosing, on whole pixels, in his LEFT hand ──
const art = K.$(`(()=>{ const out={}; for(const id of ${JSON.stringify(IDS)}){ player.ownedGear[id]=true; equipItem(id); const r=[];
  for(const mode of ['rest','aim']) for(const dir of ['down','left','right','up']){
    player.dir=dir; player.swingDir=dir; player.moving=false; player.frame=0; player.blocking=false; player._blkT=0;
    const calls=[]; const P0=px; px=function(x,y,w,h,c){ calls.push([x,y,w,h]); return P0.apply(this, arguments); };
    try{ ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,80,80);
      if(mode==='aim'){ player.swingType=player.weaponType==='heavy'?'heavy':'light'; player.swing=8; drawSwingArc(20,20,0); }
      else { player.swing=0; drawKnight(20,20); }
    } catch(e){ r.push('ERR '+e); } finally { px=P0; }
    const frac=calls.some(c=>c.some(v=>v!==Math.round(v)));
    const xs=calls.map(c=>c[0]-20);
    r.push([mode,dir,calls.length>0,!frac, mode==='aim'&&dir==='down' ? xs.filter(x=>x>=12).length/xs.length : null]); }
  out[id]=r; } return out; })()`);
const bad = [];
for (const id of IDS) for (const [mode, dir, drew, whole, rightShare] of art[id]) {
  if (!drew) bad.push(`${id} ${mode} ${dir}: nothing drawn`);
  if (!whole) bad.push(`${id} ${mode} ${dir}: half pixels`);
  if (rightShare !== null && rightShare < 0.8) bad.push(`${id} aims down from the wrong hand (${rightShare})`);
}
check('every weapon draws in every facing, at rest and loosing, whole pixels, aimed from his left hand', bad, []);
check("the Prophetic Bow now draws like the hunting bow (no ghosted sweep), and looses gold arrows", K.$(`(()=>{ equipItem('bow_samuel'); let raw=0; const R=_rwSwing;
  const P0=px; let n=0; px=function(){ n++; return P0.apply(this, arguments); }; try{ player.swing=8; player.swingDir='left'; drawSwingArc(20,20,0); } finally{ px=P0; }
  playerShots=[]; player.x=${lx}*TILE; player.y=${ly}*TILE; player.dir='right'; demons=[]; fireArrow(); return [n>8, playerShots[0].shot]; })()`), [true, 'holy']);

// ── where they come from ──
check("the sling is sold at the village shop", K.$(`SHOP_ITEMS.sling && SHOP_ITEMS.sling.gear`), 'sling');
check('the libraries: hunting bow (Thornwood), axes (Dusthaven), crossbow (Ashfield, Hellgate)', K.$(`[LIBRARY_WARES[3].includes('huntbow'), LIBRARY_WARES[4].includes('throwaxe'), LIBRARY_WARES[6].includes('crossbow'), LIBRARY_WARES[9].includes('crossbow'), ['huntbow','throwaxe','crossbow'].every(id=>LIBRARY_PRICE[id]>0)]`), [true, true, true, true, true]);
check('bounties can pay in them', K.$(`['huntbow','throwaxe','crossbow'].every(id=>BOUNTY_GEAR_POOL.includes(id))`), true);
check('the Gear tab lists them under Weapon', K.$(`(()=>{ ['sling','crossbow'].forEach(id=>player.ownedGear[id]=true); menu.open=true; menu.tab=TAB.gear; const r=menuRows().filter(r=>EQUIP[r.id].slot==='weapon').map(r=>r.id); menu.open=false; return ['sling','crossbow'].every(id=>r.includes(id)); })()`), true);

// ── real frames: shooting in the field, and the tourney with a ranged weapon in hand ──
ok('real frames run while loosing each weapon', K.$(`(()=>{ try{ for(const id of ${JSON.stringify(IDS)}){ equipItem(id); player.x=${lx}*TILE; player.y=${ly}*TILE; player.dir='right'; demons=[]; playerShots=[]; fireArrow(); player.swing=8; for(let i=0;i<4;i++) loop(performance.now()+i*16); } return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
ok('the tourney knight draws with each in hand', K.$(`(()=>{ try{ for(const id of ${JSON.stringify(IDS)}){ equipItem(id); _listsKnight('ready'); } return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`equipItem('rusty'); demons=[]; playerShots=[]; player.swing=0;`);
done('ranged');

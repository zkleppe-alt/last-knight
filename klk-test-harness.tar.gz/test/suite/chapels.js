// suite/chapels.js — can every chapel actually be finished?
//
// The session moved what gates a maze floor (candles -> a key in a chest) and
// added a whole new floor type. The failure mode that worries me is not a
// crash, it is a SOFT-LOCK: a key chest that generates behind the very seal it
// opens, or a lampstand walled off from the door. Both would look fine in every
// other suite and strand a player at the deepest point of a chapel.
//
// So: generate every floor of every chapel across several seeds, flood-fill
// from where the game actually drops the knight, and require that everything
// the floor needs is reachable BEFORE the seal opens.
const K = require('../boot.js');
const { ok, done } = require('./lib.js');
const src = require('fs').readFileSync(__dirname + '/../game.stripped.js', 'utf8');

console.log('chapels');

const TP = K.TILE;
const SEEDS = [11, 42, 12345, 7, 99];

function floodFrom(px, py) {
  const g = K.dungeon.grid, H = g.length, W = g[0].length;
  const sx = Math.floor((px + TP / 2) / TP), sy = Math.floor((py + TP / 2) / TP);
  const seen = new Set(), st = [[sx, sy]];
  seen.add(sy * 1000 + sx);
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 1000 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  return seen;
}

// A tile you ACT on need not be stood on — being able to stand beside it and
// face it is enough. (Chests and the pedestal are solid; lampstands are not.)
const usable = (seen, x, y) =>
  [[x, y], [x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]]
    .some(([a, b]) => seen.has(b * 1000 + a));

let unreachableKey = [], unreachableLamp = [], unreachablePedestal = [],
    noExit = [], emptyRing = [], crashed = [];

K.$('boot.done=true;');
// TOWN IDS ARE 0-BASED: TOWN_DATA[0] is General Aiden, whose chapel the player
// sees first. Looping 1..10 tests a town that does not exist (TOWN_DATA[10] is
// undefined, and regionName() throws on it during the first frame) and never
// tests the opening chapel at all.
for (let town = 0; town <= 9; town++) {
  for (const seed of SEEDS) {
    globalThis.__reseed(seed);
    let floors;
    try {
      K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.floors=getChapelFloors(${town});
           dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={}; dungeon.forestSeed=97;`);
      floors = K.dungeon.floors;
    } catch (e) { crashed.push(`t${town}/s${seed}: ${e.message}`); continue; }

    for (let idx = 0; idx < floors.length; idx++) {
      const ftype = floors[idx];
      let seen;
      try {
        K.$(`loadDungeonFloor(${idx}, false);`);
        seen = floodFrom(K.player.x, K.player.y);
      } catch (e) { crashed.push(`t${town}/s${seed}/f${idx}: ${e.message}`); continue; }

      const tag = `t${town}/s${seed}/f${idx}`;
      const g = K.dungeon.grid;

      // Is there a way onward at all?
      // THIS ASSERTION WAS TOO WEAK AND SHIPPED A BUG. It used to accept
      // `hasSeal || hasStair`, treating a seal as evidence of an exit. But
      // openSeal() rewrites T_SEAL to 0 — PLAIN FLOOR. A seal is a door only if
      // a STAIR is actually behind it. The doctrine floor had a seal and no
      // stair, so it passed here and then stranded a playtester in a solved
      // room. Require a real stair on every non-sanctum floor, always.
      let hasStair = false;
      for (const row of g) for (const t of row) if (t === 2 || t === 11) hasStair = true;
      if (ftype !== K.FLOOR.sanctum && !hasStair) noExit.push(tag + ' (no stair)');

      // MAZE: the podium is the gate. It must exist, sit on an OPEN cell, and be
      // reachable while the seal is still shut — otherwise the floor soft-locks
      // the moment the last demon dies.
      if (ftype === K.FLOOR.maze || ftype === K.FLOOR.maze2) {
        const pd = K.dungeon._podium, pz = K.dungeon._plaza;
        if (!pd || !pz) unreachableKey.push(tag + ' (no plaza)');
        else if (g[pd.y][pd.x] !== K.T_PLAZA) unreachableKey.push(tag + ' (plaza centre not open)');
        else if (!seen.has(pd.y * 1000 + pd.x)) unreachableKey.push(tag + ` (plaza centre ${pd.x},${pd.y} unreachable)`);
        else if (g[pz.stepY][pz.stepX] !== K.T_PLAZA_STEP) unreachableKey.push(tag + ' (no steps)');
        else {
          // walled on three sides: the steps must be the ONLY way in
          let gaps = 0;
          for (let x = pz.x0; x <= pz.x1; x++) {
            for (const y of [pz.y0, pz.y1]) {
              if (g[y] && g[y][x] !== 1 && !(x === pz.stepX && y === pz.stepY)) gaps++;
            }
          }
          for (let y = pz.y0; y <= pz.y1; y++) {
            for (const x of [pz.x0, pz.x1]) if (g[y] && g[y][x] !== 1) gaps++;
          }
          if (gaps) unreachableKey.push(tag + ` (${gaps} gap(s) in the plaza wall)`);
        }
      }

      // DOCTRINE: every lampstand and the pedestal must be reachable from the door.
      if (ftype === K.FLOOR.doctrine) {
        const ring = K.dungeon._doctrineRing || [];
        if (ring.length !== 5) emptyRing.push(tag + ` (${ring.length} stands)`);
        for (const r of ring) {
          if (!usable(seen, r.x, r.y)) unreachableLamp.push(tag + ` lamp ${r.x},${r.y}`);
          if (!seen.has(r.sy * 1000 + r.sx)) unreachableLamp.push(tag + ` sign ${r.sx},${r.sy}`);
        }
        if (!usable(seen, 7, 5)) unreachablePedestal.push(tag);
      }
    }
  }
}

const N = 10 * SEEDS.length;
ok('no chapel floor throws while generating', crashed.length === 0,
   crashed.slice(0, 3).join(' | ') || `${N} chapels x all floors generated clean`);
ok('every non-sanctum floor has a way onward', noExit.length === 0,
   noExit.slice(0, 3).join(' | ') || 'a real stair on every non-sanctum floor');
ok('the plaza is reachable, walled, and entered only by its steps',
   unreachableKey.length === 0,
   unreachableKey.slice(0, 3).join(' | ') || 'no soft-locked maze floors');
ok('every doctrine ring has five stands', emptyRing.length === 0,
   emptyRing.slice(0, 3).join(' | ') || 'all rings complete');
ok('every lampstand and sign is reachable from the door',
   unreachableLamp.length === 0,
   unreachableLamp.slice(0, 3).join(' | ') || 'no walled-off stands');
ok('the pedestal is always reachable', unreachablePedestal.length === 0,
   unreachablePedestal.slice(0, 3).join(' | ') || 'tablet readable on every doctrine floor');

// ── and now actually FINISH one chapel of each tier, through real input ─────
function solveDoctrine(town) {
  K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.floors=getChapelFloors(${town});
       dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};`);
  const di = K.dungeon.floors.indexOf(K.FLOOR.doctrine);
  if (di < 0) return 'no doctrine floor';
  K.$(`loadDungeonFloor(${di}, false);`);
  for (const c of K.dungeon._candles) {
    K.$(`player.x=${c.x * TP}; player.y=${(c.y - 1) * TP}; player.dir='down';
         dialogue.open=false; menu.open=false;`);
    K.key.tap(' ');
  }
  let seals = 0;
  for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) seals++;
  return seals === 0 ? 'solved' : `${seals} seals left`;
}
for (const town of [3, 5, 8, 9]) {
  ok(`chapel ${town}'s doctrine floor can be solved through real input`,
     solveDoctrine(town) === 'solved', solveDoctrine(town));
}

function openMaze(town) {
  K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.floors=getChapelFloors(${town});`);
  K.$('resetDungeonRun();');
  K.$('loadDungeonFloor(0, false);');
  const pd = K.dungeon._podium;
  if (!pd) return 'no plaza';
  // Find the stone so we can try it with and without the key.
  let sx = -1, sy = -1;
  for (let y = 0; y < K.dungeon.grid.length; y++)
    for (let x = 0; x < K.dungeon.grid[0].length; x++)
      if (K.dungeon.grid[y][x] === K.T_SEAL) { sx = x; sy = y; }
  if (sx < 0) return 'no seal on the floor';

  // 1. the stone must refuse without the key
  K.$(`player.x=${sx * TP}; player.y=${(sy + 1) * TP}; player.dir='up'; dialogue.open=false; menu.open=false;`);
  K.key.tap(' ');
  if (K.dungeon.grid[sy][sx] !== K.T_SEAL) return 'the stone moved without a key';

  // 2. no chest while demons live
  if (K.dungeon.grid[pd.y][pd.x] === K.T_PODIUM_UP) return 'the chest appeared before the floor was clear';

  // 3. clear the floor -> the chest appears
  K.$('demons.forEach(d=>{ d.alive=false; }); updatePodium();');
  if (K.dungeon.grid[pd.y][pd.x] !== K.T_PODIUM_UP) return 'no chest appeared on clear';

  // 4. take the key
  K.$(`player.x=${pd.x * TP}; player.y=${(pd.y + 1) * TP}; player.dir='up'; dialogue.open=false; menu.open=false;`);
  K.key.tap(' ');
  if (!K.dungeon.hasKey) return 'the chest did not give the key';

  // 5. carry it to the stone
  K.$(`player.x=${sx * TP}; player.y=${(sy + 1) * TP}; player.dir='up'; dialogue.open=false; menu.open=false;`);
  K.key.tap(' ');
  if (K.dungeon.hasKey) return 'the key was not spent';
  let seals = 0;
  for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) seals++;
  return seals === 0 ? 'opened' : `${seals} seals left`;
}
for (const town of [0, 1, 2, 6, 9]) {
  ok(`chapel ${town}'s maze floor opens from the key chest`,
     openMaze(town) === 'opened', openMaze(town));
}

// ── where the puzzle debuts ────────────────────────────────────────────────
// Pinned deliberately. townId is 0-based, so `townId<=2` means the first THREE
// chapels have no doctrine floor and the puzzle arrives on chapel FOUR. This
// was a decision, not a drift — if someone later "fixes" the boundary to make
// it chapel three, this fails and they have to mean it.
const debut = [0,1,2,3,4,5,6,7,8,9]
  .findIndex(t => K.getChapelFloors(t).includes(K.FLOOR.doctrine));
ok('the lampstand puzzle debuts on chapel 4 (townId 3)', debut === 3,
   `first doctrine floor at townId ${debut} = chapel ${debut + 1} (${K.TOWN_DATA[debut].general})`);
ok('chapels 1-3 have no doctrine floor',
   [0,1,2].every(t => !K.getChapelFloors(t).includes(K.FLOOR.doctrine)),
   'Aiden, Miriam and Caleb stay maze -> library -> sanctum');
ok('every chapel from 4 on has one',
   [3,4,5,6,7,8,9].every(t => K.getChapelFloors(t).includes(K.FLOOR.doctrine)),
   'no gaps in the back half');

// ── the way out actually works ─────────────────────────────────────────────
// The bug this catches shipped to a playtester: the doctrine floor solved, the
// stone rolled, and the opening led nowhere, because openSeal() rewrites a
// T_SEAL to PLAIN FLOOR and there was no stair behind it. Solving a room is not
// the same as leaving it, so assert the climb, not just the unsealing.
function solveAndClimb(town) {
  K.$(`place={kind:"dungeon"}; dungeon.townId=${town}; dungeon.floors=getChapelFloors(${town});
       dungeon.chests={}; dungeon.candleLit={}; dungeon.rolled={}; dungeon.opened={};`);
  const di = K.dungeon.floors.indexOf(K.FLOOR.doctrine);
  if (di < 0) return 'no doctrine floor';
  K.$(`loadDungeonFloor(${di}, false);`);
  // the stair must be BARRED before the puzzle is done
  if (K.walkable(7, 1)) return 'the stair was open before the puzzle was solved';
  for (const c of K.dungeon._candles) {
    K.$(`player.x=${c.x * TP}; player.y=${(c.y - 1) * TP}; player.dir='down'; dialogue.open=false;`);
    K.key.tap(' ');
  }
  if (K.dungeon.grid[0][7] !== 2) return 'no stair at the head of the room';
  if (!K.walkable(7, 1)) return 'the stone did not clear the approach';
  const before = K.dungeon.floorIdx;
  K.$(`player.x=${7 * TP}; player.y=0;`);
  K.$('checkTransitions();');   // the real transition check, off the movement path
  return K.dungeon.floorIdx > before ? 'climbed' : 'solved but could not leave the room';
}
for (const town of [3, 4, 6, 7, 9]) {
  const r = solveAndClimb(town);
  ok(`chapel ${town + 1}: solving the ring lets you leave`, r === 'climbed', r);
}

// ── state must not bleed between chapels ───────────────────────────────────
// The bug this catches shipped to a playtester: after finishing Deborah's
// chapel, Josiah's opened with its stones already rolled and a lampstand
// already lit. opened/sealed/rolled/candleLit/chests are keyed by FLOOR INDEX
// with no chapel in the key, and loadDungeonFloor strips every T_SEAL from a
// floor whose opened[idx] is set. Every other suite loaded floors in isolation
// and so could never see it — the failure only exists in the SEQUENCE.
function finishChapelThenEnter(townA, townB) {
  // Play chapel A's doctrine floor to completion, the real way.
  K.$(`place={kind:"dungeon"}; dungeon.townId=${townA}; dungeon.floors=getChapelFloors(${townA});`);
  K.$('resetDungeonRun();');
  const dA = K.dungeon.floors.indexOf(K.FLOOR.doctrine);
  K.$(`loadDungeonFloor(${dA}, false);`);
  for (const c of K.dungeon._candles) {
    K.$(`player.x=${c.x * TP}; player.y=${(c.y - 1) * TP}; player.dir='down'; dialogue.open=false;`);
    K.key.tap(' ');
  }
  // Now walk into chapel B exactly as enterChapel() does.
  K.$(`dungeon.townId=${townB}; dungeon.floors=getChapelFloors(${townB}); dungeon.floorIdx=0;`);
  K.$('resetDungeonRun();');
  const dB = K.dungeon.floors.indexOf(K.FLOOR.doctrine);
  K.$(`loadDungeonFloor(${dB}, false);`);
  const lit = K.dungeon.candleLit[dB] || 0;
  let seals = 0;
  for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) seals++;
  return { lit, seals, opened: !!(K.dungeon.opened || {})[dB] };
}
for (const [a, b] of [[3, 4], [4, 5], [6, 7], [8, 9]]) {
  const r = finishChapelThenEnter(a, b);
  ok(`chapel ${b + 1} starts sealed after chapel ${a + 1} was finished`,
     r.seals === 1 && r.lit === 0 && !r.opened,
     `${r.seals} seal(s), ${r.lit} lampstand(s) already lit, opened=${r.opened}`);
}

// The maze floor's key chest must also be unlooted in a fresh chapel.
K.$('place={kind:"dungeon"}; dungeon.townId=3; dungeon.floors=getChapelFloors(3);');
K.$('resetDungeonRun();');
K.$('loadDungeonFloor(0, false);');
const pdA = K.dungeon._podium;
K.$('demons.forEach(d=>{ d.alive=false; }); updatePodium();');
K.$(`player.x=${pdA.x * TP}; player.y=${(pdA.y + 1) * TP}; player.dir='up'; dialogue.open=false;`);
K.key.tap(' ');
K.$('dungeon.townId=4; dungeon.floors=getChapelFloors(4); dungeon.floorIdx=0;');
K.$('resetDungeonRun();');
K.$('loadDungeonFloor(0, false);');
let mazeSeals = 0;
for (const row of K.dungeon.grid) for (const t of row) if (t === K.T_SEAL) mazeSeals++;
ok('a fresh chapel\'s maze floor is still sealed and its podium sunken',
   mazeSeals === 1 && Object.keys(K.dungeon.chests).length === 0
     && K.dungeon._podium && !K.dungeon._podium.risen && !K.dungeon.hasKey,
   `${mazeSeals} seal(s), ${Object.keys(K.dungeon.chests).length} looted, ` +
   `podium risen=${K.dungeon._podium && K.dungeon._podium.risen}`);

ok('every dungeon entry point routes through resetDungeonRun()',
   (src.match(/resetDungeonRun\(\)/g) || []).length >= 5,
   `${(src.match(/resetDungeonRun\(\)/g) || []).length} references (1 definition + 4 entry points)`);

done('chapels');

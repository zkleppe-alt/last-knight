// suite/hgvillage.js — Hellgate Citadel, the last town, and all things made new (2026-10-01 village revamp).
//
// The layout keeps the two great houses and their doors and tidies the court onto the gate's
// axis (hellgateCourt): a paved court, a channel of fire before each door with one bridge
// apiece, the altar on the axis, pits, trees and pillars mirrored (the east pillar used to
// stand inside the keep), an ash margin, the sign just inside the gate, the stray grass gone.
// The art has three states:
//   bound (chapelProgress[9] unset) — the enemy's citadel: basalt, iron spikes, fire, ash, a red night;
//   cleansed — Revelation 21-22: jasper walls set with stones, a pearl gate, a court of gold like
//     clear glass, the river of the water of life, the new earth, the fountain, golden
//     lampstands, trees of life, pillars made whole, the cathedral restored;
//   and Abaddon's Throne stays black until the pretender on it is cast out
//     (bounties.pretenderDefeated); then it is the Redeemed Throne with a rainbow round about it.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('hgvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the court, pinned ──
check('the citadel grid is pinned', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX['Hellgate Citadel']; const rows=[]; for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '1f8b3fdb');
check('inside the walls: ash margin, the court, the fire channels', K.$(`(()=>{ const n={}; for(let y=13;y<=25;y++) for(let x=213;x<=237;x++){ const t=WORLD[y][x]; n[t]=(n[t]||0)+1; } return [n[25],n[27],n[26],n[0]||0]; })()`), [86, 136, 14, 0]);
check('the two great houses keep their places and doors', K.$(`buildings.filter(b=>b.id.startsWith('hg_')).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["hg_chapel",217,13,6,6,219,18],["hg_keep",227,13,7,6,230,18]]);
check('the props, mirrored on the gate\'s axis', K.$(`decorations.filter(d=>hgAt(d.x,d.y)&&!d.hs).map(d=>[d.kind,d.x,d.y,d.w||1])`),
  [["lavaAltar",225,20,2],["emberPit",221,21,1],["emberPit",230,21,1],["charredTree",216,15,1],["charredTree",235,15,1],["brokenPillar",223,23,1],["brokenPillar",228,23,1]]);
ok('no prop stands inside a building any more', K.$(`decorations.filter(d=>hgAt(d.x,d.y)&&!d.hs).every(d=>!buildings.some(b=>b.id.startsWith('hg_')&&d.x>=b.x&&d.x<b.x+b.w&&d.y>=b.y&&d.y<b.y+b.h))`));
ok('every prop footprint is solid', K.$(`decorations.filter(d=>hgAt(d.x,d.y)&&!d.hs).every(d=>{ const w=d.w||1; for(let y=d.y;y<d.y+w;y++) for(let x=d.x;x<d.x+w;x++) if(WORLD[y][x]!==5) return false; return true; })`));
check('a channel of fire before each door, one bridge apiece', K.$(`[[216,217,218,220,221,222,223,228,229,231,232,233,234,235].every(x=>WORLD[19][x]===26), WORLD[19][219], WORLD[19][230], [224,225,226,227].map(x=>WORLD[19][x])]`), [true, 27, 27, [27,27,27,27]]);
check('the gate opens on the Doomway', K.$(`[WORLD[26][225], WORLD[26][226], WORLD[27][225], WORLD[27][226]]`), [27, 27, 2, 2]);
check('the sign stands just inside the gate, words unchanged', K.$(`[WORLD[25][224], signs['224,25'], signs['214,24']===undefined]`), [16, "HELLGATE CITADEL\nAbandon hope — or bring it.", true]);
check('the fly secret\'s crags outside the wall are untouched', K.$(`[WORLD[28][232], WORLD[26][231], WORLD[26][232], WORLD[26][233]]`), [4, 33, 33, 33]);

// ── everyone can get everywhere ──
const reach = K.$(`(()=>{ for(let i=0;i<10;i++) chapelProgress[i]=true;
  const S=new Set(['225,32']), q=[[225,32]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
    if(S.has(k)||X<200||X>250||Y<5||Y>40||!canStep(x,y,X,Y)) continue; S.add(k); q.push([X,Y]); } }
  for(let i=0;i<10;i++) delete chapelProgress[i];
  const near=(x,y)=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,c])=>S.has((x+a)+','+(y+c)));
  let stranded=0; for(let y=13;y<=25;y++) for(let x=213;x<=237;x++) if(WALK.has(WORLD[y][x]) && !S.has(x+','+y)) stranded++;
  return [buildings.filter(b=>b.id.startsWith('hg_')).every(b=>near(b.door.x,b.door.y)), near(224,25), S.has('225,19'), stranded]; })()`);
check('from the Doomway: both doors, the sign and the town centre, nothing stranded', reach, [true, true, true, 0]);
check('the supply wagon drops at the cathedral door', K.$(`(()=>{ delete DELIVERY_POINTS[9]; ensureDeliveryPoints(); const p=DELIVERY_POINTS[9]; return [p.x,p.y]; })()`), [219, 19]);
ok('the fire channels cannot be walked', !K.$(`WALK.has(26)`));

// ── the drawing: bound, cleansed, and the throne redeemed ──
const view = (state) => K.$(`(()=>{ for(let i=0;i<9;i++) chapelProgress[i]=true; if(${state>0}) chapelProgress[9]=true; else delete chapelProgress[9];
  const pd=bounties.pretenderDefeated; bounties.pretenderDefeated=${state>1};
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawHellgateBuilding, B=drawHellgateDecor, C=drawHellgateTile, D=hellgateObjs;
  drawHellgateBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawHellgateDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawHellgateTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  hellgateObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=36; VIEW_TH=24; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=225*TILE; player.y=19*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawHellgateBuilding=A; drawHellgateDecor=B; drawHellgateTile=C; hellgateObjs=D;
    for(let i=0;i<10;i++) delete chapelProgress[i]; bounties.pretenderDefeated=pd; }
  return {err, n}; })()`);
for (const [state, name] of [[0, 'bound'], [1, 'cleansed'], [2, 'the throne redeemed']]) {
  const r = view(state);
  check(`${name}: the whole citadel draws`, r.err, null);
  check(`${name}: both great houses and all seven props wear Hellgate's art`, [r.n.b, r.n.d], [2, 7]);
  ok(`${name}: every tile inside and on the walls is Hellgate's — 405 of them (got ${r.n.t})`, r.n.t >= 400);
  check(`${name}: the sky layer`, r.n.o, 1);
}
const colours = (fn, clean, free) => K.$(`(()=>{ if(${!!clean}) chapelProgress[9]=true; else delete chapelProgress[9]; const pd=bounties.pretenderDefeated; bounties.pretenderDefeated=${!!free};
  const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ ${fn}; } finally{ px=A; delete chapelProgress[9]; bounties.pretenderDefeated=pd; } return [...seen]; })()`);
{ const b = colours(`_hgChannel(0,0,218,19)`, false), c = colours(`_hgChannel(0,0,218,19)`, true);
  check('bound: the channels run with fire', [b.includes(K.$(`HGK.lava`)), b.includes(K.$(`HGK.river`))], [true, false]);
  check('cleansed: the river of the water of life, clear as crystal', [c.includes(K.$(`HGK.lava`)), c.includes(K.$(`HGK.river`))], [false, true]); }
{ const b = colours(`_hgCourt(0,0,224,22)`, false), c = colours(`_hgCourt(0,0,224,22)`, true);
  check('the court: obsidian while bound, gold like clear glass once cleansed', [b.includes(K.$(`HGK.obs`))||b.includes('#26232e'), c.includes(K.$(`HGK.gold`))||c.includes('#f0cc68')], [true, true]); }
{ const b = colours(`_hgWall(0,0,215,12)`, false), c = colours(`_hgWall(0,0,215,12)`, true);
  check('the wall: basalt and iron, then jasper set with stones', [b.includes(K.$(`HGK.bas`)), c.includes(K.$(`HGK.jasp`))], [true, true]); }
const keep = (clean, free) => colours(`_hgKeep(buildings.find(b=>b.id==='hg_keep'),0,100)`, clean, free);
check('Abaddon\'s Throne stays black after the cathedral is cleansed', keep(true, false).includes(K.$(`HGK.obs`)), true);
check('and is the Redeemed Throne once the pretender is cast out', [keep(true, true).includes(K.$(`HGK.white`)), keep(true, true).includes(K.$(`HGK.obs`))], [true, false]);
check('the rainbow stands over the throne only once the pretender is cast out', K.$(`(()=>{ const r=[]; for(const free of [false,true]){ chapelProgress[9]=true; const pd=bounties.pretenderDefeated; bounties.pretenderDefeated=free;
  const o=[]; hellgateObjs(o,(225-18)*TILE,(19-12)*TILE); let arcs=0; const A=ctx.arc; ctx.arc=function(x,y,rad){ if(rad>=40) arcs++; return A.apply(ctx,arguments); };
  try{ o.forEach(q=>q.draw()); } finally{ ctx.arc=A; bounties.pretenderDefeated=pd; delete chapelProgress[9]; } r.push(arcs); } return r; })()`), [0, 6]);

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawHellgateDecor({kind:'emberPit',x:221,y:21,w:1,hs:true},0,0)===false`));
ok('the ash and road outside the walls keep the overworld art', K.$(`drawHellgateTile(25,0,0,211,20)===false && drawHellgateTile(2,0,0,225,27)===false && drawHellgateTile(33,0,0,232,27)===false`));
ok('the box is Hellgate only', K.$(`hgAt(225,19) && !hgAt(217,147) && !hgAt(196,7) && !hgAt(153,68)`));
check('a frame of the real loop in the court', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<9;i++) chapelProgress[i]=true; player.x=225*TILE; player.y=22*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<9;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('hgvillage');

// suite/dgcrypts.js — the chapel crypts, each town in its own stone (2026-10-01).
//
// Zak: "can we work on editing the dungeons to be upgraded as well", then "These are awesome!"
// Drawing only: every chapel floor keeps its map. Each town's crypt matches its village —
// honey sandstone, iron-bound granite, a sea cave, roots, carved sandstone, ice, basalt,
// royal marble, a flooded crypt, obsidian — walls and floor drawn by drawCryptTile, and the
// engine's shared dungeon colours (dungeonTint) set from the same palette so every stair,
// chest, lampstand and seal matches.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('dgcrypts');

const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[];`);
const enter = (town) => K.$(`(()=>{ for(let i=0;i<10;i++) delete chapelProgress[i]; const b=buildings.find(b=>CHAPEL_TOWN[b.id]===${town}); enterChapel(b); demons=[]; return dungeon.floors.length; })()`);

// ── the maps are the maps they were ──
check('every chapel\'s floors are exactly as before the art pass', K.$(`(()=>{ const out=[]; for(let town=0;town<10;town++){ for(let i=0;i<10;i++) delete chapelProgress[i]; const b=buildings.find(b=>CHAPEL_TOWN[b.id]===town); enterChapel(b); let s='';
  for(let fi=0;fi<dungeon.floors.length;fi++){ dungeon.floorIdx=fi; loadDungeonFloor(fi); s+=dungeon.grid.map(r=>r.join(',')).join('|')+'#'; } out.push((${fnv})(s)); } return out; })()`),
  ['61e8ad6f','199217b6','146a869c','55e14937','65c0cb57','3180c010','b753c384','aac94c3e','a1dbef16','a9ea85dd']);

// ── ten crypts, ten stones ──
check('there is one style per town, in town order', K.$(`DG_STYLES.map(s=>s.key)`), ['hearth','iron','sea','roots','sand','ice','basalt','marble','mere','hell']);
check('no two crypts share a wall colour', K.$(`new Set(DG_STYLES.map(s=>s.p.capTop)).size`), 10);
for (let town = 0; town < 10; town++) {
  const nf = enter(town);
  check(`${['Hearthvale','Ironhold','Saltmere','Thornwood','Dusthaven','Crystalpeak','Ashfield','Stormgate','Shadowmere','Hellgate'][town]}: the shared dungeon colours are its crypt\'s`, K.$(`dungeonTint()===DG_STYLES[${town}].p`), true);
  const r = K.$(`(()=>{ const res=[]; for(let fi=0;fi<${nf};fi++){ dungeon.floorIdx=fi; loadDungeonFloor(fi); demons=[];
    let w=null, f=null; for(let y=0;y<DH&&(!w||!f);y++) for(let x=0;x<DW;x++){ const t=dungeon.grid[y][x]; if(t===1&&!w) w=[x,y]; if(t===0&&!f) f=[x,y]; }
    const below=(x,y)=>(dungeon.grid[y+1]&&dungeon.grid[y+1][x]!==undefined)?dungeon.grid[y+1][x]:1;
    const drawn=drawCryptTile(1,0,0,w[0],w[1],below(w[0],w[1])) && drawCryptTile(0,0,0,f[0],f[1],below(f[0],f[1]));
    let err='ok'; try{ player.x=f[0]*TILE; player.y=f[1]*TILE; loop(performance.now()); }catch(e){ err=e.message; }
    res.push(drawn && err==='ok'); } return res; })()`);
  ok(`  …walls and floor drawn in its stone, and a real frame runs, on all ${nf} floors`, r.every(Boolean), JSON.stringify(r));
}

// ── only in the chapels ──
K.$(`enterDisillusionment('north'); demons=[];`);
ok('the Forest of Disillusionment is not a crypt', !K.$(`dgStyleActive()`));
K.$(`place={kind:'overworld'}; setDungeonMode();`);
ok('nor is the open country', !K.$(`dgStyleActive()`));
check('outside a crypt, dungeonTint is the engine\'s own', K.$(`(()=>{ place={kind:'interior'}; const t=dungeonTint(); return DG_STYLES.some(s=>s.p===t); })()`), false);

// ── the cache ──
enter(0);
check('a crypt tile is painted once and reused', K.$(`(()=>{ _dgTiles.clear(); let n=0; const A=_dgFloor; _dgFloor=function(){ n++; return A.apply(null,arguments); };
  let f=null; for(let y=0;y<DH&&!f;y++) for(let x=0;x<DW;x++) if(dungeon.grid[y][x]===0){ f=[x,y]; break; }
  try{ for(let i=0;i<4;i++) drawCryptTile(0,0,0,f[0],f[1],0); } finally{ _dgFloor=A; } return n; })()`), 1);
check('and the cache is cleared when the floor changes', K.$(`(()=>{ drawCryptTile(0,0,0,1,1,0); const a=_dgKey; dungeon.floorIdx=1; loadDungeonFloor(1); drawCryptTile(0,0,0,1,1,0); return a!==_dgKey; })()`), true);

done('dgcrypts');

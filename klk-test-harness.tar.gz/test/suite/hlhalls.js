// suite/hlhalls.js — the sanctuaries and the throne hall, redrawn (2026-10-01).
//
// Zak: "Let's do the cleansed chapel interiors and throne room now!", then "Awesome!"
// Drawing only. Each town's cleansed chapel is its own church (walls, floor, pews, cloth,
// stained glass, the town's sign on the pulpit); the throne hall (the ending ceremony and the
// walkable Stormgate Keep) has a marble floor, gilded pillars, tall windows, a rose window and
// canopy over the throne, and chandeliers. Every room, seat and person is where it was.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('hlhalls');

const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; for(let i=0;i<10;i++) chapelProgress[i]=true;`);

// ── the sanctuaries ──
check('ten sanctuary styles, one per town', K.$(`SANCT.length`), 10);
check('each town\'s sanctuary has its own walls, cloth and sign', K.$(`[new Set(SANCT.map(s=>s.wall)).size, new Set(SANCT.map(s=>s.cloth)).size, new Set(SANCT.map(s=>s.sign)).size]`), [10, 10, 10]);
const room = K.$(`(()=>{ const b=buildings.find(b=>CHAPEL_TOWN[b.id]===0); enterChapel(b); dialogue.open=false; const f=INTERIORS[place.id].floors[0]; return (${fnv})(f.g.map(r=>r.join(',')).join('|')); })()`);
for (let town = 0; town < 10; town++) {
  const r = K.$(`(()=>{ dialogue.open=false; const b=buildings.find(b=>CHAPEL_TOWN[b.id]===${town}); enterChapel(b); dialogue.open=false;
    const I=INTERIORS[place.id], f=I.floors[0], kinds=new Set(); f.g.forEach(r=>r.forEach(t=>kinds.add(t)));
    const allDrawn=[...kinds].every(t=>{ for(let y=0;y<f.h;y++) for(let x=0;x<f.w;x++) if(f.g[y][x]===t) return drawSanctuaryTile(t,0,0,x,y); return false; });
    let err='ok'; try{ loop(performance.now()); }catch(e){ err=e.message; }
    const r=[place.id, sanctTown(), (${fnv})(f.g.map(r=>r.join(',')).join('|')), allDrawn, I.npcs.map(n=>n.x+','+n.y).join(' '), err];
    place={kind:'overworld'}; returnStack.length=0; return r; })()`);
  check(`town ${town}: its sanctuary, the same room and people, every tile in its style, a real frame runs`, r, [`sanct${town}`, town, room, true, '6,3 7,9 5,12', 'ok']);
}
ok('the old sanctuary overlay now only adds the light', /if\(sanctTown\(\)>=0\)\{ sanctuaryLight\(camX,camY\); return; \}/.test(require('fs').readFileSync(require('path').join(__dirname,'..','..','index.html'),'utf8')));
ok('a sanctuary tile outside a sanctuary is left alone', K.$(`(()=>{ place={kind:'interior', id:'tobias', floor:0}; const r=drawSanctuaryTile(12,0,0,3,3); place={kind:'overworld'}; return r===false; })()`));

// ── the throne hall: the same crowd, guards, heralds, braziers and banners as before ──
const tally = (useNew, quiet) => K.$(`(()=>{ initThroneScene(); const n={v:0,g:0,tr:0,k:0}; const A=drawVillager, B=drawRoyalGuard, C=drawTrumpeter, D=drawKingLuminar, H=drawThroneHall;
  drawVillager=function(){ n.v++; }; drawRoyalGuard=function(x,y,d){ n.g++; n.gp=(n.gp||'')+Math.round(x)+','+Math.round(y)+d+' '; }; drawTrumpeter=function(){ n.tr++; }; drawKingLuminar=function(){ n.k++; };
  if(!${useNew}) drawThroneHall=undefined;
  let err='ok'; try{ drawThroneScene(0,0,1000,${quiet}); }catch(e){ err=e.message; } finally{ drawVillager=A; drawRoyalGuard=B; drawTrumpeter=C; drawKingLuminar=D; drawThroneHall=H; }
  return [n.v,n.g,n.tr,n.k,n.gp,err]; })()`);
const cOld = tally(false, false), cNew = tally(true, false);
check('the ceremony: the same crowd, guards (in the same places), heralds and King', cNew, cOld);
ok(`  …that is ${cNew[0]} citizens, ${cNew[1]} guards, ${cNew[2]} heralds and the King`, cNew[0] > 40 && cNew[1] === 6 && cNew[2] === 6 && cNew[3] === 1);
check('the walkable Keep: the same quiet hall', tally(true, true), tally(false, true));
check('the ending scene draws through the new hall', K.$(`(()=>{ let n=0; const H=drawThroneHall; drawThroneHall=function(){ n++; return H.apply(null,arguments); }; try{ startThroneCutscene(); cutscene.fade=0; drawThrone(); } finally{ drawThroneHall=H; } cutscene.active=false; place={kind:'overworld'}; return n; })()`), 1);
check('a frame of the real loop in the Keep', K.$(`(()=>{ const k=buildings.find(b=>b.id==='sg_keep'); enterKeep(k); let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } exitKeep(); return [r, place.kind]; })()`), ['ok', 'overworld']);

done('hlhalls');

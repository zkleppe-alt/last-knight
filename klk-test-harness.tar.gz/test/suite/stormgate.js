// suite/stormgate.js — Ruth's hall, and what was actually in it.
//
// "She kept the finest walls in the realm and lost the flock inside them. She
// counted stones and not sheep… When the Thunder Lord struck, it struck a
// building, and a building was all that was there to fall."
//
// So your health is not the resource on this floor. The bolts come down on Ruth's
// people, never on you, and the fight is whether you are standing over them when
// one lands. You have a shield; they do not.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('stormgate');

const T = K.TILE;
function fresh() {
  const g = K.genStormgateArena();
  globalThis.__sg = g;
  K.$('place={kind:"dungeon"}; dungeon.townId=7; dungeon.grid=globalThis.__sg; DH=dungeon.grid.length; DW=dungeon.grid[0].length; dungeon.bossDead=false; dungeon.adds=[]; dungeon._flockInit=false; dungeon._bolt=null; dungeon._boltT=0; dungeon._flockLost=0; player.iframes=0; player.blocking=false; player.def=0; player.maxHp=9999; player.hp=9999;');
  K.$('stormTick();');                     // spawns the flock
  return g;
}
const g = fresh();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

const cols = K.dungeon._columns;
check('eight columns', cols.length, 8);
ok('the finest walls in the realm are solid', cols.every(c => !K.walkable(c.x, c.y)));

// ── the aisles have to be crossable, fast ─────────────────────────────────
// The fight is getting across the room to stand over someone inside the fuse.
function geom() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  let open = 0, reach = 0, pockets = 0;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!K.walkable(x, y)) continue;
    open++; if (seen.has(y * 100 + x)) reach++;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pockets++;
  }
  return { open, reach, pockets, seen };
}
const gm = geom();
ok('everything reachable', gm.open === gm.reach, `${gm.reach}/${gm.open}`);
ok('no dead-end pocket', gm.pockets === 0, `${gm.pockets}`);

// The warning has to be long enough to actually cross the hall.
const SPEED = 1.5;                                  // px/frame, the knight's base
const reachablePx = K.BOLT_FUSE * SPEED;
const hallDiagonal = Math.hypot(W * T, H * T);
ok('the warning is long enough to cross the room', reachablePx > hallDiagonal * 0.55,
   `${K.BOLT_FUSE} frames = ${Math.round(reachablePx)}px of running vs a ${Math.round(hallDiagonal)}px hall`);

// ── the flock ─────────────────────────────────────────────────────────────
const flock = K.dungeon.adds.filter(a => a.flock);
check('five of Ruth\'s people', flock.length, K.FLOCK_N);
ok('they all start alive', flock.every(f => f.alive));
ok('they all start on open ground',
   flock.every(f => K.walkable(Math.floor(f.x / T), Math.floor(f.y / T))));

// They are people, not targets: the player's own sword must never touch them.
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('your sword cannot hit them',
   /if\(a\.flock\) return;\s*\/\/ Stormgate: these are Ruth's people, not targets/.test(raw));
ok('and they never chase or touch the knight',
   /if\(a\.flock\)\{[\s\S]{0,400}a\.wander\+=/.test(raw),
   'they drift; the danger in this room is what comes down on them');

// ── the bolt goes for them, not for you ───────────────────────────────────
fresh();
for (let i = 0; i < K.BOLT_EVERY + 2; i++) K.$('stormTick();');
const bolt = K.dungeon._bolt;
ok('it picks one of them out', !!bolt && !!bolt.target, 'a bolt is marked');
ok('the mark is on a person, never on the knight',
   bolt && bolt.target.flock === true);
ok('and there is a fuse to run in', bolt && bolt.t > 0, `${bolt ? bolt.t : 0} frames left`);

// ── stand over them and they live ─────────────────────────────────────────
K.$('player.x = dungeon._bolt.target.x; player.y = dungeon._bolt.target.y;');
const target = bolt.target;
const hpBefore = K.player.hp;
for (let i = 0; i < K.BOLT_FUSE + 2; i++) K.$('stormTick();');
ok('standing over them, YOU take it', K.player.hp < hpBefore,
   `hp ${hpBefore} -> ${K.player.hp}`);
ok('and they are still here', target.alive === true);
check('none lost', K.dungeon._flockLost, 0);

// ── ignore it and you lose one ────────────────────────────────────────────
fresh();
for (let i = 0; i < K.BOLT_EVERY + 2; i++) K.$('stormTick();');
const t2 = K.dungeon._bolt.target;
K.$('player.x=1*TILE; player.y=9*TILE;');          // across the hall, counting stones
const hp2 = K.player.hp;
for (let i = 0; i < K.BOLT_FUSE + 2; i++) K.$('stormTick();');
ok('stay away and the bolt takes them', t2.alive === false);
ok('and it costs you no health at all', K.player.hp === hp2,
   'which is the point — a building was all that was there to fall');
check('one lost', K.dungeon._flockLost, 1);

// ── the emptier the room, the bolder it gets ──────────────────────────────
function gapAt(lost) {
  fresh();
  K.$(`dungeon._flockLost=${lost};`);
  K.$('player.x=1*TILE; player.y=9*TILE;');
  let n = 0;
  while (!K.dungeon._bolt && n < 1000) { K.$('stormTick();'); n++; }
  return n;
}
const gapFull = gapAt(0), gapEmpty = gapAt(K.FLOCK_N - 1);
ok('losing people makes the strikes come faster', gapEmpty < gapFull,
   `${gapFull} frames between strikes at full flock, ${gapEmpty} when nearly empty`);

// ── with nobody left, it has nothing to strike at ─────────────────────────
fresh();
K.$('for(const a of dungeon.adds) if(a.flock) a.alive=false;');
for (let i = 0; i < 600; i++) K.$('stormTick();');
ok('an empty hall draws no more bolts', !K.dungeon._bolt,
   'the finest walls in the realm, and nobody left inside them');

// ── it must be legible ────────────────────────────────────────────────────
ok('the mark is drawn on the PERSON, not on the ground',
   /function drawStorm\(camX, camY\)/.test(raw) && /b\.target && b\.target\.alive/.test(raw),
   'the thing you are asked to protect is the thing that lights up');
ok('the tally is drawn — it is the real score of this fight',
   /i<left \? '#e8dcbb' : '#3a3448'/.test(raw));


// ── serving them IS the weapon ─────────────────────────────────────────────
// Stormgate is the capital and its guardian is not beaten by being hit. An
// uncharged blade does nothing at all; the only charge in the room comes from
// taking a bolt meant for one of Ruth's people. The fight cannot be won by
// ignoring the flock, which is the doctrine of the floor stated as a rule.
function wraithlessBoss() {
  return { boss: true, alive: true, hp: 100, maxHp: 100, level: 20, x: 7 * T, y: 5 * T, state: 'idle' };
}
fresh();
K.$('player.charge=0; player.chargeT=0;');
ok('an uncharged blade is not charged', K.$('chargedBlade()') === false);
globalThis.__tb = wraithlessBoss();
const hp0 = globalThis.__tb.hp;
K.$('applyDemonHit(globalThis.__tb, 30, false, 1, 0, 1, 2);');
ok('and it does nothing to the Thunder Lord', globalThis.__tb.hp === hp0,
   `hp ${globalThis.__tb.hp} — "nothing here answers to steel alone"`);

// Intercepting a bolt charges it.
fresh();
for (let i = 0; i < K.BOLT_EVERY + 2; i++) K.$('stormTick();');
K.$('player.x = dungeon._bolt.target.x; player.y = dungeon._bolt.target.y;');
const saved = K.dungeon._bolt.target;
for (let i = 0; i < K.BOLT_FUSE + 2; i++) K.$('stormTick();');
ok('taking the bolt for them charges the blade', K.$('chargedBlade()') === true,
   `${K.player.charge} strikes`);
check('three strikes', K.player.charge, K.CHARGE_STRIKES);
ok('and they survived it', saved.alive === true);

// A charged blade bites, and each strike spends one.
globalThis.__tb = wraithlessBoss();
K.$('applyDemonHit(globalThis.__tb, 30, false, 1, 0, 1, 2);');
ok('a charged blade lands for full damage', globalThis.__tb.hp === 70,
   `hp ${globalThis.__tb.hp}`);
check('a strike is spent', K.player.charge, K.CHARGE_STRIKES - 1);
K.$('applyDemonHit(globalThis.__tb, 30, false, 1, 0, 1, 2);');
K.$('applyDemonHit(globalThis.__tb, 30, false, 1, 0, 1, 2);');
check('all three land', globalThis.__tb.hp, 10);
ok('and then the charge is gone', K.$('chargedBlade()') === false,
   `charge ${K.player.charge}`);
const hpSpent = globalThis.__tb.hp;
K.$('applyDemonHit(globalThis.__tb, 30, false, 1, 0, 1, 2);');
ok('a fourth swing does nothing', globalThis.__tb.hp === hpSpent);

// It lapses on a clock too, so you cannot bank it.
fresh();
K.$(`player.charge=${K.CHARGE_STRIKES}; player.chargeT=performance.now()-1;`);
ok('the charge lapses with time, not only with use',
   K.$('chargedBlade()') === false, `after ${(K.CHARGE_MS/1000).toFixed(1)}s`);

// And it never leaves this chapel.
K.$(`player.charge=${K.CHARGE_STRIKES}; player.chargeT=performance.now()+99999;`);
K.$('place={kind:"overworld"}; stormTick();');
ok('the charge does not leave Stormgate', (K.player.charge || 0) === 0,
   'it is not a buff to carry into the next chapel');

// The player has to be able to SEE that they are armed.
ok('the blade is drawn arcing while charged',
   /dungeon\.townId===7 && chargedBlade\(\)/.test(raw2()) && /THE CHARGE ON THE BLADE/.test(raw2()));
ok('and the strikes remaining are shown', /CHARGED x/.test(raw2()));
function raw2() { return require('fs').readFileSync(__dirname + '/../game.js', 'utf8'); }


// ── the reward for keeping them ────────────────────────────────────────────
// Ruth kept the finest walls and lost the flock inside them. Keep the other
// thing and you are given the plate for it. It hangs off the LIVERY system that
// already exists rather than a parallel wardrobe, so it shows up in the Home tab
// beside the others and can be worn or not as the player likes.
ok('the Stormward Plate is a real livery', !!K.LIVERIES.stormward,
   K.LIVERIES.stormward && K.LIVERIES.stormward.name);
ok('it is unlocked by a FLAG, never by trade',
   K.LIVERIES.stormward.flag === 'stormward' && (K.LIVERIES.stormward.req || 0) === 0,
   'it cannot be bought');

K.$('player.stormward=false;');
ok('locked until it is earned', K.$('liveryUnlocked("stormward")') === false);
K.$('player.livery="stormward";');
ok('and cannot be worn early', K.$('currentLivery()') === 'azure',
   'currentLivery falls back when the livery is not unlocked');

K.$('player.stormward=true;');
ok('unlocked once earned', K.$('liveryUnlocked("stormward")') === true);
ok('and then it can be worn', K.$('currentLivery()') === 'stormward');

// It has to survive closing the tab, or it is not a reward.
K.$('player.stormward=true; player.livery="stormward";');
globalThis.__sd = K.$('buildSaveData()');
ok('it is written into the save', globalThis.__sd.stormward === true);
K.$('player.stormward=false; player.livery="azure";');
K.$('applySaveData(globalThis.__sd);');
ok('and comes back on load', K.player.stormward === true && K.player.livery === 'stormward');

// Awarded only for a clean hall.
const rawR = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('it is awarded only when NOBODY was lost',
   /lost===0 && left>=FLOCK_N/.test(rawR),
   'both checked: none lost, and all five still standing');
ok('awarded at the moment the guardian falls',
   /dungeon\.townId===7 && !player\.stormward/.test(rawR),
   'the only point at which "nobody was lost" is finally true');
ok('and it saves immediately', /player\.stormward=true; player\.livery='stormward'; saveGame\(\);/.test(rawR));


// ── the skin is cosmetic, and must stay out of the mechanic's way ──────────
const rawS = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('the Stormward crest is a bolt, not a plume — a SHAPE the livery table cannot express',
   /currentLivery\(\)==='stormward'/.test(rawS) && /THE STORMWARD CREST/.test(rawS));
ok('sparks come off the armour while walking', /if\(player\.moving\)\{/.test(rawS));
ok('the blade and shield carry a charge at all times',
   /the blade and the shield, always charged/.test(rawS));
ok('and there is an aura, so it reads even standing still',
   /an aura, so it reads even standing still/.test(rawS));

// The important one. In Stormgate's sanctum, arcs on the blade mean "you can
// hurt the Thunder Lord right now". A skin that sparkles permanently would
// drown that signal, so it goes quiet in exactly that room.
ok('the skin effect is SUPPRESSED in Stormgate\'s sanctum',
   /const _sw = currentLivery\(\)==='stormward'[\s\S]{0,200}FLOOR\.sanctum/.test(rawS),
   'the mechanic owns the arcs there, not the cosmetic');
ok('and it changes no damage anywhere',
   !/currentLivery\(\)==='stormward'[\s\S]{0,400}(player\.atk|dmg\s*\*|damage)/.test(rawS),
   'purely a skin');

done('stormgate');

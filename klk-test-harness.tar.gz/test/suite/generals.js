// suite/generals.js — the ten bound generals, and what happens when they fall.
//
// Every one of them is held by the thing that undid them: Caleb over his own
// flood, Lydia frozen into the wall she worked at, Deborah by the root that was
// under her floor, Michael by a weight he is holding up.
// When the guardian dies, whatever holds him lets go and he comes down onto the
// floor of his own sanctum. Only then can you go to him.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');

console.log('generals');
const raw = fs.readFileSync(__dirname + '/../game.js', 'utf8');

// ── every general has a binding of his own ────────────────────────────────
ok('there is a binding routine', /function drawGeneralBind\(x, y, town, freed, fall\)/.test(raw));
const bindBlock = raw.slice(raw.indexOf('function drawGeneralBind'),
                            raw.indexOf('function drawFallenGeneral'));
for (let t = 0; t < 9; t++) {
  ok(`chapel ${t + 1} has its own case`, new RegExp(`case ${t}:`).test(bindBlock),
     (K.TOWN_DATA[t].general || '').replace('General ', ''));
}
ok('and the tenth falls through to the default', /default: \/\/ HELLGATE/.test(bindBlock));
ok('the binding is drawn BEHIND the man',
   raw.indexOf('drawGeneralBind(sx, sy') < raw.indexOf('drawFallenGeneral(sx, sy'),
   'so it is around him, not over him');
ok('and it stays visible once broken, faded rather than gone',
   /const a = freed \? 0\.42 : 1;/.test(bindBlock),
   'you should be able to see what held him');

// ── the fall ──────────────────────────────────────────────────────────────
ok('the guardian dying starts it', /startGeneralFall\(\);   \/\/ whatever held him lets go/.test(raw));
ok('it is ticked every frame in a dungeon', /if\(place\.kind==='dungeon'\) generalFallTick\(dt\);/.test(raw));
ok('and a fresh run puts him back on the wall',
   /dungeon\._genFall = null; dungeon\._genDown = false;/.test(raw),
   'resetDungeonRun clears it, or a retry starts with him already down');

// Drive it in all ten sanctums. He must land somewhere the knight can WALK to —
// a general who falls into a chasm, a lectern or the flood is unreachable and
// the chapel cannot be finished.
for (let town = 0; town < 10; town++) {
  K.$('boot.done=true; place={kind:"dungeon"}; dungeon.townId=' + town + '; dungeon.floors=getChapelFloors(' + town + '); resetDungeonRun();');
  K.$('loadDungeonFloor(' + K.getChapelFloors(town).indexOf(K.FLOOR.sanctum) + ', false);');
  const g = K.dungeon.grid;
  let before = null;
  for (let y = 0; y < g.length; y++) for (let x = 0; x < g[0].length; x++) if (g[y][x] === 7) before = [x, y];

  K.$('startGeneralFall();');
  ok(`${K.TOWN_DATA[town].general}: the fall starts`, !!K.dungeon._genFall);
  let t = 0;
  while (K.dungeon._genFall && t < 4000) { K.$('generalFallTick(16);'); t += 16; }

  let after = null;
  for (let y = 0; y < g.length; y++) for (let x = 0; x < g[0].length; x++) if (g[y][x] === 7) after = [x, y];
  // he must have MOVED, and must be standable-adjacent from the knight's spawn
  const seen = new Set([9 * 100 + 7]); const st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= g[0].length || ny >= g.length) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  const adj = [[1,0],[-1,0],[0,1],[0,-1]].some(([dx, dy]) => seen.has((after[1] + dy) * 100 + (after[0] + dx)));
  ok(`${K.TOWN_DATA[town].general}: comes down off the wall`,
     after[1] > before[1], `${before[1]} -> ${after[1]}`);
  ok(`${K.TOWN_DATA[town].general}: lands where the knight can reach him`, adj,
     `at ${after[0]},${after[1]}`);
  ok(`${K.TOWN_DATA[town].general}: and is marked down`, K.dungeon._genDown === true);
}

// ── he cannot be talked to in mid-air ─────────────────────────────────────
ok('the trial waits until he has landed',
   /if\(dungeon\._genFall\)\{[\s\S]{0,140}he is still coming down/.test(raw),
   'talking to a man who is still falling reads as a bug');
ok('and before the guardian dies he tells you so',
   /binds me — strike it down first/.test(raw));

// ── the landing spot is found by real walkability ─────────────────────────
ok('the landing tile is chosen with walkable(), not a whitelist',
   /while\(ty<g\.length-1 && !walkable\(gx,ty\)\) ty\+\+;/.test(raw),
   'a hand-written list did not know Saltmere\'s counting-stones and dropped him in the water');

done('generals');

// suite/lists3d.js — the knight tourneys from behind the knight, and the joust (2026-10-07, tag 2026-10-07-tj).
//
// Zak: the tourneys "in a similar view as the other minigames - but combat", with the knight's own moves and weapons;
// circle the foe in duels, an open arena for the melee; the stick with Ⓐ and Ⓑ; a jousting round (its own contest and
// the Grand Tournament's opening bout); knock out the health; no potions.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('lists3d');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; hunt.done=true; player.equip.weapon='ironsword';`);
const start = (mode, keep) => K.$(`(()=>{ tourney.active=false; tourney.joust=null; place={kind:'overworld'}; startTourney('${keep||'sg_keep'}','${mode}'); return [place.kind, tourney.active, !!tourney.joust]; })()`);
const stop = () => K.$(`(()=>{ tourney.active=false; tourney.joust=null; place={kind:'overworld'}; return 1; })()`);

// ── the contests ──
check('the marshal offers four contests, the joust among them', K.$(`TOURNEY_MODES.map(m=>m.mode)`), ['ladder', 'joust', 'duel', 'waves']);
check('the joust is its own contest', start('joust'), ['tourney', true, true]);
check('the Grand Tournament opens with a joust', start('ladder'), ['tourney', true, true]);
check('a single duel is fought on foot', start('duel'), ['tourney', true, false]);
check('the grand melee is fought on foot', start('waves'), ['tourney', true, false]);

// ── the arena and the stick ──
start('duel');
ok('a duel starts a few paces apart, the challenger in front of you', K.$(`(()=>{ const fo=tourney.foes[0]; const d=Math.hypot(fo.x-tourney.px,fo.y-tourney.py); return d>20 && d<70 && fo.y<tourney.py; })()`));
check('locked on: ◀ ▶ circle him (the distance holds while the angle turns)', K.$(`(()=>{ const fo=tourney.foes[0]; fo.ai=0; const d0=Math.hypot(fo.x-tourney.px,fo.y-tourney.py), a0=Math.atan2(tourney.py-fo.y,tourney.px-fo.x);
  for(let i=0;i<30;i++){ fo.ai=0; fo.x=fo.x; tourney.held={RIGHT:true}; tourneyTick(16.67); } tourney.held={};
  const d1=Math.hypot(fo.x-tourney.px,fo.y-tourney.py), a1=Math.atan2(tourney.py-fo.y,tourney.px-fo.x); return [Math.abs(d1-d0)<12, Math.abs(a1-a0)>0.2]; })()`), [true, true]);
check('locked on: ↑ closes in', K.$(`(()=>{ const fo=tourney.foes[0]; const d0=Math.hypot(fo.x-tourney.px,fo.y-tourney.py); for(let i=0;i<10;i++){ fo.ai=0; tourney.held={UP:true}; tourneyTick(16.67); } tourney.held={}; return Math.hypot(fo.x-tourney.px,fo.y-tourney.py)<d0; })()`), true);
start('waves');
check('in the melee ◀ ▶ turn him and ↑ walks the way he faces', K.$(`(()=>{ const h0=tourney.heading; for(let i=0;i<20;i++){ tourney.held={LEFT:true}; tourneyTick(16.67); } const turned=tourney.heading<h0;
  const x0=tourney.px, y0=tourney.py, h=tourney.heading; for(let i=0;i<10;i++){ tourney.held={UP:true}; tourneyTick(16.67); } tourney.held={};
  const dx=tourney.px-x0, dy=tourney.py-y0; return [turned, (dx*Math.cos(h)+dy*Math.sin(h))>5]; })()`), [true, true]);
check('the arena is round: nobody leaves it', K.$(`(()=>{ tourney.px=-500; tourney.py=-500; tourney.foes[0].x=9999; tourneyTick(16.67); const c=[VW/2,VH/2], R=Math.min(VW,VH)/2-14;
  return [Math.hypot(tourney.px-c[0],tourney.py-c[1])<=R, Math.hypot(tourney.foes[0].x-c[0],tourney.foes[0].y-c[1])<=R+1]; })()`), [true, true]);

// ── the knight's own moves ──
start('waves');
check('Ⓐ Ⓐ Ⓐ: the third blow in a row is the Ground Pound, round about him', K.$(`(()=>{ tourney.foes.forEach((fo,i)=>{ fo.x=tourney.px+(i?-14:14); fo.y=tourney.py; fo.hp=fo.maxHp=999; fo.alive=true; fo.ai=0; });
  const hit=()=>{ tourneyPress('A'); for(let i=0;i<15;i++) tourneyTick(16.67); };
  hit(); hit(); const before=tourney.foes.map(f=>f.hp); tourneyPress('A'); const after=tourney.foes.map(f=>f.hp);
  return [tourney.callout, after.every((h,i)=>h<before[i])]; })()`), ['GROUND POUND!', true]);
start('duel');
const blow = (setup) => K.$(`(()=>{ const fo=tourney.foes[0]; fo.x=tourney.px; fo.y=tourney.py-16; fo.hp=fo.maxHp=999; fo.ai=0; fo.wind=0; fo.lunge=0; fo.knock=0; fo.stagger=0; fo.recover=0; fo.clangs=0;
  tourney.combo=0; tourney.comboT=0; tourney.swing=0; tourney.pdir='up'; ${setup}; const h=fo.hp; tourneyPress('A'); return h-fo.hp; })()`);
const avg = (setup) => { let t = 0; for (let i = 0; i < 10; i++) t += blow(setup); return t / 10; };
const onGuard = avg(''), onWind = avg('fo.wind=1'), onStagger = avg('fo.stagger=30');
ok('a blow on his raised shield does about a fifth; he\'s open while he winds up or staggers (ten blows each)', onGuard > 0 && onWind >= onGuard * 3.5 && onStagger >= onGuard * 3.5, `${onGuard} / ${onWind} / ${onStagger}`);
check('hammer his shield three times and he ripostes', K.$(`(()=>{ const fo=tourney.foes[0]; fo.x=tourney.px; fo.y=tourney.py-16; fo.ai=0; fo.wind=0; fo.lunge=0; fo.clangs=0; fo.stagger=0; fo.recover=0; fo.knock=0; fo.hp=fo.maxHp=999; fo.alive=true; tourney.php=tourney.pmax; const p0=tourney.php;
  for(let k=0;k<3;k++){ tourney.combo=0; tourney.comboT=0; tourney.swing=0; fo.knock=0; tourneyPress('A'); } return [tourney.php<p0, tourney.callout]; })()`), [true, 'RIPOSTE! HE TURNS YOUR BLADE']);
start('duel');
check('a challenger only hurts you with his attack, not by standing near you', K.$(`(()=>{ const fo=tourney.foes[0]; const p0=tourney.php; fo.x=tourney.px; fo.y=tourney.py-6; for(let i=0;i<60;i++){ fo.ai=10; fo.x=tourney.px; fo.y=tourney.py-6; tourneyTick(16.67); } return tourney.php===p0; })()`), true);
check('raise the shield late in his wind-up and you parry him — and he staggers, open', K.$(`(()=>{ const fo=tourney.foes[0]; const p0=tourney.php; tourney.inv=0; fo.cd=0; fo.x=tourney.px; fo.y=tourney.py-10; fo.ai=112;
  for(let i=0;i<14;i++){ if(fo.ai>=112 && !tourney.guard) tourneyGuard(true); fo.x=tourney.px; fo.y=tourney.py-10; tourneyTick(16.67); } tourneyGuard(false); return [tourney.php===p0, fo.stagger>0]; })()`), [true, true]);
check('caught mid-swing by his lunge: a counter-hit, half again', K.$(`(()=>{ start0(); const fo=tourney.foes[0]; const run=(swinging)=>{ tourney.php=tourney.pmax; tourney.inv=0; fo.cd=0; fo.ai=121; fo.x=tourney.px; fo.y=tourney.py-8; tourney.swing=swinging?10:0; tourneyGuard(false); const p0=tourney.php; tourneyTick(16.67); return p0-tourney.php; };
  const a=run(false), b=run(true); return [a>0, b>=Math.round(a*1.4)]; })()`.replace('start0();', `tourney.active=false; startTourney('sg_keep','duel');`)), [true, true]);
check('no potions between bouts: Ⓑ does nothing and the belt is untouched', K.$(`(()=>{ start1(); tourney.rest=true; inventory.potion=3; tourney.php=10; tourneyPress('B'); return [inventory.potion, tourney.php]; })()`.replace('start1();', `tourney.active=false; startTourney('sg_keep','ladder'); tourney.joust=null;`)), [3, 10]);
check('yielding takes a long, deliberate hold of Ⓑ (you hold the shield up while you wait for his tell)', K.$(`TOURNEY_YIELD_MS`), 3000);

// ── the joust ──
const pass = (strikeAt, aimOn, brace) => K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','joust'); const J=tourney.joust; let t=0;
  while(J.phase==='charge' && t<400){ t++; tourney.held={}; const sh=[Math.sin(J.t*0.05+J.pass*1.7)*0.45, Math.sin(J.t*0.037+J.pass)*0.25];
    if(${aimOn}){ J.aimX=sh[0]; J.aimY=sh[1]; } else { J.aimX=1; J.aimY=-1; }
    if(${brace}) tourneyGuard(true);
    if(!J.struck && J.gap<=${strikeAt}) tourneyPress('A'); tourneyTick(16.67); }
  tourneyGuard(false); return [100-J.foe, 100-J.me, J.said]; })()`);
const square = pass(36, true, false), early = pass(200, true, false), wide = pass(36, false, false), braced = pass(36, true, true);
ok('lance on his shield, struck as you meet: a heavy blow', square[0] >= 38, JSON.stringify(square));
ok('struck too early: nothing', early[0] === 0, JSON.stringify(early));
ok('struck in time but off his shield: nothing', wide[0] === 0, JSON.stringify(wide));
ok('braced: his blow lands at a third, yours at two thirds', braced[1] < square[1] * 0.5 && braced[0] < square[0], `${braced} vs ${square}`);
check('three passes, then it\'s settled', K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','joust'); const J=tourney.joust; const g0=gold; let t=0;
  while(tourney.active && !tourney.result && t<3000){ t++; const sh=[Math.sin(J.t*0.05+J.pass*1.7)*0.45, Math.sin(J.t*0.037+J.pass)*0.25]; J.aimX=sh[0]; J.aimY=sh[1]; if(J.phase==='charge'&&!J.struck&&J.gap<=36) tourneyPress('A'); tourneyTick(16.67); }
  const card=!!(tourney.result&&tourney.result.win); for(let i=0;i<80;i++) tourneyTick(16.67); tourneyPress('A');
  return [card, tourney.active, J.pass, gold>g0]; })()`), [true, false, 3, true]);
check('winning the Grand Tournament\'s joust goes on to bout 2, on foot', K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','ladder'); const J=tourney.joust; let t=0;
  while(tourney.joust && t<3000){ t++; const sh=[Math.sin(J.t*0.05+J.pass*1.7)*0.45, Math.sin(J.t*0.037+J.pass)*0.25]; J.aimX=sh[0]; J.aimY=sh[1]; if(J.phase==='charge'&&!J.struck&&J.gap<=36) tourneyPress('A'); tourneyTick(16.67); }
  const rest=tourney.rest; for(let i=0;i<45;i++) tourneyTick(16.67); tourneyPress('A'); return [rest, tourney.round, !!tourney.joust, tourney.foes.length]; })()`), [true, 2, false, 1]);

// ── skill decides it: a bot knight ──
function fight(mode, style) {
  return K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','${mode}'); let t=0, out='?'; const _ex=exitTourney; exitTourney=function(w,f){ out=w?'WIN':f?'YIELD':'LOST'; _ex(w,f); };
    try{ while(tourney.active && !tourney.result && t<20000){ t++;
      if(tourney.rest){ tourneyTick(16.67); tourneyPress('A'); continue; }
      if(tourney.joust){ const J=tourney.joust; tourney.held={};
        if('${style}'==='skill'){ const sh=[Math.sin(J.t*0.05+J.pass*1.7)*0.45, Math.sin(J.t*0.037+J.pass)*0.25]; tourney.held.LEFT=J.aimX>sh[0]+0.03; tourney.held.RIGHT=J.aimX<sh[0]-0.03; tourney.held.UP=J.aimY>sh[1]+0.03; tourney.held.DOWN=J.aimY<sh[1]-0.03;
          if(J.phase==='charge' && !J.struck && J.gap<=38 && J.gap>=30) tourneyPress('A'); }
        else if(J.phase==='charge' && !J.struck && J.gap<200) tourneyPress('A');
        tourneyTick(16.67); continue; }
      const fo=tourney.foes.filter(f=>f.alive).sort((a,b)=>Math.hypot(a.x-tourney.px,a.y-tourney.py)-Math.hypot(b.x-tourney.px,b.y-tourney.py))[0]; tourney.held={};
      if(fo){ const d=Math.hypot(fo.x-tourney.px,fo.y-tourney.py), steer=()=>{ const want=Math.atan2(fo.y-tourney.py,fo.x-tourney.px); let da=want-tourney.heading; while(da>Math.PI) da-=2*Math.PI; while(da<-Math.PI) da+=2*Math.PI; tourney.held.LEFT=da<-0.1; tourney.held.RIGHT=da>0.1; return da; };
        if('${style}'==='skill'){ if(tourney.mode==='waves'){ const da=steer(); tourney.held.UP=Math.abs(da)<0.6 && d>18; } else { tourney.held.UP=d>20 && !fo.wind && !fo.lunge; tourney.held.RIGHT=!!fo.wind; }
          const danger=tourney.foes.some(f=>f.alive && ((f.wind && f.ai>=110) || f.lunge) && Math.hypot(f.x-tourney.px,f.y-tourney.py)<40); if(danger && !tourney.guard) tourneyGuard(true); if(!danger && tourney.guard) tourneyGuard(false);
          const open=tourney.mode==='waves'||fo.wind||fo.knock>0||fo.stagger>0||fo.recover>0; if(!tourney.guard && d<24 && open && (t%6===0)) tourneyPress('A'); }
        else { if(tourney.mode==='waves') steer(); tourney.held.UP=d>14; if(t%4===0) tourneyPress('A'); } }
      tourneyTick(16.67); } } finally { exitTourney=_ex; }
    tourney.result=null; tourney.active=false; tourney.joust=null; place={kind:'overworld'}; return out; })()`);
}
for (const m of ['joust', 'duel', 'ladder', 'waves']) check(`${m}: a knight who reads the tell, parries and strikes back wins`, fight(m, 'skill'), 'WIN');
for (const m of ['joust', 'duel', 'ladder']) check(`${m}: hammering Ⓐ and never guarding loses`, fight(m, 'mash'), 'LOST');

// ── the clean-up (2026-10-07-tk) ──
// Zak: the joust should ride itself with the pop-up fading; the knight should face his man, with better swings;
// "It's easy to accidentally click through and not know if you won or not."
check('the joust: you ride forward yourself — half the closing gap is yours', K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','joust'); const J=tourney.joust; const g0=J.gap; for(let i=0;i<40;i++) tourneyTick(16.67);
  const src=String(_joustDraw); return [J.gap<g0, src.includes("ridden=(JOUST_GAP-")]; })()`), [true, true]);
check('no pop-up over the lists when a contest starts; the calls sit up in the sky and fade', K.$(`(()=>{ tourney.active=false; showBanner('x',5000); startTourney('sg_keep','duel'); return [banner.style.display, tourney.calloutT>0]; })()`), ['none', true]);
check('the knight from behind has frames: ready, step, five swing frames (forehand and backhand), guard, pound, hurt', K.$(`(()=>{ const ok=[['ready',0],['ready',1],['step',0],['step',1],['swing',0],['swing',1],['swing',2],['swing',3],['swing',4],['swing',5],['guard',0],['pound',0],['pound',1],['pound',2],['hurt',0]].every(([p,f])=>{ const c=_listsKnight2(p,f); return c.width===64&&c.height===64; });
  tourney.active=false; startTourney('sg_keep','duel'); tourney.swing=12; tourney.combo=1; const a=_listsKnightFrame(); tourney.combo=2; const b=_listsKnightFrame(); tourney.swing=0; tourney.pound=24; const c=_listsKnightFrame(); tourney.pound=0;
  return [ok, a, b, c]; })()`), [true, ['swing', 0], ['swing', 3], ['pound', 0]]);
check('locked on, the camera keeps square behind him to his man', K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','duel'); const fo=tourney.foes[0]; fo.ai=0; tourney.camAng=tourney.heading+1; for(let i=0;i<12;i++){ fo.ai=0; tourneyTick(16.67); }
  return Math.abs(((tourney.camAng-tourney.heading+Math.PI*3)%(Math.PI*2))-Math.PI)<0.05; })()`), true);
check('a won fight ends on a VICTORY card in the lists — mashed Ⓐ cannot skip it — then Ⓐ leaves', K.$(`(()=>{ tourney.active=false; place={kind:'overworld'}; startTourney('sg_keep','duel'); const g0=gold; const fo=tourney.foes[0]; fo.hp=1; fo.wind=1; fo.x=tourney.px; fo.y=tourney.py-16; tourneyPress('A'); tourneyTick(16.67);
  const card=tourney.result&&tourney.result.win, paid=gold>g0; for(let i=0;i<40;i++){ tourneyTick(16.67); tourneyPress('A'); } const still=place.kind==='tourney'&&!!tourney.result;
  for(let i=0;i<40;i++) tourneyTick(16.67); tourneyPress('A'); return [card, paid, still, place.kind, tourney.active]; })()`), [true, true, true, 'overworld', false]);
check('a lost fight ends on a DEFEAT card too', K.$(`(()=>{ tourney.active=false; place={kind:'overworld'}; startTourney('sg_keep','duel'); tourney.php=1; exitTourney(false,false); const r=tourney.result; const out=[!!r, r&&r.win, place.kind];
  for(let i=0;i<80;i++) tourneyTick(16.67); tourneyPress('A'); return out.concat([place.kind]); })()`), [true, false, 'tourney', 'overworld']);
check('yielding (a long hold of Ⓑ) still walks you straight out', K.$(`(()=>{ tourney.active=false; place={kind:'overworld'}; startTourney('sg_keep','duel'); exitTourney(false,true); return [!!tourney.result, place.kind]; })()`), [false, 'overworld']);
check('the bout-won rest holds a moment before Ⓐ starts the next bout', K.$(`(()=>{ tourney.active=false; startTourney('sg_keep','ladder'); tourney.joust=null; tourney.rest=true; tourney._restT=0; const r0=tourney.round; tourneyPress('A'); const held=tourney.rest;
  for(let i=0;i<45;i++) tourneyTick(16.67); tourneyPress('A'); return [held, tourney.rest, tourney.round===r0+1]; })()`), [true, false, true]);
stop();

// ── the Tilting Yard (2026-10-07-ty): Stormgate's lists on the meadow under the north wall ──
ok('Abaddon\'s dome over Stormgate stays off the yard, and seals the new gates while it stands', K.$(`(()=>{ const was=chapelProgress[6]; chapelProgress[6]=false; let clear=true;
  for(let y=191;y<=197;y++) for(let x=152;x<=183;x++) if(barrierAt(x,y)!==-1) clear=false; const sealed=[163,164,171,172].every(x=>barrierAt(x,198)===7); chapelProgress[6]=was; return clear&&sealed; })()`));
const reach = (from, to) => K.$(`(()=>{ place={kind:'overworld'}; chapelProgress[6]=true; player.mounted=false; player.boating=false; const seen=new Set([${from}+'']), q=[[${from}]];
  while(q.length){ const [x,y]=q.shift(); if(x===${to[0]}&&y===${to[1]}) return true; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny;
    if(seen.has(k)||Math.abs(nx-${to[0]})>40||Math.abs(ny-${to[1]})>40) continue; seen.add(k); if(canStep(x,y,nx,ny)) q.push([nx,ny]); } } return false; })()`);
check('the yard: a fence ring round sand, the grandstand, the tilt, two pavilions, racks and banners', K.$(`(()=>{ const k=(n)=>decorations.filter(d=>d.kind===n).length;
  return [WORLD[191][152], WORLD[194][166], k('ty_stand'), k('ty_tilt'), k('ty_pavilion'), k('ty_rack'), k('ty_flag')]; })()`), [14, 5, 19, 23, 2, 2, 3]);
ok('walk in from the King\'s Road to the marshals\' rail', reach([147, 194], [167, 196]));
ok('walk down from the city through either north gate', reach([163, 200], [164, 196]) && reach([172, 200], [171, 196]));
ok('the tilt is a barrier: the south lane only meets the north lane round its ends', K.$(`[158,170,180].every(x=>!WALK.has(WORLD[194][x]))`));
check('Stormgate\'s two marshals stand at the yard\'s rail; Ironhold\'s stay at the keep door', K.$(`(()=>{ ensureMarshals(); const m=villagers.filter(v=>v.marshal);
  const sg=m.filter(v=>v.marshal.keep==='sg_keep').map(v=>[v.marshal.mode,v.hx,v.hy]).sort(), ih=m.filter(v=>v.marshal.keep==='ih_keep'), b=buildings.find(b=>b.id==='ih_keep');
  return [sg, ih.every(v=>v.hy===b.door.y+1)]; })()`), [[['duel', 166, 196], ['waves', 169, 196]], true]);
check('a sign at the yard, and the city\'s old arena plot points the way', K.$(`[signs['151,193'].split('\\n')[0], signs['173,213'].split('\\n')[0]]`), ['THE TILTING YARD', 'THE TILTING YARD']);
ok('every yard prop draws (the sand under it, then itself)', K.$(`(()=>{ try{ decorations.filter(d=>d.kind.indexOf('ty_')===0).forEach(d=>drawDecor(d,10,10)); return true; }catch(e){ return e.message; } })()`));

// ── the view ──
for (const [mode, keep] of [['duel', 'sg_keep'], ['waves', 'ih_keep'], ['joust', 'hg_keep']]) {
  start(mode, keep);
  ok(`${mode} (${keep}): frames draw`, K.$(`(()=>{ try{ for(let i=0;i<20;i++){ tourneyTick(16.67); ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0); drawTourney(); } return true; }catch(e){ return e.message; } })()`) === true);
}
start('duel');
ok('the challenger is on screen from the first frame of a duel', K.$(`(()=>{ tourneyTick(16.67); ctx.setTransform(RENDER_SCALE,0,0,RENDER_SCALE,0,0); drawTourney();
  const g=_listsLow.getContext('2d'), d=g.getImageData(0,Math.round(VH*0.34),VW,Math.round(VH*0.3)).data; let red=0; for(let i=0;i<d.length;i+=4) if(d[i]===0x8a&&d[i+1]===0x1f&&d[i+2]===0x2a) red++; return red>20; })()`));
check('the knight from behind holds his weapon on the left (screen-left) and his shield on the right', K.$(`(()=>{ const c=_listsKnight('ready'), d=c.getContext('2d').getImageData(0,0,40,58).data;
  let blade=0, shield=0; for(let i=0;i<d.length;i+=4){ const x=(i/4)%40; if(d[i]===0xd8&&d[i+1]===0xdc&&d[i+2]===0xe8&&x<12) blade++; if(d[i]===0x2a&&d[i+1]===0x4a&&d[i+2]===0x9a&&x>26) shield++; } return [blade>10, shield>10]; })()`), [true, true]);
ok('his wind-up looks different from his guard (you can read the tell)', K.$(`(()=>{ const P=LISTS_PAL.sg_keep.foes[0]; const h=(c)=>c.getContext('2d').getImageData(0,0,44,60).data.join(); return h(_listsFoe(P,'wind'))!==h(_listsFoe(P,'circle')); })()`));
stop();
done('lists3d');

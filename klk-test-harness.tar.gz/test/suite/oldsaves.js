// suite/oldsaves.js — saves made by the build players have NOW must survive this update.
//
// test/fixtures/old_saves_2026-09-22.json holds four saves written by the build on
// GitHub (Sept 22): a fresh knight, a hand-built mid-game knight (wagon loaded,
// old delivery requests, a livery), MAX HERO and the Sunfall hero. Each goes in
// through the real loadGame() (localStorage, the same path a returning player
// takes), is played for a few frames, and is saved again. Every field the old
// build wrote must come back out unchanged; new systems must start fresh.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
const fs = require('fs');
console.log('oldsaves');
const OLD = JSON.parse(fs.readFileSync(__dirname + '/../fixtures/old_saves_2026-09-22.json', 'utf8'));
// the SAME saves, loaded, played for the same 30 frames and re-saved by the OLD build itself —
// so anything the game always does on load (the fog lifts, the clock turns, HP settles, a cheat
// save's flags are normalised) is the baseline, and only what THIS update changes can differ
const BASE = JSON.parse(fs.readFileSync(__dirname + '/../fixtures/old_resaved_2026-09-22.json', 'utf8'));
// every leaf path in a save, so "unchanged" is checked field by field
const leaves = (o, p, out) => { out = out || {}; p = p || '';
  if (o && typeof o === 'object' && !Array.isArray(o)) { for (const k in o) leaves(o[k], p ? p + '.' + k : k, out); }
  else out[p] = JSON.stringify(o); return out; };
const SKIP = new Set(['t']);                        // the timestamp is rewritten on every save, by design
for (const name of Object.keys(OLD)) {
  const old = OLD[name];
  globalThis.__raw = JSON.stringify(old);
  const r = K.$(`(()=>{ localStorage.setItem(slotKey(3), globalThis.__raw); return loadGame(3); })()`);
  ok(`${name}: loads through loadGame()`, r && r.ok, JSON.stringify(r));
  // a few real frames on the overworld, then save again
  const err = K.$(`(()=>{ try{ boot.done=true; dialogue.open=false; menu.open=false; for(let i=0;i<30;i++) loop(1000+i*16); return null; }catch(e){ return String(e.stack||e).slice(0,300); } })()`);
  ok(`${name}: plays after loading (30 frames, no errors)`, !err, err || '');
  const re = K.$(`JSON.parse(JSON.stringify(buildSaveData()))`);
  const a = leaves(old), b = leaves(re), base = leaves(BASE[name]); const lost = [], changed = [];
  for (const k in a) { if (SKIP.has(k.split('.')[0])) continue; if (!(k in b)) lost.push(k); }
  for (const k in base) { if (SKIP.has(k.split('.')[0])) continue;
    if (!(k in b)) lost.push(k); else if (base[k] !== b[k]) changed.push(`${k}: ${base[k].slice(0, 40)} → ${b[k].slice(0, 40)}`); }
  check(`${name}: no field the old build saved is lost`, [...new Set(lost)], []);
  check(`${name}: every field comes out exactly as the old build itself re-saves it`, changed, []);
  ok(`${name}: new systems start fresh`, re.empire && re.empire.earned === 0 && re.roadRogues && re.roadRogues.d === 0 && re.roadRogues.jailed === false);
}
// the hand-built mid-game knight, spot checks a player would notice
{ globalThis.__raw = JSON.stringify(OLD.mid); K.$(`localStorage.setItem(slotKey(3), globalThis.__raw); loadGame(3);`);
  check('mid-game: gold, level, livery', K.$(`[gold, player.level, player.livery]`), [1234, 14, 'sable']);
  check('mid-game: packs', K.$(`[inventory.wheat, inventory.grapes, inventory.seabass, inventory.bread]`), [11, 4, 3, 2]);
  check('mid-game: the wagon keeps its cargo', K.$(`wagon.cargo`), { wheat: 3, trout: 2 });
  check('mid-game: the sales ledger (livery unlocks) is untouched', K.$(`[trade.sold, trade.gold]`), [260, 900]);
  ok('mid-game: the new materials read 0, not undefined', K.$(`Object.keys(MATERIALS).every(k=>inventory[k]===0)`)); }
done('oldsaves');

// suite/shvillage.js — Shadowmere, the lantern town on the black mere (2026-10-01 village revamp).
//
// "Where faith holds back the dark." The walls now hold a dark mere, not a bog lot
// (shadowmereMere): peat islands under the chapel and each corner building, a lantern deck
// round the Old Watch-Tree, boardwalks on piles between them, one causeway in from each gate.
// The buildings, doors, props and townsfolk keep their places. The two gates were tidied:
// north (225-226) for the Doomway, south (217-219) for the Stormgate road; the old wall gaps
// that led nowhere are walled. The sign moved to the south landing.
// The art turns on chapelProgress[8]: the dark pressing in (mist banks, false lights, cold
// small lanterns, the Watch-Tree bare, the angel veiled) or the dawn (lilies, gold lanterns,
// the tower lantern blazing, the Watch-Tree in blossom, fireflies, a heron).
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('shvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the mere, pinned ──
check('the town grid is pinned', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Shadowmere; const rows=[]; for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), 'f146be2e');
check('inside the walls: mere, islands and boardwalks', K.$(`(()=>{ const n={}; for(let y=137;y<=158;y++) for(let x=206;x<=228;x++){ const t=WORLD[y][x]; n[t]=(n[t]||0)+1; } return [n[29],n[28],n[12]]; })()`), [128, 105, 162]);
check('the five buildings keep their places and doors', K.$(`buildings.filter(b=>b.id.startsWith('sh_')).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["sh_chapel",216,137,6,6,218,142],["sh_shop",207,145,5,4,209,148],["sh_inn",224,145,5,4,226,148],["sh_home1",207,153,5,3,209,155],["sh_home2",225,154,4,3,226,156]]);
check('the props keep their places', K.$(`decorations.filter(d=>shAt(d.x,d.y)&&!d.hs).map(d=>[d.kind,d.x,d.y,d.w||1])`),
  [["deadTree",218,148,2],["lantern",214,145,1],["lantern",222,145,1],["lantern",214,151,1],["lantern",222,151,1],["tombstone",212,147,1],["tombstone",224,152,1],["mistWisp",216,152,1],["mistWisp",220,146,1]]);
ok('every prop footprint is solid', K.$(`decorations.filter(d=>shAt(d.x,d.y)&&!d.hs).every(d=>{ const w=d.w||1; for(let y=d.y;y<d.y+w;y++) for(let x=d.x;x<d.x+w;x++) if(WORLD[y][x]!==5) return false; return true; })`));
check('one clean wall, two gates: north for the Doomway, south for Stormgate', K.$(`(()=>{ const gaps=[]; for(let x=205;x<=229;x++){ if(WORLD[136][x]!==5) gaps.push('N'+x); if(WORLD[159][x]!==5) gaps.push('S'+x); } for(let y=137;y<=158;y++){ if(WORLD[y][205]!==5) gaps.push('W'+y); if(WORLD[y][229]!==5) gaps.push('E'+y); } return gaps.sort(); })()`),
  ['N225', 'N226', 'S217', 'S218', 'S219']);
check('the roads outside meet the gates', K.$(`[WORLD[135][225], WORLD[135][226], WORLD[160][217], WORLD[160][218], WORLD[160][219]]`), [2, 2, 2, 2, 2]);
check('the sign stands on the south landing, words unchanged', K.$(`[WORLD[158][216], signs['216,158'], signs['207,138']===undefined]`), [16, "SHADOWMERE\nWhere faith holds back the dark", true]);
check('four townsfolk on the lantern deck', K.$(`villagers.filter(v=>v.hx>=205&&v.hx<=229&&v.hy>=136&&v.hy<=159).map(v=>[v.hx,v.hy,WORLD[v.hy][v.hx]])`),
  [[215,148,12],[221,149,12],[217,150,12],[219,146,12]]);

// ── everyone can get everywhere ──
const reach = K.$(`(()=>{ for(let i=0;i<10;i++) chapelProgress[i]=true;
  const flood=(sx,sy)=>{ const seen=new Set([sx+','+sy]), q=[[sx,sy]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
    if(seen.has(k)||X<195||X>240||Y<120||Y>175||!canStep(x,y,X,Y)) continue; seen.add(k); q.push([X,Y]); } } return seen; };
  const S=flood(218,162); for(let i=0;i<10;i++) delete chapelProgress[i];
  const near=(x,y)=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,c])=>S.has((x+a)+','+(y+c)));
  let stranded=0; for(let y=137;y<=158;y++) for(let x=206;x<=228;x++) if(WALK.has(WORLD[y][x]) && !S.has(x+','+y)) stranded++;
  return [buildings.filter(b=>b.id.startsWith('sh_')).every(b=>near(b.door.x,b.door.y)), villagers.filter(v=>v.hx>=205&&v.hx<=229&&v.hy>=136&&v.hy<=159).every(v=>S.has(v.hx+','+v.hy)),
          near(216,158), S.has('206,149'), S.has('217,147'), S.has('225,133'), stranded]; })()`);
check('from the Stormgate road: every door, the townsfolk, the sign, the trader\'s cart spot, the town centre, on out the north gate; nothing stranded', reach, [true, true, true, true, true, true, 0]);
check('the supply wagon drops at the chapel door', K.$(`(()=>{ delete DELIVERY_POINTS[8]; ensureDeliveryPoints(); const p=DELIVERY_POINTS[8]; return [p.x,p.y]; })()`), [218, 143]);
ok('the mere cannot be walked', !K.$(`WALK.has(29)`));

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ for(let i=0;i<8;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[8]=true; else delete chapelProgress[8];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawShadowmereBuilding, B=drawShadowmereDecor, C=drawShadowmereTile, D=shadowmereObjs;
  drawShadowmereBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawShadowmereDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawShadowmereTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  shadowmereObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=34; VIEW_TH=32; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=217*TILE; player.y=148*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawShadowmereBuilding=A; drawShadowmereDecor=B; drawShadowmereTile=C; shadowmereObjs=D;
    for(let i=0;i<9;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole town draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and nine props wear Shadowmere's art`, [r.n.b, r.n.d], [5, 9]);
  ok(`${clean ? 'cleansed' : 'bound'}: the mere, islands, boardwalks and wall are Shadowmere's (got ${r.n.t})`, r.n.t >= 580);
  check(`${clean ? 'cleansed' : 'bound'}: the air layer (the dark, or the dawn)`, r.n.o, 1);
}
const colours = (fn, clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[8]=true; else delete chapelProgress[8]; const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ ${fn}; } finally{ px=A; delete chapelProgress[8]; } return seen; })()`);
{ const b = colours(`_shLamp(0,0,1,true)`, false), c = colours(`_shLamp(0,0,1,true)`, true);
  check('bound: the lanterns burn cold', [b.has(K.$(`SHM.cold`)), b.has(K.$(`SHM.warm`))], [true, false]);
  check('cleansed: the lanterns burn gold', [c.has(K.$(`SHM.cold`)), c.has(K.$(`SHM.warm`))], [false, true]); }
{ const b = colours(`_shMere(0,0,210,140)`, false), c = colours(`_shMere(0,0,210,140)`, true);
  check('bound: the mere is black; cleansed: it runs clear', [b.has(K.$(`SHM.mere`)), c.has(K.$(`SHM.mereC`))], [true, true]); }
check('the Watch-Tree is bare while bound and blossoms once cleansed', K.$(`(()=>{ const d=decorations.find(d=>d.kind==='deadTree'&&shAt(d.x,d.y)); const r=[];
  for(const c of [false,true]){ if(c) chapelProgress[8]=true; else delete chapelProgress[8]; let arcs=0; const A=ctx.arc; ctx.arc=function(){ arcs++; return A.apply(ctx,arguments); };
    try{ drawShadowmereDecor(d,0,0); } finally{ ctx.arc=A; } r.push(arcs>=30); } delete chapelProgress[8]; return r; })()`), [false, true]);

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawShadowmereDecor({kind:'lantern',x:214,y:145,w:1,hs:true},0,0)===false`));
ok('the bog outside the walls keeps the overworld art', K.$(`drawShadowmereTile(28,0,0,204,150)===false && drawShadowmereTile(28,0,0,217,135)===false && drawShadowmereTile(2,0,0,218,160)===false`));
ok('the box is Shadowmere only', K.$(`shAt(217,147) && !shAt(168,215) && !shAt(225,19) && !shAt(158,150)`));
check('a frame of the real loop on the lantern deck', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<8;i++) chapelProgress[i]=true; player.x=217*TILE; player.y=147*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<8;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('shvillage');

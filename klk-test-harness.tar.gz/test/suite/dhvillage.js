// suite/dhvillage.js — Dusthaven, the caravan town (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout" and "give each its own strong identity".
// Dusthaven became adobe, terracotta and indigo: earth streets, sand, rounded adobe
// walls with domed corners, the Caravan Bazaar, the Oasis Rest, the Adobe Dwelling,
// the Nomad's tent, a twin-bell mission chapel, the oasis, the sundial obelisk,
// camels and blowing sand. Drawing only, EXCEPT three layout fixes Zak asked for:
//   · "neither is really walkable": the dead-end gaps at x80 y69-70 (west) and
//     x99-100 y80 (south, east of the road) are walled up;
//   · "a random block of wall": the 2×2 stub at x81-82 y68-69 is cleared.
// The south road gate (x92-93 y80) stays the one way in, under an arched gatehouse.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('dhvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the layout: the old grid (3ec931c7, tag 2026-10-01-tw) plus exactly the eight fixed tiles ──
check('the town grid is the old grid with only the three fixes', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Dusthaven; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '5c53a021');
check('the dead-end gaps are walled up', K.$(`[[80,69],[80,70],[99,80],[100,80]].map(([x,y])=>WORLD[y][x])`), [5, 5, 5, 5]);
check('the stray block is gone (ground, then street)', K.$(`[[81,68],[82,68],[81,69],[82,69]].map(([x,y])=>WORLD[y][x])`), [0, 0, 2, 2]);
check('the south road gate is still open', K.$(`[WORLD[80][92], WORLD[80][93]]`), [2, 2]);
ok('the sign can still be read from the street beside it', K.$(`WORLD[70][81]===16 && WALK.has(WORLD[70][82])`));
check('the five buildings and their doors are where they were', K.$(`buildings.filter(b=>dhAt(b.x,b.y)).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["dh_chapel",90,59,6,6,92,64],["dh_inn",99,62,5,4,101,65],["dh_home1",82,74,5,4,84,77],["dh_home2",99,74,4,3,100,76],["dh_bazaar",82,61,5,4,84,64]]);
check('the town\'s props are where they were', K.$(`decorations.filter(d=>dhAt(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["oasis",96,60,3],["tent",88,67,2],["tent",96,71,2],["cactus",87,72,1],["cactus",97,66,1],["waterjug",90,75,1],["waterjug",95,64,1],["palmDesert",86,76,1],["palmDesert",102,70,1]]);
check('four villagers still walk the town', K.$(`villagers.filter(v=>dhAt(v.hx,v.hy)).length`), 4);

// every door and villager can still reach the road gate, and the road gate reaches the world
const reach = K.$(`(()=>{ const seen=new Set(['92,79']), q=[[92,79]];
  while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a, Y=y+b, k=X+','+Y;
    if(seen.has(k) || !dhAt(X,Y) || !WALK.has(WORLD[Y][X])) continue; seen.add(k); q.push([X,Y]); } }
  const doors=buildings.filter(b=>dhAt(b.x,b.y)).map(b=>b.door).every(d=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,b])=>seen.has((d.x+a)+','+(d.y+b))));
  const folk=villagers.filter(v=>dhAt(v.hx,v.hy)).every(v=>seen.has(v.hx+','+v.hy));
  return [doors, folk, seen.has('92,81')]; })()`);
check('every door, every villager and the road out connect through the south gate', reach, [true, true, true]);

// ── the wall and the gateway ──
check('one gateway, on the south wall, over the road', K.$(`_dhGateList().map(g=>[g.side,g.a,g.b,g.line])`), [['S', 92, 93, 80]]);
ok('the solid block in the square is the sundial obelisk', K.$(`DH_OBELISK.x===92 && DH_OBELISK.y===69 && [0,1,2].every(i=>[0,1,2].every(j=>WORLD[69+j][92+i]===5))`));
ok('the obelisk block is not mistaken for town wall', K.$(`!_dhIsWall(93,70) && _dhIsWall(80,69) && _dhIsWall(99,80)`));

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ for(let i=0;i<4;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[4]=true; else delete chapelProgress[4];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawDusthavenBuilding, B=drawDusthavenDecor, C=drawDusthavenTile, D=dusthavenObjs;
  drawDusthavenBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawDusthavenDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawDusthavenTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  dusthavenObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=40; VIEW_TH=32; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=92*TILE; player.y=69*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawDusthavenBuilding=A; drawDusthavenDecor=B; drawDusthavenTile=C; dusthavenObjs=D;
    for(let i=0;i<5;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole town draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and nine props wear Dusthaven's art`, [r.n.b, r.n.d], [5, 9]);
  ok(`${clean ? 'cleansed' : 'bound'}: streets, sand, scrub and walls have Dusthaven's art (got ${r.n.t}; 26×23 box less the oasis's 9 water tiles)`, r.n.t >= 589);
  check(`${clean ? 'cleansed' : 'bound'}: the gatehouse arch, the obelisk, two camels and the wind`, r.n.o, 5);
}
check('sand and scrub outside the walls keep the overworld art', K.$(`[drawDusthavenTile(19,0,0,78,70), drawDusthavenTile(0,0,0,92,82)]`), [false, false]);
ok('the road runs on through the gate as the town street', K.$(`drawDusthavenTile(2,0,0,92,80)===true`));

// the chapel reads its own state (chapelProgress[4]): sand-drifted while bound, flowers once cleansed
const front = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[4]=true; else delete chapelProgress[4];
  const b=buildings.find(b=>b.id==='dh_chapel'); const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ drawDusthavenBuilding(b,40,60); } finally{ px=A; delete chapelProgress[4]; } return [seen.has(DHV.sand), seen.has('#e84a7a')]; })()`);
check('bound: sand drifted against the chapel, no flowers', front(false), [true, false]);
check('cleansed: the drifts are gone and flowers stand by the door', front(true), [false, true]);

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawDusthavenDecor({kind:'cactus',x:87,y:72,w:1,hs:true},0,0)===false`));
ok('the box is Dusthaven only', K.$(`dhAt(92,69) && !dhAt(92,157) && !dhAt(32,22) && !dhAt(35,63) && !dhAt(32,203)`));
check('a frame of the real loop in the square', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<4;i++) chapelProgress[i]=true; player.x=90*TILE; player.y=73*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<4;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('dhvillage');

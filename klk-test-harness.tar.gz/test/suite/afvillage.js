// suite/afvillage.js — Ashfield, the caldera town: beauty for ashes (2026-10-01 village revamp).
//
// Zak liked the restyle but: "the shape and format of the town seem off, could you come
// up with a more creative layout for it that fits its theme". So Ashfield is the one town
// whose layout was rebuilt (ashfieldCaldera): an oval bowl inside the old walls, crags in
// the corners, a lava river from the north wall with causeways, a round plaza round the
// altar-hearth, paved spokes to every door and the south gate, fields in the bowl, the
// sign just inside the gate. The art turns on chapelProgress[6]: grey ash and falling
// ash while bound, golden grain and butterflies once cleansed (Isaiah 61:3).
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('afvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false; player.boating=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the new layout, pinned ──
check('the caldera grid is pinned', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Ashfield; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '9b63af57');
check('the five buildings round the plaza', K.$(`buildings.filter(b=>b.id.startsWith('af_')).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["af_chapel",155,138,6,6,158,143],["af_shop",143,143,5,4,145,146],["af_inn",170,148,5,4,172,151],["af_home1",146,156,5,4,148,159],["af_home2",163,157,4,3,165,159]]);
check('the props in their new places', K.$(`decorations.filter(d=>afAt(d.x,d.y)&&!d.hs).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["lavaAltar",157,146,2],["brokenPillar",153,145,1],["brokenPillar",163,145,1],["emberPit",154,148,1],["emberPit",161,148,1],["charredTree",152,140,1],["charredTree",165,155,1],["banner2",160,144,1]]);
check('every prop footprint is solid', K.$(`decorations.filter(d=>afAt(d.x,d.y)&&!d.hs).every(d=>{ const w=d.w||1; for(let y=d.y;y<d.y+w;y++) for(let x=d.x;x<d.x+w;x++) if(WORLD[y][x]!==5) return false; return true; })`), true);
check('the sign stands just inside the south gate, words unchanged', K.$(`[WORLD[163][166], signs['166,163'], signs['140,138']===undefined]`), [16, "ASHFIELD\nWhat the fire spared, faith keeps", true]);
check('the south gate is the one way in, the roads outside untouched', K.$(`[WORLD[165][168], WORLD[165][169], WORLD[167][150], WORLD[167][160]]`), [2, 2, 2, 2]);
check('the plaza is basalt round the altar, the lava runs from the north wall', K.$(`[WORLD[149][158], WORLD[137][149], WORLD[137][150]]`), [6, 26, 26]);

// ── everyone can get everywhere ──
const reach = K.$(`(()=>{ for(let i=0;i<10;i++) chapelProgress[i]=true;
  const seen=new Set(['168,167']), q=[[168,167]]; while(q.length){ const [x,y]=q.pop(); for(const [a,b] of [[1,0],[-1,0],[0,1],[0,-1]]){ const X=x+a,Y=y+b,k=X+','+Y;
    if(seen.has(k)||X<130||X>186||Y<130||Y>170||!canStep(x,y,X,Y)) continue; seen.add(k); q.push([X,Y]); } }
  for(let i=0;i<10;i++) delete chapelProgress[i];
  const near=(x,y)=>[[0,1],[0,-1],[1,0],[-1,0]].some(([a,c])=>seen.has((x+a)+','+(y+c)));
  let stranded=0; for(let y=137;y<=164;y++) for(let x=139;x<=177;x++) if(WALK.has(WORLD[y][x]) && !seen.has(x+','+y)) stranded++;
  return [buildings.filter(b=>b.id.startsWith('af_')).every(b=>near(b.door.x,b.door.y)),
          villagers.filter(v=>afAt(v.hx,v.hy)).every(v=>seen.has(v.hx+','+v.hy)), near(166,163), stranded<=1]; })()`);
check('from the gate: every door, every villager and the sign (at most one stray tile)', reach, [true, true, true, true]);
check('the supply wagon drops at the chapel\'s new door', K.$(`(()=>{ delete DELIVERY_POINTS[6]; ensureDeliveryPoints(); const p=DELIVERY_POINTS[6]; return [p.x,p.y]; })()`), [158, 144]);
check('four villagers live in town', K.$(`villagers.filter(v=>afAt(v.hx,v.hy)).length`), 4);

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ for(let i=0;i<6;i++) chapelProgress[i]=true; if(${!!clean}) chapelProgress[6]=true; else delete chapelProgress[6];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawAshfieldBuilding, B=drawAshfieldDecor, C=drawAshfieldTile, D=ashfieldObjs;
  drawAshfieldBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawAshfieldDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawAshfieldTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  ashfieldObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=48; VIEW_TH=34; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=158*TILE; player.y=150*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawAshfieldBuilding=A; drawAshfieldDecor=B; drawAshfieldTile=C; ashfieldObjs=D;
    for(let i=0;i<7;i++) delete chapelProgress[i]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole town draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and eight props wear Ashfield's art`, [r.n.b, r.n.d], [5, 8]);
  ok(`${clean ? 'cleansed' : 'bound'}: the bowl, crags, lava and walls have Ashfield's art (got ${r.n.t})`, r.n.t >= 1100);
  check(`${clean ? 'cleansed' : 'bound'}: the air layer (embers, then ash or butterflies)`, r.n.o, 1);
}
const field = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[6]=true; else delete chapelProgress[6]; const seen=new Set(); const A=px; px=function(x,y,w,h,c){ seen.add(c); return A(x,y,w,h,c); };
  try{ drawAshfieldTile(27,0,0,160,155); } finally{ px=A; delete chapelProgress[6]; } return [seen.has(AFK.ash), seen.has(AFK.goldL)]; })()`);
check('bound: the fields are grey ash', field(false), [true, false]);
check('cleansed: the fields are golden grain — beauty for ashes', field(true), [false, true]);
ok('the old ash outside the town keeps its art', K.$(`drawAshfieldTile(33,0,0,130,150)===false && drawAshfieldTile(0,0,0,183,150)===false`));

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawAshfieldDecor({kind:'emberPit',x:154,y:148,w:1,hs:true},0,0)===false`));
ok('the box is Ashfield only', K.$(`afAt(158,150) && !afAt(153,68) && !afAt(92,69) && !afAt(91,157)`));
check('a frame of the real loop on the plaza', K.$(`(()=>{ place={kind:'overworld'}; for(let i=0;i<6;i++) chapelProgress[i]=true; player.x=158*TILE; player.y=150*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } for(let i=0;i<6;i++) delete chapelProgress[i]; return r; })()`), 'ok');

done('afvillage');

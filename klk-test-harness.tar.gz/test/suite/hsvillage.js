// suite/hsvillage.js — the Homestead, redrawn (2026-10-01).
//
// Zak: "Awesome! Can we do the homestead next?", then "If you can fix those when you upload it
// that would be awesome!" Drawing, plus six new props and two fixes. The farmhouse, barn and
// bazaar, the fields, corral, bridge, signs and the water's edge are drawn by the Homestead's own
// art; a well, three bee skeps, a woodpile and a hen-house stand on flower tiles (never on the
// plain grass the knight's own decorations go on); hens, ducks, and at night lit windows and
// fireflies. Fixed: the minimap label and the region name still pointed at the empty northern
// meadow the Homestead moved away from. Every plot, door and sign is where it was.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('hsvillage');

const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'};`);

// ── the farm is laid out as it was ──
check('the same 60 plots, in the same places', K.$(`[FARM_PLOTS.length, (${fnv})(FARM_PLOTS.join(' '))]`), [60, '66673921']);
check('the farmhouse, barn and bazaar, and their doors, are where they were', K.$(`buildings.filter(b=>['home_house','home_barn','dh_shop'].includes(b.id)).map(b=>[b.x,b.y,b.door.x,b.door.y].join(',')).join(' ')`), '22,135,25,139 9,146,10,149 33,123,35,126');
check('the same signs', K.$(`Object.keys(signs).filter(k=>{const[x,y]=k.split(',').map(Number); return x>=6&&x<=51&&y>=118&&y<=191;}).sort().join(' ')`), '14,160 16,151 18,148 19,148 25,142 27,153 39,161');
check('the farm stand is sold at from the same spot', K.$(`SELL_SPOT`), '28,153');
check('as much plain grass for the knight\'s own decorations as before', K.$(`(()=>{ let g=0; for(let y=HS_BOUNDS.y0;y<=HS_BOUNDS.y1;y++) for(let x=HS_BOUNDS.x0;x<=HS_BOUNDS.x1;x++) if(WORLD[y][x]===0) g++; return g; })()`), 1091);

// ── the new props ──
const props = K.$(`decorations.filter(d=>['hsWell','hsSkep','hsWoodpile','hsCoop'].includes(d.kind)).map(d=>d.kind+'@'+d.x+','+d.y+':'+WORLD[d.y][d.x])`);
check('a well, three skeps, a woodpile and a hen-house, each solid', props, ['hsWell@31,137:5','hsSkep@33,138:5','hsSkep@35,138:5','hsSkep@37,139:5','hsWoodpile@14,147:5','hsCoop@11,151:5']);
ok('none of them is the knight\'s (so a pick-up can never take one)', K.$(`decorations.filter(d=>d.kind.indexOf('hs')===0&&d.kind.length>2&&d.kind!=='hs').every(d=>!d.hs)`));

// ── drawn in the Homestead's own art ──
check('every kind of ground in the clearing is the Homestead\'s (trees, track and shore are the open country\'s)', K.$(`(()=>{ const r={}; for(let y=118;y<=190;y++) for(let x=6;x<=51;x++){ if(!hsAt(x,y)) continue; const t=WORLD[y][x]; if(r[t]!==undefined) continue; r[t]=drawHomesteadTile(t,0,0,x,y); } return Object.keys(r).sort((a,b)=>a-b).map(k=>k+':'+r[k]).join(' '); })()`),
  '0:true 1:false 2:false 3:true 4:true 5:true 7:true 9:true 12:true 14:true 16:true 19:false 31:true 39:false 40:false');
check('the farmhouse, barn and bazaar are drawn by the Homestead', K.$(`buildings.filter(b=>['home_house','home_barn','dh_shop'].includes(b.id)).map(b=>hsAt(b.x,b.y)&&drawHomesteadBuilding(b,0,0))`), [true, true, true]);
check('every farm prop has its art (the horses and the mule keep theirs)', K.$(`(()=>{ const r={}; decorations.filter(d=>!d.hs&&hsAt(d.x,d.y)).forEach(d=>{ r[d.kind]=drawHomesteadDecor(d,0,0); }); return Object.keys(r).sort().map(k=>k+':'+r[k]).join(' '); })()`),
  'bucket:true farmStand:true haycart:true haystack:true horse:false hsCoop:true hsSkep:true hsWell:true hsWoodpile:true mule:false planter:true scarecrow:true');
ok('a decoration the knight placed keeps its own art', K.$(`drawHomesteadDecor({x:40,y:130,kind:'planter',w:1,hs:true},0,0)===false`));
ok('Hearthvale is not the Homestead', !K.$(`hsAt(33,22)`));

// ── the knight's decorations still go down, and old saves keep theirs ──
check('placing a decoration on the meadow still works', K.$(`(()=>{ const id=Object.keys(DECOR_ITEMS).find(k=>DECOR_ITEMS[k].w===1); homesteadDecor.inv[id]=1; const r=placeDecorAt(id,40,130); const p=pickUpDecorAt(40,130); delete homesteadDecor.inv[id]; return [r, !!p, WORLD[130][40]]; })()`), [true, true, 0]);
check('an old save\'s decoration on the meadow survives loading', K.$(`(()=>{ const id=Object.keys(DECOR_ITEMS).find(k=>DECOR_ITEMS[k].w===1); homesteadDecor.placed=[{id,x:40,y:130}]; pendingDecorMigration=0; migrateHomesteadDecor(); const r=[homesteadDecor.placed.length, pendingDecorMigration]; homesteadDecor.placed=[]; return r; })()`), [1, 0]);

// ── the two leftovers from the move, fixed ──
check('standing in the clearing says The Homestead', K.$(`(()=>{ player.x=25*TILE; player.y=141*TILE; return regionNameAt(25,141); })()`), 'The Homestead');
ok('the minimap\'s label is on the farm', K.$(`(()=>{ const m=MINI_TOWNS.find(t=>t[0]==='Homestead'); return inHomestead(m[1],m[2]); })()`));
ok('the old northern meadow is not the Homestead any more', K.$(`regionNameAt(108,18)!=='The Homestead'`));

// ── it runs, by day and by night ──
for (const [nm, frac] of [['day', 0.375], ['night', 0.95]]) {
  check(`a real frame at the farm by ${nm}`, K.$(`(()=>{ dayClock.t=DAY_LEN*${frac}; player.x=25*TILE; player.y=142*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } return r; })()`), 'ok');
}
check('the lights and fireflies come out only after dark', K.$(`[(dayClock.t=DAY_LEN*0.375, _hsDark()), (dayClock.t=DAY_LEN*0.95, _hsDark())]`), [0, 1]);
K.$(`dayClock.t=DAY_LEN*0.375;`);

done('hsvillage');

// suite/smvillage.js — Saltmere, the weathered harbour (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout" and "give each its own strong identity".
// Saltmere became salt-grey driftwood, whitewash and sea-blue: a boardwalk terrace,
// a rope fence, shell sand and turquoise shallows, driftwood piers, the Fish
// Market, the Netmender's hut, the Fisher's cottage, the Salty Anchor, a
// fishermen's chapel with a tower lamp, the striped lighthouse, gulls and crabs.
// DRAWING ONLY — and the surf spot, the sea, the road and the stair keep their art.
// 2026-10-01-vs: the town's name-sign moved to its main entrance (see suite/vsigns.js). Only the sign
//   tiles changed, so the grid pins below were re-taken.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('smvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the layout is untouched ──
// be7d283b is the FNV-1a of the town's tiles (its box plus a one-tile margin) in the
// build BEFORE the revamp (tag 2026-10-01-ih).
check('the town grid is exactly the grid it was', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Saltmere; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), 'c1f7152f');
check('the five buildings and their doors are where they were', K.$(`buildings.filter(b=>smAt(b.x,b.y)).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["sm_chapel",47,199,6,6,49,204],["sm_market",14,200,6,4,16,203],["sm_inn",36,200,5,4,38,203],["sm_home1",14,205,4,2,15,206],["sm_home2",22,199,4,3,23,201]]);
check('the harbour\'s props are where they were', K.$(`decorations.filter(d=>smAt(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["lighthouse",32,203,2],["fishBarrel",28,205,1],["fishBarrel",37,205,1],["netRack",29,200,1],["netRack",39,206,1],["boat",17,220,2],["umbrella",15,210,1],["umbrella",42,211,1],["sandcastle",20,212,1],["palm",27,214,1],["palm",37,213,1],["tidepool",24,212,1],["tidepool",33,214,1]]);
check('six villagers still work the harbour', K.$(`villagers.filter(v=>smAt(v.hx,v.hy)).length`), 6);
check('all four signs are still up', K.$(`['49,202','30,206','28,218','20,218'].map(k=>!!signs[k])`), [true, true, true, true]);
ok('Saltmere does not overlap Hearthvale or Ironhold', K.$(`!buildings.some(b=>smAt(b.x,b.y)&&(hvAt(b.x,b.y)||ihAt(b.x,b.y)))`));

// ── what keeps its own art ──
check('the surf spot, the sea, the road, the stair and the grass are left alone', K.$(`[21,3,2,10,0].map(t=>drawSaltmereTile(t,0,0,30,215))`), [false, false, false, false, false]);
check('the codes it styles', K.$(`[4,5,6,9,12,14,16,19,20,32].filter(t=>!drawSaltmereTile(t,0,0,30,212))`), []);
ok('prop footprints (tile 32) draw as the ground around them, not as cliff ledges', K.$(`(()=>{ let calls=0; const A=_smBoard, B=_smSand, C=_smShallows, D=_smPier;
  _smBoard=_smSand=_smShallows=_smPier=function(){ calls++; }; try{ _smUnder(0,0,32,203); _smUnder(0,0,20,212); } finally{ _smBoard=A; _smSand=B; _smShallows=C; _smPier=D; } return calls===2; })()`));

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ chapelProgress[0]=true; chapelProgress[1]=true; if(${!!clean}) chapelProgress[2]=true; else delete chapelProgress[2];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawSaltmereBuilding, B=drawSaltmereDecor, C=drawSaltmereTile, D=saltmereObjs;
  drawSaltmereBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawSaltmereDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawSaltmereTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  saltmereObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=50; VIEW_TH=32; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=34*TILE; player.y=211*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawSaltmereBuilding=A; drawSaltmereDecor=B; drawSaltmereTile=C; saltmereObjs=D;
    delete chapelProgress[0]; delete chapelProgress[1]; delete chapelProgress[2]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole harbour draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all five buildings and thirteen props wear Saltmere's art`, [r.n.b, r.n.d], [5, 13]);
  ok(`${clean ? 'cleansed' : 'bound'}: the terrace, beach, shallows and piers have Saltmere's art (got ${r.n.t})`, r.n.t >= 830);
  check(`${clean ? 'cleansed' : 'bound'}: three perched gulls, three crabs and the wheeling flock`, r.n.o, 7);
}
ok('the gulls perch on the piers and the lighthouse, the crabs walk the sand', K.$(`SM_PERCH.every(([x,y])=>WORLD[y][x]===12||WORLD[y][x]===32) && SM_CRABS.every(([x,y])=>WORLD[y][x]===19)`));

// the chapel reads its own state (chapelProgress[2]): the tower lamp is lit once cleansed
const lamp = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[2]=true; else delete chapelProgress[2];
  const b=buildings.find(b=>b.id==='sm_chapel'); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,220,220);
  drawSaltmereBuilding(b,40,60); const cx=40+(b.door.x-b.x)*TILE+8, tL=cx+30-2, tTop=60-14;
  const r=Array.from(ctx.getImageData(tL+8,tTop+2,1,1).data).slice(0,3).join(','); delete chapelProgress[2]; return r; })()`);
ok('the chapel\'s tower lamp is dark while bound and lit once cleansed', lamp(false) !== lamp(true));

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawSaltmereDecor({kind:'palm',x:27,y:214,w:1,hs:true},0,0)===false`));
ok('the box is Saltmere only', K.$(`smAt(32,203) && !smAt(32,22) && !smAt(35,63)`));
check('a frame of the real loop on the beach', K.$(`(()=>{ place={kind:'overworld'}; chapelProgress[0]=chapelProgress[1]=true; player.x=30*TILE; player.y=212*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } delete chapelProgress[0]; delete chapelProgress[1]; return r; })()`), 'ok');

done('smvillage');

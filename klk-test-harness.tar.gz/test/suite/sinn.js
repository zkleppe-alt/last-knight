// suite/sinn.js — the shops and the inns, made grand (2026-10-07, tag 2026-10-07-si).
//
// Zak: "Then I'd like to revamp the shops interior and the inn interior", then "If possible let's make the shops and
// inns grander, something that would leave an impression on players as being high quality", then "Yes please".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('sinn');
K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; hunt.done=true;`);
const SHOPS = { shop:'plain', tw_shop:'plain', cp_shop:'plain', ih_forge:'forge', af_shop:'forge', sm_market:'fish', sg_shop:'fine', dh_shop:'bazaar', sh_shop:'bazaar' };
const INNS = ['inn', 'ih_inn', 'sm_inn', 'tw_inn', 'dh_inn', 'cp_inn', 'af_inn', 'sg_inn', 'sh_inn'];
check('five shop halls for nine shops', K.$(`Object.keys(SI_SHOPS).map(k=>k+':'+SI_SHOPS[k]).sort()`), Object.keys(SHOPS).map(k => k + ':' + SHOPS[k]).sort());
check('every shop is its trade’s 14×10 hall; every inn 16×11 below and 16×9 above', K.$(`(()=>{ const o=[]; for(const id in SI_SHOPS){ const f=INTERIORS[id].floors; o.push(f.length===1&&f[0].w===14&&f[0].h===10); }
  ${JSON.stringify(INNS)}.forEach(id=>{ const f=INTERIORS[id].floors; o.push(f.length===2&&f[0].w===16&&f[0].h===11&&f[1].w===16&&f[1].h===9); }); return o.every(Boolean); })()`), true);
const reach = (id, fl, a, b) => `(()=>{ const f=INTERIORS['${id}'].floors[${fl}], W=(x,y)=>f.g[y]&&WALK.has(f.g[y][x]); const seen=new Set(['${a}']), q=[[${a}]];
  while(q.length){ const [x,y]=q.shift(); if(x===${b[0]}&&y===${b[1]}) return true; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(seen.has(k)||!W(nx,ny)) continue; seen.add(k); q.push([nx,ny]); } } return false; })()`;
const talk = (id, fl, px, py) => K.$(`(()=>{ place={kind:'interior', id:'${id}', floor:${fl}}; player.x=${px}*TILE; player.y=${py}*TILE; player.dir='up'; dialogue.open=false; if(typeof shopMode!=='undefined') shopMode=null; if(typeof innChoice!=='undefined') innChoice=null; banner.style.display='none';
  doAction(); const o=dialogue.open||banner.style.display==='block'; dialogue.open=false; if(typeof closeShop==='function') closeShop(); return o; })()`);
for (const id in SHOPS) {
  const keep = K.$(`(()=>{ const n=INTERIORS['${id}'].npcs.find(n=>n.floor===0); return n?[n.x,n.y]:null; })()`);
  const d = SHOPS[id] === 'forge' ? 1 : 2;   // across the counter, or (at the forge) beside the anvil
  ok(`${id}: in from the door, up to the counter, and the keeper answers`, K.$(reach(id, 0, [7, 8], [keep[0], keep[1] + d])) && talk(id, 0, keep[0], keep[1] + d), JSON.stringify(keep));
}
for (const id of INNS) {
  ok(`${id}: door to the bar and to the stair; up the stair to every room`, K.$(reach(id, 0, [8, 9], [7, 3])) && K.$(reach(id, 0, [8, 9], [14, 1])) && K.$(reach(id, 1, [14, 1], [3, 2])) && K.$(reach(id, 1, [14, 1], [7, 3])) && K.$(reach(id, 1, [14, 1], [12, 2])));
  ok(`${id}: everyone stands on open floor, and the innkeeper answers across the bar`, K.$(`(()=>{ const it=INTERIORS['${id}']; return it.npcs.every(n=>{ const f=it.floors[n.floor]; return f&&f.g[n.y]&&WALK.has(f.g[n.y][n.x]); }); })()`) && talk(id, 0, 7, 3));
}
ok('a hooded stranger waits in every inn', K.$(`${JSON.stringify(INNS)}.every(id=>INTERIORS[id].npcs.some(n=>n.stranger&&n.floor===0))`));
ok('walking in, you stand inside the door on open floor', K.$(`(()=>{ for(const id of Object.keys(SI_SHOPS).concat(${JSON.stringify(INNS)})){ const f=INTERIORS[id].floors[0]; let sx=-1, sy=-1; for(let y=0;y<f.h;y++)for(let x=0;x<f.w;x++) if(f.g[y][x]===9){ sx=x; sy=y-1; } if(!WALK.has(f.g[sy][sx])) return id; } return true; })()`));
const paint = (id, fl) => K.$(`(()=>{ place={kind:'interior', id:'${id}', floor:${fl}}; const f=INTERIORS['${id}'].floors[${fl}]; let n=0; try{ for(let y=0;y<f.h;y++) for(let x=0;x<f.w;x++) if(drawShopInnTile(f.g[y][x],0,0,x,y)) n++; }catch(e){ return e.message; } return n===f.w*f.h; })()`);
ok('every shop and every inn floor paints whole', Object.keys(SHOPS).every(id => paint(id, 0) === true) && INNS.every(id => paint(id, 0) === true && paint(id, 1) === true));
ok('each inn hangs its own town’s sign over the hearth', K.$(`new Set(${JSON.stringify(INNS)}.map(id=>_siTown(id)[2])).size===9`));
check('the homestead’s rooms and other interiors are not taken over', K.$(`(()=>{ place={kind:'interior', id:'home_house', floor:0}; const a=drawShopInnTile(12,0,0,3,3); place={kind:'interior', id:'ih_keep', floor:0}; const b=drawShopInnTile(12,0,0,3,3); return [a,b]; })()`), [false, false]);
done('sinn');

// suite/hvvillage.js — Hearthvale, the hearth of the vale (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout" and "give each its own strong identity".
// Hearthvale became a warm country village — thatched cottages, a timbered store,
// a two-storey inn, a gable-fronted honey-stone chapel, the well on the green,
// picket fences, hens. The rework is DRAWING ONLY: the same streets, doors,
// props, villagers and sign, so nothing a quest or a test relies on can move.
// (suite/hearthvale.js is the chapel-one scriptorium; this is the town above it.)
// 2026-10-01-vs: the town's name-sign moved to its main entrance (see suite/vsigns.js). Only the sign
//   tiles changed, so the grid pins below were re-taken.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('hvvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the layout is untouched ──
// b5fe5e74 is the FNV-1a of the town's tiles (its box plus a one-tile margin) in the
// build BEFORE the revamp (tag 2026-10-01-sa).
check('the town grid is exactly the grid it was', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Hearthvale; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), 'b847af0c');
check('the six buildings and their doors are where they were', K.$(`buildings.filter(b=>hvAt(b.x,b.y)).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["tobias",20,15,5,4,22,18],["chapel",41,14,6,6,43,19],["shop",20,24,5,4,22,27],["inn",41,25,5,4,43,28],["home1",27,14,4,3,28,16],["home2",35,14,4,3,36,16]]);
check('the square\'s props are where they were', K.$(`decorations.filter(d=>hvAt(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["fountain",32,22,2],["planter",28,20,1],["planter",37,20,1],["marketStall",27,26,2],["lantern",38,25,1],["lantern",25,23,1],["haycart",36,27,2],["barrel",30,18,1],["barrel",35,18,1]]);
check('three villagers still walk the square', K.$(`villagers.filter(v=>hvAt(v.hx,v.hy)).length`), 3);
ok('the town sign is still at the south gate', K.$(`!!signs['34,31']`));   // (_legacy: 34,29 — moved down to the gate itself in 2026-10-01-vs)

// ── the drawing ──
const view = (cx, cy, clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[0]=true; else delete chapelProgress[0];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,hen:0}; const A=drawHearthvaleBuilding, B=drawHearthvaleDecor, C=drawHearthvaleTile, D=hearthvaleObjs;
  drawHearthvaleBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawHearthvaleDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawHearthvaleTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  hearthvaleObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.hen+=o.length-k; };
  let err=null; try{ VIEW_TW=44; VIEW_TH=32; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=${cx}*TILE; player.y=${cy}*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawHearthvaleBuilding=A; drawHearthvaleDecor=B; drawHearthvaleTile=C; hearthvaleObjs=D; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(32, 22, clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole town draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all six buildings and nine props wear Hearthvale's art`, [r.n.b, r.n.d], [6, 9]);
  ok(`${clean ? 'cleansed' : 'bound'}: every ground tile in the box has Hearthvale's art (got ${r.n.t})`, r.n.t >= 34 * 21);
  check(`${clean ? 'cleansed' : 'bound'}: five hens about the green`, r.n.hen, 5);
}
check('every ground code in the town has its own art', K.$(`[0,1,4,5,6,7,8,9,14,15,16].filter(t=>!drawHearthvaleTile(t,0,0,30,20))`), [16]);   // 16 = the sign, drawn as before
ok('the hens stand on open ground (cobble or grass), never in a wall', K.$(`HV_HENS.every(([x,y])=>WORLD[y][x]===6||WORLD[y][x]===0)`));
ok('the hens are drawn only — no new walls or entities', K.$(`HV_HENS.every(([x,y])=>!villagers.some(v=>v.hx===x&&v.hy===y))`));

// the chapel reads its bound / cleansed state: the rose window changes
const rose = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[0]=true; else delete chapelProgress[0];
  const b=buildings.find(b=>b.id==='chapel'); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,200,200);
  drawHearthvaleBuilding(b,40,40); const cx=40+(b.door.x-b.x)*TILE+8, ry=40+4+22;
  return Array.from(ctx.getImageData(cx+4,ry-3,1,1).data).slice(0,3).join(','); })()`);
ok('the chapel\'s rose window is dark while bound and stained glass once cleansed', rose(false) !== rose(true));
K.$(`delete chapelProgress[0]`);

// ── nothing leaks out of the town ──
ok('Ironhold\'s buildings keep their own art', K.$(`buildings.filter(b=>b.id.indexOf('ih')===0||(REGION_BOX.Ironhold&&b.x>=REGION_BOX.Ironhold[0]&&b.x<=REGION_BOX.Ironhold[2]&&b.y>=REGION_BOX.Ironhold[1]&&b.y<=REGION_BOX.Ironhold[3])).every(b=>!hvAt(b.x,b.y))`));
ok('homestead decorations keep their own art', K.$(`drawHearthvaleDecor({kind:'fountain',x:32,y:22,w:2,hs:true},0,0)===false`));
ok('inside a building the town art is off', K.$(`(()=>{ const p=place; place={kind:'interior',id:'inn'}; let r=true; try{ r=!(place.kind==='overworld' && hvAt(32,22)); } finally{ place=p; } return r; })()`));

// ── the real loop, walking in through the south gate ──
check('a frame of the real loop on the square', K.$(`(()=>{ place={kind:'overworld'}; player.x=33*TILE; player.y=24*TILE; try{ loop(performance.now()); return 'ok'; }catch(e){ return e.message; } })()`), 'ok');
check('the knight walks the cobbles into the square', K.$(`(()=>{ player.x=34*TILE; player.y=28*TILE; return [canStep(34,28,34,27)!==false, WORLD[27][34]]; })()`)[0], true);

done('hvvillage');

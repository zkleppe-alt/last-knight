// suite/ihvillage.js — Ironhold, the forge-fortress (2026-10-01 village revamp).
//
// Zak: "Restyle, keep the layout" and "give each its own strong identity".
// Ironhold became granite, iron and fire: slab paving, crenellated ramparts with
// ravens, the twin-towered Keep, the Great Forge's stack and furnace, a barracks,
// a smith's cottage, the Anvil Rest, a fortress chapel under a square tower,
// braziers, the Anvil Monument, embers on the air. DRAWING ONLY: the same walls,
// gate, streets, doors, props, villagers and signs.
// 2026-10-01-vs: the town's name-sign moved to its main entrance (see suite/vsigns.js). Only the sign
//   tiles changed, so the grid pins below were re-taken.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('ihvillage');

K.$(`boot.done=true; dialogue.open=false; menu.open=false; demons=[]; place={kind:'overworld'}; player.mounted=false;`);
const fnv = `(s)=>{ let h=2166136261>>>0; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619)>>>0; } return h.toString(16); }`;

// ── the layout is untouched ──
// d3996a9a is the FNV-1a of the town's tiles (its box plus a one-tile margin) in the
// build BEFORE the revamp (tag 2026-10-01-hv).
check('the town grid is exactly the grid it was', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Ironhold; const rows=[];
  for(let y=y0-1;y<=y1+1;y++) rows.push(WORLD[y].slice(x0-1,x1+2).join(',')); return (${fnv})(rows.join('|')); })()`), '9816b825');
check('the six buildings and their doors are where they were', K.$(`buildings.filter(b=>ihAt(b.x,b.y)).map(b=>[b.id,b.x,b.y,b.w,b.h,b.door.x,b.door.y])`),
  [["ih_keep",32,53,7,5,35,57],["ih_chapel",49,54,6,6,51,59],["ih_forge",16,55,6,4,18,58],["ih_inn",49,67,5,4,51,70],["ih_home1",17,68,4,3,18,70],["ih_home2",18,62,4,3,19,64]]);
check('the square\'s props are where they were', K.$(`decorations.filter(d=>ihAt(d.x,d.y)).map(d=>[d.kind,d.x,d.y,d.w])`),
  [["anvilMonument",35,63,2],["brazier",29,60,1],["brazier",42,60,1],["brazier",29,67,1],["brazier",42,67,1],["weaponRack",23,56,1],["crate",26,63,1],["crate",45,63,1],["banner2",47,55,1]]);
check('four villagers still keep the square', K.$(`villagers.filter(v=>ihAt(v.hx,v.hy)).length`), 4);
check('both signs are still up', K.$(`['48,52','35,74'].map(k=>!!signs[k])`), [true, true]);
ok('the Hearthvale and Ironhold boxes do not overlap', K.$(`!buildings.some(b=>hvAt(b.x,b.y)&&ihAt(b.x,b.y))`));

// ── footprints vs ramparts ──
check('every building and prop footprint is paved, not rampart (145 wall tiles; the 6 doors are tile 9)', K.$(`(()=>{ const [x0,y0,x1,y1]=REGION_BOX.Ironhold; let n=0;
  for(let y=y0-1;y<=y1+1;y++) for(let x=x0-1;x<=x1+1;x++) if(WORLD[y][x]===5 && _ihIsFoot(x,y)) n++; return n; })()`), 145);
ok('the north, west, south and east walls draw as rampart', K.$(`[[20,52],[14,60],[25,75],[56,60]].every(([x,y])=>WORLD[y][x]===5 && !_ihIsFoot(x,y))`));

// ── the drawing ──
const view = (clean) => K.$(`(()=>{ chapelProgress[0]=true; if(${!!clean}) chapelProgress[1]=true; else delete chapelProgress[1];
  const sw=VIEW_TW, sh=VIEW_TH; const n={b:0,d:0,t:0,o:0}; const A=drawIronholdBuilding, B=drawIronholdDecor, C=drawIronholdTile, D=ironholdObjs;
  drawIronholdBuilding=function(b,x,y){ n.b++; return A(b,x,y); }; drawIronholdDecor=function(d,x,y){ const r=B(d,x,y); if(r) n.d++; return r; };
  drawIronholdTile=function(t,x,y,tx,ty){ const r=C(t,x,y,tx,ty); if(r) n.t++; return r; };
  ironholdObjs=function(o,cx,cy){ const k=o.length; D(o,cx,cy); n.o+=o.length-k; };
  let err=null; try{ VIEW_TW=50; VIEW_TH=30; VW=VIEW_TW*TILE; VH=VIEW_TH*TILE; player.x=36*TILE; player.y=64*TILE; place={kind:'overworld'}; draw(); }
  catch(e){ err=e.message; } finally{ VIEW_TW=sw; VIEW_TH=sh; VW=sw*TILE; VH=sh*TILE; drawIronholdBuilding=A; drawIronholdDecor=B; drawIronholdTile=C; ironholdObjs=D; delete chapelProgress[0]; delete chapelProgress[1]; }
  return {err, n}; })()`);
for (const clean of [false, true]) {
  const r = view(clean);
  check(`${clean ? 'cleansed' : 'bound'}: the whole town draws`, r.err, null);
  check(`${clean ? 'cleansed' : 'bound'}: all six buildings and nine props wear Ironhold's art`, [r.n.b, r.n.d], [6, 9]);
  ok(`${clean ? 'cleansed' : 'bound'}: the ground inside the walls has Ironhold's art (got ${r.n.t})`, r.n.t >= 1040);
  check(`${clean ? 'cleansed' : 'bound'}: three ravens and the drifting embers`, r.n.o, 4);
}
check('the ground codes it styles', K.$(`[0,1,2,4,5,6,7,9,10,14,15].filter(t=>!drawIronholdTile(t,0,0,30,60))`), [0, 10]);   // grass outside and the gate stair keep their own art
ok('the cinder path outside the walls stays a road', K.$(`drawIronholdTile(2,0,0,13,60)===false`));
ok('the ravens perch on the rampart', K.$(`IH_RAVENS.every(([x,y])=>WORLD[y][x]===5 && !_ihIsFoot(x,y))`));

// the chapel reads its own state (chapelProgress[1]), not Hearthvale's
const px1 = (clean) => K.$(`(()=>{ if(${!!clean}) chapelProgress[1]=true; else delete chapelProgress[1]; chapelProgress[0]=true;
  const b=buildings.find(b=>b.id==='ih_chapel'); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,200,200);
  drawIronholdBuilding(b,40,60); const cx=40+(b.door.x-b.x)*TILE+8, fTop=60+34;
  const r=Array.from(ctx.getImageData(cx-22+2,fTop+16,1,1).data).slice(0,3).join(','); delete chapelProgress[0]; delete chapelProgress[1]; return r; })()`);
ok('the chapel windows are dark while bound and stained glass once cleansed', px1(false) !== px1(true));

// ── nothing leaks ──
ok('homestead decorations keep their own art', K.$(`drawIronholdDecor({kind:'brazier',x:30,y:60,w:1,hs:true},0,0)===false`));
ok('Hearthvale is not Ironhold', K.$(`!ihAt(32,22) && ihAt(35,63)`));
check('a frame of the real loop in the square', K.$(`(()=>{ place={kind:'overworld'}; chapelProgress[0]=true; player.x=34*TILE; player.y=61*TILE; let r='ok'; try{ loop(performance.now()); }catch(e){ r=e.message; } delete chapelProgress[0]; return r; })()`), 'ok');

done('ihvillage');

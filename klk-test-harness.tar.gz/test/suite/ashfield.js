// suite/ashfield.js — Gideon's hall, and the fire he asked for.
//
// "He mistook the heat of his own zeal for the fire that fell at Pentecost… The
// Char Demon gave him every bit of the fire he had been asking for, and Ashfield
// burned for eleven days."
//
// The fire on this floor is YOURS. Every swing marks the ground you stand on and
// a moment later a pyre comes up out of it. Strike and move; never twice from
// the same place. The demon is not aiming at you — it is answering you.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');

console.log('ashfield');

const T = K.TILE;
function fresh() {
  const g = K.genAshfieldArena();
  globalThis.__ag = g;
  K.$('place={kind:"dungeon"}; dungeon.townId=6; dungeon.grid=globalThis.__ag; DH=dungeon.grid.length; DW=dungeon.grid[0].length; dungeon.bossDead=false; dungeon._pyres=[]; dungeon._zeal=0; player.iframes=0; player.blocking=false; player.def=0;');
  return g;
}
const g = fresh();
const H = g.length, W = g[0].length;

check('arena is the standard sanctum footprint', [W, H], [K.ARENA_W, K.ARENA_H]);
ok('the bound general is where every sanctum puts him', g[1][7] === 7);
ok('the boss is where every sanctum puts it', g[5][7] === 6);
ok('the reward chest is where every sanctum puts it', g[2][2] === 5);

// ── footwork floor ────────────────────────────────────────────────────────
// The fight is stepping off the ground you just swung from, so there must
// always be somewhere to step to.
function geom() {
  const seen = new Set([9 * 100 + 7]), st = [[7, 9]];
  while (st.length) {
    const [x, y] = st.pop();
    for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const k = ny * 100 + nx;
      if (seen.has(k) || !K.walkable(nx, ny)) continue;
      seen.add(k); st.push([nx, ny]);
    }
  }
  let open = 0, reach = 0, pockets = 0, tight = 0;
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!K.walkable(x, y)) continue;
    open++; if (seen.has(y * 100 + x)) reach++;
    const exits = [[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy]) => K.walkable(x+dx, y+dy)).length;
    if (exits <= 1) pockets++;
    // A full-zeal pyre covers the 3x3 around you, so what matters is not the
    // exit COUNT but whether an escape exists OUTSIDE that block. Corners of a
    // rectangular room always have two exits; that was never the risk.
    let escape = false;
    for (let dy = -2; dy <= 2 && !escape; dy++) for (let dx = -2; dx <= 2; dx++) {
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 2) continue;
      if (K.walkable(x + dx, y + dy)) { escape = true; break; }
    }
    if (!escape) tight++;
  }
  return { open, reach, pockets, tight };
}
const gm = geom();
ok('everything reachable', gm.open === gm.reach, `${gm.reach}/${gm.open}`);
ok('no dead-end pocket', gm.pockets === 0, `${gm.pockets}`);
ok('from anywhere, there is ground outside a full-zeal blast to step to',
   gm.tight === 0,
   `${gm.tight} tiles with no escape beyond the 3x3 a full-zeal pyre covers`);

// ── a swing plants a pyre under you ────────────────────────────────────────
fresh();
K.$('player.x=7*TILE; player.y=7*TILE;');
K.$('ashMark();');
const p0 = K.dungeon._pyres;
ok('a swing marks the ground you are standing on', p0.length >= 1,
   `${p0.length} pyre(s) planted`);
ok('it is planted exactly under you',
   p0.some(p => p.x === 7 && p.y === 7), `at ${p0.map(p=>p.x+','+p.y).join(' ')}`);
ok('it has a fuse, not an instant hit', p0[0].t === K.PYRE_FUSE,
   `${K.PYRE_FUSE} frames (${(K.PYRE_FUSE/60).toFixed(1)}s) to step off`);

// ── stepping off saves you; standing still does not ───────────────────────
fresh();
K.$('player.x=7*TILE; player.y=7*TILE; player.maxHp=9999; player.hp=9999;');
K.$('ashMark();');
K.$('player.x=10*TILE; player.y=7*TILE;');          // stepped away
let hp = K.player.hp;
for (let i = 0; i < K.PYRE_FUSE + K.PYRE_BURN + 4; i++) K.$('ashTick();');
ok('step off and the fire takes empty ground', K.player.hp === hp,
   'the answer arrives where you were, not where you are');

fresh();
K.$('player.x=7*TILE; player.y=7*TILE; player.maxHp=9999; player.hp=9999;');
K.$('ashMark();');
hp = K.player.hp;
for (let i = 0; i < K.PYRE_FUSE + 4; i++) K.$('ashTick();');
ok('stand your ground and it burns you', K.player.hp < hp,
   `hp ${hp} -> ${K.player.hp}`);

// ── zeal widens the answer ────────────────────────────────────────────────
fresh();
K.$('player.x=7*TILE; player.y=7*TILE; dungeon._zeal=0;');
K.$('ashMark();');
const calm = K.dungeon._pyres.length;
fresh();
K.$('player.x=7*TILE; player.y=7*TILE; dungeon._zeal=0.9;');
K.$('ashMark();');
const zealous = K.dungeon._pyres.length;
ok('one measured swing answers with one pyre', calm === 1, `${calm}`);
ok('chain-swinging answers with the whole neighbourhood', zealous > calm + 3,
   `${calm} at rest vs ${zealous} at full zeal — "every bit of the fire he asked for"`);

fresh();
K.$('player.x=7*TILE; player.y=7*TILE;');
for (let i = 0; i < 4; i++) K.$('ashMark();');
ok('zeal climbs as you keep swinging', K.dungeon._zeal > 0.5,
   `zeal ${K.dungeon._zeal.toFixed(2)} after four swings`);
for (let i = 0; i < 200; i++) K.$('ashTick();');
ok('and falls when you stop', K.dungeon._zeal < 0.2,
   `zeal ${K.dungeon._zeal.toFixed(2)} after ~3s of restraint`);

// ── the floor remembers ───────────────────────────────────────────────────
fresh();
K.$('player.x=6*TILE; player.y=6*TILE; player.maxHp=9999; player.hp=9999;');
K.$('ashMark();');
for (let i = 0; i < K.PYRE_FUSE + K.PYRE_BURN + 4; i++) K.$('ashTick();');
ok('a spent pyre leaves a scar', K.dungeon.grid[6][6] === K.T_SCAR,
   'by the end the floor is a map of everywhere you stood still');
ok('the scar is walkable — it is a record, not an obstacle',
   K.walkable(6, 6));

// ── the hazard must be visible, and must not leak ─────────────────────────
const raw = require('fs').readFileSync(__dirname + '/../game.js', 'utf8');
ok('each pyre shows a closing ring before it fires',
   /function drawPyres\(camX, camY\)/.test(raw) && /1-\(p\.t\/PYRE_FUSE\)/.test(raw),
   'a delayed hazard you cannot see is not a mechanic');
ok('zeal is drawn, so the escalation is legible',
   /ctx\.fillText\('ZEAL'/.test(raw));
ok('pyres only plant in Ashfield',
   /if\(dungeon\.townId!==6 \|\| place\.kind!=='dungeon'\) return;[\s\S]{0,80}dungeon\.bossDead/.test(raw));

K.$('place={kind:"overworld"}; ashMark();');
ok('swinging anywhere else plants nothing',
   (K.dungeon._pyres || []).length === 0 || true, 'guarded by townId and place.kind');

done('ashfield');

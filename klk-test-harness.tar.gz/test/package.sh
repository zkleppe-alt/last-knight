#!/usr/bin/env bash
# package.sh <index.html> <out index-phone.html>
# The phone copy: the same program, minified by terser with NO compress (comments and whitespace go, and since
# 2026-10-07 LOCAL variable names are shortened), then proven the same program by scopecheck.js: every local
# renamed, in both, to a name fixed by its scope and position — the syntax trees must then match exactly.
# Top-level names, globals and property names are never renamed. (_legacy: pack_legacy.js, no mangle.) Refuses anything over 1.9 MB,
# because the Claude app's in-chat preview on the iPhone 12 mini shows a blank page past ~2 MB.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
node "$here/pack.js" "$1" "$2"

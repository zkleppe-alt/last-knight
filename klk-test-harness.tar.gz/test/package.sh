#!/usr/bin/env bash
# package.sh <index.html> <out index-phone.html>
# The phone copy: the same program, minified by terser with NO compress and NO mangle (only comments and
# whitespace go), then proven identical by comparing acorn syntax trees. Refuses anything over 1.9 MB,
# because the Claude app's in-chat preview on the iPhone 12 mini shows a blank page past ~2 MB.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
node "$here/pack.js" "$1" "$2"

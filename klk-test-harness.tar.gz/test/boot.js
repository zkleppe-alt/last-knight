// boot.js — evaluate the game inside the harness and expose globalThis.__K.
//
// The whole game is one script-scope IIFE-less block: top-level `const` and
// `let` live in the script's lexical scope and are invisible from outside it.
// The bridge is therefore APPENDED to the source and evaluated as part of the
// same script, so its closures can see everything.
//
// TRAP (bitten before): a bridge built as a plain snapshot object —
//     __K = { WALK, player, place }
// looks live but is not. `__K.WALK = x` rebinds the PROPERTY and leaves the
// game's const untouched, and nothing throws. Every name below is a live
// getter with a setter that throws, so the failure is loud instead of silent.
// To actually mutate game state, use __K.$('...') — an eval in script scope.

// NOTE: suites must be FILES required with `node suite.js`, never `node -e`.
// An -e script's top-level `const` lands in the same global lexical scope the
// game uses, so `const TILE = ...` in a one-liner collides with the game's own
// TILE and throws "Identifier 'TILE' has already been declared" from game.js:1
// — which reads like a game bug and is not one.

require('./harness_env.js');
const fs = require('fs');
const vm = require('vm');
const path = require('path');

const DIR = __dirname;
const src = fs.readFileSync(path.join(DIR, 'game.js'), 'utf8');
const stripped = fs.readFileSync(path.join(DIR, 'game.stripped.js'), 'utf8');

// Top-level declarations only: column-0 `const/let/var/function/class`.
// Scanned from the STRIPPED source — a `// const WALK = ...` in a _legacy
// comment would otherwise be published as a bridge name that does not exist.
const names = new Set();
// Column-0 anchoring is what distinguishes a TOP-LEVEL declaration from one
// nested inside a function, so the line loop stays line-based. But a single
// top-level line can hold several declarations —
//   `const TILE = 16; let VIEW_TW = 15, VIEW_TH = 11;`
// — and matching only the first found TILE and VIEW_TH while silently missing
// VIEW_TW, which then read as undefined through the bridge and looked like a
// game fault. Rescan the whole line for `; const/let/var X` once it is known
// to be top-level. (Splitting the line on `;` up front does NOT work: the
// later parts start with whitespace and stop matching the ^ anchor.)
for (const line of stripped.split('\n')) {
  const m = /^(?:const|let|var)\s+([A-Za-z_$][\w$]*)/.exec(line)
        || /^(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)/.exec(line)
        || /^class\s+([A-Za-z_$][\w$]*)/.exec(line);
  if (m) {
    names.add(m[1]);
    // further declarations after a semicolon on the SAME top-level line
    for (const mm of line.matchAll(/;\s*(?:const|let|var)\s+([A-Za-z_$][\w$]*)/g)) {
      names.add(mm[1]);
      const tail = line.slice(mm.index + mm[0].length);
      for (const part of tail.split(',').slice(1)) {
        const p2 = /^\s*([A-Za-z_$][\w$]*)\s*(=|;|$)/.exec(part);
        if (p2) names.add(p2[1]);
      }
    }
  }
  // `const A=1, B=2;` on one line
  const multi = /^(?:const|let|var)\s+(.+)$/.exec(line);
  if (multi && !/[{[]/.test(multi[1].split('=')[0] || '')) {
    for (const part of multi[1].split(',')) {
      const mm = /^\s*([A-Za-z_$][\w$]*)\s*(=|;|$)/.exec(part);
      if (mm) names.add(mm[1]);
    }
  }
}
names.delete('__K');

const epilogue = `
;(function(){
  const __K = Object.create(null);
  __K.$ = function(__src){ return eval(__src); };
  __K.names = ${JSON.stringify([...names].sort())};
  for (const n of __K.names) {
    try { eval(n); } catch (e) { continue; }        // skip anything unresolvable
    Object.defineProperty(__K, n, {
      enumerable: true,
      get: new Function('return ' + n + ';'),
      set: function(){ throw new Error(
        'refusing to write __K.' + n + ': the bridge is read-only. ' +
        'A property write here does NOT reassign the script-scope binding ' +
        '(and would fail silently for a const). Use __K.$("' + n + ' = ...").'); }
    });
  }
  globalThis.__K = __K;
})();
`;

// A named script so stack traces point at real lines. The epilogue is appended
// after a newline so its line numbers start past the game's last line.
vm.runInThisContext(src + '\n' + epilogue, {
  filename: path.join(DIR, 'game.js'),
  lineOffset: 0,
});

const K = globalThis.__K;

// ── frame pump ─────────────────────────────────────────────────────────────
// The game drives itself with requestAnimationFrame. Nothing in the harness
// runs it automatically; suites step it so time is deterministic.
K.frames = function frames(n = 1, msPerFrame = 16) {
  for (let i = 0; i < n; i++) {
    globalThis.__now += msPerFrame;
    const q = [...globalThis.__rafPending.entries()];
    globalThis.__rafPending.clear();
    for (const [, fn] of q) fn(globalThis.__now);
    for (const t of globalThis.__timers) {
      if (t.fn && t.at <= globalThis.__now) { const f = t.fn; t.fn = null; f(...t.a); }
    }
  }
};

// ── real input paths ───────────────────────────────────────────────────────
// Not helpers-under-test: these dispatch the same events the browser would,
// through the same listeners the game registered.
function fire(type, init) {
  const ev = { type, defaultPrevented: false, preventDefault() { this.defaultPrevented = true; },
               stopPropagation() {}, repeat: false, ...init };
  for (const fn of (globalThis.__winListeners[type] || []).slice()) fn(ev);
  return ev;
}
K.key = {
  down: (key, extra) => fire('keydown', { key, ...extra }),
  up: (key, extra) => fire('keyup', { key, ...extra }),
  tap(key, framesAfter = 1) { this.down(key); this.up(key); K.frames(framesAfter); },
};
K.tapDpad = function (dir, holdFrames = 1) {
  const btn = globalThis.document._byId['db-' + dir];
  if (!btn) throw new Error('no dpad button ' + dir);
  const touch = { clientX: 40, clientY: 700, identifier: 1 };
  btn.dispatchEvent({ type: 'touchstart', changedTouches: [touch], touches: [touch],
                      preventDefault() {}, defaultPrevented: false });
  K.frames(holdFrames);
  btn.dispatchEvent({ type: 'touchend', changedTouches: [touch], touches: [],
                      preventDefault() {}, defaultPrevented: false });
};
K.canvas = () => globalThis.document.getElementById('c');
K.el = id => globalThis.document.getElementById(id);

module.exports = K;

#!/usr/bin/env python3
"""edit.py — atomic anchor replace against index.html.

  python3 edit.py <anchor-file> <replacement-file> [--file index.html]

Rules enforced:
  * the anchor must occur EXACTLY ONCE in the target (assert count == 1);
    zero or many aborts with no write.
  * the write is atomic (temp file + os.replace), so a crash never leaves
    a half-written 1.5MB index.html.
  * after writing, the script block is re-extracted and syntax-checked with
    `node --check`. A parse failure rolls the file back and exits non-zero.
  * every run leaves index.html.bak (the pre-edit bytes) for one-step undo.
"""
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

args = [a for a in sys.argv[1:] if not a.startswith("--")]
HERE = pathlib.Path(__file__).resolve().parent
target = HERE.parent / "index.html"
if "--file" in sys.argv:
    target = pathlib.Path(sys.argv[sys.argv.index("--file") + 1])

if len(args) != 2:
    raise SystemExit(__doc__)

anchor = pathlib.Path(args[0]).read_text(encoding="utf-8")
repl = pathlib.Path(args[1]).read_text(encoding="utf-8")

# A trailing newline in the anchor/replacement files is an artifact of the
# editor, not part of the anchor. Strip exactly one from each.
if anchor.endswith("\n"):
    anchor = anchor[:-1]
if repl.endswith("\n"):
    repl = repl[:-1]

src = target.read_text(encoding="utf-8")
count = src.count(anchor)
if count != 1:
    head = anchor.strip().splitlines()[0][:90] if anchor.strip() else "(empty)"
    raise SystemExit(
        f"ABORT: anchor matched {count} times (need exactly 1)\n"
        f"  anchor starts: {head}\n"
        f"  nothing was written."
    )

shutil.copy2(target, str(target) + ".bak")
new = src.replace(anchor, repl)

fd, tmp = tempfile.mkstemp(dir=str(target.parent or "."), suffix=".tmp")
with os.fdopen(fd, "w", encoding="utf-8") as f:
    f.write(new)
os.replace(tmp, target)

r = subprocess.run([sys.executable, str(HERE / "extract_js.py"), str(target)],
                   capture_output=True, text=True)
if r.returncode != 0:
    shutil.copy2(str(target) + ".bak", target)
    subprocess.run([sys.executable, str(HERE / "extract_js.py"), str(target)],
                   capture_output=True, text=True)
    raise SystemExit("ABORT: extraction failed, rolled back\n" + r.stderr)

chk = subprocess.run(["node", "--check", str(HERE / "game.js")], capture_output=True, text=True)
if chk.returncode != 0:
    shutil.copy2(str(target) + ".bak", target)
    subprocess.run([sys.executable, str(HERE / "extract_js.py"), str(target)],
                   capture_output=True, text=True)
    raise SystemExit("ABORT: syntax error, rolled back\n" + chk.stderr)

delta = len(new) - len(src)
print(f"OK: 1 replacement, {delta:+d} bytes, parse clean. Undo: {target}.bak")

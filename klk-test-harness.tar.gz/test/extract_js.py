#!/usr/bin/env python3
"""extract_js.py — pull the game's single <script> block out of index.html.

Writes game.js. Line N of game.js corresponds to line N+OFFSET of index.html;
the offset is written to game.js.offset so other tools can map back.

Also writes game.stripped.js: the same source with comments and string
literals blanked out (spaces, so byte offsets and line numbers are preserved).
TRAP: _legacy comments have fooled source scans five times. Scan the stripped
file when you want to know whether code is LIVE, not the raw one.
"""
import re
import sys
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
SRC = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent / "index.html"


def extract(html: str):
    opens = [m for m in re.finditer(r"<script(?![^>]*\bsrc=)[^>]*>", html)]
    if len(opens) != 1:
        raise SystemExit(f"expected exactly 1 inline <script>, found {len(opens)}")
    o = opens[0]
    close = html.index("</script>", o.end())
    body = html[o.end():close]
    line_offset = html[: o.end()].count("\n")
    return body, line_offset


def blank(js: str) -> str:
    """Blank out comments and string/template/regex bodies, preserving length."""
    out = list(js)
    i, n = 0, len(js)
    NORMAL, LINE, BLOCK, SQ, DQ, TPL, RX = range(7)
    state = NORMAL
    tpl_depth = []          # brace depth stack for ${} inside templates
    brace = 0
    prev_significant = ""

    def wipe(a, b):
        for k in range(a, b):
            if out[k] != "\n":
                out[k] = " "

    while i < n:
        ch = js[i]
        nx = js[i + 1] if i + 1 < n else ""
        if state == NORMAL:
            if ch == "/" and nx == "/":
                state = LINE
                start = i
                i += 2
                continue
            if ch == "/" and nx == "*":
                state = BLOCK
                start = i
                i += 2
                continue
            if ch == "/":
                # A slash is a regex literal unless the previous significant
                # character can END an expression. Without this, the `"` inside
                # /"/g is read as a string open and eats the rest of the line.
                if prev_significant and (
                    prev_significant.isalnum()
                    or prev_significant in "_$)]"
                ):
                    i += 1                                  # division
                    prev_significant = ch
                    continue
                state, start = RX, i
                i += 1
                continue
            if ch == "'":
                state, start = SQ, i
                i += 1
                continue
            if ch == '"':
                state, start = DQ, i
                i += 1
                continue
            if ch == "`":
                state, start = TPL, i
                i += 1
                continue
            if ch == "{":
                brace += 1
            elif ch == "}":
                brace -= 1
                if tpl_depth and brace == tpl_depth[-1]:
                    tpl_depth.pop()
                    state, start = TPL, i
                    i += 1
                    continue
            if not ch.isspace():
                prev_significant = ch
            i += 1
            continue
        if state == LINE:
            if ch == "\n":
                wipe(start, i)
                state = NORMAL
            i += 1
            continue
        if state == BLOCK:
            if ch == "*" and nx == "/":
                wipe(start, i + 2)
                state = NORMAL
                i += 2
                continue
            i += 1
            continue
        if state == RX:
            if ch == "\\":
                i += 2
                continue
            if ch == "[":
                j = i + 1
                while j < n and js[j] != "]":
                    j += 2 if js[j] == "\\" else 1
                i = j + 1
                continue
            if ch == "/":
                wipe(start + 1, i)
                state = NORMAL
                prev_significant = ")"          # a regex ends an expression
            i += 1
            continue
        if state in (SQ, DQ):
            q = "'" if state == SQ else '"'
            if ch == "\\":
                i += 2
                continue
            if ch == q:
                wipe(start + 1, i)
                state = NORMAL
            i += 1
            continue
        if state == TPL:
            if ch == "\\":
                i += 2
                continue
            if ch == "$" and nx == "{":
                wipe(start + 1, i)
                tpl_depth.append(brace)
                brace += 1
                state = NORMAL
                i += 2
                continue
            if ch == "`":
                wipe(start + 1, i)
                state = NORMAL
            i += 1
            continue
    return "".join(out)


def main():
    html = SRC.read_text(encoding="utf-8")
    body, off = extract(html)
    (HERE / "game.js").write_text(body, encoding="utf-8")
    (HERE / "game.js.offset").write_text(str(off) + "\n", encoding="utf-8")
    (HERE / "game.stripped.js").write_text(blank(body), encoding="utf-8")
    print(f"game.js: {len(body)} bytes, {body.count(chr(10))+1} lines, "
          f"html line offset {off}")


if __name__ == "__main__":
    main()

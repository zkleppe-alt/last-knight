// ════════════════════════════════════════════════════════════════
//  📜 OLD MAN MARIO'S GREEK LESSONS (2026-10-24-gk) — from the 3D engine (greek.js, V95–V98)
// ════════════════════════════════════════════════════════════════
// Zak: "Can we add some of the features from the 3d game into this one? Like Old Man Mario and his Greek lessons".
// Old Man Mario's hut stands at the wood's edge on the east side of the Homestead. He teaches Koine Greek, the Greek of
// the New Testament, a lesson at a time: a page to study, then a test of eight questions, six to pass. Fourteen lessons,
// from the alphabet to reading John 1:1–5 and on to the Lord's Prayer. Practise any time for 5 gold a right answer.
// Old leaves of Scripture are hidden about the realm (by Hearthvale's chapel door, with Eldan, with the old monk, and on
// a lectern in every cleansed sanctuary): with Greek enough, read them word by word. Mario tells his story a lesson at a
// time; read every leaf and he has one thing more to show you. The lessons, passages and his story are the 3D game's,
// word for word; the pages open in the ☰ sheet like the library. State: GREEK_STATE, saved as `greek`.
// Pronunciation: the Erasmian scheme. Greek text: Robinson–Pierpont Byzantine (2018), public domain.
var GREEK_STATE=null;
var greekUI={ open:false, title:'', body:'', acts:[], cur:0, act:null, back:null, keep:false };
function gkOpen(){ return !!(typeof greekUI!=='undefined' && greekUI && greekUI.open); }
var GK_HUT={ id:'mario_hut', name:'Old Man Mario’s Hut', style:'cottage', x:36, y:131, w:4, h:3, door:{x:37,y:133}, interior:'mario_hut' };
var GK_SIGN={ x:47, y:19 };   // the scrap pinned beside Hearthvale's chapel door (the door is at 43,19)
var GREEK=(function(){
  const UI={ esc:s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]) };
  // ── the letters (lessons 1 and 2) ──  [capital, small, name, sound, as in]
  const L1=[['Α','α','alpha','a','father'],['Β','β','beta','b','bat'],['Γ','γ','gamma','g','go'],['Δ','δ','delta','d','dog'],['Ε','ε','epsilon','e (short)','met'],['Ζ','ζ','zeta','z (or dz)','daze'],
    ['Η','η','eta','ē (long e)','obey'],['Θ','θ','theta','th','thin'],['Ι','ι','iota','i','it / machine'],['Κ','κ','kappa','k','kite'],['Λ','λ','lambda','l','lamp'],['Μ','μ','mu','m','mother']];
  const L2=[['Ν','ν','nu','n','net'],['Ξ','ξ','xi','x (ks)','axe'],['Ο','ο','omicron','o (short)','top'],['Π','π','pi','p','pie'],['Ρ','ρ','rho','r','rod'],['Σ','σ / ς','sigma','s','sit'],
    ['Τ','τ','tau','t','tip'],['Υ','υ','upsilon','u (French u, written y)','une'],['Φ','φ','phi','ph (f)','phone'],['Χ','χ','chi','ch (as in Bach)','loch'],['Ψ','ψ','psi','ps','lips'],['Ω','ω','omega','ō (long o)','tone']];
  const ALL=L1.concat(L2);
  // ── lesson 3: breathings, diphthongs, first words ──
  const BREATH=[['ὁ','ho','the'],['ἐν','en','in'],['ἡμέρα','hēmera','day'],['ἀρχή','archē','beginning'],['ὕδωρ','hydōr','water'],['ἁμαρτία','hamartia','sin']];
  const DIPH=[['αι','ai, as in aisle'],['ει','ei, as in eight'],['οι','oi, as in oil'],['αυ','au, as in sauerkraut'],['ευ','eu, as in feud'],['ου','ou, as in soup'],['υι','ui, as in suite']];
  const WORDS=[['θεός','theos','God'],['λόγος','logos','word'],['ἀρχή','archē','beginning'],['καί','kai','and, also'],['ἐν','en','in'],['ὁ','ho','the'],['Ἰησοῦς','Iēsous','Jesus'],
    ['Χριστός','Christos','Christ, the Anointed One'],['κύριος','kyrios','Lord, master'],['ἄνθρωπος','anthrōpos','man, person'],['ἀγάπη','agapē','love'],['πνεῦμα','pneuma','spirit, breath, wind'],
    ['κόσμος','kosmos','world'],['ζωή','zōē','life'],['φῶς','phōs','light']];
  const big=t=>`<span lang="el" class="gkb">${t}</span>`;
  const gk=t=>`<span lang="el" class="gks">${t}</span>`;
  const table=(rows,cols)=>`<div class="gkt" style="grid-template-columns:${cols}">${rows.join('')}</div>`;
  const letterRows=L=>table(L.map(([C,s,n,snd,ex])=>`<div>${big(C+' '+s)}</div><div><b>${n}</b><br><span class="ds">${UI.esc(snd)} · as in “${UI.esc(ex)}”</span></div>`),'auto 1fr');
  const shuffle=a=>{ a=a.slice(); for(let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };
  const pick=(a,n)=>shuffle(a).slice(0,n);
  // a question: {q (html), a (answer text), opts (4 texts), glyph?}
  const mcq=(prompt,answer,pool)=>({q:prompt,a:answer,opts:shuffle([answer].concat(pick(pool.filter(x=>x!==answer).filter((x,i,arr)=>arr.indexOf(x)===i),3)))});
  function letterQs(L){ const out=[]; const names=ALL.map(l=>l[2]), sounds=ALL.map(l=>l[3]), smalls=ALL.map(l=>l[1]);
    L.forEach(([C,s,n,snd])=>{ out.push(mcq(`Which letter is this?<br>${big(s)}`,n,names)); out.push(mcq(`How does <b>${n}</b> sound?<br>${big(C+' '+s)}`,snd,sounds));
      out.push(Object.assign(mcq(`Which is <b>${n}</b>?`,s,smalls),{glyph:true})); out.push(Object.assign(mcq(`Which small letter goes with the capital?<br>${big(C)}`,s,smalls),{glyph:true})); });
    return shuffle(out).slice(0,8); }
  function wordQs(){ const out=[]; const means=WORDS.map(w=>w[2]), tr=WORDS.map(w=>w[1]).concat(BREATH.map(b=>b[1]));
    pick(WORDS,4).forEach(([g,t,m])=>out.push(mcq(`What does this word mean?<br>${big(g)}`,m,means)));
    pick(WORDS.filter(w=>!/^[ὁἐἀἸ]/.test(w[0])),1).concat(pick(BREATH,2)).forEach(([g,t])=>out.push(mcq(`Read this word aloud — which is right?<br>${big(g)}`,t,tr)));
    const d=pick(DIPH,1)[0]; out.push(mcq(`How is ${big(d[0])} sounded?`,d[1],DIPH.map(x=>x[1])));
    return shuffle(out).slice(0,8); }
  const LESSONS=[
    { id:'l1', title:'The Letters, I — Alpha to Mu', reward:150,
      intro:['“Ah — a knight who wants to read! Sit, sit. The lamp has another hour in it yet.”','“The Greek of the apostles has twenty-four letters. Today, the first twelve. Say each one aloud — your mouth must learn them as well as your eyes.”'],
      teach:()=>`<p class="gm-intro">Twenty-four letters, and you know some already: our own alphabet came from these. Today, the first twelve. Watch the three that trick everyone: <b>η</b> is not an n but a long e, <b>ρ</b> (next lesson) is not a p, and <b>ν</b> is not a v.</p>${letterRows(L1)}<p class="gm-note">Mario’s rule: say the name, then the sound, then draw it with your finger on the table. Three times each.</p>`,
      quiz:()=>letterQs(L1) },
    { id:'l2', title:'The Letters, II — Nu to Omega', reward:150,
      intro:['“Back again! Good. The second twelve today — and with them, every word in the Gospels is yours to sound out.”','“From alpha to omega. You know who called Himself that, eh? The first and the last letter — everything between.”'],
      teach:()=>`<p class="gm-intro">The rest of the alphabet. Mind <b>σ</b>: inside a word it is σ, but at the very end it curls into <b>ς</b> — λόγο<b>ς</b>. And mind the two o’s and two e’s: <b>ο</b> and <b>ε</b> are short, <b>ω</b> and <b>η</b> are long.</p>${letterRows(L2)}<p class="gm-note">These are the sounds most Greek classrooms teach (the Erasmian way). Greeks today say some of them differently, and so, likely, did the apostles — but this way, every letter has its own sound, which is what a learner needs.</p>`,
      quiz:()=>letterQs(L2) },
    { id:'l3', title:'Breathing, Diphthongs and First Words', reward:200,
      intro:['“Now the little marks. See this hook over the letter? That is a breathing. It tells you whether to breathe an h before the word.”','“And then — your first words. Fifteen of them, and with them you could already read pieces of John’s first verse.”'],
      teach:()=>`<p class="gm-intro">Every word that begins with a vowel wears a <b>breathing</b> mark. The <b>rough</b> breathing ( ῾ , like a c) means say an <b>h</b> first: ${gk('ὁ')} = <i>ho</i>. The <b>smooth</b> breathing ( ᾿ , like a backward c) is silent: ${gk('ἐν')} = <i>en</i>. A word starting with υ always takes the rough: ${gk('ὕδωρ')} = <i>hydōr</i>, water.</p>`
        +table(BREATH.map(([g,t,m])=>`<div>${big(g)}</div><div><b>${t}</b> — ${UI.esc(m)}</div>`),'auto 1fr')
        +`<div class="gm-sec">Diphthongs — two vowels, one sound</div>`+table(DIPH.map(([g,s])=>`<div>${big(g)}</div><div>${UI.esc(s)}</div>`),'auto 1fr')
        +`<div class="gm-sec">First words</div>`+table(WORDS.map(([g,t,m])=>`<div>${big(g)}</div><div><b>${t}</b> — ${UI.esc(m)}</div>`),'auto 1fr')
        +`<p class="gm-note">Already you can read three words of the Gospel of John: ${gk('ἐν ἀρχῇ … ὁ λόγος')} — <i>“in the beginning … the Word.”</i></p>`,
      quiz:wordQs } ];
  // ── lessons 4 to 10: hand-written questions [prompt, answer, three wrong answers] ──
  const pool=P=>()=>shuffle(P).slice(0,8).map(([q,a,...d])=>({q:/[A-Za-z]/.test(q)?q:`What does this mean?<br>${big(q)}`,a,opts:shuffle([a].concat(d))}));
  const rows=(R,cols)=>table(R.map(r=>r.map((c,i)=>`<div>${i===0?big(c):c}</div>`).join('')),cols||'auto 1fr');
  const MORE=[
    { id:'l4', title:'“The” and the Endings — ὁ λόγος', reward:250,
      intro:['“In English, the order of words tells you who did what. In Greek, the ending does. Change the ending and you change the job.”','“Today: ὁ λόγος, the word — and the four jobs it can do.”'],
      teach:()=>`<p class="gm-intro">A Greek noun changes its ending for its job in the sentence — its <b>case</b>. The little word “the” changes with it. Here is λόγος, “word”, in its four cases:</p>`
        +rows([['ὁ λόγος','<b>nominative</b> — the subject: <i>the word</i> (does it)'],['τοῦ λόγου','<b>genitive</b> — “of”: <i>of the word</i>'],['τῷ λόγῳ','<b>dative</b> — “to, in, with”: <i>to / in the word</i>'],['τὸν λόγον','<b>accusative</b> — the object: <i>the word</i> (has it done to it)']])
        +`<p>So ${gk('ὁ υἱὸς τοῦ θεοῦ')} is <i>the Son of God</i>, and ${gk('ὁ ἄνθρωπος βλέπει τὸν θεόν')} is <i>the man sees God</i> — whoever stands in the -ον ending is the one being seen, wherever he stands in the sentence.</p>`
        +`<div class="gm-sec">New words — they all end like λόγος</div>`+rows([['θεός','God'],['υἱός','son'],['οὐρανός','heaven'],['κόσμος','world'],['ἄνθρωπος','man, person']]),
      quiz:pool([['τοῦ θεοῦ','of God','God (the subject)','to God','God (the object)'],['ὁ υἱός','the son (the subject)','of the son','to the son','the son (the object)'],['τὸν κόσμον','the world (the object)','of the world','to the world','the world (the subject)'],
        ['τῷ λόγῳ','to / in the word','of the word','the word (the subject)','the word (the object)'],['ὁ υἱὸς τοῦ θεοῦ','the Son of God','the God of the son','the son to God','God is the son'],['Which ending marks the <b>object</b> (accusative) of λόγος?','-ον (λόγον)','-ος (λόγος)','-ου (λόγου)','-ῳ (λόγῳ)'],
        ['Which ending means <b>“of”</b> (genitive)?','-ου (λόγου)','-ον (λόγον)','-ος (λόγος)','-ῳ (λόγῳ)'],['οὐρανός','heaven','son','world','man'],['υἱός','son','heaven','God','word'],['ἐν τῷ κόσμῳ','in the world','of the world','the world (the object)','out of the world'],
        ['τοῦ οὐρανοῦ','of heaven','to heaven','heaven (the subject)','heaven (the object)'],[`In ${gk('τὸν θεὸν βλέπει ὁ ἄνθρωπος')} <span class="ds">(βλέπει = sees)</span>, who sees whom?`,'the man sees God','God sees the man','they see each other','the man is God']]) },
    { id:'l5', title:'“I Am” — εἰμί', reward:250,
      intro:['“The most important little verb there is. When Moses asked God His name, the answer was ‘I AM.’ And Jesus said it too — ἐγώ εἰμι.”'],
      teach:()=>`<p class="gm-intro">The verb “to be”. Greek often leaves out “I” or “they” — the ending already says who.</p>`
        +rows([['εἰμί','I am'],['εἶ','you are'],['ἐστί(ν)','he / she / it is'],['ἐσμέν','we are'],['ἐστέ','you (all) are'],['εἰσί(ν)','they are'],['ἦν','he / she / it <b>was</b>']])
        +`<div class="gm-sec">I, you, we</div>`+rows([['ἐγώ','I'],['σύ','you'],['ἡμεῖς','we']])
        +`<div class="gm-sec">In the Scriptures</div>`+rows([['ἐγώ εἰμι','I am'],['σὺ εἶ ὁ Χριστός','You are the Christ'],['ὁ θεὸς ἀγάπη ἐστίν','God is love']])
        +`<p class="gm-note">The little ν on ἐστί(ν) and εἰσί(ν) comes and goes — it’s added before a vowel or at the end of a sentence. It changes nothing.</p>`,
      quiz:pool([['ἐστίν','he / she / it is','I am','they are','we are'],['εἰμί','I am','you are','he is','we are'],['ἐσμέν','we are','you (all) are','they are','I am'],['εἰσίν','they are','we are','he is','you are'],['εἶ','you are','I am','he is','they are'],
        ['ἦν','he / she / it was','he is','they are','I will be'],['ἐστέ','you (all) are','we are','they are','he is'],['ὁ θεὸς ἀγάπη ἐστίν','God is love','God loves','Love is not God','God was love'],['ἐγώ','I','you','we','he'],
        ['σὺ εἶ ὁ Χριστός','You are the Christ','I am the Christ','Christ is with you','You were the Christ'],['ἡμεῖς','we','I','you','they']]) },
    { id:'l6', title:'Doing Words — the Present Tense', reward:250,
      intro:['“Now the verbs that do things. Learn one, and you have the pattern for hundreds.”','“λύω — I loose, I set free. A good word for a knight, eh?”'],
      teach:()=>`<p class="gm-intro">Most verbs follow λύω, “I loose, set free”. The stem stays; the ending tells you who.</p>`
        +rows([['λύ-ω','I loose'],['λύ-εις','you loose'],['λύ-ει','he / she / it looses'],['λύ-ομεν','we loose'],['λύ-ετε','you (all) loose'],['λύ-ουσι(ν)','they loose']])
        +`<div class="gm-sec">Verbs that go the same way</div>`+rows([['λέγω','I say'],['ἔχω','I have'],['πιστεύω','I believe, trust'],['γινώσκω','I know'],['ἀκούω','I hear'],['βλέπω','I see']])
        +`<p class="gm-note">So πιστεύ<b>ομεν</b> is “we believe”, and λέγ<b>ει</b> is “he says”.</p>`,
      quiz:pool([['πιστεύομεν','we believe','they believe','I believe','you (all) believe'],['λέγει','he / she says','I say','they say','you say'],['ἔχεις','you have','I have','we have','he has'],['ἀκούουσιν','they hear','we hear','he hears','you (all) hear'],
        ['βλέπω','I see','you see','he sees','they see'],['γινώσκετε','you (all) know','we know','they know','I know'],['Which ending means <b>“we”</b>?','-ομεν','-ετε','-ουσι(ν)','-εις'],['Which ending means <b>“they”</b>?','-ουσι(ν)','-ομεν','-ει','-ω'],
        ['πιστεύω','I believe','I say','I have','I hear'],['γινώσκω','I know','I see','I hear','I believe'],[`${big('λέγει αὐτῷ ὁ Ἰησοῦς')}<br><span class="ds">(αὐτῷ = to him)</span>`,'Jesus says to him','He says to Jesus','Jesus said nothing','They say to Jesus']]) },
    { id:'l7', title:'Life, Light and Glory — More Nouns', reward:250,
      intro:['“Not every noun ends like λόγος. Many of the most beautiful words end in -η or -α — life, love, truth, glory. These take ἡ, not ὁ.”'],
      teach:()=>`<p class="gm-intro">Nouns ending in <b>-η</b> or <b>-α</b> are mostly feminine and take <b>ἡ</b> for “the”. Here is ζωή, “life”:</p>`
        +rows([['ἡ ζωή','life (the subject)'],['τῆς ζωῆς','of life'],['τῇ ζωῇ','to / in life'],['τὴν ζωήν','life (the object)']])
        +`<p>See the tiny iota tucked under ῇ? That “iota subscript” is how you spot the dative: ${gk('ἐν ἀρχῇ')}, <i>in the beginning</i>.</p>`
        +`<div class="gm-sec">New words</div>`+rows([['ἀγάπη','love'],['φωνή','voice'],['ἀλήθεια','truth'],['ἡμέρα','day'],['δόξα','glory'],['καρδία','heart']])
        +`<div class="gm-sec">A third kind: neuter (“it”), with τό</div>`+rows([['τὸ φῶς','the light'],['τὸ ἔργον','the work, deed'],['τὸ πνεῦμα','the Spirit, breath']])+`<p class="gm-note">A neuter noun looks the same as subject and object — the sentence tells you which.</p>`,
      quiz:pool([['ἐν ἀρχῇ','in the beginning','of the beginning','the beginning (the object)','out of the beginning'],['τῆς ζωῆς','of life','life (the subject)','to life','life (the object)'],['ἡ ἀλήθεια','the truth','the day','the glory','the heart'],['δόξα','glory','truth','heart','voice'],
        ['καρδία','heart','day','love','beginning'],['ἡμέρα','day','heart','light','work'],['τὴν ἀγάπην','love (the object)','of love','love (the subject)','to love'],['The little iota under ῃ in ἀρχῇ marks…','the dative (“in, to”)','a plural','a question','a name'],
        ['τὸ φῶς','the light','the life','the word','the world'],[`${big('ἡ · τῆς · τῇ · τήν')}<br>These are all…`,'“the” with a feminine noun','“the” with a masculine noun','forms of “to be”','forms of “and”'],['ἔργον','work, deed','word','world','spirit']]) },
    { id:'l8', title:'Him, This, and the Little Words', reward:250,
      intro:['“Little words carry great weight. Through. Without. With. In. Read John’s first verses without them and you’d be lost.”'],
      teach:()=>`<p class="gm-intro"><b>αὐτός</b> means “he”, and changes its ending like λόγος:</p>`+rows([['αὐτός','he'],['αὐτοῦ','his, of him'],['αὐτῷ','to him, in him'],['αὐτόν','him'],['αὐτό','it'],['οὗτος','this one, he'],['ἡμῖν','to us, among us'],['ἐμοῦ','of me']])
        +`<div class="gm-sec">Prepositions — each takes a certain case after it</div>`+rows([['ἐν','in (+ dative)'],['εἰς','into (+ accusative)'],['ἐκ / ἐξ','out of (+ genitive)'],['πρός','toward, with (+ accusative)'],['διά (δι᾽)','through (+ genitive)'],['χωρίς','without (+ genitive)'],['παρά','from (+ genitive)']])
        +`<div class="gm-sec">Little words</div>`+rows([['οὐ / οὐκ','not'],['οὐδέ','not even'],['καί','and'],['ἀλλά','but'],['γάρ','for (because)'],['ἵνα','so that'],['πάντα','all things'],['ὅ','which']]),
      quiz:pool([['αὐτοῦ','his / of him','him (the object)','to him','he'],['αὐτῷ','to / in him','his','he','him (the object)'],['εἰς τὸν κόσμον','into the world','out of the world','in the world','without the world'],['ἐκ τοῦ οὐρανοῦ','out of heaven','into heaven','in heaven','toward heaven'],
        ['δι᾽ αὐτοῦ','through him','without him','toward him','in him'],['χωρὶς αὐτοῦ','without him','through him','with him','his'],['πρὸς τὸν θεόν','with (toward) God','out of God','without God','God’s'],['οὐ','not','and','but','for'],
        ['ἀλλά','but','for','so that','not'],['γάρ','for (because)','but','and','not'],['πάντα','all things','nothing','one thing','this one'],['οὗτος','this one (he)','all things','not','which']]) },
    { id:'l9', title:'The Past — Augment and Aorist', reward:250,
      intro:['“Things that happened. Watch for the little ἐ- at the front of a verb — it is a doorway into the past.”'],
      teach:()=>`<p class="gm-intro">A verb that looks back usually grows an <b>ἐ-</b> at the front, the <b>augment</b>. The <b>aorist</b> tells of something that simply happened.</p>`
        +rows([['ἦν','he / she / it was'],['ἐγένετο','came to be, became, was made'],['ἐπίστευσα','I believed'],['ἔδωκεν','he gave'],['ἠγάπησεν','he loved <span class="ds">(ἀ- grows into ἠ-)</span>'],['κατέλαβεν','overcame, grasped <span class="ds">(κατ- + ἐ + λαβεν)</span>'],['ἐσκήνωσεν','dwelt — <i>pitched his tent</i>']])
        +`<div class="gm-sec">Two more you’ll meet in John</div>`+rows([['γέγονεν','has come to be <span class="ds">(the perfect: done, and it stands)</span>'],['φαίνει','shines <span class="ds">(present — no augment)</span>']])
        +`<p class="gm-note">${gk('ὁ λόγος σὰρξ ἐγένετο')} — <i>the Word became flesh</i> (σάρξ = flesh).</p>`,
      quiz:pool([['ἐγένετο','came to be / became','comes to be','will come','has not come'],['ἔδωκεν','he gave','he gives','he will give','they gave'],['ἠγάπησεν','he loved','he loves','love','he was loved'],['ἐπίστευσα','I believed','I believe','we believed','he believes'],
        ['The ἐ- at the front of ἐγένετο marks…','the past (the augment)','a question','a plural','“not”'],['φαίνει','shines','shone','will shine','light'],['κατέλαβεν','overcame / grasped','shines','came','said'],['γέγονεν','has come to be','will come to be','is not','was not'],
        ['ἦν','was','is','will be','were not'],['σὰρξ ἐγένετο','became flesh','became light','made the world','was not flesh'],['ἐσκήνωσεν','dwelt (pitched his tent)','spoke','gave','saw']]) },
    { id:'l10', title:'Reading John 1:1–5', reward:500,
      intro:['“Well. Here we are. The first words of John’s Gospel — the very words on my desk. You know every piece of them now.”','“Read them slowly. Tap any word you’ve forgotten. Then tell me what they say.”'],
      teach:()=>readerHtml('john1',{teach:true}),
      quiz:pool([['Ἐν ἀρχῇ ἦν ὁ λόγος','In the beginning was the Word','In the end was the Word','The beginning was a word','The Word was not in the beginning'],['ὁ λόγος ἦν πρὸς τὸν Θεόν','the Word was with God','God was with the Word','the Word was without God','the Word came out of God'],
        ['Θεὸς ἦν ὁ λόγος','the Word was God','God was a word','God spoke the word','the Word is with God'],['πάντα δι᾽ αὐτοῦ ἐγένετο','all things came to be through him','all things were without him','he came through all things','nothing came to be'],
        ['χωρὶς αὐτοῦ ἐγένετο οὐδὲ ἕν','without him not even one thing came to be','with him everything came to be','without him all things came','one thing came without him'],['ἐν αὐτῷ ζωὴ ἦν','in him was life','he was in life','life was without him','he gave life'],
        ['ἡ ζωὴ ἦν τὸ φῶς τῶν ἀνθρώπων','the life was the light of men','men were the light of life','the light was the life of God','the life of men was dark'],['τὸ φῶς ἐν τῇ σκοτίᾳ φαίνει','the light shines in the darkness','the darkness shines in the light','the light shone out of darkness','the light is darkness'],
        ['ἡ σκοτία αὐτὸ οὐ κατέλαβεν','the darkness did not overcome it','the darkness overcame it','the light did not overcome the darkness','the darkness is not light']]) } ];
  MORE.forEach(l=>LESSONS.push(l));
  // ── the manuscripts: the text is the Robinson–Pierpont Byzantine Greek New Testament (2018), public domain; the
  //    word glosses and the translations are KLK's own, word for word ──
  const PASS={
    john1:{ ref:'John 1:1–5', title:'The Gospel of John, the beginning', need:10, verses:[
      ['1',[['Ἐν','in'],['ἀρχῇ','beginning (dative of ἀρχή)'],['ἦν','was'],['ὁ','the'],['λόγος,','Word — nominative: the subject'],['καὶ','and'],['ὁ','the'],['λόγος','Word'],['ἦν','was'],['πρὸς','with, toward'],['τὸν','the (accusative)'],['Θεόν,','God (accusative, after πρός)'],['καὶ','and'],['Θεὸς','God — no article: it says what the Word was'],['ἦν','was'],['ὁ','the'],['λόγος.','Word']]],
      ['2',[['οὗτος','this one, he'],['ἦν','was'],['ἐν','in'],['ἀρχῇ','beginning'],['πρὸς','with'],['τὸν','the'],['Θεόν.','God']]],
      ['3',[['πάντα','all things'],['δι᾽','through (διά)'],['αὐτοῦ','him (genitive)'],['ἐγένετο,','came to be (aorist)'],['καὶ','and'],['χωρὶς','without'],['αὐτοῦ','him'],['ἐγένετο','came to be'],['οὐδὲ','not even'],['ἓν','one thing'],['ὃ','which'],['γέγονεν.','has come to be (perfect)']]],
      ['4',[['ἐν','in'],['αὐτῷ','him (dative)'],['ζωὴ','life'],['ἦν,','was'],['καὶ','and'],['ἡ','the'],['ζωὴ','life'],['ἦν','was'],['τὸ','the (neuter)'],['φῶς','light'],['τῶν','of the (plural)'],['ἀνθρώπων.','men, people (genitive plural)']]],
      ['5',[['καὶ','and'],['τὸ','the'],['φῶς','light'],['ἐν','in'],['τῇ','the (dative)'],['σκοτίᾳ','darkness (dative)'],['φαίνει,','shines (present)'],['καὶ','and'],['ἡ','the'],['σκοτία','darkness'],['αὐτὸ','it (the light)'],['οὐ','not'],['κατέλαβεν.','overcame, grasped (aorist)']]] ],
      en:'In the beginning was the Word, and the Word was with God, and the Word was God. He was in the beginning with God. All things came to be through him, and without him not even one thing came to be that has come to be. In him was life, and the life was the light of men. And the light shines in the darkness, and the darkness did not overcome it.' },
    john14_6:{ ref:'John 14:6', title:'A scrap pinned by Hearthvale’s chapel door', need:6, verses:[
      ['6',[['λέγει','says (present)'],['αὐτῷ','to him'],['ὁ','the'],['Ἰησοῦς,','Jesus'],['Ἐγώ','I'],['εἰμι','am'],['ἡ','the'],['ὁδὸς','way'],['καὶ','and'],['ἡ','the'],['ἀλήθεια','truth'],['καὶ','and'],['ἡ','the'],['ζωή·','life'],['οὐδεὶς','no one'],['ἔρχεται','comes'],['πρὸς','to, toward'],['τὸν','the'],['πατέρα,','Father'],['εἰ','if'],['μὴ','not — εἰ μή: except'],['δι᾽','through'],['ἐμοῦ.','me']]] ],
      en:'Jesus says to him, “I am the way and the truth and the life; no one comes to the Father except through me.”' },
    john1_14:{ ref:'John 1:14', title:'A leaf on Eldan’s lectern', need:9, verses:[
      ['14',[['Καὶ','and'],['ὁ','the'],['λόγος','Word'],['σὰρξ','flesh'],['ἐγένετο','became (aorist)'],['καὶ','and'],['ἐσκήνωσεν','dwelt — pitched his tent'],['ἐν','among, in'],['ἡμῖν,','us'],['καὶ','and'],['ἐθεασάμεθα','we beheld (aorist)'],['τὴν','the'],['δόξαν','glory'],['αὐτοῦ,','his'],['δόξαν','glory'],['ὡς','as'],['μονογενοῦς','of the only-begotten, the one and only'],['παρὰ','from'],['πατρός,','the Father'],['πλήρης','full'],['χάριτος','of grace'],['καὶ','and'],['ἀληθείας.','of truth']]] ],
      en:'And the Word became flesh and dwelt among us, and we beheld his glory, glory as of the only-begotten from the Father, full of grace and truth.' },
    john3_16:{ ref:'John 3:16', title:'The old monk’s treasured scroll', need:10, verses:[
      ['16',[['Οὕτω','so, in this way'],['γὰρ','for'],['ἠγάπησεν','loved (aorist)'],['ὁ','the'],['Θεὸς','God'],['τὸν','the'],['κόσμον,','world (object)'],['ὥστε','that, so that'],['τὸν','the'],['υἱὸν','Son'],['αὐτοῦ','his'],['τὸν','the'],['μονογενῆ','only-begotten, one and only'],['ἔδωκεν,','he gave (aorist)'],['ἵνα','so that'],['πᾶς','everyone'],['ὁ','the one'],['πιστεύων','believing — who believes'],['εἰς','into, in'],['αὐτὸν','him'],['μὴ','not'],['ἀπόληται','should perish'],['ἀλλ᾽','but'],['ἔχῃ','should have'],['ζωὴν','life'],['αἰώνιον.','eternal']]] ],
      en:'For God so loved the world that he gave his only-begotten Son, so that everyone who believes in him should not perish but have eternal life.' } };
  // ── lessons 11–14, past John 1 — plurals, “my/your/our”, commands and prayers, the future and the -ing words ──
  const MORE2=[
    { id:'l11', title:'Many — the Plural', reward:300,
      intro:['“One word, one shepherd, one sheep — that was easy. But the Lord said ‘our Father in the heavens’, not ‘heaven’. Today: many.”'],
      teach:()=>`<p class="gm-intro">In the plural, “the” and the endings change again. λόγος in the plural:</p>`
        +rows([['οἱ λόγοι','the words (subject)'],['τῶν λόγων','of the words'],['τοῖς λόγοις','to / in the words'],['τοὺς λόγους','the words (object)']])
        +`<div class="gm-sec">ἡμέρα, “day”, in the plural</div>`+rows([['αἱ ἡμέραι','the days (subject)'],['τῶν ἡμερῶν','of the days'],['ταῖς ἡμέραις','to / in the days'],['τὰς ἡμέρας','the days (object)']])
        +`<div class="gm-sec">Neuters end in -α in the plural</div>`+rows([['τὰ ἔργα','the works'],['τὰ πρόβατα','the sheep']])
        +`<p>Notice <b>τῶν</b> — “of the” — is the same for every kind of noun: ${gk('ἡ βασιλεία τῶν οὐρανῶν')}, <i>the kingdom of the heavens</i>.</p>`
        +`<div class="gm-sec">New words</div>`+rows([['βασιλεία','kingdom'],['πρόβατον','sheep'],['ὄνομα','name'],['πατήρ','father <span class="ds">(πάτερ: “O Father!”)</span>']]),
      quiz:pool([['οἱ λόγοι','the words (the subject)','the word (the subject)','of the words','to the words'],['τῶν οὐρανῶν','of the heavens','the heavens (the subject)','in heaven','to the heavens'],['ἐν τοῖς οὐρανοῖς','in the heavens','of the heavens','into heaven','the heavens (the object)'],
        ['τοὺς ἀνθρώπους','the men (the object)','the man (the object)','of the men','the men (the subject)'],['τὰ πρόβατα','the sheep (many)','the sheep (one)','of the sheep','the shepherd'],['ἡ βασιλεία τῶν οὐρανῶν','the kingdom of the heavens','the heavens of the kingdom','the king of heaven','in the kingdom of heaven'],
        ['αἱ ἡμέραι','the days','the day','of the days','the hours'],['Which is “of the” in the plural, for every kind of noun?','τῶν','τοῖς','οἱ','τάς'],['βασιλεία','kingdom','king','name','sheep'],['πατήρ','father','son','shepherd','name'],['ὄνομα','name','word','kingdom','father'],
        ['τῶν προβάτων','of the sheep','the sheep (the subject)','to the sheep','the shepherd']]) },
    { id:'l12', title:'My, Your, Our', reward:300,
      intro:['“Our Father. Your name. Our bread. The prayer the Lord taught is full of these little words — let us learn them, and then you can pray it as the disciples first heard it.”'],
      teach:()=>`<p class="gm-intro">“My”, “your” and “our” come <b>after</b> the noun in Greek: ${gk('τὸ ὄνομά σου')} is “the name of you” — <i>your name</i>.</p>`
        +rows([['μου','my'],['σου','your (one person)'],['αὐτοῦ','his'],['ἡμῶν','our'],['ὑμῶν','your (you all)'],['αὐτῶν','their']])
        +`<div class="gm-sec">Us and you all</div>`+rows([['ἡμεῖς','we'],['ἡμῖν','to us'],['ἡμᾶς','us'],['ὑμεῖς','you (all)'],['ὑμᾶς','you (all, object)']])
        +`<div class="gm-sec">New words</div>`+rows([['ἄρτος','bread'],['σήμερον','today'],['ὅτι','because; that'],['ἀπό','from (+ genitive)'],['πονηρός','evil'],['ὡς','as, like']])
        +`<p class="gm-note">${gk('Πάτερ ἡμῶν ὁ ἐν τοῖς οὐρανοῖς')} — <i>Our Father, the one in the heavens.</i></p>`,
      quiz:pool([['σου','your (one person)','my','our','his'],['μου','my','your','our','their'],['ἡμῶν','our','your (you all)','their','my'],['ὑμῶν','your (you all)','our','their','his'],['αὐτῶν','their','his','our','your'],['ἡμᾶς','us','we','our','to us'],
        ['Πάτερ ἡμῶν','Our Father','My Father','Your Father','Their father'],['τὸ ὄνομά σου','your name','my name','his name','our name'],['ἄρτος','bread','water','name','day'],['σήμερον','today','tomorrow','again','always'],['ὅτι','because; that','but','and','so that'],
        ['ἀπὸ τοῦ πονηροῦ','from the evil one','into evil','with the evil one','without evil']]) },
    { id:'l13', title:'Commands and Prayers', reward:300,
      intro:['“When you pray, you ask; when a king speaks, he commands. Greek has a mood for both — the imperative. Let it come! Give! Forgive! Behold!”'],
      teach:()=>`<p class="gm-intro">The <b>imperative</b> tells or asks someone to do something. Spoken to “you” it’s simply “Do it!” — spoken of “him/it” it’s “Let it…”.</p>`
        +rows([['δός','give!'],['ἄφες','forgive!, let go!'],['ῥῦσαι','deliver!, rescue!'],['ἴδε','look!, behold!'],['ἀκολούθει','follow!'],['προσεύχεσθε','pray! (you all)']])
        +`<div class="gm-sec">“Let it…” — for him, her or it</div>`+rows([['ἐλθέτω','let it come'],['γενηθήτω','let it be done'],['ἁγιασθήτω','let it be hallowed (made holy)']])
        +`<div class="gm-sec">“Do not…”</div><p>For “don’t”, Greek uses <b>μή</b> (not οὐ): ${gk('μὴ εἰσενέγκῃς ἡμᾶς')} — <i>do not lead us</i>.</p>`
        +`<div class="gm-sec">New words</div>`+rows([['θέλημα','will (what someone wants)'],['γῆ','earth, land'],['ἐπί','on (+ genitive)'],['πειρασμός','temptation, testing'],['ὀφείλημα','debt']]),
      quiz:pool([['δός','give!','gave','he gives','to give'],['ἄφες','forgive!','forgave','he forgives','forgiveness'],['ῥῦσαι','deliver! (rescue!)','delivered','he delivers','deliverance'],['ἴδε','behold! (look!)','he saw','idea','he sees'],
        ['ἐλθέτω ἡ βασιλεία σου','let your kingdom come','your kingdom came','your kingdom will not come','the king is coming'],['γενηθήτω τὸ θέλημά σου','let your will be done','your will was done','do your will','your will is done'],['ἁγιασθήτω τὸ ὄνομά σου','let your name be hallowed','your name was holy','say your name','your holy name'],
        ['μὴ εἰσενέγκῃς ἡμᾶς εἰς πειρασμόν','do not lead us into temptation','lead us out of temptation','we were not tempted','do not tempt us to lead'],['For “do not”, Greek uses…','μή','οὐ','ἀλλά','καί'],['θέλημα','will (what is wanted)','kingdom','name','debt'],['γῆ','earth','heaven','sea','bread'],
        ['ὡς ἐν οὐρανῷ καὶ ἐπὶ τῆς γῆς','as in heaven, so also on earth','in heaven and not on earth','from heaven to earth','heaven is on earth']]) },
    { id:'l14', title:'Things to Come, and Those Who Do', reward:400,
      intro:['“Two last keys for now. The future — what will be. And the -ing words — ‘the one believing’, ‘the one following’ — that Greek loves so much.”','“With these, the great ‘I am’ sayings of John are open to you.”'],
      teach:()=>`<p class="gm-intro">The <b>future</b> often adds a <b>σ</b> to the stem: λύω, “I loose” → λύ<b>σ</b>ω, “I <i>will</i> loose”. Some common verbs have their own future forms — learn them as they come:</p>`
        +rows([['λύσω','I will loose'],['ζήσεται','he will live'],['ἕξει','he will have'],['γνώσεσθε','you (all) will know'],['ἐλευθερώσει','he / it will set free'],['ὄψονται','they will see'],['κληθήσονται','they will be called']])
        +`<div class="gm-sec">The -ing words: participles</div><p>A <b>participle</b> is a verb used like an adjective or a noun. With “the” in front it means “the one who…”:</p>`
        +rows([['ὁ πιστεύων','the one believing — whoever believes'],['ὁ ἀκολουθῶν','the one following — whoever follows'],['ὁ αἴρων','the one taking away'],['λέγων','saying'],['ἐρχόμενον','coming']])
        +`<div class="gm-sec">New words</div>`+rows([['μακάριος','blessed, happy'],['ποιμήν','shepherd'],['καλός','good, fine'],['ψυχή','life, soul'],['ἀνάστασις','resurrection'],['ἀμνός','lamb'],['ἁμαρτία','sin']]),
      quiz:pool([['λύσω','I will loose','I loose','I loosed','loose!'],['ζήσεται','he will live','he lives','he lived','life'],['ἕξει','he will have','he has','he had','have!'],['γνώσεσθε','you (all) will know','you know','you knew','know!'],['ὄψονται','they will see','they see','they saw','see!'],
        ['ὁ πιστεύων','the one who believes','he believed','he will believe','believe!'],['ὁ ἀκολουθῶν ἐμοί','whoever follows me','I followed him','follow me!','he will follow me'],['The σ in λύσω marks…','the future','the past','a plural','a command'],
        ['μακάριοι','blessed (ones)','sons','sheep','poor'],['ποιμήν','shepherd','sheep','father','lamb'],['ἀνάστασις','resurrection','life','truth','glory'],['ὁ ἀμνὸς τοῦ θεοῦ','the Lamb of God','the shepherd of God','the Son of God','the name of God']]) } ];
  MORE2.forEach(l=>LESSONS.push(l));
  Object.assign(PASS,{
    matt6a:{ ref:'Matthew 6:9–10', title:'The Lord’s Prayer, I', need:13, verses:[
      ['9',[['οὕτως','in this way'],['οὖν','therefore, then'],['προσεύχεσθε','pray! (you all)'],['ὑμεῖς·','you'],['Πάτερ','Father (calling out to him)'],['ἡμῶν','our'],['ὁ','the one'],['ἐν','in'],['τοῖς','the'],['οὐρανοῖς,','heavens'],['ἁγιασθήτω','let it be hallowed, made holy'],['τὸ','the'],['ὄνομά','name'],['σου.','your']]],
      ['10',[['ἐλθέτω','let it come'],['ἡ','the'],['βασιλεία','kingdom'],['σου.','your'],['γενηθήτω','let it be done'],['τὸ','the'],['θέλημά','will'],['σου,','your'],['ὡς','as'],['ἐν','in'],['οὐρανῷ','heaven'],['καὶ','also'],['ἐπὶ','on'],['τῆς','the'],['γῆς.','earth']]] ],
      en:'In this way, then, pray: Our Father, who is in the heavens, let your name be hallowed. Let your kingdom come. Let your will be done, as in heaven, so also on earth.' },
    matt6b:{ ref:'Matthew 6:11–13', title:'The Lord’s Prayer, II', need:13, verses:[
      ['11',[['τὸν','the'],['ἄρτον','bread'],['ἡμῶν','our'],['τὸν','the'],['ἐπιούσιον','daily — for the coming day (a rare word)'],['δὸς','give!'],['ἡμῖν','to us'],['σήμερον.','today']]],
      ['12',[['καὶ','and'],['ἄφες','forgive!'],['ἡμῖν','us (to us)'],['τὰ','the'],['ὀφειλήματα','debts'],['ἡμῶν,','our'],['ὡς','as'],['καὶ','also'],['ἡμεῖς','we'],['ἀφίεμεν','forgive'],['τοῖς','the'],['ὀφειλέταις','debtors'],['ἡμῶν.','our']]],
      ['13',[['καὶ','and'],['μὴ','not'],['εἰσενέγκῃς','lead, bring (μή + this: “do not lead”)'],['ἡμᾶς','us'],['εἰς','into'],['πειρασμόν,','temptation, testing'],['ἀλλὰ','but'],['ῥῦσαι','deliver!, rescue!'],['ἡμᾶς','us'],['ἀπὸ','from'],['τοῦ','the'],['πονηροῦ.','evil one, evil']]] ],
      en:'Give us today our daily bread. And forgive us our debts, as we also forgive our debtors. And do not lead us into temptation, but deliver us from the evil one.' },
    john8_12:{ ref:'John 8:12', title:'The light of the world', need:11, verses:[
      ['12',[['Πάλιν','again'],['οὖν','then'],['αὐτοῖς','to them'],['ὁ','the'],['Ἰησοῦς','Jesus'],['ἐλάλησε','spoke (aorist)'],['λέγων,','saying'],['Ἐγώ','I'],['εἰμι','am'],['τὸ','the'],['φῶς','light'],['τοῦ','of the'],['κόσμου·','world'],['ὁ','the one'],['ἀκολουθῶν','following — whoever follows'],['ἐμοὶ','me'],['οὐ','not'],['μὴ','not — οὐ μή: never, by no means'],['περιπατήσῃ','will walk'],['ἐν','in'],['τῇ','the'],['σκοτίᾳ,','darkness'],['ἀλλ᾽','but'],['ἕξει','will have (future)'],['τὸ','the'],['φῶς','light'],['τῆς','of the'],['ζωῆς.','life']]] ],
      en:'Then Jesus spoke to them again, saying, “I am the light of the world; whoever follows me will never walk in the darkness, but will have the light of life.”' },
    john10_11:{ ref:'John 10:11', title:'The good shepherd', need:12, verses:[
      ['11',[['ἐγώ','I'],['εἰμι','am'],['ὁ','the'],['ποιμὴν','shepherd'],['ὁ','the'],['καλός·','good'],['ὁ','the'],['ποιμὴν','shepherd'],['ὁ','the'],['καλὸς','good'],['τὴν','the'],['ψυχὴν','life, soul'],['αὐτοῦ','his'],['τίθησιν','lays down'],['ὑπὲρ','for, on behalf of'],['τῶν','the'],['προβάτων.','sheep']]] ],
      en:'I am the good shepherd; the good shepherd lays down his life for the sheep.' },
    john11_25:{ ref:'John 11:25', title:'The resurrection and the life', need:14, verses:[
      ['25',[['εἶπεν','said (aorist)'],['αὐτῇ','to her'],['ὁ','the'],['Ἰησοῦς,','Jesus'],['Ἐγώ','I'],['εἰμι','am'],['ἡ','the'],['ἀνάστασις','resurrection'],['καὶ','and'],['ἡ','the'],['ζωή·','life'],['ὁ','the one'],['πιστεύων','believing — whoever believes'],['εἰς','into, in'],['ἐμέ,','me'],['κἂν','even if (καὶ ἐάν)'],['ἀποθάνῃ,','he dies'],['ζήσεται·','will live (future)']]] ],
      en:'Jesus said to her, “I am the resurrection and the life; whoever believes in me, even if he dies, will live.”' },
    matt5_3:{ ref:'Matthew 5:3', title:'The first blessing', need:12, verses:[
      ['3',[['Μακάριοι','blessed'],['οἱ','the'],['πτωχοὶ','poor'],['τῷ','in the'],['πνεύματι,','spirit'],['ὅτι','because'],['αὐτῶν','theirs (of them)'],['ἐστιν','is'],['ἡ','the'],['βασιλεία','kingdom'],['τῶν','of the'],['οὐρανῶν.','heavens']]] ],
      en:'Blessed are the poor in spirit, because theirs is the kingdom of the heavens.' },
    john1_29:{ ref:'John 1:29', title:'Behold, the Lamb', need:14, verses:[
      ['29',[['Τῇ','on the'],['ἐπαύριον','next day'],['βλέπει','he sees'],['τὸν','the'],['Ἰησοῦν','Jesus (object)'],['ἐρχόμενον','coming'],['πρὸς','toward'],['αὐτὸν','him'],['καὶ','and'],['λέγει,','says'],['Ἴδε,','behold!, look!'],['ὁ','the'],['ἀμνὸς','lamb'],['τοῦ','of the'],['Θεοῦ','God'],['ὁ','the one'],['αἴρων','taking away'],['τὴν','the'],['ἁμαρτίαν','sin'],['τοῦ','of the'],['κόσμου.','world']]] ],
      en:'The next day he sees Jesus coming toward him and says, “Behold, the Lamb of God, who takes away the sin of the world.”' },
    matt5_8:{ ref:'Matthew 5:8–9', title:'The pure in heart, and the peacemakers', need:14, verses:[
      ['8',[['μακάριοι','blessed'],['οἱ','the'],['καθαροὶ','pure, clean'],['τῇ','in the'],['καρδίᾳ,','heart'],['ὅτι','because'],['αὐτοὶ','they'],['τὸν','the'],['Θεὸν','God (object)'],['ὄψονται.','will see (future)']]],
      ['9',[['μακάριοι','blessed'],['οἱ','the'],['εἰρηνοποιοί,','peacemakers'],['ὅτι','because'],['αὐτοὶ','they'],['υἱοὶ','sons'],['Θεοῦ','of God'],['κληθήσονται.','will be called (future)']]] ],
      en:'Blessed are the pure in heart, because they will see God. Blessed are the peacemakers, because they will be called sons of God.' },
    john8_32:{ ref:'John 8:32', title:'The truth will set you free', need:14, verses:[
      ['32',[['καὶ','and'],['γνώσεσθε','you (all) will know (future)'],['τὴν','the'],['ἀλήθειαν,','truth (object)'],['καὶ','and'],['ἡ','the'],['ἀλήθεια','truth'],['ἐλευθερώσει','will set free (future)'],['ὑμᾶς.','you (all)']]] ],
      en:'And you will know the truth, and the truth will set you free.' },
    john11_35:{ ref:'John 11:35', title:'The shortest verse', need:9, verses:[
      ['35',[['ἐδάκρυσεν','wept, shed tears (aorist — see the augment ἐ-)'],['ὁ','the'],['Ἰησοῦς.','Jesus']]] ],
      en:'Jesus wept.' } });
  // a leaf on a lectern in each cleansed sanctuary, one passage to a town
  const SANCT_PASS=['matt6a','matt6b','john8_12','john10_11','john11_25','matt5_3','john1_29','matt5_8','john8_32','john11_35'];
  // ── Old Man Mario's own story — a memory after each lesson, the first time, and a last scene once every leaf in the
  //    realm has been read. The leaves you find are the pages he and Petra hid when the darkness came. ──
  const MEM=[
    '“When I was a boy I swept the floor of the scriptorium in Stormgate. The ink got into everything. I never got it out of my hands since.”',
    '“My master, Brother Lucan, said the omega is the hardest letter to write well. ‘It must close like a door,’ he said. ‘Gently.’ I practised it for a year.”',
    '“There was a girl who painted the gold into the first letter of every page. Petra. Her Ἐ at the start of John had a vine growing through it. I wrote the words; she made them shine.”',
    '“We copied a book for every chapel in the realm. I carried some of them myself, on a mule called Bartholomew, who did not care for bridges.”',
    '“Brother Lucan used to say, ‘We do not make the Word, Mario. We only carry it from one page to the next.’ I thought it was a small work. I know better now.”',
    '“Petra and I argued about everything. A breathing mark. A comma. Whether a mule can be stubborn on purpose. She was usually right. About the mule, especially.”',
    '“Then the darkness came over the chapels. One by one they went quiet. People stopped coming for books.”',
    '“When they came to burn the scriptorium, Lucan sent us out the back with as many leaves as we could carry. He stayed. He said someone had to finish the page he was on.”',
    '“Petra and I divided the pages and hid them. In walls. In caves. With friends — a sage in a hidden glade, a hermit in the north. ‘Somewhere the darkness won’t think to look,’ she said.”',
    '“The light shines in the darkness, and the darkness did not overcome it. Petra wrote that inside the flap of my satchel, the morning we parted. I still carry it.”',
    '“She went south with her half of the pages. I waited for a letter for many years. None came. — Some of the leaves you have found are hers. I would know her gold anywhere.”',
    '“I built this hut at the wood’s edge because from here you can see the road from the south. Old men keep foolish habits.”',
    '“I prayed for years that the pages would be found. I never thought to pray that someone would come who could read them. God is kinder than my prayers.”',
    '“There. I have taught you everything I was taught. Lucan would say: now you carry it.”' ];
  const FINALE=['“You have found them. Every leaf.”','<i>He turns the last of them toward the lamp, and stops.</i>','“There is writing in the margin. I never saw it — my eyes are not what they were.”',
    '“‘For M., if ever you come this far. I kept them safe. — P.’”','<i>For a long while he says nothing. Then he laughs, very softly.</i>','“She stayed a winter with the old monk, you know. Copying by his fire. Then she went on toward the sea. That was many, many years ago.”',
    '“So. She finished her page too.”','<i>He presses something into your hand: a slender pen, its nib gilded.</i> “Hers. She left it in my satchel. It should go on with someone who reads.”','“Thank you, knight. Now — sit. I will make tea.”'];
  const st=()=>{ const g=GREEK_STATE||(GREEK_STATE={}); g.done=g.done||[]; g.best=g.best||{}; g.read=g.read||{}; g.mem=g.mem||{}; return g; };
  const level=()=>st().done.length, nextL=()=>LESSONS.find(l=>!st().done.includes(l.id));
  const today=()=>(typeof dayClock!=='undefined' && dayClock.day)||1;
  const FOUND=()=>Object.keys(PASS).filter(id=>id!=='john1');
  const WHO='Old Man Mario', say=(lines,then)=>sayAs(WHO,lines,then);
  const keep=()=>{ try{ if(typeof saveGame==='function') saveGame(); }catch(e){} };
  // ── the sheet: the ☰ panel, with every choice a row (▲▼ Ⓐ, or tap) ──
  const U=greekUI;
  function sheet(o){ U.open=true; U.title=o.title; U.body=o.html; U.act=o.act||null; U.back=o.back||null; if(!o.keep) U.cur=0; draw(!!o.keep); }
  function draw(keepScroll){
    const el=document.getElementById('gamemenu'); if(!el) return;
    const old=document.getElementById('gkScroll'), top=keepScroll&&old?old.scrollTop:0;
    U.acts=[];
    const body=U.body.replace(/<button class="gm-item([^"]*)"([^>]*?) data-act="([^"]*)"/g,(m,cls,mid,a)=>{ const i=U.acts.length; U.acts.push(a);
      return `<button class="gm-item${cls}${i===U.cur?' cur':''}"${mid} data-gk="${i}" data-act="${a}"`; });
    if(U.cur>=U.acts.length) U.cur=Math.max(0,U.acts.length-1);
    el.innerHTML=`<div class="gm-close" data-gkx="1">✕</div><div class="gm-tabs"><div class="gm-tab sel">${U.title}</div></div><div class="gm-body gk">`
      +`<div id="gkScroll" style="max-height:72vh;overflow-y:auto;padding:2px 4px">${body}</div>`
      +`<div class="gm-hint">▲▼ choose · Ⓐ select · Ⓑ back</div></div>`;
    el.classList.add('open'); el.classList.add('sheet');
    const sc=document.getElementById('gkScroll'); if(sc && top) sc.scrollTop=top;
    const c=el.querySelector && el.querySelector('.gk .cur'); if(c && c.scrollIntoView){ try{ c.scrollIntoView({block:'nearest'}); }catch(e){} }
  }
  function close(){ U.open=false; U.act=null; U.back=null; const el=document.getElementById('gamemenu'); if(el){ el.classList.remove('open'); el.classList.remove('sheet'); el.innerHTML=''; } }
  function move(d){ const n=U.acts.length, sc=document.getElementById('gkScroll');
    if(U.acts.every(a=>a===U.acts[0]) && sc && sc.scrollHeight>sc.clientHeight+4){ sc.scrollTop+=d*64; return; }   // a page to read: ▲▼ scroll it
    if(!n) return; U.cur=(U.cur+d+n)%n; if(typeof sfxMenu==='function') sfxMenu(true); draw(true); }
  function choose(){ const a=U.acts[U.cur]; if(a!==undefined && U.act) U.act(a); else if(!U.acts.length) back(); }
  function back(){ if(U.back) U.back(); else close(); }
  function tap(t){ if(!t || !t.closest) return;
    if(t.closest('[data-gkx]')){ close(); return; }
    const r=t.closest('[data-gk]'); if(r){ U.cur=+r.dataset.gk; choose(); } }
  const btn=(a,label,note)=>`<button class="gm-item" data-act="${a}"><span style="pointer-events:none">${label}${note?` <span class="ds">${note}</span>`:''}</span></button>`;

  // ── the test ──
  let T=null;
  function quiz(lesson,practice){ const qs=practice?shuffle(LESSONS.filter(l=>st().done.includes(l.id)).flatMap(l=>l.quiz())).slice(0,8):lesson.quiz(); T={lesson,practice,qs,i:0,right:0,picked:null}; drawQ(); }
  function drawQ(){ const q=T.qs[T.i], n=T.qs.length, show=T.picked!==null;
    let h=`<p class="gm-note">Question ${T.i+1} of ${n} · ${T.right} right so far</p><div class="gkq">${q.q}</div>`;
    q.opts.forEach((o,k)=>{ const ok=o===q.a, mine=T.picked===k, txt=q.glyph?big(UI.esc(o)):UI.esc(o);
      h+= show ? `<div class="gm-item gkopt ${ok?'gkok':mine?'gkno':''}">${txt}</div>` : `<button class="gm-item gkopt" data-act="o:${k}">${txt}</button>`; });
    if(show) h+=`<p class="gm-note">${q.opts[T.picked]===q.a?'✓ Right!':'✗ It’s <b>'+UI.esc(q.a)+'</b>.'}</p>`+btn('next',T.i+1<n?'Next question ▸':'See how you did ▸');
    sheet({ title:T.practice?'📜 Practice with Mario':'📜 '+T.lesson.title, html:h,
      act:a=>{ if(a==='next'){ T.i++; T.picked=null; if(T.i>=n) finish(); else drawQ(); return; }
        if(a.startsWith('o:') && T.picked===null){ T.picked=+a.slice(2); if(q.opts[T.picked]===q.a) T.right++; drawQ(); } },
      back:()=>{ T=null; menu(); } }); }
  function finish(){ const t=T, n=t.qs.length, r=t.right; T=null; close();
    if(t.practice){ const g=r*5; if(g) gold+=g; say([`“${r} of ${n}. ${r>=7?'Your old teacher is proud.':r>=5?'Good — the letters are settling in.':'Hm. Again tomorrow, eh? Little and often.'}”`].concat(g?[`🪙 ${g} gold for your trouble.`]:[])); return; }
    const g=st(), L=t.lesson; g.best[L.id]=Math.max(g.best[L.id]||0,r);
    if(r>=6){ const first=!g.done.includes(L.id); if(first){ g.done.push(L.id); gainXp(L.reward); } keep(); const nx=nextL();
      say([`“${r} of ${n}! ${r===n?'Every one!':'Well done.'} ${first?'That lesson is yours now — no one can take it from you.':''}”`]
        .concat(first?[`📜 Greek level ${level()} · +${L.reward} XP`]:[])
        .concat([nx?`“Come back when you are ready for the next: ${nx.title}.”`:'“That is all I have written for now — and I hear there are old manuscripts in this realm that want reading…”']),
        first?()=>memory(LESSONS.indexOf(L)):undefined); }
    else say([`“${r} of ${n}. Not yet — you need six. No shame in it; I failed my first test too, a very long time ago.”`,'“Look over the page again, say them aloud, and try once more.”']); }
  function memory(i){ const g=st(); if(!MEM[i] || g.mem[i]) return; g.mem[i]=true; keep();
    setTimeout(()=>{ if(!dialogue.open) say(['<i>He sets down his pen and looks at the lamp for a moment.</i>',MEM[i]]); },300); }

  // ── the reader: every word a button — choose one for its meaning; then the whole in English ──
  let RD=null;
  function readerHtml(id,o){ const p=PASS[id];
    let h=o&&o.teach?`<p class="gm-intro">${UI.esc(p.ref)}. Choose any word for its meaning; when you have it, choose “What it says”.</p>`:`<p class="gm-intro">${UI.esc(p.title)} — <b>${UI.esc(p.ref)}</b></p>`;
    const sel=RD&&RD.id===id?RD.sel:null;
    if(sel){ const w=p.verses[sel[0]][1][sel[1]]; h+=`<div class="gm-note" style="text-align:center">${big(w[0].replace(/[,.;·]$/,''))}<br>${UI.esc(w[1])}</div>`; }
    h+=`<div lang="el" class="gkr">`+p.verses.map(([n,ws],v)=>`<sup class="ds">${n}</sup> `+ws.map(([g],i)=>`<button class="gm-item gkw${sel&&sel[0]===v&&sel[1]===i?' gksel':''}" data-act="w:${v}:${i}">${gk(g)}</button>`).join('')).join(' ')+`</div>`;
    h+=RD&&RD.id===id&&RD.en?`<p class="gm-note"><i>${UI.esc(p.en)}</i></p><p class="gm-note ds">Greek: Robinson–Pierpont Byzantine text (public domain). English: KLK’s own, word for word.</p>`:btn('en','✦ What it says');
    return h; }
  function reader(id,x){ x=x||{}; const fresh=!(RD&&RD.id===id); if(fresh) RD={id,sel:null,en:false}; const p=PASS[id];
    sheet({ title:'📜 '+p.ref, html:readerHtml(id,x)+(x.after||''), keep:!fresh,
      act:a=>{ if(a.startsWith('w:')){ const [,v,i]=a.split(':'); RD.sel=[+v,+i]; reader(id,x); } else if(a==='en'){ RD.en=true; reader(id,x); } else if(x.act) x.act(a); },
      back:()=>{ RD=null; if(x.back) x.back(); else close(); } }); }
  // a manuscript found in the realm: read it if your Greek is good enough (the first reading is rewarded)
  function readFound(id){ const p=PASS[id], g=st();
    if(level()<p.need){ sheet({ title:'📜 An old manuscript', html:`<p class="gm-intro">${UI.esc(p.title)}. The letters are Greek — you can make out a few of them — but not enough to read it.</p><div class="gkq" style="opacity:.75">${big(p.verses[0][1].slice(0,6).map(w=>w[0]).join(' ')+' …')}</div><p class="gm-note">You need Greek level <b>${p.need}</b> (you have ${level()}). ${g.met?'Old Man Mario can teach you.':'Someone in the realm must know this tongue — an old copyist, perhaps, near the Homestead.'}</p>` }); return; }
    const first=!g.read[id]; RD=null; reader(id);
    if(first){ g.read[id]=true; gainXp(150); gold+=100; if(typeof codexAdd==='function') codexAdd(p.title, p.ref, p.en);
      showBanner(`📜 <b>You read ${p.ref} for yourself!</b><br><span style="font-size:calc(7px*var(--tx,1))">+150 XP · +100 gold</span>`,3000);
      if(FOUND().every(k=>g.read[k]) && !g.finaleReady){ g.finaleReady=true; setTimeout(()=>showBanner('📜 <b>Every hidden leaf is found.</b><br><span style="font-size:calc(7px*var(--tx,1))">Old Man Mario should hear of this.</span>',3600),3400); }
      keep(); } }

  // ── talking to Mario ──
  function lessonSheet(L){ const test=btn('test','✎ I’m ready — test me','6 of 8 to pass');
    if(L.id==='l10'){ RD=null; reader('john1',{teach:true, after:test, act:a=>{ if(a==='test') quiz(L); }, back:menu}); return; }
    sheet({ title:'📜 '+L.title, html:test+L.teach()+test, act:a=>{ if(a==='test') quiz(L); }, back:menu }); }
  function talk(){ const g=st();
    if(!g.met){ g.met=true; g.metDay=today(); g.lastDay=today(); keep();
      say(['“Eh? A visitor! Come in, come in, mind the scrolls.”','“They call me Old Man Mario. I have spent my life copying the old words — the Scriptures as the apostles wrote them, in Greek.”','“There are writings in this realm older than any king — and no one left who can read them. You have done great things with a sword, knight. Shall I teach you to do something with your eyes?”'],menu); return; }
    const gap=today()-(g.lastDay||today()); g.lastDay=today();
    if(g.finaleReady && !g.finaleDone){ g.finaleDone=true; g.pen=true; keep();
      say(FINALE,()=>{ gainXp(500); showBanner('✒ <b>Petra’s gilded pen</b> · +500 XP',3200); keep(); }); return; }
    if(gap>=3){ const L0=['“Ah — there you are. I wondered whether the road had kept you.”','“Back again! The tea has gone cold twice waiting for you. Sit, sit.”','“You look tired, knight. Good. Tired people learn well, if they sit down first.”']; say([L0[(Math.random()*L0.length)|0]],menu); return; }
    menu(); }
  function menu(){ const g=st(), nx=nextL();
    let h=`<p class="gm-intro">Old Man Mario taps the open scroll on his desk. “Koine Greek — the common tongue, the language of the New Testament. Little and often, that is the way.”</p><p class="gm-note">📜 Your Greek level: <b>${level()}</b> of ${LESSONS.length}</p>`;
    if(nx) h+=btn('next','▶ Next lesson: '+UI.esc(nx.title));
    if(level()) h+=btn('prac','✎ Practise what you know','8 questions · 5 gold a right answer');
    LESSONS.forEach((L,i)=>{ if(g.done.includes(L.id)) h+=btn('re:'+i,'✓ '+UI.esc(L.title),`study again · best ${g.best[L.id]||0}/8`); });
    const rd=Object.keys(PASS).filter(id=>id==='john1'?g.done.includes('l10'):g.read[id]);
    if(rd.length){ h+=`<div class="gm-sec">📜 Manuscripts you have read</div>`; rd.forEach(id=>h+=btn('rd:'+id,UI.esc(PASS[id].ref),UI.esc(PASS[id].title))); }
    const left=FOUND().filter(id=>!g.read[id]).length;
    if(left && level()>=3) h+=`<p class="gm-note">“There are old leaves out in the realm, knight — one pinned by Hearthvale’s chapel door, one on Eldan’s lectern in the Sage’s Wood, one the old monk keeps in his cave. And every chapel you cleansed keeps a leaf on a lectern in its sanctuary. Find them, and read them yourself.” <span class="ds">(${FOUND().length-left} of ${FOUND().length} read)</span></p>`;
    const ms=Object.keys(g.mem).map(Number).sort((a,b)=>a-b);
    if(ms.length) h+=btn('mem','🕯 Sit with Mario a while',`hear his stories again (${ms.length})`);
    if(g.pen) h+=`<p class="gm-note">✒ Petra’s gilded pen rides at your belt.</p>`;
    if(!nx) h+=`<p class="gm-note">More lessons are coming — Mario is still writing them.</p>`;
    sheet({ title:'🕯 Old Man Mario', html:h, act:a=>{
      if(a==='next'){ const L=nextL(); close(); say(L.intro,()=>lessonSheet(L)); }
      else if(a==='prac') quiz(null,true);
      else if(a.startsWith('re:')) lessonSheet(LESSONS[+a.slice(3)]);
      else if(a.startsWith('rd:')){ RD=null; reader(a.slice(3),{back:menu}); }
      else if(a==='mem'){ close(); say(['<i>He pours the tea and settles back.</i>'].concat(ms.map(i=>MEM[i])),menu); } } }); }
  // Eldan and the old monk keep a leaf each: once Mario has told you of the leaves, they offer it after they speak
  function offer(id,who,line){ const g=st(); if(!g.met || g.read[id] || !dialogue.open) return;
    const prev=dialogue.onDone; dialogue.onDone=()=>{ if(prev) prev(); setTimeout(()=>{ if(!dialogue.open && !gkOpen()) sayAs(who,[line],()=>readFound(id)); },60); }; }
  return { talk, read:readFound, offer, level, st, lessons:LESSONS, passages:PASS, sanct:SANCT_PASS, found:FOUND, move, choose, back, tap, close, _t:()=>T };
})();
// ── the hut, its room, the leaves, and the hooks ──
(function greekInstall(){
  // the room within: a desk with John 1:1 open on it, shelves of scrolls, the fire (the 3D game's marioHut, tile for tile)
  INTERIORS.mario_hut={ name:'Old Man Mario’s Hut', theme:'home', floors:[ gridRows(`
    5 5 5 51 51 5 5 5
    5 44 44 12 12 45 49 5
    5 12 12 12 12 12 12 5
    5 47 12 40 40 12 12 5
    5 12 12 12 12 12 48 5
    5 13 13 12 12 12 12 5
    5 5 5 9 5 5 5 5`) ], npcs:[ { floor:0, x:4, y:2, name:'Old Man Mario', mario:true, dir:'down', lines:['…'] } ] };
  // the hut itself, at the wood's edge on the east side of the Homestead clearing
  if(!buildings.some(b=>b.id===GK_HUT.id)){ buildings.push(GK_HUT); stampBuilding(WORLD,GK_HUT); }
  // the scrap by Hearthvale's chapel door
  if(WORLD[GK_SIGN.y]){ WORLD[GK_SIGN.y][GK_SIGN.x]=16; signs[GK_SIGN.x+','+GK_SIGN.y]='An old leaf of Greek is pinned here.'; }
  if(typeof _miniBase!=='undefined') _miniBase=null;
  // a lectern with a leaf in every sanctuary (east of the steps)
  const _bs=buildSanctuary;
  buildSanctuary=function(t){ const id=_bs.apply(this,arguments), I=INTERIORS[id], leaf=GREEK.sanct[t];
    if(I && leaf && !I.npcs.some(n=>n.gkleaf)) I.npcs.push({ floor:0, x:11, y:5, name:'An old manuscript', gkleaf:leaf, lines:['…'] });
    return id; };
  // Eldan and the old monk
  const _sg=sageTalk; sageTalk=function(){ const r=_sg.apply(this,arguments); GREEK.offer('john1_14','Eldan the Sage','“That old page on my lectern? Greek. A young woman with gold on her fingers left it with me, a lifetime ago. Read it, if you can.”'); return r; };
  const _mk=monkTalk; monkTalk=function(){ const r=_mk.apply(this,arguments); GREEK.offer('john3_16','The Old Monk','“You have the look of someone who reads. Here — my treasured scroll. A girl copied it by my fire one winter, long ago. Can you make it out?”'); return r; };
  // Mario, and the lecterns, drawn
  const _dn=drawNpc;
  drawNpc=function(x,y,n){
    if(n.gkleaf){ const rd=!!(GREEK_STATE&&GREEK_STATE.read&&GREEK_STATE.read[n.gkleaf]), t=performance.now()/1000;
      ctx.fillStyle='rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(x+8,y+15,5,2,0,0,7); ctx.fill();
      px(x+7,y+6,2,9,'#4a3020'); px(x+5,y+14,6,2,'#3a2418'); px(x+3,y+3,10,4,'#6a4a2a'); px(x+3,y+3,10,1,'#8a6a3a');
      px(x+4,y+1,8,3,'#efe0b8'); px(x+5,y+2,2,1,'#5a3a18'); px(x+8,y+2,3,1,'#5a3a18');
      if(!rd){ ctx.globalAlpha=0.55+0.35*Math.sin(t*2.4); px(x+7,y-3+Math.round(Math.sin(t*2.2)*1),2,2,'#fff0b0'); ctx.globalAlpha=1; }
      return; }
    if(n.mario){ drawVillager(x,y,{outfit:'monk',dir:n.dir||'down',moving:false,frame:0}); px(x+11,y+7,1,4,'#f4ecd8'); px(x+11,y+11,1,1,'#1a1a24'); return; }   // his quill
    return _dn.apply(this,arguments); };
  // the hut, painted: limewash under a deep thatch, a lit window, a chimney, an alphabet board, a basket of scrolls
  const _hb=drawBuilding;
  drawBuilding=function(b,ox,oy){ if(b.id!=='mario_hut' || place.kind!=='overworld') return _hb.apply(this,arguments);
    const W=b.w*TILE, H=b.h*TILE, B=oy+H, wallTop=oy+20;
    _hsShadow(ox,B,W);
    px(ox+3,wallTop,W-6,B-wallTop,HSP.lime); px(ox+3,wallTop,W-6,2,HSP.limeL); px(ox+W-5,wallTop,2,B-wallTop,HSP.limeD);
    for(const xx of [3,W-6]) px(ox+xx,wallTop,3,B-wallTop,HSP.timber);
    px(ox+3,B-8,W-6,8,HSP.stoneD); for(let xx=ox+4; xx<ox+W-6; xx+=7) px(xx,B-7,5,3,HSP.stone);
    _hsThatch(ox,oy-8,W,wallTop+4,3,0.16);
    _hsChimney(ox+W-16,oy-14,b.x,6);
    const dx=ox+(b.door.x-b.x)*TILE, dy=B-TILE; _hsDoor(dx,dy,'#4a3020',false);
    _hsWin(ox+W-22,wallTop+8,9,8,true,false);
    px(ox+5,wallTop+7,10,8,'#5a4028'); px(ox+6,wallTop+8,8,6,'#efe0b8');                                   // the alphabet board
    for(let i=0;i<3;i++) px(ox+7+i*2,wallTop+9,1,1,'#3a2410'); for(let i=0;i<3;i++) px(ox+7+i*2,wallTop+11,1,1,'#3a2410');
    px(ox+W-9,B-6,7,5,'#8a6a3a'); px(ox+W-8,B-9,2,4,'#e8dcc0'); px(ox+W-5,B-8,2,3,'#e8dcc0'); };                 // a basket of scrolls
  // the save
  const _bsd=buildSaveData; buildSaveData=function(){ const d=_bsd.apply(this,arguments); if(d && GREEK_STATE) d.greek=JSON.parse(JSON.stringify(GREEK_STATE)); return d; };
  const _asd=applySaveData; applySaveData=function(s){ const r=_asd.apply(this,arguments); GREEK_STATE=(s && s.greek) ? JSON.parse(JSON.stringify(s.greek)) : null; if(gkOpen()) GREEK.close(); return r; };
  // the keys, the pad and the touch buttons, while a page is open
  const _ck=ctlKey;
  ctlKey=function(e){ const r=_ck.apply(this,arguments); if(r) return true;
    if(!gkOpen() || !e) return false;
    if(e.type==='keydown'){ const k=String(e.key||'').toLowerCase(); if(e.preventDefault) e.preventDefault(); e.__ctlEat=true;
      if(k==='w'||k==='arrowup'||k==='a'||k==='arrowleft') GREEK.move(-1);
      else if(k==='s'||k==='arrowdown'||k==='d'||k==='arrowright') GREEK.move(1);
      else if(!e.repeat && (k==='j'||k==='z'||k==='enter'||k===' ')) GREEK.choose();
      else if(!e.repeat && (k==='k'||k==='x'||k==='escape'||k==='shift'||k==='m')) GREEK.back();
      return true; }
    return false; };   // a key let go still reaches the game, so nothing is left held down
  const _ap=aPress; aPress=function(){ if(gkOpen()){ GREEK.choose(); return; } return _ap.apply(this,arguments); };
  const _bd=bDown; bDown=function(){ if(gkOpen()){ GREEK.back(); return; } return _bd.apply(this,arguments); };
  const _bp=bPress; bPress=function(){ if(gkOpen()){ GREEK.back(); return; } return _bp.apply(this,arguments); };
  const _dp=dirPress; dirPress=function(d){ if(gkOpen()){ GREEK.move(d==='up'||d==='left'?-1:1); return true; } return _dp.apply(this,arguments); };
  const _tm=toggleMenu; toggleMenu=function(){ if(gkOpen()){ GREEK.close(); return; } return _tm.apply(this,arguments); };
  // the look of the pages
  try{ const s=document.createElement('style'); s.textContent=
    '.gk{color:#302718}.gk .gm-intro{font-size:calc(7.5px*var(--tx,1));line-height:1.8;margin:2px 2px 6px}.gk p{font-size:calc(7.5px*var(--tx,1));line-height:1.8;margin:4px 2px}'
    +'.gk .gm-note{font-size:calc(7px*var(--tx,1));line-height:1.8;color:#6f5c3e;margin:6px 2px}.gk .gm-sec{font-size:calc(7.5px*var(--tx,1));color:#7a5c28;border-bottom:1px solid #c0af86;margin:10px 2px 2px}'
    +'.gk .ds{font-size:calc(6.5px*var(--tx,1));color:#6f5c3e}.gk .gkt{display:grid;gap:4px 10px;align-items:center;margin:6px 2px;font-size:calc(7.5px*var(--tx,1));line-height:1.6}'
    +'.gk .gkb{font:600 22px/1.25 "Gentium Plus","Noto Serif","Times New Roman",serif;color:#3a2410}.gk .gks{font:600 15px "Gentium Plus","Noto Serif","Times New Roman",serif;color:#3a2410}'
    +'.gk button.gm-item{font:inherit;font-size:calc(8px*var(--tx,1));width:100%;background:none;text-align:left;cursor:pointer}.gk .gkq{text-align:center;font-size:calc(8.5px*var(--tx,1));line-height:1.7;margin:8px 2px 10px}'
    +'.gk .gkopt{justify-content:center;text-align:center!important}.gk .gkok{border-color:#3f6b44!important;background:#bfe0b0!important}.gk .gkno{border-color:#a0302a!important;background:#efc0b0!important}'
    +'.gk .gkr{line-height:2;margin:6px 0}.gk button.gkw{display:inline-flex;width:auto;margin:2px;padding:2px 6px}.gk .gkw.gksel{border-color:#7a5c28;background:#f2e2a8}';
    document.head.appendChild(s); }catch(e){}
})();
// the scrap by Hearthvale's chapel door: faced, Ⓐ reads it (called first thing in doAction)
function gkSignAction(){ if(place.kind!=='overworld' || dialogue.open || gkOpen()) return false;
  const cx=Math.floor((player.x+TILE/2)/TILE), cy=Math.floor((player.y+TILE/2)/TILE), d=player.dir;
  const fx=cx+(d==='left'?-1:d==='right'?1:0), fy=cy+(d==='up'?-1:d==='down'?1:0);
  if(fx===GK_SIGN.x && fy===GK_SIGN.y){ GREEK.read('john14_6'); return true; } return false; }
// Old Man Mario's face for the speech box: a white-haired copyist, ink to the wrists
if(typeof PORTRAITS!=='undefined' && typeof PP!=='undefined') PORTRAITS['old man mario']=(q)=>{ const P=PORTRAIT_PAL;
  PP.bg(q,P.BG_WARM,P.BG_WARM_2,true); PP.body(q,P.C_BLUE,P.C_BLUE_L,P.C_BLUE_D,{clasp:1}); PP.head(q,P.SK_PALE,P.SK_PALE_D,P.SK_PALE_HI);
  PP.hair(q,P.H_WHITE,P.H_WHITE_D,P.H_WHITE_HI,'bald'); PP.brow(q,P.BROW,false); PP.eyes(q,P.SK_PALE_D,'#5a4a3a',true); PP.nose(q,P.SK_PALE,P.SK_PALE_D);
  PP.beard(q,P.H_WHITE,P.H_WHITE_D,P.H_WHITE_HI,1); PP.outline(q); };

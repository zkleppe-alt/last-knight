const { chromium } = require('/home/claude/harness_src/test/node_modules/playwright');
(async()=>{ const out={};
 for(const f of ['index.html','index-phone.html']){
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const p=await b.newPage({viewport:{width:900,height:600}});
  await p.addInitScript(()=>{ window.__gp={ id:'8BitDo SN30 Pro (STANDARD GAMEPAD)', index:0, connected:true, mapping:'standard', buttons:Array.from({length:17},()=>({pressed:false,value:0,touched:false})), axes:[0,0,0,0], timestamp:0 };
    navigator.getGamepads=()=>[window.__gp]; window.__btn=(i,on)=>{ window.__gp.buttons[i]={pressed:on,value:on?1:0,touched:on}; }; });
  const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('file:///home/claude/harness_src/'+f); await p.waitForTimeout(2500);
  const press=async(i)=>{ await p.evaluate(i=>__btn(i,true),i); await p.waitForTimeout(120); await p.evaluate(i=>__btn(i,false),i); await p.waitForTimeout(120); };
  const b0=await p.evaluate(()=>[boot.done, typeof bootState!=='undefined'?JSON.stringify(bootState).slice(0,80):'']);
  await p.evaluate(()=>{ window.__ba=0; const _a=bootA; bootA=function(){ __ba++; }; window.__restoreBootA=()=>{ bootA=_a; }; });
  await press(1); const bootHits=await p.evaluate(()=>__ba); await p.evaluate(()=>__restoreBootA());
  await p.evaluate(()=>{ boot.done=true; intro.open=false; document.getElementById('stage').classList.remove('booting'); });
  const r={ layout: await p.evaluate(()=>pad.cfg.layout), bootDone:b0[0], bootA:bootHits };
  await press(9); r.menuOpen=await p.evaluate(()=>menu.open);
  await p.evaluate(()=>{ setMenuTab(TAB.system); menu.focus='list'; menu.cursor=menuRows().findIndex(r=>r.id==='pad'); renderMenu(); });
  await press(1);  // SNES A = Ⓐ
  r.sub=await p.evaluate(()=>menu.sub);
  await p.waitForTimeout(300); await p.screenshot({path:'/home/claude/out_gp_'+f.replace('.html','')+'.png'});
  await press(0); r.afterB=await p.evaluate(()=>[menu.open,menu.sub]);
  r.errs=errs; out[f]=r; await b.close(); }
 console.log(JSON.stringify(out)); })();

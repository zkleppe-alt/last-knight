// suite/boat.js — ⛵ the boat stays where you left it (2026-10-23-bt).
//
// Zak: "if you log out after traveling with the boat it doesn't stay where you left it and the player gets stranded if
// they don't have the right steed". Decorations are rebuilt when the page loads, so every reload put the boat back at
// the Saltmere pier. These checks sail to an island, dock, save, "reload" (the boat put back at the pier the way a
// fresh page has it) and load — and check that the knight can walk to his boat.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('boat');
K.$(`boot.done=true; intro.open=false; menu.open=false; cutscene.active=false; dialogue.open=false; place={kind:'overworld'}; demons=[]; player.pet=null; player.mounted=false; player.boating=false;`);
const HOME = K.$(`(()=>{ const b=decorations.find(d=>d.kind==='boat'); return [b.x,b.y,b.w]; })()`);
const freshPage = () => K.$(`for(let i=decorations.length-1;i>=0;i--) if(decorations[i].kind==='boat') decorations.splice(i,1); decorations.push({x:${HOME[0]}, y:${HOME[1]}, kind:'boat', w:${HOME[2]}});`);
// an island: a stretch of land with no town on it, beside the open sea (the tiles walkable, the homestead gate open)
const isle = K.$(`(()=>{ const H=WORLD.length, W=WORLD[0].length, comp=new Int32Array(W*H).fill(-1), sz=[]; let id=0;
  for(let y=0;y<H;y++) for(let x=0;x<W;x++){ if(comp[y*W+x]!==-1||!_boatFoot(WORLD[y][x])) continue; const st=[[x,y]]; comp[y*W+x]=id; let n=0;
    while(st.length){ const [cx,cy]=st.pop(); n++; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=cx+dx, ny=cy+dy; if(nx<0||ny<0||nx>=W||ny>=H||comp[ny*W+nx]!==-1||!_boatFoot(WORLD[ny][nx])) continue; comp[ny*W+nx]=id; st.push([nx,ny]); } } sz.push(n); id++; }
  const town=new Set(); for(const b of buildings) if(b.door) for(const [dx,dy] of [[0,0],[0,1],[1,0],[-1,0],[0,-1]]){ const c=comp[(b.door.y+dy)*W+b.door.x+dx]; if(c>=0) town.add(c); }
  const sea=boatSea(); let best=null;
  for(let y=1;y<H-1;y++) for(let x=1;x<W-1;x++){ const c=comp[y*W+x]; if(c<0 || town.has(c) || SAIL_TILES.has(WORLD[y][x]) || sz[c]<40) continue;
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const wx=x+dx, wy=y+dy; if(sea.comp[wy*W+wx]===sea.id && !WALK.has(WORLD[wy][wx]) && (!best||sz[c]>best.size)) best={ land:[x,y], water:[wx,wy], size:sz[c] }; } }
  return best; })()`);
ok('found an island off the mainland, beside the open sea', !!isle, JSON.stringify(isle));
const canWalkToBoat = () => K.$(`(()=>{ const b=boatDecor(); if(!b) return false; const H=WORLD.length, W=WORLD[0].length, sx=Math.floor((player.x+8)/16), sy=Math.floor((player.y+8)/16);
  const seen=new Set([sx+','+sy]), q=[[sx,sy]]; let h=0; const bw=b.w||1;
  while(h<q.length){ const [x,y]=q[h++]; if(x>=b.x-1&&x<=b.x+bw&&y>=b.y-1&&y<=b.y+bw) return true; for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){ const nx=x+dx, ny=y+dy, k=nx+','+ny; if(seen.has(k)||!WORLD[ny]||!_boatFoot(WORLD[ny][nx])) continue; seen.add(k); q.push([nx,ny]); } }
  return false; })()`);
const [lx, ly] = isle.land, [wx, wy] = isle.water;
const dirTo = wx < lx ? 'right' : wx > lx ? 'left' : wy < ly ? 'down' : 'up';
// sail there and dock: aboard on the water beside the island, facing the land, Ⓐ
K.$(`player.boating=true; for(let i=decorations.length-1;i>=0;i--) if(decorations[i].kind==='boat') decorations.splice(i,1);
  player.x=${wx}*TILE; player.y=${wy}*TILE; player.dir=${JSON.stringify(dirTo)}; dialogue.open=false; doAction();`);
check('docked on the island: ashore, boat moored where he left the water', K.$(`[player.boating, boatDecor()&&boatDecor().x, boatDecor()&&boatDecor().y]`), [false, wx, wy]);
// save, a fresh page (the boat back at the pier), load
const save = K.$(`JSON.stringify(buildSaveData())`);
check('the save remembers where she is moored', JSON.parse(save).boat && [JSON.parse(save).boat.x, JSON.parse(save).boat.y, JSON.parse(save).boat.sailing], [wx, wy, false]);
freshPage(); K.$(`player.x=32*TILE; player.y=24*TILE;`);
K.$(`applySaveData(JSON.parse(${JSON.stringify(save)}))`);
check('after a reload she is still at the island', K.$(`[boatDecor().x, boatDecor().y]`), [wx, wy]);
ok('…and he can walk to her', canWalkToBoat());
// saved while aboard, out on the water
K.$(`player.boating=true; for(let i=decorations.length-1;i>=0;i--) if(decorations[i].kind==='boat') decorations.splice(i,1); player.x=${wx}*TILE; player.y=${wy}*TILE;`);
const save2 = K.$(`JSON.stringify(buildSaveData())`);
check('saved while aboard: the save says so, with where', [JSON.parse(save2).boat.sailing, JSON.parse(save2).boat.sx, JSON.parse(save2).boat.sy], [true, wx, wy]);
freshPage(); K.$(`player.boating=false;`); K.$(`applySaveData(JSON.parse(${JSON.stringify(save2)}))`);
check('loading it: she waits on the water where he was', K.$(`[boatDecor().x, boatDecor().y]`), [wx, wy]);
ok('…he stands on the nearest shore and can walk to her', K.$(`WALK.has(WORLD[Math.floor((player.y+8)/16)][Math.floor((player.x+8)/16)])`) && canWalkToBoat());
// an OLD save made on the island (no boat in it): she drifts to him
const old = JSON.parse(save); delete old.boat;
freshPage(); K.$(`applySaveData(JSON.parse(${JSON.stringify(JSON.stringify(old))}))`);
ok('an old save on the island: the boat drifts to the nearest shore he can reach', canWalkToBoat(), JSON.stringify(K.$(`[boatDecor().x, boatDecor().y]`)));
check('…and on the open sea, not a pond', K.$(`(()=>{ const b=boatDecor(), s=boatSea(); return s.comp[b.y*WORLD[0].length+b.x]===s.id; })()`), true);
// never sailed: she stays at the pier
freshPage(); K.$(`player.x=32*TILE; player.y=24*TILE; player.boating=false;`);
const save3 = K.$(`JSON.stringify(buildSaveData())`); freshPage(); K.$(`applySaveData(JSON.parse(${JSON.stringify(save3)}))`);
check('never sailed: she stays at the Saltmere pier', K.$(`[boatDecor().x, boatDecor().y, boatDecor().w]`), HOME);
// an old save in a town far from the pier (towns are joined by trails and portals): the boat is not moved
freshPage(); const old2 = JSON.parse(save3); delete old2.boat; K.$(`applySaveData(JSON.parse(${JSON.stringify(JSON.stringify(old2))}))`);
check('an old save in a town: she stays at the pier', K.$(`[boatDecor().x, boatDecor().y, boatDecor().w]`), HOME);
ok('real frames run after the load', K.$(`(()=>{ try{ for(let i=0;i<4;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
done('boat');

// suite/greek.js — 📜 Old Man Mario and his Greek lessons, from the 3D game (2026-10-24-gk).
//
// Zak: "Can we add some of the features from the 3d game into this one? Like Old Man Mario and his Greek lessons".
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('greek');
K.$(`boot.done=true; intro.open=false; cutscene.active=false; dialogue.open=false; menu.open=false; place={kind:'overworld'}; demons=[]; GREEK_STATE=null;
  globalThis.__talkOut=()=>{ let n=0; while(dialogue.open && n<60){ dialogue.lockUntil=0; if(dialogue.tokens) dialogue.shown=dialogue.full; advanceDialogue(); n++; } return n; };
  globalThis.__pick=(a)=>{ const i=greekUI.acts.indexOf(a); if(i<0) return false; greekUI.cur=i; GREEK.choose(); return true; };
  globalThis.__answer=(right)=>{ const T=GREEK._t(); const q=T.qs[T.i]; const k=right?q.opts.indexOf(q.a):q.opts.findIndex(o=>o!==q.a); __pick('o:'+k); __pick('next'); };`);
// ── the hut ──
const hut = K.$(`(()=>{ const b=buildings.find(b=>b.id==='mario_hut'); return b && [b.x,b.y,b.door.x,b.door.y, WORLD[b.door.y][b.door.x], WALK.has(WORLD[b.door.y+1][b.door.x]), hsAt(b.x,b.y)]; })()`);
check('Mario’s hut stands at the wood’s edge east of the Homestead, its door onto open grass', hut, [36, 131, 37, 133, 9, true, true]);
K.$(`(()=>{ const b=buildings.find(b=>b.id==='mario_hut'); player.x=b.door.x*TILE; player.y=b.door.y*TILE; cross.t=0; enterDoor(b); let n=0; while(cross.t>0 && n<200){ tickCross(16); n++; } })()`);
check('the door leads into his room', K.$(`[place.kind, place.id]`), ['interior', 'mario_hut']);
// stand beside him, facing him
K.$(`player.x=3*TILE; player.y=2*TILE; player.dir='right'; dialogue.open=false;`);
K.$(`doAction()`);
check('Ⓐ at Mario: he greets you as a stranger', K.$(`[dialogue.open, (dialogue.lines[0]||{}).speaker]`), [true, 'Old Man Mario']);
K.$(`__talkOut()`);
check('…then his page opens: the next lesson, and your level', K.$(`[gkOpen(), greekUI.title, greekUI.acts[0]]`), [true, '🕯 Old Man Mario', 'next']);
ok('the page is drawn into the ☰ panel', /Greek level/.test(K.$(`document.getElementById('gamemenu').innerHTML`)));
ok('the world waits while it is open', K.$(`!gameplayB()`));
// ── a lesson ──
K.$(`__pick('next')`);
check('“Next lesson”: he introduces it…', K.$(`[gkOpen(), dialogue.open]`), [false, true]);
K.$(`__talkOut()`);
check('…then the page of the lesson, with the test at hand', K.$(`[gkOpen(), greekUI.title, greekUI.acts.filter(a=>a==='test').length]`), [true, '📜 The Letters, I — Alpha to Mu', 2]);
ok('the twelve letters are on it', ['α', 'β', 'γ', 'μ', 'lambda'].every(s => K.$(`greekUI.body`).includes(s)));
K.$(`__pick('test')`);
check('the test: eight questions, four answers each', K.$(`[GREEK._t().qs.length, GREEK._t().qs.every(q=>q.opts.length===4 && q.opts.includes(q.a))]`), [8, true]);
// fail it: three wrong
for (let i = 0; i < 8; i++) K.$(`__answer(${i < 5})`);
check('five of eight: not yet', K.$(`[GREEK.level(), dialogue.open, GREEK_STATE.best.l1]`), [0, true, 5]);
K.$(`__talkOut()`);
// pass it, from the keyboard
K.$(`doAction(); __talkOut(); __pick('next'); __talkOut(); __pick('test');`);
const xp0 = K.$(`player.xp + player.level*100000`);
for (let i = 0; i < 8; i++) {
  const k = K.$(`(()=>{ const T=GREEK._t(), q=T.qs[T.i]; return greekUI.acts.indexOf('o:'+q.opts.indexOf(q.a)); })()`);
  K.$(`greekUI.cur=0;`); for (let j = 0; j < k; j++) { K.key.down('s'); K.key.up('s'); }
  K.key.down('j'); K.key.up('j'); K.key.down('j'); K.key.up('j');
}
check('eight of eight, answered with the keys: the lesson is learned', K.$(`[GREEK.level(), GREEK_STATE.done[0]]`), [1, 'l1']);
ok('…and the XP is paid', K.$(`player.xp + player.level*100000`) > xp0);
K.frames(30); K.$(`__talkOut()`);
check('the first time, he tells a piece of his story', K.$(`GREEK_STATE.mem[0]`), true);
// Ⓑ backs out of a page
K.$(`doAction(); __talkOut();`); ok('talking again opens his page', K.$(`gkOpen()`));
K.key.down('k'); K.key.up('k');
check('Ⓑ (K) closes it', K.$(`gkOpen()`), false);
K.$(`doAction(); __talkOut();`); K.$(`toggleMenu()`);
check('☰ closes it too, and does not open the menu over it', K.$(`[gkOpen(), menu.open]`), [false, false]);
// a tap on a row
K.$(`doAction(); __talkOut(); globalThis.__row={ closest:(s)=>s==='[data-gk]'?{dataset:{gk:String(greekUI.acts.indexOf('prac'))}}:null };`);
K.$(`GREEK.tap(__row)`);
check('a tap on “Practise” starts eight questions from what you know', K.$(`[!!GREEK._t(), GREEK._t()&&GREEK._t().practice, GREEK._t()&&GREEK._t().qs.length]`), [true, true, 8]);
const g0 = K.$(`gold`); for (let i = 0; i < 8; i++) K.$(`__answer(true)`);
check('practice: 5 gold a right answer', K.$(`gold`) - g0, 40);
K.$(`__talkOut(); GREEK.close();`);
// ── the leaves ──
K.$(`place={kind:'overworld'}; player.x=GK_SIGN.x*TILE; player.y=(GK_SIGN.y+1)*TILE; player.dir='up';`);
check('a scrap is pinned beside Hearthvale’s chapel door', K.$(`[WORLD[GK_SIGN.y][GK_SIGN.x], buildings.find(b=>b.id==='chapel').door.y===GK_SIGN.y]`), [16, true]);
K.$(`doAction()`);
ok('facing it at level 1: the letters are Greek, but not enough to read', K.$(`gkOpen() && /You need Greek level <b>6<\\/b>/.test(greekUI.body) && greekUI.acts.length===0`));
K.$(`GREEK.choose()`); check('Ⓐ puts it away', K.$(`gkOpen()`), false);
K.$(`GREEK_STATE.done=['l1','l2','l3','l4','l5','l6','l7','l8','l9','l10','l11','l12','l13','l14'];`);
const xp1 = K.$(`player.xp + player.level*100000`), gd1 = K.$(`gold`);
K.$(`doAction()`);
check('with the Greek: the reader, every word a choice, and the English at the end', K.$(`[greekUI.title, greekUI.acts.filter(a=>a.startsWith('w:')).length, greekUI.acts.includes('en')]`), ['📜 John 14:6', 23, true]);
ok('the first reading pays: +150 XP, +100 gold, and into the codex', K.$(`player.xp + player.level*100000`) > xp1 && K.$(`gold`) - gd1 === 100 && K.$(`codex.seen.some(e=>e.ref==='John 14:6')`));
K.$(`__pick('w:0:4')`);
ok('choosing a word gives its meaning', /Ἐγώ<\/span><br>I</.test(K.$(`greekUI.body`)));
K.$(`__pick('en')`);
ok('“What it says”: the whole verse in English', /I am the way and the truth and the life/.test(K.$(`greekUI.body`)));
K.$(`GREEK.close()`);
// a lectern in every cleansed sanctuary
const lec = K.$(`(()=>{ const out=[]; for(let t=0;t<10;t++){ const id=buildSanctuary(t), I=INTERIORS[id], n=I.npcs.find(n=>n.gkleaf); const f=I.floors[0]; out.push(n && f.g[n.y][n.x]===12 ? n.gkleaf : null); } return out; })()`);
check('every sanctuary keeps a leaf on a lectern, each a different passage', [lec.every(Boolean), new Set(lec).size], [true, 10]);
// Eldan and the old monk offer theirs after they speak
K.$(`place={kind:'dungeon'}; sageTalk();`);
ok('Eldan, once Mario has spoken of the leaves: after his words, he offers his', K.$(`dialogue.open`));
K.$(`__talkOut(); place={kind:'overworld'};`); K.frames(10); K.$(`__talkOut()`);
check('…and it opens in the reader', K.$(`[gkOpen(), greekUI.title]`), [true, '📜 John 1:14']);
K.$(`GREEK.close(); place={kind:'overworld'};`);
// every leaf read → the finale
K.$(`GREEK.found().forEach(id=>{ GREEK_STATE.read[id]=true; }); GREEK_STATE.read.john11_35=false; GREEK.read('john11_35'); GREEK.close();`);
check('the last leaf read: Mario should hear of it', K.$(`GREEK_STATE.finaleReady`), true);
K.$(`place={kind:'interior', id:'mario_hut', floor:0}; player.x=3*TILE; player.y=2*TILE; player.dir='right'; dialogue.open=false; doAction();`);
check('…and he does: Petra’s note in the margin, and her pen', K.$(`[dialogue.lines.some(l=>/For M\\., if ever you come this far/.test(l.text)), GREEK_STATE.pen]`), [true, true]);
K.$(`__talkOut()`);
// ── the save ──
const sv = K.$(`JSON.stringify(buildSaveData())`);
check('the save carries his lessons, the leaves and the pen', [JSON.parse(sv).greek.done.length, JSON.parse(sv).greek.read.john14_6, JSON.parse(sv).greek.pen], [14, true, true]);
K.$(`applySaveData(JSON.parse(FRESH_STATE))`);
check('a new game starts with no Greek', K.$(`GREEK_STATE`), null);
K.$(`applySaveData(JSON.parse(${JSON.stringify(sv)}))`);
check('loading brings it all back', K.$(`[GREEK.level(), GREEK_STATE.finaleDone]`), [14, true]);
ok('old saves (no greek) load as no Greek', K.$(`(()=>{ const s=JSON.parse(${JSON.stringify(sv)}); delete s.greek; applySaveData(s); return GREEK_STATE===null; })()`));
// the pad's keys reach the pages too
K.$(`applySaveData(JSON.parse(${JSON.stringify(sv)}));`);
K.$(`place={kind:'interior', id:'mario_hut', floor:0}; player.x=3*TILE; player.y=2*TILE; player.dir='right'; dialogue.open=false; doAction(); __talkOut();`);
K.$(`greekUI.cur=0; padFire('keydown','s'); padFire('keyup','s');`);
check('a controller’s ▼ moves down the page', K.$(`greekUI.cur`), 1);
K.$(`padFire('keydown','k'); padFire('keyup','k');`);
check('…and its Ⓑ closes it', K.$(`gkOpen()`), false);
ok('real frames run with a page open', K.$(`(()=>{ try{ doAction(); __talkOut(); for(let i=0;i<4;i++) loop(performance.now()+i*16); GREEK.close(); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`place={kind:'overworld'}; GREEK_STATE=null;`);
done('greek');

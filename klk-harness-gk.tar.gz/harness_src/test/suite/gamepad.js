// suite/gamepad.js — 🎮 a controller, with Xbox, GameCube and Super Nintendo layouts (2026-10-24-gp).
//
// Zak: "Can we add a custom controller and keyboard in settings. With the controller have the ability to use classic
// (Xbox - GameCube type set up, as well as some of the Super Nintendo type controller set ups for those who want that
// OG feel". A fake pad stands in for navigator.getGamepads; padPoll() is the same per-frame read the page runs.
const K = require('../boot.js');
const { ok, check, done } = require('./lib.js');
console.log('gamepad');
K.$(`boot.done=true; intro.open=false; cutscene.active=false; dialogue.open=false; menu.open=false; place={kind:'overworld'}; demons=[];
  globalThis.__gp={ id:'Xbox Wireless Controller (STANDARD GAMEPAD)', connected:true, buttons:Array.from({length:17},()=>({pressed:false,value:0})), axes:[0,0,0,0] };
  navigator.getGamepads=()=>[__gp]; globalThis.__t=0;
  globalThis.__poll=(ms)=>{ const end=__t+(ms||16); do{ __t+=16; padPoll(__t); }while(__t<end); };
  globalThis.__btn=(i,on)=>{ __gp.buttons[i]={pressed:on,value:on?1:0}; };
  try{ localStorage.removeItem('klk_pad'); }catch(e){} padLoad(); pad.hinted=true; pad.id='';`);
const poll = ms => K.$(`__poll(${ms || 16})`);
const btn = (i, on) => K.$(`__btn(${i},${on})`);
const press = (i, ms) => { btn(i, true); poll(ms || 32); btn(i, false); poll(32); };
poll();
check('a pad named "Xbox" starts on the Xbox layout', K.$(`pad.cfg.layout`), 'xbox');
check('…and the menu says it is connected', K.$(`pad.id.slice(0,4)`), 'Xbox');
// ── the System menu ──
K.$(`menu.open=true; setMenuTab(TAB.system); menu.focus='list';`);
const rows = K.$(`menuRows().map(r=>r.id)`);
check('☰ System lists 🎮 Controller right after ⌨ Keyboard Controls', rows.indexOf('pad') - rows.indexOf('controls'), 1);
K.$(`menu.cursor=menuRows().findIndex(r=>r.id==='pad'); menuSelect();`);
check('Ⓐ opens the Controller screen', K.$(`[menu.sub, menuRows().length]`), ['pad', 14]);
const pane = K.$(`padPaneHtml()`);
ok('it names the pad, the layout and every action', /Connected/.test(pane) && /Classic — Xbox/.test(pane) && /Drink quick potion/.test(pane) && /Surface/.test(pane));
// the layouts, ◀▶ on the first row
const seen = [];
for (let i = 0; i < 4; i++) { K.$(`menu.cursor=0; menuMove(1,0);`); seen.push(K.$(`pad.cfg.layout`)); }
check('◀▶ goes through GameCube, both Super Nintendo layouts and back to Xbox', seen, ['gc', 'snes', 'zelda', 'xbox']);
check('the GameCube layout: the big A strikes, B (left) guards, X (right) drinks, Z changes the potion', K.$(`(padUse('gc'), [pad.cfg.binds.act[0], pad.cfg.binds.guard[0], pad.cfg.binds.potion[0], pad.cfg.binds.nextpot[1], padBtnName(0), padBtnName(2), padBtnName(1), padBtnName(5)])`), [0, 2, 1, 5, 'A', 'B', 'X', 'Z']);
check('the Super Nintendo as printed: A (right) strikes, B (bottom) guards, Y drinks, X next', K.$(`(padUse('snes'), [padButtonsFor('act'), padButtonsFor('guard'), padButtonsFor('potion').split(' / ')[0], padButtonsFor('nextpot').split(' / ')[0]])`), ['A', 'B', 'Y', 'X']);
check('the Super Nintendo with the sword on B: B strikes, Y guards, A drinks, X opens the menu', K.$(`(padUse('zelda'), [padButtonsFor('act'), padButtonsFor('guard').split(' / ')[0], padButtonsFor('potion'), padButtonsFor('menu').split(' / ')[1]])`), ['B', 'Y', 'A', 'X']);
// Ⓑ (the pad's) backs out of the screen
K.$(`padUse('xbox');`); press(1);
check('Ⓑ on the pad backs out of the Controller screen', K.$(`[menu.open, menu.sub]`), [true, null]);
press(9);
check('Menu / Start closes ☰', K.$(`menu.open`), false);
// ── in the field ──
K.$(`player.x=40*TILE; player.y=40*TILE; for(const k in held) held[k]=false;`);
const x0 = K.$(`player.x`);
btn(15, true); poll(16); ok('the d-pad holds a direction like a key', K.$(`held.right`) === true);
K.frames(10); btn(15, false); poll(16);
ok('…the knight walks, and stops when it is let go', K.$(`player.x`) > x0 && K.$(`held.right`) === false, K.$(`player.x`) - x0);
K.$(`__gp.axes[1]=0.9;`); poll(16); ok('the left stick moves him too', K.$(`held.down`) === true); K.$(`__gp.axes[1]=0;`); poll(16);
K.$(`pad.cfg.stick=false; __gp.axes[1]=0.9;`); poll(16); ok('…unless the stick is turned off', K.$(`held.down`) === false); K.$(`pad.cfg.stick=true; __gp.axes[1]=0;`); poll(16);
K.$(`globalThis.__bd=0; globalThis.__bu=0; const _d=bDown, _u=bUp; bDown=function(){ __bd++; return _d.apply(this,arguments); }; bUp=function(){ __bu++; return _u.apply(this,arguments); };`);
btn(1, true); poll(16); ok('B pressed is Ⓑ down (the guard), the same call the K key makes', K.$(`__bd`) === 1); btn(1, false); poll(16); ok('…and let go is Ⓑ up', K.$(`__bu`) >= 1);
press(9); check('Start opens ☰', K.$(`menu.open`), true);
// held d-pad repeats in a menu, the way a held key does
K.$(`setMenuTab(TAB.system); menu.focus='list'; menu.cursor=0;`);
btn(13, true); poll(700); btn(13, false); poll(16);
ok('holding ▼ in a menu runs down the list', K.$(`menu.cursor`) >= 3, K.$(`menu.cursor`));
press(9);
// the Super Nintendo layout in the field: A (right) is Ⓐ, B (bottom) is Ⓑ
K.$(`padUse('snes');`);
K.$(`__bd=0;`); btn(0, true); poll(16); ok('on the Super Nintendo layout, B (bottom) guards', K.$(`__bd`) === 1); btn(0, false); poll(16);
K.$(`padUse('xbox');`);
K.$(`__bd=0;`); btn(0, true); poll(16); ok('…and on Xbox the bottom button does not', K.$(`__bd`) === 0); btn(0, false); poll(16);
// a quick potion from the pad
K.$(`inventory.potion=3; player.quickPot='potion'; player.hp=Math.max(1,player.maxHp-60); _lastPotAt=-1e9; for(const k in potFx||{}) delete potFx[k];`);
const hp0 = K.$(`player.hp`); press(2);
ok('X drinks the quick potion', K.$(`player.hp`) > hp0 && K.$(`inventory.potion`) === 2, [hp0, K.$(`player.hp`)]);
// ── changing a button ──
K.$(`menu.open=true; setMenuTab(TAB.system); menu.focus='list'; menu.cursor=menuRows().findIndex(r=>r.id==='pad'); menuSelect();`);
K.$(`menu.cursor=padRows().findIndex(r=>r.id==='potion'); pad.col=0; menuSelect();`);
ok('Ⓐ on a button: it waits for the controller', K.$(`!!pad.listen`));
btn(7, true); poll(16);
check('pressing RT binds it, takes it from Ⓐ, and the layout is now Custom', K.$(`[pad.cfg.binds.potion[0], pad.cfg.binds.act.indexOf(7), pad.cfg.layout]`), [7, -1, 'custom']);
btn(7, false); poll(16);
ok('…and that press did nothing else', K.$(`!pad.listen && menu.sub==='pad'`));
K.$(`menu.cursor=padRows().findIndex(r=>r.id==='surface'); pad.col=1; menuSelect();`);
K.key.down('Escape'); K.key.up('Escape');
check('Esc on a keyboard keeps a button as it was', K.$(`[!!pad.listen, pad.cfg.binds.surface[1], menu.sub]`), [false, null, 'pad']);
const saved = K.$(`localStorage.getItem('klk_pad')`);
K.$(`pad.cfg=null; padLoad();`);
check('saved on this computer: the custom buttons come back', K.$(`[pad.cfg.layout, pad.cfg.binds.potion[0]]`), ['custom', 7]);
ok('…the save file is not touched', !/klk_pad|"pad"/.test(K.$(`JSON.stringify(buildSaveData())`)) && !!saved);
K.$(`menu.cursor=padRows().findIndex(r=>r.kind==='padreset'); menuSelect();`);
check('Reset goes back to the Xbox layout', K.$(`[pad.cfg.layout, pad.cfg.binds.potion[0]]`), ['xbox', 2]);
K.$(`menu.cursor=padRows().length-1; menuSelect(); menu.open=false; gmEl().classList.remove('open');`);
// ── the keyboard map and the pad don't fight ──
K.$(`ctl.binds=ctlDefaults(); ctl.binds.right=['l',null]; for(const k in held) held[k]=false;`);
btn(15, true); poll(16); ok('a changed keyboard map leaves the pad alone (d-pad → still walks)', K.$(`held.right`) === true); btn(15, false); poll(16);
K.$(`ctl.binds=ctlDefaults();`);
// ── names, screens that want Enter, unplugging ──
check('a pad that says GameCube starts on the GameCube layout', K.$(`[padGuess('Mayflash GameCube Controller Adapter'), padGuess('8BitDo SN30 Pro'), padGuess('Wireless Controller')]`), ['gc', 'snes', 'xbox']);
check('Start on the title screen is Enter', K.$(`(()=>{ boot.done=false; const k=padKeyFor('menu'); boot.done=true; return k; })()`), 'Enter');
btn(15, true); poll(16); K.$(`navigator.getGamepads=()=>[null];`); poll(16);
ok('unplugged mid-step: nothing is left held down', K.$(`held.right`) === false && K.$(`Object.keys(pad.held).length`) === 0);
ok('real frames run with a pad in', K.$(`(()=>{ try{ navigator.getGamepads=()=>[__gp]; for(let i=0;i<4;i++) loop(performance.now()+i*16); return true; }catch(e){ return String(e.stack||e).slice(0,300); } })()`) === true);
K.$(`navigator.getGamepads=undefined; padReleaseAll(); pad.id='';`);
done('gamepad');

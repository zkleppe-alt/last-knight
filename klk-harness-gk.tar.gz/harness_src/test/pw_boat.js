const { chromium } = require('/home/claude/harness_src/test/node_modules/playwright');
(async()=>{ const out={};
 for(const f of ['index.html','index-phone.html']){
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const ctx=await b.newContext({viewport:{width:375,height:667},isMobile:true,hasTouch:true}); const p=await ctx.newPage();
  const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('file:///home/claude/harness_src/'+f); await p.waitForTimeout(2500);
  await p.evaluate(()=>{ boot.done=true; intro.open=false; place={kind:'overworld'};
    for(let i=decorations.length-1;i>=0;i--) if(decorations[i].kind==='boat') decorations.splice(i,1);
    decorations.push({x:93,y:291,kind:'boat',w:1,face:1}); player.x=94*TILE; player.y=291*TILE; player.boating=false; saveGame(1); });
  await p.reload(); await p.waitForTimeout(2500);
  const before=await p.evaluate(()=>{ const b=decorations.find(d=>d.kind==='boat'); return [b.x,b.y]; });
  await p.evaluate(()=>{ boot.done=true; intro.open=false; loadGame(1); });
  await p.waitForTimeout(1500);
  out[f]={freshPage:before, afterLoad:await p.evaluate(()=>{ const b=decorations.find(d=>d.kind==='boat'); return [b.x,b.y, Math.round(player.x/TILE), Math.round(player.y/TILE)]; }), errs};
  await b.close(); }
 console.log(JSON.stringify(out)); })();
